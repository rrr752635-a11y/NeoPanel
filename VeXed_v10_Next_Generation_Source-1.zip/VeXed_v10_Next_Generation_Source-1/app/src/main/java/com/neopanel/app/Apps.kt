package com.neopanel.app

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.ApplicationInfo
import android.graphics.drawable.Drawable
import org.json.JSONArray

class AppRow(val pkg: String, val label: String, val icon: Drawable?, val game: Boolean)

/** Daftar aplikasi, favorit, dan riwayat main yang dipakai bersama oleh layar utama dan launcher melayang. */
object Apps {
    private val hints = listOf(
        "pubg", "tencent", "mobilelegends", "moonton", "freefire", "garena", "supercell", "activision",
        "mihoyo", "hoyoverse", "roblox", "mojang", "epicgames", "netease", "riotgames", "lilithgames",
        "proximabeta", "levelinfinite", "gameloft", "konami", "ubisoft", "miniclip", "playrix", "habby",
        "krafton", "valve", "nintendo", "bandainamco", "kiloo", "rovio", "zynga", "scopely", "voodoo",
        "ketchapp", "innersloth", "devsisters", "nexon", "com.ea.", "unity3d", ".game", ".games"
    )

    @Suppress("DEPRECATION")
    fun isGame(ai: ApplicationInfo): Boolean {
        if (ai.category == ApplicationInfo.CATEGORY_GAME) return true
        if ((ai.flags and ApplicationInfo.FLAG_IS_GAME) != 0) return true
        val p = ai.packageName.lowercase()
        return hints.any { p.contains(it) }
    }

    /** Jalankan di thread latar. */
    fun load(ctx: Context): List<AppRow> {
        val pm = ctx.packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val out = ArrayList<AppRow>()
        val seen = HashSet<String>()
        for (ri in pm.queryIntentActivities(intent, 0)) {
            val ai = ri.activityInfo.applicationInfo
            val pkg = ai.packageName
            if (pkg == ctx.packageName || !seen.add(pkg)) continue
            val label = try { ri.loadLabel(pm).toString() } catch (e: Exception) { pkg }
            val icon = try { ri.loadIcon(pm) } catch (e: Exception) { null }
            out.add(AppRow(pkg, label, icon, isGame(ai)))
        }
        out.sortBy { it.label.lowercase() }
        return out
    }

    private fun readList(p: SharedPreferences, key: String): MutableList<String> = try {
        val a = JSONArray(p.getString(key, "[]"))
        val l = ArrayList<String>()
        for (i in 0 until a.length()) l.add(a.getString(i))
        l
    } catch (e: Exception) {
        ArrayList()
    }

    fun favs(p: SharedPreferences): MutableSet<String> = LinkedHashSet(readList(p, "favs"))

    fun saveFavs(p: SharedPreferences, s: Set<String>) {
        p.edit().putString("favs", JSONArray(s.toList()).toString()).apply()
    }

    fun recents(p: SharedPreferences): List<String> = readList(p, "recents")

    fun pushRecent(p: SharedPreferences, pkg: String) {
        val l = readList(p, "recents")
        l.remove(pkg)
        l.add(0, pkg)
        while (l.size > 12) l.removeAt(l.size - 1)
        p.edit().putString("recents", JSONArray(l).toString()).apply()
    }
}
