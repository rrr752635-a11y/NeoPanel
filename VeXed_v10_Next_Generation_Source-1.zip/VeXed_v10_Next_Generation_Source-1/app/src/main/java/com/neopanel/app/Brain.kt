package com.neopanel.app

class BrainCtx(
    val ram: Int, val temp: Int, val battery: Int, val fps: Int, val ping: Int,
    val game: String, val sessionMin: Long
)

/**
 * VeXed AI bawaan: asisten lokal berbasis pengetahuan dan aturan (bukan model bahasa besar).
 * Jalan tanpa internet dan tanpa kunci API. Mengingat topik terakhir dalam sesi supaya
 * jawaban "iya" / "lanjut" / "gimana caranya" terasa nyambung, tanpa menyimpan isi obrolan.
 */
object VexBrain {
    private var lastTopic: String? = null
    private val rnd = java.util.Random()
    private fun <T> List<T>.pick(): T = this[rnd.nextInt(size)]

    private class Rule(val id: String, val words: List<String>, val weight: Int = 2, val out: (BrainCtx) -> String)

    // --- pencocokan berbasis kata, bukan substring, supaya "ping" tidak kena "kucing" ---
    private fun tokens(q: String): Set<String> =
        Regex("[a-z0-9]+").findAll(q.lowercase()).map { it.value }.toSet()

    private fun fpsAdvice(c: BrainCtx): String {
        val now = if (c.fps in 1..240) "FPS-mu sekarang sekitar ${c.fps}. " else ""
        val extra = when {
            c.temp >= 42 -> "Kemungkinan besar penyebabnya suhu HP yang sudah ${c.temp}°C, jadi performanya otomatis diturunkan sistem. "
            c.ram >= 85 -> "RAM-mu juga sudah ${c.ram}%, itu ikut bikin lag. "
            else -> ""
        }
        return now + extra + "Urutan yang biasanya paling ngaruh: (1) nyalakan Mode Game di tab BOOSTER, (2) turunkan grafis/bayangan di game-nya sendiri, " +
            "(3) bersihkan RAM, (4) lepas casing dan jauhkan dari colokan saat main, (5) kunci refresh rate ke angka yang stabil, bukan yang tertinggi."
    }

    private fun heatAdvice(c: BrainCtx): String {
        val t = if (c.temp > 0) "Suhu baterai sekarang ${c.temp}°C. " else ""
        val lvl = when {
            c.temp >= 45 -> "Itu sudah panas sekali, istirahatkan HP-nya dulu beberapa menit, jangan sambil dicas. "
            c.temp >= 40 -> "Itu mulai hangat, masih aman tapi perlu diawasi. "
            else -> ""
        }
        return t + lvl + "Caranya: lepas casing, jangan main sambil mengisi daya, turunkan kecerahan dan refresh rate, lalu kalau masih naik terus, istirahat dulu."
    }

    private fun netAdvice(c: BrainCtx): String {
        val p = if (c.ping in 0..999) "Ping-mu sekarang ${c.ping} ms. " else ""
        return p + "Supaya lebih stabil: dekati router atau pakai jaringan 5 GHz, tutup aplikasi yang lagi unduh, coba DNS Cepat di tab JARINGAN, dan hindari main bareng orang lain yang sedang streaming di jaringan yang sama."
    }

    private val rules: List<Rule> = listOf(
        Rule("project", listOf("project", "projek", "aplikasi", "apk", "coding", "kode", "program", "gui", "desain", "update"), 3) {
            "Oke, kita pecah jadi langkah kecil: tentukan bagian yang mau diubah, cek file terkait, lalu implementasi tanpa merusak fitur lama. Kirim nama file atau jelaskan hasil yang kamu inginkan, nanti aku bantu susun perubahannya."
        },
        Rule("belajar", listOf("belajar", "jelasin", "jelaskan", "paham", "materi", "contoh"), 2) {
            "Bisa. Aku jelaskan dari dasar dulu, pakai contoh sederhana, lalu kita coba satu contoh bareng. Bagian mana yang paling bikin bingung?"
        },
        Rule("fps", listOf("fps", "lag", "patah", "ngelag", "nge", "drop", "nglag", "fresrate", "stutter"), 3) { fpsAdvice(it) },
        Rule("panas", listOf("panas", "suhu", "overheat", "hangat", "kepanasan"), 3) { heatAdvice(it) },
        Rule("net", listOf("ping", "koneksi", "jaringan", "sinyal", "delay", "wifi", "data", "internet", "lemot", "lelet"), 3) { netAdvice(it) },
        Rule("baterai", listOf("baterai", "boros", "charger", "cas", "ngecas", "batre", "batere"), 2) { c ->
            "Baterai ${c.battery}%. Hemat baterai: turunkan kecerahan, kunci refresh ke 60 Hz, matikan HUD detail, dan jangan main sambil dicas kalau bisa."
        },
        Rule("ram", listOf("ram", "memori", "memory", "penuh", "berat"), 2) { c ->
            "RAM terpakai ${c.ram}%. Ketuk Bersihkan RAM di tab BOOSTER, atau tinggal bilang \"bersihkan ram\" ke aku. Boost butuh Shizuku aktif."
        },
        Rule("crosshair", listOf("crosshair", "bidik", "sight", "aim"), 2) {
            "Tahan tile Crosshair di tab GAME untuk atur bentuk, warna, ukuran, celah, transparansi, dan posisinya. Ketuk tilenya buat tampil/sembunyikan."
        },
        Rule("launcher", listOf("launcher", "profil", "daftar")) {
            "Buka game dari Launcher: ketuk buat membuka, tahan buat atur profil khusus (HUD, crosshair, boost, DND, dan lainnya aktif otomatis tiap game ini dibuka)."
        },
        Rule("youtube", listOf("youtube", "musik", "lagu", "nonton", "video", "yt"), 2) {
            "Tile YouTube di tab GAME buka pemutar melayang tanpa kunci API. Tarik sudut kanan-bawah buat ubah ukuran, ketuk Ketik kalau mau cari video."
        },
        Rule("voice", listOf("voice", "suara", "soundboard", "changer")) {
            "Voice changer ada 12 efek, butuh izin mikrofon (Setelan > Izin mikrofon). Pakai headset biar nggak berdengung. Hasilnya cuma diputar di HP ini, nggak masuk ke voice chat game tanpa root."
        },
        Rule("lock", listOf("kunci", "lock", "pin", "privasi", "sidik", "fingerprint"), 2) {
            "Kunci Aplikasi ada di tab Kunci: buat PIN, nyalakan layanan aksesibilitas, lalu nyalakan kuncinya. Semua app dikunci kecuali yang kamu bebaskan di daftar. Kalau toggle-nya nggak bisa dipencet, itu pembatasan Android buat app sideload, ada tombol penjelasnya di tab Kunci juga."
        },
        Rule("shizuku", listOf("shizuku", "rish", "overlay", "izin")) {
            "Shizuku buka FPS asli, Boost, dan screenshot buat robot. Nyalakan Wireless Debugging, lalu Hubungkan Shizuku di Beranda. Perintah rish ada di Setelan bagian Cadangan."
        },
        Rule("api", listOf("gemini", "api", "token", "kunci", "model")) {
            "Buat obrolan bebas yang lebih luwes, isi kunci Gemini atau API lain lewat Setelan > Atur kunci API & model robot. Tanpa kunci, aku (VeXed AI bawaan) tetap bisa bantu soal fitur VeXed dan tips performa."
        },
        Rule("terjemah", listOf("terjemah", "translate", "bahasa")) {
            "Tile Penerjemah di tab GAME bisa buat teks atau layar. Fitur ini butuh kunci API; mode layar juga butuh Shizuku."
        },
        Rule("stats", listOf("statistik", "layar", "berapa", "lama", "screentime")) { c ->
            val s = if (c.sessionMin > 0) "Sesi ${c.game.ifEmpty { "game ini" }} udah jalan ${c.sessionMin} menit. " else ""
            s + "Waktu layar harian per aplikasi ada di Beranda, perlu layanan Kunci aktif dulu."
        },
        Rule("tips", listOf("tips", "saran", "rekomendasi", "gimana", "cara")) { c ->
            when {
                c.temp >= 42 -> heatAdvice(c)
                c.fps in 1..30 -> fpsAdvice(c)
                c.ram >= 85 -> "RAM kamu udah ${c.ram}%. Bersihkan RAM dulu sebelum lanjut main."
                else -> "Kondisi HP-mu lagi aman kok: RAM ${c.ram}%, suhu ${c.temp}°C, baterai ${c.battery}%. Nyalain Mode Game buat performa terbaik, dan jangan lupa istirahat tiap 45 menit."
            }
        },
        Rule("fitur", listOf("fitur", "bisa", "apa", "bantu")) {
            "Aku bisa bantu atur fitur VeXed, launcher, HUD, crosshair, Mode Game, RAM, penerjemah, voice changer, dan tips performa. Aku juga bisa bantu brainstorming project dan belajar langkah demi langkah. Untuk jawaban online yang lebih luas, hubungkan penyedia AI di Setelan."
        },
        Rule("robot", listOf("vex", "robot", "kamu", "namamu", "siapa")) {
            "Aku Vex, asisten VeXed. Mode bawaan berjalan offline dengan kemampuan terbatas; kalau penyedia AI/API disambungkan, obrolan bisa lebih luas. Aku bakal berusaha jelas, santai, dan nggak asal mengarang."
        },
        Rule("sapa", listOf("halo", "hai", "hi", "pagi", "siang", "sore", "malam", "assalamualaikum")) { c ->
            listOf(
                "Halo, Kak! Kondisi HP: RAM ${c.ram}%, suhu ${c.temp}°C, baterai ${c.battery}%. Mau ngapain?",
                "Hai! Siap bantu. Ada yang mau diatur atau ditanyain?",
                "Halo~ aku standby di sini. Butuh HUD, crosshair, atau tips performa?"
            ).pick()
        },
        Rule("makasih", listOf("makasih", "terima", "thanks", "thx", "mantap", "sip")) {
            listOf("Sama-sama, Kak!", "Siap, senang bisa bantu!", "Yuk lanjut main, aku standby kalau butuh lagi.").pick()
        },
        Rule("emosi", listOf("bosan", "capek", "lelah", "sedih", "kesal", "bete", "ngantuk")) {
            "Istirahat sebentar penting banget. Minum dulu, regangkan badan, baru lanjut main kalau udah segar. Aku di sini kalau butuh teman."
        },
        Rule("ya", listOf("ya", "iya", "boleh", "lanjut", "gas", "oke", "ok"), 1) { c ->
            when (lastTopic) {
                "fps" -> fpsAdvice(c)
                "panas" -> heatAdvice(c)
                "net" -> netAdvice(c)
                else -> "Oke! Mau aku bantu apa persisnya, Kak? Bisa sebut fitur atau masalahnya."
            }
        }
    )

    fun reply(q: String, c: BrainCtx, style: Int): String {
        val t = tokens(q)
        var best: Rule? = null
        var bestScore = 0
        for (r in rules) {
            var sc = 0
            for (w in r.words) if (w in t) sc += r.weight
            if (sc > bestScore) { bestScore = sc; best = r }
        }
        if (best == null) {
            return when (style) {
                0 -> "Hmm, aku belum punya jawaban yang cukup akurat buat itu. Ini soal aplikasi, game, HP, atau project yang sedang kamu buat? Ceritakan sedikit konteksnya, nanti kita pecahkan satu-satu."
                1 -> "Belum nangkep konteksnya nih 😅 Ini lagi bahas aplikasi, game, HP, atau project? Kasih detail sedikit, nanti kita bedah bareng."
                else -> "Saya belum memiliki informasi yang cukup untuk menjawab dengan tepat. Bisa berikan konteks atau contoh yang dimaksud?"
            }
        }
        lastTopic = best.id
        return best.out(c)
    }
}
