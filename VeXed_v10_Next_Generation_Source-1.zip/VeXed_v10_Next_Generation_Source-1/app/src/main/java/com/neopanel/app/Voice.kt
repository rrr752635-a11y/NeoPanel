package com.neopanel.app

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaRecorder
import android.os.Process

/** Pengubah suara real-time: mikrofon -> efek -> speaker/headset. Butuh izin RECORD_AUDIO. */
class VoiceEngine {
    companion object {
        val NAMES = listOf(
            "Normal", "Tupai", "Berat", "Robot", "Alien", "Gema",
            "Radio", "Megafon", "Monster", "Wanita", "Pria", "Kaleng"
        )
    }

    @Volatile var preset = 0
    @Volatile var gain = 1.0f
    @Volatile var gate = 0.0f          // ambang noise gate (0..0.1)
    @Volatile var level = 0f           // 0..1 untuk meter
    @Volatile var running = false
        private set
    private var thread: Thread? = null

    private val rate = 16000
    private val size = 4096
    private val mask = size - 1
    private val buf = FloatArray(size)
    private var w = 0
    private var ph = 0f
    private val win = 1024f
    private var rm = 0.0
    private val esize = 8192
    private val echo = FloatArray(esize)
    private var ew = 0
    private val comb = FloatArray(256)
    private var cw = 0
    private var hp = 0f
    private var lp = 0f
    private var prevIn = 0f

    // rekaman 8 detik terakhir (hasil efek) untuk diputar ulang
    private val ring = ShortArray(rate * 8)
    private var rpos = 0
    @Volatile private var rcount = 0

    val hasRecording: Boolean get() = rcount > rate

    private fun ratio(p: Int): Float = when (p) {
        1 -> 1.6f
        2 -> 0.7f
        3 -> 0.92f
        4 -> 1.3f
        8 -> 0.55f
        9 -> 1.28f
        10 -> 0.78f
        else -> 1f
    }

    private fun tap(d: Float): Float {
        val pos = w - d
        val i0 = Math.floor(pos.toDouble()).toInt()
        val f = pos - i0
        val a = buf[i0 and mask]
        val b = buf[(i0 + 1) and mask]
        return a + (b - a) * f
    }

    private fun process(x: Float, p: Int): Float {
        buf[w and mask] = x
        var y = x
        val r = ratio(p)
        if (r != 1f) {
            ph += (1f - r) / win
            if (ph >= 1f) ph -= 1f
            if (ph < 0f) ph += 1f
            val d1 = ph * win + 2f
            var p2 = ph + 0.5f
            if (p2 >= 1f) p2 -= 1f
            val d2 = p2 * win + 2f
            val s = Math.sin(Math.PI * ph).toFloat()
            val g1 = s * s
            y = tap(d1) * g1 + tap(d2) * (1f - g1)
        }
        w++
        when (p) {
            3, 4, 8 -> {
                val f = if (p == 3) 70.0 else if (p == 4) 35.0 else 25.0
                rm += 2.0 * Math.PI * f / rate
                if (rm > 2.0 * Math.PI) rm -= 2.0 * Math.PI
                val depth = if (p == 8) 0.5 else 0.9
                y *= (1.0 - depth + depth * Math.abs(Math.sin(rm))).toFloat() * 1.3f
            }
            5 -> {
                val e = echo[(ew - 4000) and (esize - 1)]
                y += e * 0.45f
                echo[ew and (esize - 1)] = y
                ew++
            }
            6 -> {
                // band-pass sempit + sedikit distorsi, seperti radio/telepon
                hp += 0.08f * (y - hp)
                val hi = y - hp
                lp += 0.45f * (hi - lp)
                y = Math.tanh((lp * 2.2f).toDouble()).toFloat() * 0.9f
            }
            7 -> {
                hp += 0.18f * (y - hp)
                y = Math.tanh(((y - hp) * 4.0f).toDouble()).toFloat() * 0.8f
            }
            11 -> {
                val d = comb[(cw - 70) and 255]
                comb[cw and 255] = y + d * 0.6f
                cw++
                y = (y + d * 0.8f) * 0.7f
            }
        }
        return y
    }

    /** Mengembalikan pesan error, atau null kalau berhasil. */
    fun start(): String? {
        if (running) return null
        val minIn = AudioRecord.getMinBufferSize(rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val minOut = AudioTrack.getMinBufferSize(rate, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
        if (minIn <= 0 || minOut <= 0) return "perangkat tidak mendukung"
        val rec = try {
            AudioRecord(
                MediaRecorder.AudioSource.MIC, rate, AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT, minIn * 2
            )
        } catch (e: Throwable) {
            return "izin mikrofon belum diberikan"
        }
        if (rec.state != AudioRecord.STATE_INITIALIZED) {
            rec.release()
            return "mikrofon tidak bisa dibuka (izin atau dipakai app lain)"
        }
        val trk = try {
            AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build()
                )
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setSampleRate(rate)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build()
                )
                .setBufferSizeInBytes(minOut * 2)
                .setTransferMode(AudioTrack.MODE_STREAM)
                .setPerformanceMode(AudioTrack.PERFORMANCE_MODE_LOW_LATENCY)
                .build()
        } catch (e: Throwable) {
            rec.release()
            return "gagal membuka keluaran audio"
        }
        running = true
        thread = Thread {
            try {
                Process.setThreadPriority(Process.THREAD_PRIORITY_URGENT_AUDIO)
                rec.startRecording()
                trk.play()
                val b = ShortArray(512)
                while (running) {
                    val n = rec.read(b, 0, b.size)
                    if (n <= 0) continue
                    val p = preset
                    val g = gain
                    var peak = 0f
                    for (i in 0 until n) {
                        val a = Math.abs(b[i] / 32768f)
                        if (a > peak) peak = a
                    }
                    val open = peak >= gate
                    for (i in 0 until n) {
                        val xin = b[i] / 32768f
                        var y = process(if (open) xin else 0f, p) * g
                        if (y > 1f) y = 1f else if (y < -1f) y = -1f
                        val sv = (y * 32767f).toInt().toShort()
                        b[i] = sv
                        ring[rpos] = sv
                        rpos++
                        if (rpos >= ring.size) rpos = 0
                    }
                    if (rcount < ring.size) rcount = minOf(ring.size, rcount + n)
                    level = if (open) minOf(1f, peak * 3f * g) else 0f
                    trk.write(b, 0, n)
                }
            } catch (e: Throwable) {
            } finally {
                try { rec.stop() } catch (e: Throwable) { }
                rec.release()
                try { trk.stop() } catch (e: Throwable) { }
                trk.release()
                running = false
                level = 0f
            }
        }.also { it.start() }
        return null
    }

    fun stop() {
        running = false
        thread = null
    }

    /** Putar ulang rekaman terakhir (hasil efek). */
    fun replay(): Boolean {
        val cnt = rcount
        if (cnt < rate) return false
        val out = ShortArray(cnt)
        val start = if (cnt < ring.size) 0 else rpos
        for (i in 0 until cnt) out[i] = ring[(start + i) % ring.size]
        Thread {
            try {
                val t = AudioTrack.Builder()
                    .setAudioAttributes(
                        AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build()
                    )
                    .setAudioFormat(
                        AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                            .setSampleRate(rate).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build()
                    )
                    .setBufferSizeInBytes(out.size * 2)
                    .setTransferMode(AudioTrack.MODE_STATIC)
                    .build()
                t.write(out, 0, out.size)
                t.play()
                Thread.sleep(out.size * 1000L / rate + 200)
                t.release()
            } catch (e: Throwable) {
            }
        }.start()
        return true
    }
}
