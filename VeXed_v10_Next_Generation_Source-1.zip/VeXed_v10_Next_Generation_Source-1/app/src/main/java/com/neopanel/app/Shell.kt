package com.neopanel.app

import android.content.pm.PackageManager
import rikka.shizuku.Shizuku
import java.lang.reflect.Method

/** Menjalankan perintah shell lewat Shizuku (uid shell), atau lokal bila tidak tersedia. */
object Sh {
    private var m: Method? = null

    private fun method(): Method? {
        if (m == null) {
            try {
                val mm = Shizuku::class.java.getDeclaredMethod(
                    "newProcess",
                    Array<String>::class.java,
                    Array<String>::class.java,
                    String::class.java
                )
                mm.isAccessible = true
                m = mm
            } catch (e: Throwable) {
            }
        }
        return m
    }

    fun ready(): Boolean = try {
        Shizuku.pingBinder() && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
    } catch (e: Throwable) {
        false
    }

    fun start(cmd: String): Process? = try {
        method()?.invoke(null, arrayOf("sh", "-c", cmd), null, null) as? Process
    } catch (e: Throwable) {
        null
    }

    fun run(cmd: String): String {
        val p = start(cmd) ?: return ""
        return try {
            val out = p.inputStream.bufferedReader().readText()
            p.waitFor()
            out
        } catch (e: Throwable) {
            ""
        }
    }

    fun local(cmd: String): String = try {
        val p = ProcessBuilder("sh", "-c", cmd).redirectErrorStream(true).start()
        val o = p.inputStream.bufferedReader().readText()
        p.waitFor()
        o
    } catch (e: Exception) {
        ""
    }

    /** Proses panjang (streaming): lewat Shizuku bila siap, kalau tidak shell lokal. */
    fun startSys(cmd: String): Process? = try {
        if (ready()) start(cmd) else ProcessBuilder("sh", "-c", cmd).redirectErrorStream(true).start()
    } catch (e: Throwable) {
        null
    }

    fun sys(cmd: String): String = if (ready()) run(cmd) else local(cmd)
}
