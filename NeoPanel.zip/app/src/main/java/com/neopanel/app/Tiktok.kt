package com.neopanel.app

import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.regex.Pattern

/**
 * Pengambil video TikTok tanpa watermark, ditulis dari nol pakai Kotlin + org.json
 * (bukan scraper Node.js yang ditemukan pengguna). Caranya: baca halaman web TikTok,
 * ambil blok JSON bawaan halamannya (__UNIVERSAL_DATA_FOR_REHYDRATION__), lalu cari
 * tautan videonya. Watermark TikTok di web itu overlay tampilan, bukan nempel di file
 * videonya, jadi file yang didapat dari sini biasanya sudah bersih.
 *
 * Ini scraping halaman publik TikTok (bukan membobol atau mengakali sistem berbayar
 * siapa pun), tapi tetap tidak resmi: bisa berhenti berfungsi kapan saja kalau TikTok
 * mengubah struktur halamannya.
 */
object Tiktok {
    class Info(val desc: String, val author: String, val videoUrl: String, val cover: String)

    private const val UA = "Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 " +
        "(KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36"

    private val linkPattern = Pattern.compile(
        "(https?://)?(www.|vm.|vt.|m.)?tiktok.com/[^\\s]+", Pattern.CASE_INSENSITIVE
    )

    /** Cari tautan TikTok pertama di dalam sebuah kalimat bebas. Null kalau tidak ada. */
    fun findLink(text: String): String? {
        val m = linkPattern.matcher(text)
        if (!m.find()) return null
        var raw = m.group().trimEnd('.', ',', ')', ']')
        if (!raw.startsWith("http")) raw = "https://" + raw
        return raw
    }

    private fun get(url: String, followRedirect: Boolean): HttpURLConnection {
        val con = URL(url).openConnection() as HttpURLConnection
        con.instanceFollowRedirects = followRedirect
        con.connectTimeout = 12000
        con.readTimeout = 15000
        con.setRequestProperty("User-Agent", UA)
        con.setRequestProperty("Accept-Language", "en-US,en;q=0.9,id;q=0.8")
        con.setRequestProperty("Referer", "https://www.tiktok.com/")
        return con
    }

    /** Ikuti tautan pendek (vm.tiktok.com / vt.tiktok.com) sampai ke URL video yang panjang. */
    private fun resolve(url: String): String {
        var cur = url
        for (i in 0 until 5) {
            val con = get(cur, false)
            try {
                val code = con.responseCode
                if (code in 300..399) {
                    val loc = con.getHeaderField("Location") ?: return cur
                    cur = if (loc.startsWith("http")) loc else "https://www.tiktok.com" + loc
                } else {
                    return cur
                }
            } finally {
                con.disconnect()
            }
        }
        return cur
    }

    private fun extractJson(html: String): JSONObject? {
        val marker = "id=" + "\"" + "__UNIVERSAL_DATA_FOR_REHYDRATION__" + "\""
        val m = html.indexOf(marker)
        if (m == -1) return null
        val start = html.indexOf('>', m) + 1
        val end = html.indexOf("</script>", start)
        if (start <= 0 || end == -1) return null
        return try { JSONObject(html.substring(start, end)) } catch (e: Exception) { null }
    }

    /** Coba beberapa kemungkinan letak data video di dalam JSON halaman (bisa berubah-ubah). */
    private fun findItemStruct(root: JSONObject): JSONObject? {
        try {
            val scope = root.optJSONObject("__DEFAULT_SCOPE__") ?: return null
            val detail = scope.optJSONObject("webapp.video-detail")
            val item = detail?.optJSONObject("itemInfo")?.optJSONObject("itemStruct")
            if (item != null) return item
        } catch (e: Exception) {
        }
        return null
    }

    /** Jalankan di thread latar. Melempar Exception berisi pesan yang bisa ditampilkan ke pengguna. */
    fun fetch(rawUrl: String): Info {
        val full = resolve(rawUrl)
        val con = get(full, true)
        val html: String
        try {
            val code = con.responseCode
            if (code !in 200..299) throw RuntimeException("halaman TikTok membalas kode " + code)
            html = con.inputStream.bufferedReader().use { it.readText() }
        } finally {
            con.disconnect()
        }
        val root = extractJson(html) ?: throw RuntimeException("format halaman TikTok tidak dikenali (mungkin berubah)")
        val item = findItemStruct(root) ?: throw RuntimeException("videonya tidak ditemukan di halaman (privat/dihapus?)")
        val video = item.optJSONObject("video") ?: throw RuntimeException("data video tidak lengkap")
        val addr = video.optString("playAddr").ifBlank { video.optString("downloadAddr") }
        if (addr.isBlank()) throw RuntimeException("tautan video tidak ditemukan")
        val author = item.optJSONObject("author")?.optString("uniqueId") ?: "?"
        val desc = item.optString("desc")
        val cover = video.optString("cover").ifBlank { video.optString("originCover") }
        return Info(desc, author, addr, cover)
    }

    /** Unduh byte video. Dibatasi 80 MB sebagai jaga-jaga. Jalankan di thread latar. */
    fun download(info: Info, outFile: java.io.File): Long {
        val con = get(info.videoUrl, true)
        try {
            val code = con.responseCode
            if (code !in 200..299) throw RuntimeException("gagal mengunduh video (kode " + code + ")")
            var total = 0L
            val cap = 80L * 1024 * 1024
            con.inputStream.use { ins ->
                outFile.outputStream().use { out ->
                    val buf = ByteArray(16 * 1024)
                    while (true) {
                        val n = ins.read(buf)
                        if (n <= 0) break
                        total += n
                        if (total > cap) throw RuntimeException("video terlalu besar (>80 MB)")
                        out.write(buf, 0, n)
                    }
                }
            }
            return total
        } finally {
            con.disconnect()
        }
    }
}
