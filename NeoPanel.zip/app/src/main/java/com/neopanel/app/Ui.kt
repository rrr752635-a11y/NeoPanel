package com.neopanel.app

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorFilter
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.drawable.Drawable
import android.view.View

/**
 * Latar kaca buram ala "liquid glass": kotak membulat, semi-transparan, dengan kilau diagonal
 * tipis di bagian atas dan garis tepi terang. Dipadukan dengan FLAG_BLUR_BEHIND di jendela
 * (Android 12+) supaya yang ada di belakang jendela ikut buram sungguhan.
 */
class GlassDrawable(
    private val tint: Int,
    private val edge: Int,
    private val radius: Float,
    private val d: Float,
    private val tintAlpha: Int = 52
) : Drawable() {
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val sheen = Paint(Paint.ANTI_ALIAS_FLAG)
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val rect = RectF()
    private val path = Path()

    override fun onBoundsChange(bounds: Rect) {
        super.onBoundsChange(bounds)
        val w = bounds.width().toFloat()
        val h = bounds.height().toFloat()
        rect.set(0f, 0f, w, h)
        path.reset()
        path.addRoundRect(rect, radius, radius, Path.Direction.CW)
        fill.shader = LinearGradient(
            0f, 0f, 0f, h,
            (tint and 0x00FFFFFF) or (tintAlpha shl 24),
            0x0B0D14 or ((tintAlpha * 2 / 3) shl 24),
            Shader.TileMode.CLAMP
        )
        sheen.shader = LinearGradient(
            0f, 0f, w * 0.65f, h * 0.55f,
            0x2FFFFFFF, 0x00FFFFFF, Shader.TileMode.CLAMP
        )
    }

    override fun draw(canvas: Canvas) {
        canvas.save()
        canvas.translate(bounds.left.toFloat(), bounds.top.toFloat())
        canvas.drawPath(path, fill)
        canvas.save()
        canvas.clipPath(path)
        canvas.drawPath(path, sheen)
        canvas.restore()
        line.strokeWidth = 1.3f * d
        line.color = 0x55FFFFFF
        canvas.drawPath(path, line)
        line.strokeWidth = 1f * d
        line.color = (edge and 0x00FFFFFF) or 0x40000000
        val inset = 1.6f * d
        rect.set(inset, inset, bounds.width() - inset, bounds.height() - inset)
        val r2 = (radius - inset).coerceAtLeast(0f)
        path.reset()
        path.addRoundRect(rect, r2, r2, Path.Direction.CW)
        canvas.drawPath(path, line)
        canvas.restore()
        // kembalikan path ke ukuran penuh untuk gambar berikutnya
        path.reset()
        rect.set(0f, 0f, bounds.width().toFloat(), bounds.height().toFloat())
        path.addRoundRect(rect, radius, radius, Path.Direction.CW)
    }

    override fun setAlpha(alpha: Int) {}
    override fun setColorFilter(cf: ColorFilter?) {}
    override fun getOpacity(): Int = PixelFormat.TRANSLUCENT
}

/** Latar bersudut tajam (sudut kiri-atas dan kanan-bawah dipotong) dengan garis neon. */
class ChamferDrawable(
    private val top: Int,
    private val bottom: Int,
    private val edge: Int,
    private val cut: Float,
    private val d: Float,
    private val glow: Boolean = true
) : Drawable() {
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeJoin = Paint.Join.MITER
    }
    private val path = Path()
    private var w = 0f
    private var h = 0f
    private var c = 0f
    private var m = 0f

    override fun onBoundsChange(bounds: Rect) {
        super.onBoundsChange(bounds)
        w = bounds.width().toFloat()
        h = bounds.height().toFloat()
        m = if (glow) 2.5f * d else 0.6f * d
        c = minOf(cut, (w - 2 * m) / 3f, (h - 2 * m) / 3f)
        if (c < 0f) c = 0f
        fill.shader = LinearGradient(0f, 0f, 0f, h, top, bottom, Shader.TileMode.CLAMP)
        path.reset()
        path.moveTo(m + c, m)
        path.lineTo(w - m, m)
        path.lineTo(w - m, h - m - c)
        path.lineTo(w - m - c, h - m)
        path.lineTo(m, h - m)
        path.lineTo(m, m + c)
        path.close()
    }

    override fun draw(canvas: Canvas) {
        canvas.save()
        canvas.translate(bounds.left.toFloat(), bounds.top.toFloat())
        canvas.drawPath(path, fill)
        line.strokeCap = Paint.Cap.BUTT
        line.color = edge
        if (glow) {
            line.alpha = 38
            line.strokeWidth = 5f * d
            canvas.drawPath(path, line)
            line.alpha = 90
            line.strokeWidth = 3f * d
            canvas.drawPath(path, line)
        }
        line.color = edge
        line.strokeWidth = 1.2f * d
        canvas.drawPath(path, line)
        if (glow) {
            line.strokeWidth = 3f * d
            val l = 26f * d
            val g = 6f * d
            canvas.drawLine(m + c + g, m, m + c + g + l, m, line)
            canvas.drawLine(w - m - c - g - l, h - m, w - m - c - g, h - m, line)
        }
        canvas.restore()
    }

    override fun setAlpha(alpha: Int) {}
    override fun setColorFilter(colorFilter: ColorFilter?) {}
    @Deprecated("Deprecated in Java")
    override fun getOpacity(): Int = PixelFormat.TRANSLUCENT
}

/** Logo VeXed: V putih di atas, X-ekor merah di bawah. */
object Brand {
    private val t1 = floatArrayOf(10f, 10f, 28f, 10f, 57.25f, 55f, 39.25f, 55f)
    private val t2 = floatArrayOf(90f, 10f, 72f, 10f, 42.75f, 55f, 60.75f, 55f)
    private val b1 = floatArrayOf(40.55f, 57f, 58.55f, 57f, 80f, 90f, 62f, 90f)
    private val b2 = floatArrayOf(59.45f, 57f, 41.45f, 57f, 20f, 90f, 38f, 90f)

    private fun poly(c: Canvas, a: FloatArray, k: Float, p: Paint) {
        val path = Path()
        path.moveTo(a[0] * k, a[1] * k)
        var i = 2
        while (i < a.size) {
            path.lineTo(a[i] * k, a[i + 1] * k)
            i += 2
        }
        path.close()
        c.drawPath(path, p)
    }

    /** Logo VeXed, versi "Liquid Glass": tiap kaki huruf V diberi gradien halus dan kilau tipis. */
    fun draw(c: Canvas, s: Float, topColor: Int, bottomColor: Int) {
        val k = s / 100f
        val p = Paint(Paint.ANTI_ALIAS_FLAG)

        fun lighten(col: Int, amt: Float): Int {
            val r = (Color.red(col) + (255 - Color.red(col)) * amt).toInt().coerceIn(0, 255)
            val g = (Color.green(col) + (255 - Color.green(col)) * amt).toInt().coerceIn(0, 255)
            val b = (Color.blue(col) + (255 - Color.blue(col)) * amt).toInt().coerceIn(0, 255)
            return Color.rgb(r, g, b)
        }

        p.shader = LinearGradient(0f, 0f, 0f, 56f * k, lighten(topColor, 0.35f), topColor, Shader.TileMode.CLAMP)
        poly(c, t1, k, p)
        poly(c, t2, k, p)
        p.shader = LinearGradient(0f, 56f * k, 0f, 90f * k, bottomColor, Color.argb(255,
            (Color.red(bottomColor) * 0.72f).toInt(), (Color.green(bottomColor) * 0.72f).toInt(), (Color.blue(bottomColor) * 0.72f).toInt()
        ), Shader.TileMode.CLAMP)
        poly(c, b1, k, p)
        poly(c, b2, k, p)
        p.shader = null

        // kilau tipis di puncak kedua kaki atas, ciri khas gaya kaca
        p.color = Color.argb(140, 255, 255, 255)
        val shine = Path()
        shine.moveTo(t1[0] * k + 1.5f * k, t1[1] * k + 1.5f * k)
        shine.lineTo(t1[2] * k - 1.5f * k, t1[3] * k + 1.5f * k)
        shine.lineTo(t1[2] * k - 3.5f * k, t1[3] * k + 7f * k)
        shine.lineTo(t1[0] * k + 3.5f * k, t1[1] * k + 7f * k)
        shine.close()
        c.drawPath(shine, p)
    }
}

class LogoView(ctx: Context, private val topColor: Int, private val bottomColor: Int) : View(ctx) {
    override fun onDraw(canvas: Canvas) {
        Brand.draw(canvas, minOf(width, height).toFloat(), topColor, bottomColor)
    }
}

/** Ikon vektor digambar lewat Canvas (grid 24x24), tanpa emoji. */
object Icons {
    const val CROSSHAIR = 0
    const val DND = 1
    const val CHART = 2
    const val GLOBE = 3
    const val NOTE = 4
    const val CALC = 5
    const val TIMER = 6
    const val BOLT = 7
    const val ROCKET = 8
    const val SUN = 9
    const val LOCK = 10
    const val GEAR = 11
    const val CPU = 12
    const val THERMO = 13
    const val PHONEOFF = 14
    const val HEADSET = 15
    const val REC = 16
    const val CAMERA = 17
    const val MIC = 18
    const val SPEAKER = 19
    const val WIFI = 20
    const val TOUCH = 21
    const val EYE = 22
    const val BELLOFF = 23
    const val MEM = 24
    const val DATA = 25
    const val SHIELD = 26
    const val ANIM = 27
    const val SAT = 28
    const val CLOSE = 29
    const val BACK = 30
    const val PLUS = 31
    const val TRASH = 32
    const val COPY = 33
    const val SHOT = 34
    const val FLASH = 35
    const val ROBOT = 36
    const val CLOCK = 37
    const val GAME = 38
    const val PLAY = 39
    const val STAR = 40
    const val SEND = 41
    const val FINGERPRINT = 42
    const val CHECK = 43

    fun draw(c: Canvas, id: Int, s: Float, color: Int) {
        val u = s / 24f
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.color = color
        p.style = Paint.Style.STROKE
        p.strokeWidth = 1.9f * u
        p.strokeCap = Paint.Cap.ROUND
        p.strokeJoin = Paint.Join.ROUND
        val f = Paint(Paint.ANTI_ALIAS_FLAG)
        f.color = color
        f.style = Paint.Style.FILL

        fun ln(a: Number, b: Number, x: Number, y: Number) =
            c.drawLine(a.toFloat() * u, b.toFloat() * u, x.toFloat() * u, y.toFloat() * u, p)

        fun ci(x: Number, y: Number, r: Number, fill: Boolean = false) =
            c.drawCircle(x.toFloat() * u, y.toFloat() * u, r.toFloat() * u, if (fill) f else p)

        fun rr(l: Number, t: Number, r: Number, b: Number, rad: Number = 2) =
            c.drawRoundRect(
                RectF(l.toFloat() * u, t.toFloat() * u, r.toFloat() * u, b.toFloat() * u),
                rad.toFloat() * u, rad.toFloat() * u, p
            )

        fun ar(l: Number, t: Number, r: Number, b: Number, st: Number, sw: Number) =
            c.drawArc(
                RectF(l.toFloat() * u, t.toFloat() * u, r.toFloat() * u, b.toFloat() * u),
                st.toFloat(), sw.toFloat(), false, p
            )

        fun pl(close: Boolean, vararg v: Number) {
            val path = Path()
            path.moveTo(v[0].toFloat() * u, v[1].toFloat() * u)
            var i = 2
            while (i < v.size) {
                path.lineTo(v[i].toFloat() * u, v[i + 1].toFloat() * u)
                i += 2
            }
            if (close) path.close()
            c.drawPath(path, p)
        }

        when (id) {
            CROSSHAIR -> {
                ci(12, 12, 7); ln(12, 2, 12, 7); ln(12, 17, 12, 22)
                ln(2, 12, 7, 12); ln(17, 12, 22, 12); ci(12, 12, 1.3, true)
            }
            DND -> { ci(12, 12, 9); ln(7.5, 12, 16.5, 12) }
            CHART -> {
                ln(4, 20, 20, 20); rr(5, 12, 8.5, 20, 0.6)
                rr(10.2, 5, 13.7, 20, 0.6); rr(15.5, 9, 19, 20, 0.6)
            }
            GLOBE -> {
                ci(12, 12, 9); ln(3, 12, 21, 12); ar(8, 3, 16, 21, 0, 360)
                ln(4.5, 7.5, 19.5, 7.5); ln(4.5, 16.5, 19.5, 16.5)
            }
            NOTE -> {
                rr(5, 3, 19, 21, 2); ln(8.5, 8, 15.5, 8)
                ln(8.5, 12, 15.5, 12); ln(8.5, 16, 12.5, 16)
            }
            CALC -> {
                rr(5, 3, 19, 21, 2); rr(8, 6, 16, 10, 0.6)
                ci(9, 14, 0.9, true); ci(12, 14, 0.9, true); ci(15, 14, 0.9, true)
                ci(9, 18, 0.9, true); ci(12, 18, 0.9, true); ci(15, 18, 0.9, true)
            }
            TIMER -> {
                ci(12, 13.5, 7.5); ln(12, 13.5, 12, 9.5); ln(12, 13.5, 15, 15.5)
                ln(9.5, 2.8, 14.5, 2.8); ln(12, 2.8, 12, 6)
            }
            BOLT -> pl(true, 13, 2, 5, 13.5, 11.5, 13.5, 10.5, 22, 19, 10, 12.5, 10)
            ROCKET -> {
                pl(true, 12, 2, 16, 8, 16, 15, 8, 15, 8, 8)
                pl(false, 8, 11.5, 4.5, 16, 8, 16)
                pl(false, 16, 11.5, 19.5, 16, 16, 16)
                ci(12, 9, 1.5); ln(12, 18, 12, 22)
            }
            SUN -> {
                ci(12, 12, 4)
                for (k in 0 until 8) {
                    val a = k * Math.PI / 4
                    ln(12 + 7 * Math.cos(a), 12 + 7 * Math.sin(a), 12 + 9.7 * Math.cos(a), 12 + 9.7 * Math.sin(a))
                }
            }
            LOCK -> {
                rr(5, 11, 19, 21, 2); ar(8, 3, 16, 13, 180, 180)
                ln(8, 8, 8, 11); ln(16, 8, 16, 11)
            }
            GEAR -> {
                ci(12, 12, 3); ci(12, 12, 7)
                for (k in 0 until 8) {
                    val a = k * Math.PI / 4
                    ln(12 + 7 * Math.cos(a), 12 + 7 * Math.sin(a), 12 + 10 * Math.cos(a), 12 + 10 * Math.sin(a))
                }
            }
            CPU -> {
                rr(7, 7, 17, 17, 1.5); ci(12, 12, 1.4, true)
                ln(10, 3, 10, 7); ln(14, 3, 14, 7); ln(10, 17, 10, 21); ln(14, 17, 14, 21)
                ln(3, 10, 7, 10); ln(3, 14, 7, 14); ln(17, 10, 21, 10); ln(17, 14, 21, 14)
            }
            THERMO -> { rr(10, 3, 14, 15, 2); ci(12, 17.5, 3.5); ln(12, 7, 12, 16) }
            PHONEOFF -> {
                rr(7, 2, 17, 22, 2.5); ln(10.5, 18.5, 13.5, 18.5); ln(4, 4, 20, 20)
            }
            HEADSET -> { ar(4, 4, 20, 20, 180, 180); rr(3, 12.5, 7, 19, 1.5); rr(17, 12.5, 21, 19, 1.5) }
            REC -> { ci(12, 12, 9); ci(12, 12, 4.5, true) }
            CAMERA -> {
                rr(3, 7, 21, 20, 2.5); ci(12, 13.5, 4); pl(false, 8.5, 7, 10, 4, 14, 4, 15.5, 7)
            }
            MIC -> {
                rr(9, 2, 15, 13, 3); ar(6, 6, 18, 20, 0, 180)
                ln(12, 20, 12, 22.5); ln(8.5, 22.5, 15.5, 22.5)
            }
            SPEAKER -> {
                pl(true, 4, 9, 8, 9, 13, 5, 13, 19, 8, 15, 4, 15)
                ar(11, 8, 19, 16, -50, 100); ar(10, 4, 24, 20, -50, 100)
            }
            WIFI -> {
                ar(8, 15, 16, 23, 225, 90); ar(3, 10, 21, 28, 225, 90)
                ar(-2, 5, 26, 33, 225, 90); ci(12, 19, 1.3, true)
            }
            TOUCH -> {
                ci(12, 12, 2, true); ci(12, 12, 6)
                ar(2, 2, 22, 22, 200, 50); ar(2, 2, 22, 22, 20, 50)
            }
            EYE -> {
                val pa = Path()
                pa.moveTo(2 * u, 12 * u)
                pa.quadTo(12 * u, 3.5f * u, 22 * u, 12 * u)
                pa.quadTo(12 * u, 20.5f * u, 2 * u, 12 * u)
                c.drawPath(pa, p)
                ci(12, 12, 3)
            }
            BELLOFF -> {
                ar(6, 4, 18, 16, 180, 180); ln(6, 10, 6, 17); ln(18, 10, 18, 17)
                ln(4, 17, 20, 17); ci(12, 20.2, 1.2, true); ln(4, 4, 20, 20)
            }
            MEM -> {
                rr(3, 8, 21, 16, 1.5); ln(6, 16, 6, 19); ln(10, 16, 10, 19)
                ln(14, 16, 14, 19); ln(18, 16, 18, 19); ln(7, 12, 17, 12)
            }
            DATA -> {
                ln(8, 4, 8, 18); pl(false, 5, 15, 8, 18, 11, 15)
                ln(16, 20, 16, 6); pl(false, 13, 9, 16, 6, 19, 9)
            }
            SHIELD -> {
                pl(true, 12, 3, 20, 6, 20, 12, 12, 21, 4, 12, 4, 6)
                pl(false, 8.5, 12, 11, 14.5, 15.5, 9.5)
            }
            ANIM -> { pl(true, 4, 6, 12, 12, 4, 18); pl(true, 12, 6, 20, 12, 12, 18) }
            SAT -> {
                ci(12, 12, 8)
                c.drawArc(RectF(4 * u, 4 * u, 20 * u, 20 * u), 90f, 180f, true, f)
            }
            CLOSE -> { ln(6, 6, 18, 18); ln(18, 6, 6, 18) }
            BACK -> pl(false, 15, 5, 8, 12, 15, 19)
            PLUS -> { ln(12, 5, 12, 19); ln(5, 12, 19, 12) }
            TRASH -> {
                ln(4, 7, 20, 7); pl(false, 7, 7, 8, 20, 16, 20, 17, 7)
                pl(false, 9.5, 7, 9.5, 4, 14.5, 4, 14.5, 7)
            }
            COPY -> { rr(4, 3, 15, 15, 2); rr(9, 9, 20, 21, 2) }
            SHOT -> {
                pl(false, 4, 9, 4, 4, 9, 4); pl(false, 15, 4, 20, 4, 20, 9)
                pl(false, 20, 15, 20, 20, 15, 20); pl(false, 9, 20, 4, 20, 4, 15)
                ci(12, 12, 2.5)
            }
            FLASH -> { pl(true, 8, 2, 16, 2, 15, 8, 9, 8); rr(9, 8, 15, 22, 1.5) }
            ROBOT -> {
                rr(5, 8, 19, 19, 3); ln(12, 4.5, 12, 8); ci(12, 3.6, 1.2, true)
                ci(9.2, 13, 1.3, true); ci(14.8, 13, 1.3, true); ln(9.5, 16.5, 14.5, 16.5)
                ln(3, 12, 3, 15); ln(21, 12, 21, 15)
            }
            CLOCK -> { ci(12, 12, 9); ln(12, 12, 12, 7); ln(12, 12, 16, 14) }
            GAME -> {
                rr(3, 8, 21, 17, 4); ln(8, 10.5, 8, 14.5); ln(6, 12.5, 10, 12.5)
                ci(15.5, 11.5, 1, true); ci(18, 13.5, 1, true)
            }
            PLAY -> pl(true, 8, 5, 19, 12, 8, 19)
            STAR -> pl(true, 12, 3, 14.5, 9, 21, 9.5, 16, 13.8, 17.8, 20.5, 12, 17, 6.2, 20.5, 8, 13.8, 3, 9.5, 9.5, 9)
            SEND -> pl(true, 3, 11, 21, 3, 14, 21, 11.5, 13)
            FINGERPRINT -> {
                ar(5, 3, 19, 17, 200, 320)
                ar(7.2, 6.2, 16.8, 15.8, 200, 320)
                ln(12, 8.2, 12, 13.5)
                ar(9.6, 10.2, 14.4, 15, 200, 230)
            }
            CHECK -> pl(false, 4, 12.5, 9.5, 18, 20, 6)
        }
    }
}

class IconView(ctx: Context, var icon: Int, var color: Int) : View(ctx) {
    override fun onDraw(canvas: Canvas) {
        val w = width - paddingLeft - paddingRight
        val h = height - paddingTop - paddingBottom
        val s = minOf(w, h).toFloat()
        if (s <= 0f) return
        canvas.save()
        canvas.translate(paddingLeft + (w - s) / 2f, paddingTop + (h - s) / 2f)
        Icons.draw(canvas, icon, s, color)
        canvas.restore()
    }
}
