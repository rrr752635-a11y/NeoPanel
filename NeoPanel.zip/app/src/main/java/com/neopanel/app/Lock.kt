package com.neopanel.app

import android.accessibilityservice.AccessibilityService
import android.app.Activity
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.SharedPreferences
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.hardware.biometrics.BiometricPrompt
import android.os.Build
import android.os.Bundle
import android.os.CancellationSignal
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.os.VibrationEffect
import android.os.Vibrator
import android.provider.Settings
import android.telecom.TelecomManager
import android.util.Base64
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.inputmethod.InputMethodManager
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import org.json.JSONArray
import org.json.JSONObject
import java.security.MessageDigest
import java.security.SecureRandom
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec

/** Penyimpanan pengaturan kunci. PIN disimpan sebagai hash PBKDF2 bergaram, bukan teks biasa. */
object LockStore {
    fun prefs(ctx: Context): SharedPreferences = ctx.getSharedPreferences("vexed", Context.MODE_PRIVATE)

    private fun hash(pin: String, salt: ByteArray): ByteArray =
        SecretKeyFactory.getInstance("PBKDF2WithHmacSHA1")
            .generateSecret(PBEKeySpec(pin.toCharArray(), salt, 20000, 256)).encoded

    fun hasPin(p: SharedPreferences) = p.contains("lock_hash")

    fun setPin(p: SharedPreferences, pin: String) {
        val salt = ByteArray(16)
        SecureRandom().nextBytes(salt)
        p.edit()
            .putString("lock_salt", Base64.encodeToString(salt, Base64.NO_WRAP))
            .putString("lock_hash", Base64.encodeToString(hash(pin, salt), Base64.NO_WRAP))
            .putInt("lock_len", pin.length)
            .apply()
    }

    fun checkPin(p: SharedPreferences, pin: String): Boolean {
        val s = p.getString("lock_salt", null) ?: return false
        val h = p.getString("lock_hash", null) ?: return false
        return try {
            MessageDigest.isEqual(Base64.decode(h, Base64.NO_WRAP), hash(pin, Base64.decode(s, Base64.NO_WRAP)))
        } catch (e: Exception) {
            false
        }
    }

    fun enabled(p: SharedPreferences) = p.getBoolean("lock_on", false) && hasPin(p)
    fun pinLen(p: SharedPreferences) = p.getInt("lock_len", 4).coerceIn(4, 8)
    fun graceMs(p: SharedPreferences): Long = p.getInt("lock_grace", 20) * 1000L
    fun fingerprint(p: SharedPreferences) = p.getBoolean("lock_fp", true)

    fun exempt(p: SharedPreferences): MutableSet<String> = try {
        val a = JSONArray(p.getString("lock_exempt", "[]"))
        val s = LinkedHashSet<String>()
        for (i in 0 until a.length()) s.add(a.getString(i))
        s
    } catch (e: Exception) {
        LinkedHashSet()
    }

    fun saveExempt(p: SharedPreferences, s: Set<String>) {
        p.edit().putString("lock_exempt", JSONArray(s.toList()).toString()).apply()
    }

    fun serviceEnabled(ctx: Context): Boolean {
        if (LockBridge.service != null) return true
        val v = Settings.Secure.getString(ctx.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
        return v.contains(ctx.packageName) && v.contains("LockService")
    }
}

/** Waktu layar per aplikasi per hari (dicatat oleh layanan kunci). */
object LockStats {
    private fun key(d: Date = Date()) = "usage_" + SimpleDateFormat("yyyyMMdd", Locale.US).format(d)

    fun add(p: SharedPreferences, pkg: String, ms: Long) {
        if (ms < 1000L) return
        val k = key()
        val o = try { JSONObject(p.getString(k, "{}")) } catch (e: Exception) { JSONObject() }
        o.put(pkg, o.optLong(pkg, 0L) + ms)
        p.edit().putString(k, o.toString()).apply()
    }

    fun today(p: SharedPreferences): List<Pair<String, Long>> {
        val o = try { JSONObject(p.getString(key(), "{}")) } catch (e: Exception) { JSONObject() }
        val out = ArrayList<Pair<String, Long>>()
        val ks = o.keys()
        while (ks.hasNext()) {
            val k = ks.next()
            out.add(k to o.optLong(k, 0L))
        }
        out.sortByDescending { it.second }
        return out
    }

    fun cleanup(p: SharedPreferences) {
        val c = Calendar.getInstance()
        c.add(Calendar.DAY_OF_YEAR, -7)
        val cutoff = key(c.time)
        val e = p.edit()
        for (k in p.all.keys) if (k.startsWith("usage_") && k < cutoff) e.remove(k)
        e.apply()
    }
}

object LockBridge {
    @Volatile var service: LockService? = null
    @Volatile var showing: String? = null
    @Volatile var fails = 0
    @Volatile var lockedUntil = 0L
}

/**
 * Layanan aksesibilitas: hanya mendengarkan perubahan jendela (nama aplikasi), tidak membaca isi layar.
 * Menampilkan layar PIN untuk aplikasi yang dikunci dan mencatat waktu layar.
 */
class LockService : AccessibilityService() {
    private val unlocked = HashMap<String, Long>()   // pkg -> waktu keluar (0 = masih di dalam)
    private var cur: String? = null
    private var curStart = 0L
    private var cover: View? = null
    private var always: Set<String> = emptySet()
    private var home: String? = null
    private val ui = Handler(Looper.getMainLooper())
    private val prefs by lazy { LockStore.prefs(this) }
    private val hideRun = Runnable { hideCover() }

    private val screenOff = object : BroadcastReceiver() {
        override fun onReceive(c: Context?, i: Intent?) {
            flushUsage()
            unlocked.clear()
            hideCover()
        }
    }

    override fun onServiceConnected() {
        LockBridge.service = this
        always = computeAlways()
        home = try {
            packageManager.resolveActivity(
                Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME), 0
            )?.activityInfo?.packageName
        } catch (e: Exception) {
            null
        }
        try { registerReceiver(screenOff, IntentFilter(Intent.ACTION_SCREEN_OFF)) } catch (e: Exception) { }
        LockStats.cleanup(prefs)
    }

    private fun computeAlways(): Set<String> {
        val s = HashSet<String>(
            listOf(
                "com.android.systemui", "android", "com.android.permissioncontroller",
                "com.google.android.permissioncontroller", "com.android.packageinstaller",
                "com.google.android.packageinstaller", "com.android.incallui", "com.android.phone",
                "com.android.emergency", "com.google.android.apps.nexuslauncher.overview"
            )
        )
        try { getSystemService(TelecomManager::class.java)?.defaultDialerPackage?.let { s.add(it) } } catch (e: Exception) { }
        try {
            val imm = getSystemService(InputMethodManager::class.java)
            for (m in imm.inputMethodList) s.add(m.packageName)
        } catch (e: Exception) { }
        return s
    }

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {
        if (e == null || e.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val pkg = e.packageName?.toString() ?: return
        val cls = e.className?.toString() ?: ""
        if (pkg == packageName && cls.contains("LockActivity")) return
        if (pkg in always) return

        switchTo(pkg)
        if (pkg == home) return
        if (!LockStore.enabled(prefs)) return
        if (pkg in LockStore.exempt(prefs)) return

        val now = SystemClock.elapsedRealtime()
        val left = unlocked[pkg]
        if (left != null && (left == 0L || now - left < LockStore.graceMs(prefs))) {
            unlocked[pkg] = 0L
            return
        }
        unlocked.remove(pkg)
        showLock(pkg)
    }

    private fun switchTo(pkg: String) {
        val now = SystemClock.elapsedRealtime()
        val c = cur
        if (c != null && c != pkg) {
            LockLog.add(prefs, c, now - curStart, home)
            if (unlocked[c] == 0L) unlocked[c] = now
        }
        if (c != pkg) {
            cur = pkg
            curStart = now
        }
    }

    private fun flushUsage() {
        val c = cur ?: return
        val now = SystemClock.elapsedRealtime()
        LockLog.add(prefs, c, now - curStart, home)
        curStart = now
    }

    private fun showLock(pkg: String) {
        if (LockBridge.showing == pkg) return
        showCover()
        val i = Intent(this, LockActivity::class.java)
        i.putExtra("pkg", pkg)
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_NO_ANIMATION or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        try { startActivity(i) } catch (e: Exception) { hideCover() }
    }

    fun onUnlocked(pkg: String) {
        unlocked[pkg] = 0L
        cur = pkg
        curStart = SystemClock.elapsedRealtime()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun showCover() {
        if (cover != null) return
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val v = FrameLayout(this)
        v.setBackgroundColor(0xFF0E1018.toInt())
        v.isClickable = true
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.gravity = Gravity.CENTER
        col.addView(AvatarView(this, null, 0xFFFF2D55.toInt(), 0xFFFF7A18.toInt()), LinearLayout.LayoutParams(dp(88), dp(88)))
        val t = TextView(this)
        t.text = "Terkunci"
        t.textSize = 18f
        t.typeface = Typeface.DEFAULT_BOLD
        t.setTextColor(0xFFE8EAF6.toInt())
        t.setPadding(0, dp(12), 0, 0)
        col.addView(t)
        v.addView(col, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))
        val p = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.OPAQUE
        )
        try {
            wm.addView(v, p)
            cover = v
            ui.removeCallbacks(hideRun)
            ui.postDelayed(hideRun, 3000L)
        } catch (e: Exception) {
        }
    }

    fun hideCover() {
        val v = cover ?: return
        cover = null
        ui.removeCallbacks(hideRun)
        try { (getSystemService(WINDOW_SERVICE) as WindowManager).removeView(v) } catch (e: Exception) { }
    }

    override fun onInterrupt() {}

    override fun onUnbind(intent: Intent?): Boolean {
        flushUsage()
        hideCover()
        try { unregisterReceiver(screenOff) } catch (e: Exception) { }
        if (LockBridge.service === this) LockBridge.service = null
        return super.onUnbind(intent)
    }
}

private object LockLog {
    /** Catat waktu layar, kecuali untuk peluncur layar utama. */
    fun add(p: SharedPreferences, pkg: String, ms: Long, home: String?) {
        if (pkg == home) return
        LockStats.add(p, pkg, ms)
    }
}

/** Layar PIN dan sidik jari. */
class LockActivity : Activity() {
    private lateinit var prefs: SharedPreferences
    private var pkg = ""
    private val sb = StringBuilder()
    private var dots: LinearLayout? = null
    private var msg: TextView? = null
    private var sub: TextView? = null
    private var done = false
    private var bioTried = false
    private var cancel: CancellationSignal? = null
    private val ui = Handler(Looper.getMainLooper())
    private val pinLen get() = LockStore.pinLen(prefs)

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun labelOf(p: String): String = try {
        packageManager.getApplicationLabel(packageManager.getApplicationInfo(p, 0)).toString()
    } catch (e: Exception) {
        p
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_SECURE)
        prefs = LockStore.prefs(this)
        pkg = intent.getStringExtra("pkg") ?: ""
        buildUi()
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        setIntent(intent)
        pkg = intent?.getStringExtra("pkg") ?: pkg
        sb.clear()
        bioTried = false
        sub?.text = labelOf(pkg)
        updateDots()
    }

    private fun buildUi() {
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.gravity = Gravity.CENTER_HORIZONTAL
        root.setBackgroundColor(0xFF0E1018.toInt())
        root.setPadding(dp(24), dp(56), dp(24), dp(24))

        root.addView(AvatarView(this, null, 0xFFFF2D55.toInt(), 0xFFFF7A18.toInt()), LinearLayout.LayoutParams(dp(84), dp(84)))
        val title = TextView(this)
        title.text = "Terkunci"
        title.textSize = 22f
        title.typeface = Typeface.DEFAULT_BOLD
        title.setTextColor(0xFFE8EAF6.toInt())
        title.setPadding(0, dp(12), 0, 0)
        root.addView(title)
        val s = TextView(this)
        s.text = labelOf(pkg)
        s.textSize = 13f
        s.setTextColor(0xFF9AA0B5.toInt())
        sub = s
        root.addView(s)

        val d = LinearLayout(this)
        d.orientation = LinearLayout.HORIZONTAL
        d.gravity = Gravity.CENTER
        d.setPadding(0, dp(26), 0, dp(8))
        dots = d
        root.addView(d)
        val m = TextView(this)
        m.textSize = 12f
        m.setTextColor(0xFFFF5252.toInt())
        m.gravity = Gravity.CENTER
        msg = m
        root.addView(m, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(22)))

        val keys = listOf(
            listOf("1", "2", "3"), listOf("4", "5", "6"), listOf("7", "8", "9"),
            listOf("bio", "0", "del")
        )
        val bioOk = Build.VERSION.SDK_INT >= 28 && LockStore.fingerprint(prefs)
        for (r in keys) {
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER
            for (k in r) {
                val b = TextView(this)
                b.gravity = Gravity.CENTER
                b.setTextColor(0xFFFFFFFF.toInt())
                when (k) {
                    "bio" -> { b.text = if (bioOk) "Sidik\njari" else ""; b.textSize = 11f }
                    "del" -> { b.text = "Hapus"; b.textSize = 12f }
                    else -> { b.text = k; b.textSize = 26f }
                }
                if (k != "bio" || bioOk) {
                    val gd = GradientDrawable()
                    gd.shape = GradientDrawable.OVAL
                    gd.setColor(if (k == "bio" || k == "del") 0xFF171A26.toInt() else 0xFF1F2333.toInt())
                    b.background = gd
                    b.setOnClickListener {
                        when (k) {
                            "bio" -> { bioTried = true; tryBio() }
                            "del" -> {
                                if (sb.isNotEmpty()) {
                                    sb.deleteCharAt(sb.length - 1)
                                    updateDots()
                                }
                            }
                            else -> press(k)
                        }
                    }
                }
                val lp = LinearLayout.LayoutParams(dp(74), dp(74))
                lp.setMargins(dp(10), dp(6), dp(10), dp(6))
                row.addView(b, lp)
            }
            root.addView(row)
        }
        setContentView(root)
        updateDots()
        refreshLockout()
    }

    private fun updateDots() {
        val d = dots ?: return
        d.removeAllViews()
        for (i in 0 until pinLen) {
            val v = View(this)
            val gd = GradientDrawable()
            gd.shape = GradientDrawable.OVAL
            gd.setColor(if (i < sb.length) 0xFFFF7A18.toInt() else 0xFF3A4057.toInt())
            v.background = gd
            val lp = LinearLayout.LayoutParams(dp(14), dp(14))
            lp.setMargins(dp(7), 0, dp(7), 0)
            d.addView(v, lp)
        }
    }

    private fun press(k: String) {
        if (SystemClock.elapsedRealtime() < LockBridge.lockedUntil) return
        if (sb.length >= pinLen) return
        sb.append(k)
        updateDots()
        if (sb.length == pinLen) {
            if (LockStore.checkPin(prefs, sb.toString())) success() else fail()
        }
    }

    private fun fail() {
        LockBridge.fails++
        sb.clear()
        updateDots()
        dots?.animate()?.translationX(dp(14).toFloat())?.setDuration(50)?.withEndAction {
            dots?.animate()?.translationX(-dp(14).toFloat())?.setDuration(80)?.withEndAction {
                dots?.animate()?.translationX(0f)?.setDuration(50)?.start()
            }?.start()
        }?.start()
        try {
            if (Build.VERSION.SDK_INT >= 26) {
                getSystemService(Vibrator::class.java)?.vibrate(VibrationEffect.createOneShot(90, VibrationEffect.DEFAULT_AMPLITUDE))
            }
        } catch (e: Exception) { }
        if (LockBridge.fails >= 5) {
            val secs = if (LockBridge.fails == 5) 30L else 60L
            LockBridge.lockedUntil = SystemClock.elapsedRealtime() + secs * 1000L
            refreshLockout()
        } else {
            msg?.text = "PIN salah (${LockBridge.fails}/5)"
        }
    }

    private fun refreshLockout() {
        val left = LockBridge.lockedUntil - SystemClock.elapsedRealtime()
        if (left > 0) {
            msg?.text = "Terlalu banyak percobaan. Coba lagi dalam ${(left + 999) / 1000} detik"
            ui.postDelayed({ refreshLockout() }, 500L)
        } else if (LockBridge.lockedUntil != 0L) {
            msg?.text = ""
        }
    }

    private fun success() {
        if (done) return
        done = true
        LockBridge.fails = 0
        LockBridge.lockedUntil = 0L
        LockBridge.service?.onUnlocked(pkg)
        cancel?.cancel()
        finish()
        overridePendingTransition(0, 0)
    }

    private fun tryBio() {
        if (Build.VERSION.SDK_INT < 28 || !LockStore.fingerprint(prefs) || done) return
        try {
            val exec = mainExecutor
            val cs = CancellationSignal()
            cancel = cs
            val bp = BiometricPrompt.Builder(this)
                .setTitle("Buka kunci VeXed")
                .setSubtitle(labelOf(pkg))
                .setNegativeButton("Pakai PIN", exec) { _, _ -> }
                .build()
            bp.authenticate(cs, exec, object : BiometricPrompt.AuthenticationCallback() {
                override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult?) {
                    success()
                }
            })
        } catch (e: Throwable) {
        }
    }

    override fun onResume() {
        super.onResume()
        LockBridge.showing = pkg
        LockBridge.service?.hideCover()
        if (!bioTried) {
            bioTried = true
            tryBio()
        }
    }

    private fun goHome() {
        val h = Intent(Intent.ACTION_MAIN)
        h.addCategory(Intent.CATEGORY_HOME)
        h.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(h)
        finish()
    }

    override fun onBackPressed() {
        goHome()
    }

    override fun onUserLeaveHint() {
        if (!done) {
            cancel?.cancel()
            finish()
        }
    }

    override fun onDestroy() {
        if (LockBridge.showing == pkg) LockBridge.showing = null
        ui.removeCallbacksAndMessages(null)
        super.onDestroy()
    }
}
