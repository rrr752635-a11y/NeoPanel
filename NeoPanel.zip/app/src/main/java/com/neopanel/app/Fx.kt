package com.neopanel.app

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.view.View
import android.view.animation.LinearInterpolator

/** Garis tipis dengan kilau neon yang bergerak. Animasi hanya jalan selama view terpasang (panel terbuka). */
class ShimmerBar(ctx: Context, private val c1: Int, private val c2: Int) : View(ctx) {
    private var t = 0f
    private val p = Paint()
    private var anim: ValueAnimator? = null

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        anim?.cancel()
        anim = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 1800
            repeatCount = ValueAnimator.INFINITE
            interpolator = LinearInterpolator()
            addUpdateListener { t = it.animatedValue as Float; invalidate() }
            start()
        }
    }

    override fun onDetachedFromWindow() {
        anim?.cancel()
        anim = null
        super.onDetachedFromWindow()
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        p.shader = null
        p.color = (c1 and 0x00FFFFFF) or 0x33000000
        c.drawRect(0f, 0f, w, h, p)
        val seg = w * 0.35f
        val x = -seg + (w + seg) * t
        p.shader = LinearGradient(
            x, 0f, x + seg, 0f,
            intArrayOf(c1 and 0x00FFFFFF, c2, c2 and 0x00FFFFFF),
            floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP
        )
        c.drawRect(0f, 0f, w, h, p)
        p.shader = null
    }
}

/** Layar animasi singkat saat meluncurkan game. progress 0..1 diatur dari luar. */
class SplashView(
    ctx: Context, private val c1: Int, private val c2: Int,
    icon: Drawable?, private val title: String
) : View(ctx) {
    var progress = 0f
    private val ic: Drawable? = icon?.constantState?.newDrawable()?.mutate()
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val d = resources.displayMetrics.density
        p.shader = null
        p.style = Paint.Style.FILL
        p.color = 0xF2090B12.toInt()
        c.drawRect(0f, 0f, w, h, p)

        // garis neon yang meluncur
        p.style = Paint.Style.STROKE
        p.strokeWidth = 2f * d
        p.color = (c1 and 0x00FFFFFF) or 0x2A000000
        for (i in 0 until 7) {
            val y = (progress * h * 1.2f + i * h / 7f) % h
            c.drawLine(0f, y, w, y - 46f * d, p)
        }

        val cx = w / 2f
        val cy = h * 0.42f
        val r = 52f * d
        rect.set(cx - r, cy - r, cx + r, cy + r)
        p.strokeWidth = 4f * d
        p.strokeCap = Paint.Cap.ROUND
        p.color = 0x33FFFFFF
        c.drawCircle(cx, cy, r, p)
        p.color = c1
        c.drawArc(rect, progress * 720f, 100f, false, p)
        p.color = c2
        c.drawArc(rect, progress * 720f + 180f, 100f, false, p)

        val sz = (r * 1.1f * (0.8f + 0.2f * minOf(1f, progress * 4f))).toInt()
        val left = (cx - sz / 2f).toInt()
        val top = (cy - sz / 2f).toInt()
        val icn = ic
        if (icn != null) {
            icn.setBounds(left, top, left + sz, top + sz)
            icn.draw(c)
        } else {
            c.save()
            c.translate(left.toFloat(), top.toFloat())
            Brand.draw(c, sz.toFloat(), 0xFFE8EAF6.toInt(), c1)
            c.restore()
        }

        p.style = Paint.Style.FILL
        p.textAlign = Paint.Align.CENTER
        p.typeface = Typeface.DEFAULT_BOLD
        p.color = 0xFFE8EAF6.toInt()
        p.textSize = 13f * d
        p.letterSpacing = 0.25f
        c.drawText("MELUNCURKAN", cx, cy + r + 34f * d, p)
        p.letterSpacing = 0f
        p.color = 0xFF9AA0B5.toInt()
        p.textSize = 16f * d
        c.drawText(title.take(30), cx, cy + r + 60f * d, p)

        val bw = w * 0.6f
        val bx = (w - bw) / 2f
        val by = cy + r + 90f * d
        p.color = 0x22FFFFFF
        c.drawRect(bx, by, bx + bw, by + 4f * d, p)
        p.shader = LinearGradient(bx, 0f, bx + bw, 0f, c1, c2, Shader.TileMode.CLAMP)
        c.drawRect(bx, by, bx + bw * progress, by + 4f * d, p)
        p.shader = null
    }
}
