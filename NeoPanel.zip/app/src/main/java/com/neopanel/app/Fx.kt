package com.neopanel.app

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.os.SystemClock
import android.view.View
import android.view.animation.LinearInterpolator

/** Garis tipis dengan kilau neon yang bergerak. Animasi hanya jalan selama view terpasang (panel terbuka). */
class ShimmerBar(ctx: Context, private val c1: Int, private val c2: Int) : View(ctx) {
    private var t = 0f
    private val p = Paint()
    private var anim: ValueAnimator? = null

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        anim?.cancel()
        anim = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 1800
            repeatCount = ValueAnimator.INFINITE
            interpolator = LinearInterpolator()
            addUpdateListener { t = it.animatedValue as Float; invalidate() }
            start()
        }
    }

    override fun onDetachedFromWindow() {
        anim?.cancel()
        anim = null
        super.onDetachedFromWindow()
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        p.shader = null
        p.color = (c1 and 0x00FFFFFF) or 0x33000000
        c.drawRect(0f, 0f, w, h, p)
        val seg = w * 0.35f
        val x = -seg + (w + seg) * t
        p.shader = LinearGradient(
            x, 0f, x + seg, 0f,
            intArrayOf(c1 and 0x00FFFFFF, c2, c2 and 0x00FFFFFF),
            floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP
        )
        c.drawRect(0f, 0f, w, h, p)
        p.shader = null
    }
}

/** Layar peluncuran game yang mewah: cahaya, partikel, cincin, kilau, dan progress. progress 0..1 diatur dari luar. */
class SplashView(
    ctx: Context, private val c1: Int, private val c2: Int,
    icon: Drawable?, private val title: String
) : View(ctx) {
    var progress = 0f
    private val ic: Drawable? = icon?.constantState?.newDrawable()?.mutate()
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()
    private val path = Path()
    private val n = 40
    private val rnd = java.util.Random(11)
    private val px = FloatArray(n) { rnd.nextFloat() }
    private val py = FloatArray(n) { rnd.nextFloat() }
    private val ps = FloatArray(n) { 0.4f + rnd.nextFloat() }
    private val pr = FloatArray(n) { 1f + rnd.nextFloat() * 2.4f }
    private var glow: RadialGradient? = null

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        glow = RadialGradient(
            w / 2f, h * 0.42f, maxOf(w, h) * 0.62f,
            intArrayOf((c1 and 0x00FFFFFF) or 0x70000000, (c2 and 0x00FFFFFF) or 0x26000000, 0x00000000),
            floatArrayOf(0f, 0.45f, 1f), Shader.TileMode.CLAMP
        )
    }

    private fun easeOutBack(t: Float): Float {
        val k = 1.70158f
        val x = t - 1f
        return 1f + (k + 1f) * x * x * x + k * x * x
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val d = resources.displayMetrics.density
        val pg = progress
        val cx = w / 2f
        val cy = h * 0.42f
        val r = 54f * d

        p.shader = null
        p.style = Paint.Style.FILL
        p.color = 0xFB070910.toInt()
        c.drawRect(0f, 0f, w, h, p)
        p.shader = glow
        c.drawRect(0f, 0f, w, h, p)
        p.shader = null

        // sinar berputar
        c.save()
        c.translate(cx, cy)
        c.rotate(pg * 70f)
        p.color = (c1 and 0x00FFFFFF) or 0x16000000
        val len = maxOf(w, h)
        for (i in 0 until 12) {
            val a1 = Math.toRadians(i * 30.0)
            val a2 = Math.toRadians(i * 30.0 + 9.0)
            path.reset()
            path.moveTo(0f, 0f)
            path.lineTo((len * Math.cos(a1)).toFloat(), (len * Math.sin(a1)).toFloat())
            path.lineTo((len * Math.cos(a2)).toFloat(), (len * Math.sin(a2)).toFloat())
            path.close()
            c.drawPath(path, p)
        }
        c.restore()

        // partikel naik
        for (i in 0 until n) {
            val y = h - ((pg * ps[i] * 1.6f + py[i]) % 1f) * h
            val x = px[i] * w + Math.sin(pg * 6.0 + i).toFloat() * 8f * d
            val a = (70 + 150 * Math.abs(Math.sin(pg * 9.0 + i))).toInt()
            p.color = ((if (i % 2 == 0) c2 else 0xFFFFFFFF.toInt()) and 0x00FFFFFF) or (a shl 24)
            c.drawCircle(x, y, pr[i] * d, p)
        }

        // gelombang cincin
        p.style = Paint.Style.STROKE
        p.strokeWidth = 2f * d
        for (k in 0..2) {
            val ph = (pg * 2f + k / 3f) % 1f
            p.color = (c1 and 0x00FFFFFF) or (((1f - ph) * 90).toInt() shl 24)
            c.drawCircle(cx, cy, r * (1.1f + ph * 1.7f), p)
        }

        // cahaya di belakang ikon
        p.style = Paint.Style.FILL
        val pulse = 1f + 0.06f * Math.sin(pg * 18.0).toFloat()
        p.color = (c1 and 0x00FFFFFF) or 0x30000000
        c.drawCircle(cx, cy, r * 1.05f * pulse, p)
        p.color = (c2 and 0x00FFFFFF) or 0x22000000
        c.drawCircle(cx, cy, r * 0.82f * pulse, p)

        // ikon dengan efek membal
        val sc = easeOutBack(minOf(1f, pg * 3.2f))
        val sz = (r * 1.2f * sc).toInt()
        val left = (cx - sz / 2f).toInt()
        val top = (cy - sz / 2f).toInt()
        c.save()
        c.clipRect(left.toFloat(), top.toFloat(), (left + sz).toFloat(), (top + sz).toFloat())
        val icn = ic
        if (icn != null) {
            icn.setBounds(left, top, left + sz, top + sz)
            icn.draw(c)
        } else {
            c.save()
            c.translate(left.toFloat(), top.toFloat())
            Brand.draw(c, sz.toFloat(), 0xFFE8EAF6.toInt(), c1)
            c.restore()
        }
        // kilau
        if (pg in 0.35f..0.75f) {
            val t = (pg - 0.35f) / 0.4f
            val bx = left - sz * 0.4f + (sz * 1.8f) * t
            path.reset()
            path.moveTo(bx, top.toFloat())
            path.lineTo(bx + sz * 0.22f, top.toFloat())
            path.lineTo(bx + sz * 0.22f - sz * 0.3f, (top + sz).toFloat())
            path.lineTo(bx - sz * 0.3f, (top + sz).toFloat())
            path.close()
            p.color = 0x66FFFFFF
            c.drawPath(path, p)
        }
        c.restore()

        // cincin berputar
        rect.set(cx - r * 1.12f, cy - r * 1.12f, cx + r * 1.12f, cy + r * 1.12f)
        p.style = Paint.Style.STROKE
        p.strokeWidth = 4f * d
        p.strokeCap = Paint.Cap.ROUND
        p.color = 0x22FFFFFF
        c.drawCircle(cx, cy, r * 1.12f, p)
        p.color = c1
        c.drawArc(rect, pg * 900f, 90f, false, p)
        p.color = c2
        c.drawArc(rect, pg * 900f + 180f, 90f, false, p)

        // teks
        p.style = Paint.Style.FILL
        p.textAlign = Paint.Align.CENTER
        p.typeface = Typeface.DEFAULT_BOLD
        p.color = 0xFF9AA0B5.toInt()
        p.textSize = 12f * d
        p.letterSpacing = 0.35f
        c.drawText("MELUNCURKAN", cx, cy + r * 1.12f + 40f * d, p)
        val t2 = title.take(30)
        val shown = minOf(t2.length, (pg * t2.length * 1.8f).toInt())
        p.color = 0xFFE8EAF6.toInt()
        p.textSize = 20f * d
        p.letterSpacing = 0.08f
        c.drawText(t2.substring(0, shown), cx, cy + r * 1.12f + 72f * d, p)
        p.letterSpacing = 0f

        // progress bar bercahaya
        val bw = w * 0.62f
        val bx0 = (w - bw) / 2f
        val by = cy + r * 1.12f + 104f * d
        val bh = 6f * d
        p.color = 0x22FFFFFF
        rect.set(bx0, by, bx0 + bw, by + bh)
        c.drawRoundRect(rect, bh / 2f, bh / 2f, p)
        p.shader = LinearGradient(bx0, 0f, bx0 + bw, 0f, c1, c2, Shader.TileMode.CLAMP)
        rect.set(bx0, by, bx0 + bw * pg, by + bh)
        c.drawRoundRect(rect, bh / 2f, bh / 2f, p)
        p.shader = null
        p.color = (c2 and 0x00FFFFFF) or 0x55000000
        c.drawCircle(bx0 + bw * pg, by + bh / 2f, bh * 1.4f, p)
        p.color = 0xFFFFFFFF.toInt()
        c.drawCircle(bx0 + bw * pg, by + bh / 2f, bh * 0.6f, p)
        p.color = 0xFF9AA0B5.toInt()
        p.textSize = 12f * d
        c.drawText("${(pg * 100).toInt()}%", cx, by + bh + 22f * d, p)

        // kilatan akhir
        if (pg > 0.9f) {
            p.color = ((((pg - 0.9f) / 0.1f) * 90).toInt() shl 24) or 0x00FFFFFF
            c.drawRect(0f, 0f, w, h, p)
        }
    }
}

/** Efek pemindaian layar: garis scan, kotak deteksi, dan sudut bidik. Jalan selama terpasang. */
class ScanView(ctx: Context, private val c1: Int, private val c2: Int) : View(ctx) {
    private var t = 0f
    private var anim: ValueAnimator? = null
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        anim?.cancel()
        anim = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 1500
            repeatCount = ValueAnimator.INFINITE
            interpolator = LinearInterpolator()
            addUpdateListener { t = it.animatedValue as Float; invalidate() }
            start()
        }
    }

    override fun onDetachedFromWindow() {
        anim?.cancel()
        anim = null
        super.onDetachedFromWindow()
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val d = resources.displayMetrics.density
        val now = SystemClock.uptimeMillis()
        p.shader = null
        p.style = Paint.Style.FILL
        p.color = 0x40000000
        c.drawRect(0f, 0f, w, h, p)

        // kotak deteksi muncul di area yang sudah terlewati garis scan
        val scanY = t * h
        val rnd = java.util.Random(now / 500L)
        p.style = Paint.Style.STROKE
        p.strokeWidth = 1.6f * d
        for (i in 0 until 6) {
            val bw = (60 + rnd.nextInt(150)) * d
            val bh = (30 + rnd.nextInt(90)) * d
            val bx = rnd.nextFloat() * (w - bw)
            val by = rnd.nextFloat() * (h - bh)
            if (by + bh < scanY) {
                p.color = (c2 and 0x00FFFFFF) or (((80 + 120 * Math.abs(Math.sin(now / 160.0 + i))).toInt()) shl 24)
                rect.set(bx, by, bx + bw, by + bh)
                c.drawRoundRect(rect, 4f * d, 4f * d, p)
            }
        }

        // jejak dan garis scan
        p.style = Paint.Style.FILL
        p.shader = LinearGradient(
            0f, scanY - 140f * d, 0f, scanY,
            c1 and 0x00FFFFFF, (c1 and 0x00FFFFFF) or 0x70000000, Shader.TileMode.CLAMP
        )
        c.drawRect(0f, scanY - 140f * d, w, scanY, p)
        p.shader = null
        p.color = c2
        c.drawRect(0f, scanY - 1.5f * d, w, scanY + 1.5f * d, p)

        // sudut bidik
        val a = (140 + 100 * Math.sin(now / 220.0)).toInt()
        p.style = Paint.Style.STROKE
        p.strokeWidth = 3.5f * d
        p.strokeCap = Paint.Cap.SQUARE
        p.color = (c1 and 0x00FFFFFF) or (a shl 24)
        val m = 22f * d
        val l = 38f * d
        c.drawLine(m, m, m + l, m, p); c.drawLine(m, m, m, m + l, p)
        c.drawLine(w - m, m, w - m - l, m, p); c.drawLine(w - m, m, w - m, m + l, p)
        c.drawLine(m, h - m, m + l, h - m, p); c.drawLine(m, h - m, m, h - m - l, p)
        c.drawLine(w - m, h - m, w - m - l, h - m, p); c.drawLine(w - m, h - m, w - m, h - m - l, p)

        // teks
        p.style = Paint.Style.FILL
        p.textAlign = Paint.Align.CENTER
        p.typeface = Typeface.DEFAULT_BOLD
        p.letterSpacing = 0.3f
        p.textSize = 14f * d
        p.color = 0xFFE8EAF6.toInt()
        val dots = ".".repeat(((now / 350L) % 4L).toInt())
        c.drawText("MENGANALISIS LAYAR$dots", w / 2f, h - 70f * d, p)
        p.letterSpacing = 0f
    }
}

/** Meter level suara dengan batang bergerak. src() mengembalikan 0..1. */
class LevelView(ctx: Context, private val c1: Int, private val c2: Int, private val src: () -> Float) : View(ctx) {
    private val n = 28
    private val v = FloatArray(n)
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()
    private val ticker = object : Runnable {
        override fun run() {
            System.arraycopy(v, 1, v, 0, n - 1)
            v[n - 1] = src().coerceIn(0f, 1f)
            invalidate()
            postDelayed(this, 50)
        }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        removeCallbacks(ticker)
        post(ticker)
    }

    override fun onDetachedFromWindow() {
        removeCallbacks(ticker)
        super.onDetachedFromWindow()
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val bw = w / n
        p.shader = LinearGradient(0f, h, 0f, 0f, c1, c2, Shader.TileMode.CLAMP)
        for (i in 0 until n) {
            val bh = maxOf(3f, v[i] * h)
            rect.set(i * bw + bw * 0.18f, (h - bh) / 2f, (i + 1) * bw - bw * 0.18f, (h + bh) / 2f)
            c.drawRoundRect(rect, bw * 0.3f, bw * 0.3f, p)
        }
        p.shader = null
    }
}
