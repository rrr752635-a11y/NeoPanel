package com.neopanel.app

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val d = resources.displayMetrics.density
        fun dp(v: Int) = (v * d).toInt()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xFF171A24.toInt())
            setPadding(dp(24), dp(48), dp(24), dp(24))
        }

        fun btn(label: String, action: () -> Unit) = Button(this).apply {
            text = label
            setOnClickListener { action() }
        }

        root.addView(TextView(this).apply {
            text = "NeoPanel"
            textSize = 26f
            setTextColor(0xFFE8EAF6.toInt())
            setPadding(0, 0, 0, dp(16))
        })

        root.addView(btn("1. Izin tampil di atas aplikasi lain") {
            startActivity(
                Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName")
                )
            )
        })

        root.addView(btn("2. Izin Jangan Ganggu") {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS))
        })

        root.addView(btn("Mulai panel") {
            if (!Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "Beri izin overlay dulu", Toast.LENGTH_LONG).show()
            } else {
                startForegroundService(Intent(this, OverlayService::class.java))
                Toast.makeText(this, "Geser dari tepi kanan layar", Toast.LENGTH_SHORT).show()
            }
        })

        root.addView(btn("Hentikan panel") {
            stopService(Intent(this, OverlayService::class.java))
        })

        root.addView(TextView(this).apply {
            text = "Kalau izin overlay diblokir sistem, jalankan lewat rish:\n" +
                "appops set com.neopanel.app SYSTEM_ALERT_WINDOW allow"
            textSize = 13f
            setTextColor(0xFF9AA0B5.toInt())
            setPadding(0, dp(20), 0, 0)
        })

        setContentView(root)

        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
    }
}
