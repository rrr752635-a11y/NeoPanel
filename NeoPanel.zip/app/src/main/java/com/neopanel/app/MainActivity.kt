package com.neopanel.app

import android.Manifest
import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private lateinit var status: TextView
    private val cmdDump = "pm grant com.neopanel.app android.permission.DUMP"
    private val cmdOverlay = "appops set com.neopanel.app SYSTEM_ALERT_WINDOW allow"

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun btn(label: String, primary: Boolean = false, action: () -> Unit) = TextView(this).apply {
        text = label
        textSize = 14f
        typeface = Typeface.DEFAULT_BOLD
        setTextColor(0xFFE8EAF6.toInt())
        gravity = android.view.Gravity.CENTER
        setPadding(dp(16), dp(14), dp(16), dp(14))
        val colors = if (primary) intArrayOf(0xFF7C5CFF.toInt(), 0xFF00E5FF.toInt())
        else intArrayOf(0xFF2A3045.toInt(), 0xFF1A1E2D.toInt())
        background = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, colors).apply {
            cornerRadius = dp(16).toFloat()
            setStroke(dp(1), 0x22FFFFFF)
        }
        val lp = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
        )
        lp.setMargins(0, dp(6), 0, dp(6))
        layoutParams = lp
        setOnClickListener { action() }
    }

    private fun label(t: String, size: Float, color: Int) = TextView(this).apply {
        text = t
        textSize = size
        setTextColor(color)
        setPadding(0, dp(8), 0, dp(4))
    }

    private fun copy(text: String) {
        getSystemService(ClipboardManager::class.java)
            .setPrimaryClip(ClipData.newPlainText("cmd", text))
        Toast.makeText(this, "Disalin. Tempel di rish.", Toast.LENGTH_SHORT).show()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(44), dp(22), dp(24))
        }

        root.addView(label("NeoPanel  v3", 26f, 0xFFE8EAF6.toInt()))
        status = label("", 13f, 0xFF9AA0B5.toInt())
        root.addView(status)

        root.addView(label("Izin", 12f, 0xFF7C5CFF.toInt()))
        root.addView(btn("Izin tampil di atas aplikasi lain") {
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
        })
        root.addView(btn("Izin Jangan Ganggu") {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS))
        })

        root.addView(label("Lewat Shizuku (rish)", 12f, 0xFF7C5CFF.toInt()))
        root.addView(btn("Salin perintah izin DUMP (FPS asli)") { copy(cmdDump) })
        root.addView(btn("Salin perintah izin overlay") { copy(cmdOverlay) })

        root.addView(label("Panel", 12f, 0xFF7C5CFF.toInt()))
        root.addView(btn("Mulai panel", primary = true) {
            if (!Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "Beri izin overlay dulu", Toast.LENGTH_LONG).show()
            } else {
                startForegroundService(Intent(this, OverlayService::class.java))
                Toast.makeText(this, "Geser dari tepi kanan layar", Toast.LENGTH_SHORT).show()
            }
        })
        root.addView(btn("Hentikan panel") {
            stopService(Intent(this, OverlayService::class.java))
        })

        val scroll = ScrollView(this).apply {
            setBackgroundColor(0xFF121521.toInt())
            addView(root)
        }
        setContentView(scroll)

        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
    }

    override fun onResume() {
        super.onResume()
        val ov = Settings.canDrawOverlays(this)
        val dump = checkSelfPermission("android.permission.DUMP") == PackageManager.PERMISSION_GRANTED
        status.text = "Overlay: ${if (ov) "aktif ✅" else "belum ❌"}\n" +
            "FPS game asli (DUMP): ${if (dump) "aktif ✅" else "belum ❌ (pakai FPS tampilan)"}"
    }
}
