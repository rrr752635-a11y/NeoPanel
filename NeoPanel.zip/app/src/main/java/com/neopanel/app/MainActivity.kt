package com.neopanel.app

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.app.NotificationManager
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.text.InputType
import android.provider.Settings
import android.view.Gravity
import android.graphics.drawable.GradientDrawable
import android.text.Editable
import android.text.TextUtils
import android.text.TextWatcher
import android.view.View
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import rikka.shizuku.Shizuku

class MainActivity : Activity() {

    private val red = 0xFFFF2D55.toInt()
    private val orange = 0xFFFF7A18.toInt()
    private val white = 0xFFE8EAF6.toInt()
    private val gray = 0xFF9AA0B5.toInt()

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun btn(label: String, primary: Boolean = false, action: () -> Unit): TextView {
        val t = TextView(this)
        t.text = label
        t.textSize = 14f
        t.typeface = Typeface.DEFAULT_BOLD
        t.setTextColor(white)
        t.gravity = Gravity.CENTER
        t.setPadding(dp(16), dp(14), dp(16), dp(14))
        val d = resources.displayMetrics.density
        t.background = if (primary)
            ChamferDrawable(red, orange, 0xFFFFFFFF.toInt(), dp(10).toFloat(), d, false)
        else
            ChamferDrawable(0xFF262B3D.toInt(), 0xFF171A26.toInt(), 0xFF3A4057.toInt(), dp(10).toFloat(), d, false)
        val lp = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
        )
        lp.setMargins(0, dp(5), 0, dp(5))
        t.layoutParams = lp
        t.setOnClickListener { action() }
        return t
    }

    private fun label(text: String, size: Float, color: Int): TextView {
        val t = TextView(this)
        t.text = text
        t.textSize = size
        t.setTextColor(color)
        t.setPadding(0, dp(10), 0, dp(4))
        return t
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    private fun copy(text: String) {
        getSystemService(ClipboardManager::class.java)
            .setPrimaryClip(ClipData.newPlainText("cmd", text))
        toast("Disalin")
    }

    private fun connectShizuku() {
        try {
            if (!Shizuku.pingBinder()) {
                toast("Jalankan aplikasi Shizuku dulu (Wireless Debugging)")
                return
            }
            if (Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED) {
                toast("Shizuku sudah terhubung")
            } else {
                Shizuku.requestPermission(100)
            }
        } catch (e: Throwable) {
            toast("Shizuku tidak ditemukan")
        }
    }

    private fun aiDialog() {
        val prefs = getSharedPreferences("vexed", MODE_PRIVATE)
        Ai.migrate(prefs)
        var prov = prefs.getInt("ai_provider", 2)
        val names = arrayOf("Anthropic", "OpenAI-compatible", "Gemini")
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(20), dp(8), dp(20), 0)
        val base = EditText(this)
        val key = EditText(this)
        val model = EditText(this)
        val yt = EditText(this)
        val chips = ArrayList<TextView>()
        fun paintChips() {
            chips.forEachIndexed { i, c ->
                c.text = (if (i == prov) "● " else "○ ") + names[i]
                c.setTextColor(if (i == prov) 0xFFFF7A18.toInt() else 0xFF9AA0B5.toInt())
            }
            base.hint = "Base URL (" + Ai.defBase(prov) + ")"
            model.hint = "Model (" + Ai.defModel(prov) + ")"
        }
        val provRow = LinearLayout(this)
        provRow.orientation = LinearLayout.HORIZONTAL
        names.forEachIndexed { i, n ->
            val c = TextView(this)
            c.textSize = 14f
            c.setPadding(dp(2), dp(10), dp(16), dp(10))
            c.setOnClickListener { prov = i; paintChips() }
            chips.add(c)
            provRow.addView(c)
        }
        box.addView(provRow)
        val preset = TextView(this)
        preset.text = "Pakai preset Gemini (default)"
        preset.textSize = 13f
        preset.setTextColor(0xFFFF7A18.toInt())
        preset.setPadding(dp(2), dp(4), 0, dp(10))
        preset.setOnClickListener {
            prov = 2
            base.setText(Ai.defBase(2))
            model.setText(Ai.defModel(2))
            paintChips()
        }
        box.addView(preset)
        base.setText(prefs.getString("ai_base", ""))
        base.isSingleLine = true
        key.setText(prefs.getString("ai_key", ""))
        key.hint = "Kunci API"
        key.isSingleLine = true
        key.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        model.setText(prefs.getString("ai_model", ""))
        model.isSingleLine = true
        paintChips()
        yt.hint = "Kunci YouTube Data API v3 (untuk musik, opsional)"
        yt.setText(prefs.getString("yt_key", ""))
        yt.isSingleLine = true
        yt.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        box.addView(base)
        box.addView(key)
        box.addView(model)
        box.addView(yt)
        AlertDialog.Builder(this)
            .setTitle("Asisten AI")
            .setMessage("Kunci disimpan hanya di HP ini. Kolom base URL dan model yang kosong memakai nilai bawaan (Gemini).")
            .setView(box)
            .setPositiveButton("Simpan") { _, _ ->
                val kk = key.text.toString().trim()
                if (kk.isNotEmpty() && (kk.length > 200 || kk.any { it.isWhitespace() })) {
                    toast("Kunci tidak valid: harus satu baris tanpa spasi. Tempel hanya kuncinya.")
                    return@setPositiveButton
                }
                prefs.edit()
                    .putInt("ai_provider", prov)
                    .putString("ai_base", base.text.toString().trim())
                    .putString("ai_key", key.text.toString().trim())
                    .putString("ai_model", model.text.toString().trim())
                    .putString("yt_key", yt.text.toString().trim())
                    .apply()
                toast("Tersimpan")
                refreshStatus()
            }
            .setNegativeButton("Batal", null)
            .show()
    }

    // ================= tata letak baru: Beranda · Launcher · Pandu · Pengaturan =================

    private val bg = 0xFF0E1018.toInt()
    private val prefs by lazy { getSharedPreferences("vexed", MODE_PRIVATE) }
    private lateinit var statusBox: LinearLayout
    private lateinit var navBar: LinearLayout
    private val pages = ArrayList<View>()
    private var curTab = 0
    private var allApps: List<AppRow> = emptyList()
    private var gridHost: LinearLayout? = null
    private var filter = 0
    private var query = ""

    private val dens get() = resources.displayMetrics.density

    private fun card(): LinearLayout {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        c.setPadding(dp(14), dp(12), dp(14), dp(12))
        c.background = ChamferDrawable(0xFF1F2333.toInt(), 0xFF141722.toInt(), 0xFF2E3448.toInt(), dp(12).toFloat(), dens, false)
        val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        lp.setMargins(0, dp(6), 0, dp(6))
        c.layoutParams = lp
        return c
    }

    private fun pageColumn(): LinearLayout {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        c.setPadding(dp(18), dp(4), dp(18), dp(20))
        return c
    }

    private fun scrollPage(col: LinearLayout): ScrollView {
        val sc = ScrollView(this)
        sc.isVerticalScrollBarEnabled = false
        sc.addView(col)
        return sc
    }

    private fun header(): View {
        val head = LinearLayout(this)
        head.orientation = LinearLayout.HORIZONTAL
        head.gravity = Gravity.CENTER_VERTICAL
        head.setPadding(dp(18), dp(40), dp(18), dp(10))
        head.addView(AvatarView(this, Art.face(this), red, orange), LinearLayout.LayoutParams(dp(52), dp(52)))
        val titles = LinearLayout(this)
        titles.orientation = LinearLayout.VERTICAL
        val title = TextView(this)
        title.text = "VEXED"
        title.textSize = 22f
        title.typeface = Typeface.DEFAULT_BOLD
        title.letterSpacing = 0.2f
        title.setTextColor(white)
        titles.addView(title)
        val sub = TextView(this)
        sub.text = "Final Edition  ·  v6.1"
        sub.textSize = 11f
        sub.setTextColor(gray)
        titles.addView(sub)
        val tlp = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        tlp.leftMargin = dp(12)
        head.addView(titles, tlp)
        return head
    }

    // ---------- Beranda ----------

    private fun buildHome(): View {
        val col = pageColumn()
        col.addView(label("STATUS", 12f, orange))
        val c = card()
        statusBox = c
        col.addView(c)
        col.addView(label("PANEL", 12f, orange))
        col.addView(btn("Mulai VeXed", true) {
            if (!Settings.canDrawOverlays(this)) {
                toast("Beri izin overlay dulu")
            } else {
                startForegroundService(Intent(this, OverlayService::class.java))
                toast("Ketuk logo VeXed di tepi layar")
            }
        })
        col.addView(btn("Hentikan VeXed") { stopService(Intent(this, OverlayService::class.java)) })
        col.addView(label("IZIN CEPAT", 12f, orange))
        col.addView(btn("Izin tampil di atas aplikasi lain") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        })
        col.addView(btn("Hubungkan Shizuku") { connectShizuku() })
        return scrollPage(col)
    }

    private fun statusRow(name: String, ok: Boolean) {
        val r = LinearLayout(this)
        r.orientation = LinearLayout.HORIZONTAL
        r.gravity = Gravity.CENTER_VERTICAL
        r.setPadding(0, dp(5), 0, dp(5))
        val dot = View(this)
        val gd = GradientDrawable()
        gd.shape = GradientDrawable.OVAL
        gd.setColor(if (ok) 0xFF3DFF9A.toInt() else 0xFFFF5252.toInt())
        dot.background = gd
        r.addView(dot, LinearLayout.LayoutParams(dp(10), dp(10)))
        val n = TextView(this)
        n.text = name
        n.textSize = 13f
        n.setTextColor(white)
        n.setPadding(dp(10), 0, 0, 0)
        r.addView(n, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        val v = TextView(this)
        v.text = if (ok) "aktif" else "belum"
        v.textSize = 12f
        v.setTextColor(if (ok) 0xFF3DFF9A.toInt() else gray)
        r.addView(v)
        statusBox.addView(r)
    }

    // ---------- Launcher ----------

    private fun chipBg(on: Boolean) = if (on)
        ChamferDrawable(red, orange, 0xFFFFFFFF.toInt(), dp(8).toFloat(), dens, false)
    else
        ChamferDrawable(0xFF262B3D.toInt(), 0xFF171A26.toInt(), 0xFF3A4057.toInt(), dp(8).toFloat(), dens, false)

    private fun buildLauncher(): View {
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(14), dp(4), dp(14), 0)

        val search = EditText(this)
        search.hint = "Cari game atau aplikasi"
        search.setHintTextColor(0xFF7A8099.toInt())
        search.setTextColor(white)
        search.textSize = 14f
        search.isSingleLine = true
        search.setPadding(dp(14), dp(12), dp(14), dp(12))
        search.background = ChamferDrawable(0xFF1F2333.toInt(), 0xFF141722.toInt(), 0xFF2E3448.toInt(), dp(10).toFloat(), dens, false)
        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) {
                query = s?.toString() ?: ""
                renderGrid()
            }
        })
        col.addView(search)

        val chips = ArrayList<TextView>()
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.setPadding(0, dp(8), 0, dp(6))
        listOf("Game", "Semua", "Favorit", "Terbaru").forEachIndexed { i, n ->
            val t = TextView(this)
            t.text = n
            t.textSize = 12f
            t.typeface = Typeface.DEFAULT_BOLD
            t.setTextColor(white)
            t.gravity = Gravity.CENTER
            t.setPadding(dp(4), dp(9), dp(4), dp(9))
            t.background = chipBg(i == filter)
            t.setOnClickListener {
                filter = i
                chips.forEachIndexed { j, c -> c.background = chipBg(j == i) }
                renderGrid()
            }
            chips.add(t)
            val lp = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            lp.setMargins(dp(3), 0, dp(3), 0)
            row.addView(t, lp)
        }
        col.addView(row)

        val host = LinearLayout(this)
        host.orientation = LinearLayout.VERTICAL
        gridHost = host
        val sc = ScrollView(this)
        sc.isVerticalScrollBarEnabled = false
        sc.addView(host)
        col.addView(sc, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))

        val loading = TextView(this)
        loading.text = "Memuat daftar aplikasi..."
        loading.setTextColor(gray)
        loading.setPadding(dp(4), dp(16), 0, 0)
        host.addView(loading)
        Thread {
            val l = Apps.load(this)
            runOnUiThread {
                allApps = l
                renderGrid()
            }
        }.start()
        return col
    }

    private fun addGrid(parent: LinearLayout, items: List<AppRow>, fv: Set<String>) {
        for (chunk in items.chunked(4)) {
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            for (a in chunk) {
                val lp = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                lp.setMargins(dp(3), dp(3), dp(3), dp(3))
                row.addView(gridTile(a, a.pkg in fv), lp)
            }
            for (k in chunk.size until 4) {
                row.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))
            }
            parent.addView(row)
        }
    }

    private fun gridTile(a: AppRow, fav: Boolean): View {
        val box = FrameLayout(this)
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.gravity = Gravity.CENTER_HORIZONTAL
        col.setPadding(dp(4), dp(10), dp(4), dp(8))
        col.background = ChamferDrawable(0xFF1F2333.toInt(), 0xFF141722.toInt(), 0xFF2E3448.toInt(), dp(10).toFloat(), dens, false)
        val iv = ImageView(this)
        iv.setImageDrawable(a.icon)
        col.addView(iv, LinearLayout.LayoutParams(dp(48), dp(48)))
        val tv = TextView(this)
        tv.text = a.label
        tv.textSize = 10.5f
        tv.setTextColor(white)
        tv.maxLines = 1
        tv.ellipsize = TextUtils.TruncateAt.END
        tv.gravity = Gravity.CENTER
        tv.setPadding(0, dp(5), 0, 0)
        col.addView(tv, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))
        box.addView(col, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.WRAP_CONTENT))
        if (fav) {
            box.addView(
                IconView(this, Icons.STAR, 0xFFFFD43B.toInt()),
                FrameLayout.LayoutParams(dp(18), dp(18), Gravity.TOP or Gravity.END)
            )
        }
        col.setOnClickListener { launchGame(a) }
        col.setOnLongClickListener { toggleFav(a.pkg); true }
        return box
    }

    private fun renderGrid() {
        val host = gridHost ?: return
        host.removeAllViews()
        val all = allApps
        if (all.isEmpty()) {
            val t = TextView(this)
            t.text = "Memuat daftar aplikasi..."
            t.setTextColor(gray)
            t.setPadding(dp(4), dp(16), 0, 0)
            host.addView(t)
            return
        }
        val fv = Apps.favs(prefs)
        val rec = Apps.recents(prefs)
        val q = query.trim().lowercase()
        var items = when (filter) {
            0 -> all.filter { it.game || it.pkg in fv }
            2 -> all.filter { it.pkg in fv }
            3 -> rec.mapNotNull { p -> all.firstOrNull { it.pkg == p } }
            else -> all
        }
        if (q.isNotEmpty()) items = items.filter { it.label.lowercase().contains(q) || it.pkg.contains(q) }
        if (filter != 3) items = items.sortedWith(compareByDescending<AppRow> { it.pkg in fv }.thenBy { it.label.lowercase() })
        if (items.isEmpty()) {
            val t = TextView(this)
            t.text = when {
                filter == 2 -> "Belum ada favorit. Tahan sebuah aplikasi untuk menambahkannya."
                filter == 3 -> "Belum ada riwayat. Buka game dari sini dulu."
                filter == 0 -> "Game tidak terdeteksi otomatis. Pilih \"Semua\", lalu tahan aplikasi untuk memfavoritkan."
                else -> "Tidak ada hasil."
            }
            t.setTextColor(gray)
            t.setPadding(dp(4), dp(16), dp(4), 0)
            host.addView(t)
            return
        }
        if (q.isEmpty() && (filter == 0 || filter == 1)) {
            val recent = rec.mapNotNull { p -> all.firstOrNull { it.pkg == p } }.take(4)
            if (recent.isNotEmpty()) {
                host.addView(label("TERAKHIR DIMAINKAN", 11f, orange))
                addGrid(host, recent, fv)
                host.addView(label(if (filter == 0) "GAME" else "SEMUA APLIKASI", 11f, orange))
            }
        }
        addGrid(host, items.take(200), fv)
        val pad = View(this)
        host.addView(pad, LinearLayout.LayoutParams(1, dp(16)))
    }

    private fun toggleFav(pkg: String) {
        val s = Apps.favs(prefs)
        if (!s.add(pkg)) s.remove(pkg)
        Apps.saveFavs(prefs, s)
        toast(if (pkg in s) "Ditambahkan ke favorit" else "Dihapus dari favorit")
        renderGrid()
    }

    private fun launchGame(a: AppRow) {
        if (Settings.canDrawOverlays(this)) {
            val i = Intent(this, OverlayService::class.java)
            i.putExtra("launch_pkg", a.pkg)
            startForegroundService(i)
        } else {
            Apps.pushRecent(prefs, a.pkg)
            val li = packageManager.getLaunchIntentForPackage(a.pkg)
            if (li == null) {
                toast("Tidak bisa membuka ${a.label}")
            } else {
                li.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                startActivity(li)
            }
        }
    }

    // ---------- Pandu ----------

    private fun guideItems(): List<Pair<String, String>> = listOf(
        "Mulai cepat" to "1. Di Beranda, beri izin tampil di atas aplikasi lain.\n2. Ketuk Mulai VeXed.\n3. Ketuk logo VeXed di tepi layar untuk membuka panel. Tab GAME berisi launcher, robot, jam, YouTube, dan lainnya.",
        "Shizuku dan rish" to "Shizuku membuka fitur lanjutan: FPS asli, Boost, screenshot untuk robot, dan pengaturan sistem. Nyalakan Wireless Debugging, buka aplikasi Shizuku, lalu ketuk Hubungkan Shizuku di Beranda. Perintah rish untuk memberi izin ada di tab Pengaturan, bagian Cadangan.",
        "Robot Vex" to "Ketuk robot untuk chat. Tahan robot untuk menu radial (HUD, bidik, game, YouTube, penerjemah, voice, mode game). Ikon kamera di chat menyuruh Vex melihat layar dan membantu. Ikon mikrofon untuk bicara. Aktifkan Suara Vex agar balasan dibacakan. Isi kunci API di Pengaturan supaya Vex bisa menjawab (default: Gemini).",
        "Crosshair" to "Tahan tile Crosshair di panel untuk mengatur bentuk, warna, ukuran, celah, transparansi, dan posisinya. Ketuk tilenya untuk menampilkan atau menyembunyikan. Ada preview langsung di jendela pengaturan.",
        "Launcher dan profil game" to "Buka game dari tab Launcher di sini atau dari launcher melayang. Ketuk untuk membuka, tahan di launcher melayang untuk profil khusus (HUD, crosshair, boost, DND, refresh, dan lainnya yang aktif otomatis). Di tab Launcher ini, tahan aplikasi untuk memfavoritkannya. Tab Terbaru menampilkan yang terakhir dimainkan.",
        "YouTube melayang" to "Buka tile YouTube di tab GAME untuk menonton atau mendengarkan musik sambil bermain, tanpa kunci API. Tarik sudut kanan-bawah untuk mengubah ukuran, atau pakai tombol Mini dan Besar. Ketuk Ketik saat ingin mengetik pencarian, lalu Selesai agar game kembali mendapat fokus. Tombol layar penuh di pemutar YouTube juga berfungsi.",
        "Voice changer dan soundboard" to "Beri izin mikrofon di Pengaturan. Pilih efek, lalu nyalakan. Pakai headset supaya tidak berdengung. Suara hasil efek hanya diputar di HP ini; tanpa root tidak bisa masuk ke voice chat game. Soundboard punya 16 suara dengan slider volume.",
        "Booster dan Mode Game" to "Tab BOOSTER memuat Mode Game (Boost, Jangan Ganggu, dan HUD sekaligus), pembersih RAM dan cache, kunci refresh rate, dan kecerahan maksimum. Sebagian butuh Shizuku dan hasilnya bergantung perangkat.",
        "Jika ada masalah" to "Overlay tidak muncul: cek izin tampil di atas aplikasi lain di Beranda. FPS menampilkan \"--\": hubungkan Shizuku. Robot menjawab \"Gagal\": buka Pengaturan, pastikan kolom kunci API hanya berisi kuncinya (satu baris) dan modelnya benar. Panel terasa berat: matikan HUD detail dan animasi di Pengaturan panel.",
        "Segera hadir" to "Kunci Aplikasi: VeXed mengunci aplikasi pilihanmu dengan PIN atau sidik jari, dengan daftar aplikasi yang dikecualikan.\nAI VeXed: asisten bawaan yang lebih praktis tanpa perlu kunci API sendiri. API lain tetap bisa dipakai."
    )

    private fun guideCard(title: String, body: String): View {
        val c = card()
        val head = LinearLayout(this)
        head.orientation = LinearLayout.HORIZONTAL
        head.gravity = Gravity.CENTER_VERTICAL
        val t = TextView(this)
        t.text = title
        t.textSize = 14f
        t.typeface = Typeface.DEFAULT_BOLD
        t.setTextColor(white)
        head.addView(t, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        val arrow = TextView(this)
        arrow.text = "+"
        arrow.textSize = 18f
        arrow.setTextColor(orange)
        head.addView(arrow)
        val bd = TextView(this)
        bd.text = body
        bd.textSize = 12.5f
        bd.setTextColor(0xFFC7CBE0.toInt())
        bd.setLineSpacing(0f, 1.15f)
        bd.setPadding(0, dp(8), 0, 0)
        bd.visibility = View.GONE
        c.setOnClickListener {
            val open = bd.visibility != View.VISIBLE
            bd.visibility = if (open) View.VISIBLE else View.GONE
            arrow.text = if (open) "−" else "+"
            if (open) {
                bd.alpha = 0f
                bd.animate().alpha(1f).setDuration(160).start()
            }
        }
        c.addView(head)
        c.addView(bd)
        return c
    }

    private fun buildGuide(): View {
        val col = pageColumn()
        col.addView(label("PANDU", 12f, orange))
        val intro = TextView(this)
        intro.text = "Ketuk judul untuk membuka penjelasan."
        intro.textSize = 12f
        intro.setTextColor(gray)
        col.addView(intro)
        for ((t, b) in guideItems()) col.addView(guideCard(t, b))
        return scrollPage(col)
    }

    // ---------- Pengaturan ----------

    private fun soonCard(title: String, body: String): View {
        val c = card()
        val head = LinearLayout(this)
        head.orientation = LinearLayout.HORIZONTAL
        head.gravity = Gravity.CENTER_VERTICAL
        val t = TextView(this)
        t.text = title
        t.textSize = 14f
        t.typeface = Typeface.DEFAULT_BOLD
        t.setTextColor(white)
        head.addView(t, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        val badge = TextView(this)
        badge.text = "SEGERA"
        badge.textSize = 10f
        badge.typeface = Typeface.DEFAULT_BOLD
        badge.setTextColor(0xFFFFFFFF.toInt())
        badge.setPadding(dp(8), dp(3), dp(8), dp(3))
        badge.background = ChamferDrawable(red, orange, 0x00FFFFFF, dp(6).toFloat(), dens, false)
        head.addView(badge)
        val b = TextView(this)
        b.text = body
        b.textSize = 12f
        b.setTextColor(gray)
        b.setPadding(0, dp(6), 0, 0)
        c.addView(head)
        c.addView(b)
        return c
    }

    private fun buildSettings(): View {
        val col = pageColumn()
        col.addView(label("ASISTEN AI", 12f, orange))
        col.addView(btn("Atur kunci API & model robot") { aiDialog() })
        col.addView(btn("Izin mikrofon (voice changer & suara)") {
            requestPermissions(arrayOf("android.permission.RECORD_AUDIO"), 7)
        })
        col.addView(label("IZIN", 12f, orange))
        col.addView(btn("Izin Telepon (tolak panggilan)") {
            requestPermissions(arrayOf(Manifest.permission.READ_PHONE_STATE, Manifest.permission.ANSWER_PHONE_CALLS), 2)
        })
        col.addView(btn("Izin Jangan Ganggu") {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS))
        })
        col.addView(label("CADANGAN (LEWAT RISH)", 12f, orange))
        col.addView(btn("Salin: izin overlay") { copy("appops set com.neopanel.app SYSTEM_ALERT_WINDOW allow") })
        col.addView(btn("Salin: izin DUMP (FPS tanpa Shizuku di aplikasi)") { copy("pm grant com.neopanel.app android.permission.DUMP") })
        col.addView(label("SEGERA HADIR", 12f, orange))
        col.addView(soonCard("Kunci Aplikasi", "Kunci aplikasi pilihanmu dengan PIN atau sidik jari untuk menjaga privasi, dengan daftar aplikasi yang tidak ikut dikunci."))
        col.addView(soonCard("AI VeXed", "Asisten bawaan VeXed yang lebih praktis tanpa kunci API sendiri. API lain tetap bisa dipakai."))
        return scrollPage(col)
    }

    // ---------- Navigasi ----------

    private fun buildNav(): LinearLayout {
        navBar = LinearLayout(this)
        navBar.orientation = LinearLayout.HORIZONTAL
        navBar.setPadding(dp(8), dp(6), dp(8), dp(10))
        navBar.setBackgroundColor(0xFF12151F.toInt())
        renderNav()
        return navBar
    }

    private fun renderNav() {
        navBar.removeAllViews()
        val items = listOf("Beranda" to Icons.ROCKET, "Launcher" to Icons.GAME, "Pandu" to Icons.NOTE, "Pengaturan" to Icons.GEAR)
        items.forEachIndexed { i, (name, ic) ->
            val on = i == curTab
            val c = LinearLayout(this)
            c.orientation = LinearLayout.VERTICAL
            c.gravity = Gravity.CENTER_HORIZONTAL
            c.setPadding(dp(4), dp(7), dp(4), dp(6))
            if (on) c.background = ChamferDrawable(red, orange, 0x00FFFFFF, dp(8).toFloat(), dens, false)
            c.addView(IconView(this, ic, if (on) 0xFFFFFFFF.toInt() else gray), LinearLayout.LayoutParams(dp(22), dp(22)))
            val t = TextView(this)
            t.text = name
            t.textSize = 10f
            t.typeface = Typeface.DEFAULT_BOLD
            t.setTextColor(if (on) 0xFFFFFFFF.toInt() else gray)
            t.gravity = Gravity.CENTER
            t.setPadding(0, dp(3), 0, 0)
            c.addView(t)
            c.setOnClickListener { selectTab(i) }
            val lp = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            lp.setMargins(dp(3), 0, dp(3), 0)
            navBar.addView(c, lp)
        }
    }

    private fun selectTab(i: Int) {
        curTab = i
        for ((k, p) in pages.withIndex()) {
            p.visibility = if (k == i) View.VISIBLE else View.GONE
            if (k == i) {
                p.alpha = 0f
                p.animate().alpha(1f).setDuration(170).start()
            }
        }
        renderNav()
        if (i == 0) refreshStatus()
        if (i == 1) renderGrid()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(bg)
        root.addView(header())
        val content = FrameLayout(this)
        pages.add(buildHome())
        pages.add(buildLauncher())
        pages.add(buildGuide())
        pages.add(buildSettings())
        for (p in pages) {
            content.addView(p, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))
        }
        root.addView(content, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))
        root.addView(buildNav())
        setContentView(root)
        selectTab(0)
        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
    }

    override fun onResume() {
        super.onResume()
        refreshStatus()
        if (allApps.isNotEmpty() && curTab == 1) renderGrid()
    }

    private fun refreshStatus() {
        if (!::statusBox.isInitialized) return
        statusBox.removeAllViews()
        val ph = checkSelfPermission(Manifest.permission.READ_PHONE_STATE) == PackageManager.PERMISSION_GRANTED &&
            checkSelfPermission(Manifest.permission.ANSWER_PHONE_CALLS) == PackageManager.PERMISSION_GRANTED
        statusRow("Overlay (tampil di atas aplikasi)", Settings.canDrawOverlays(this))
        statusRow("Shizuku", Sh.ready())
        statusRow("Izin telepon", ph)
        statusRow("Jangan Ganggu", getSystemService(NotificationManager::class.java).isNotificationPolicyAccessGranted)
        statusRow("Kunci API asisten", !prefs.getString("ai_key", "").isNullOrBlank())
        statusRow("Mikrofon", checkSelfPermission("android.permission.RECORD_AUDIO") == PackageManager.PERMISSION_GRANTED)
    }
}
