package com.neopanel.app

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.app.NotificationManager
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.text.InputType
import android.provider.Settings
import android.view.Gravity
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import rikka.shizuku.Shizuku

class MainActivity : Activity() {

    private lateinit var status: TextView
    private val red = 0xFFFF2D55.toInt()
    private val orange = 0xFFFF7A18.toInt()
    private val white = 0xFFE8EAF6.toInt()
    private val gray = 0xFF9AA0B5.toInt()

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun btn(label: String, primary: Boolean = false, action: () -> Unit): TextView {
        val t = TextView(this)
        t.text = label
        t.textSize = 14f
        t.typeface = Typeface.DEFAULT_BOLD
        t.setTextColor(white)
        t.gravity = Gravity.CENTER
        t.setPadding(dp(16), dp(14), dp(16), dp(14))
        val d = resources.displayMetrics.density
        t.background = if (primary)
            ChamferDrawable(red, orange, 0xFFFFFFFF.toInt(), dp(10).toFloat(), d, false)
        else
            ChamferDrawable(0xFF262B3D.toInt(), 0xFF171A26.toInt(), 0xFF3A4057.toInt(), dp(10).toFloat(), d, false)
        val lp = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
        )
        lp.setMargins(0, dp(5), 0, dp(5))
        t.layoutParams = lp
        t.setOnClickListener { action() }
        return t
    }

    private fun label(text: String, size: Float, color: Int): TextView {
        val t = TextView(this)
        t.text = text
        t.textSize = size
        t.setTextColor(color)
        t.setPadding(0, dp(10), 0, dp(4))
        return t
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    private fun copy(text: String) {
        getSystemService(ClipboardManager::class.java)
            .setPrimaryClip(ClipData.newPlainText("cmd", text))
        toast("Disalin")
    }

    private fun connectShizuku() {
        try {
            if (!Shizuku.pingBinder()) {
                toast("Jalankan aplikasi Shizuku dulu (Wireless Debugging)")
                return
            }
            if (Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED) {
                toast("Shizuku sudah terhubung")
            } else {
                Shizuku.requestPermission(100)
            }
        } catch (e: Throwable) {
            toast("Shizuku tidak ditemukan")
        }
    }

    private fun aiDialog() {
        val prefs = getSharedPreferences("vexed", MODE_PRIVATE)
        Ai.migrate(prefs)
        var prov = prefs.getInt("ai_provider", 2)
        val names = arrayOf("Anthropic", "OpenAI-compatible", "Gemini")
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(20), dp(8), dp(20), 0)
        val base = EditText(this)
        val key = EditText(this)
        val model = EditText(this)
        val yt = EditText(this)
        val chips = ArrayList<TextView>()
        fun paintChips() {
            chips.forEachIndexed { i, c ->
                c.text = (if (i == prov) "● " else "○ ") + names[i]
                c.setTextColor(if (i == prov) 0xFFFF7A18.toInt() else 0xFF9AA0B5.toInt())
            }
            base.hint = "Base URL (" + Ai.defBase(prov) + ")"
            model.hint = "Model (" + Ai.defModel(prov) + ")"
        }
        val provRow = LinearLayout(this)
        provRow.orientation = LinearLayout.HORIZONTAL
        names.forEachIndexed { i, n ->
            val c = TextView(this)
            c.textSize = 14f
            c.setPadding(dp(2), dp(10), dp(16), dp(10))
            c.setOnClickListener { prov = i; paintChips() }
            chips.add(c)
            provRow.addView(c)
        }
        box.addView(provRow)
        val preset = TextView(this)
        preset.text = "Pakai preset Gemini (default)"
        preset.textSize = 13f
        preset.setTextColor(0xFFFF7A18.toInt())
        preset.setPadding(dp(2), dp(4), 0, dp(10))
        preset.setOnClickListener {
            prov = 2
            base.setText(Ai.defBase(2))
            model.setText(Ai.defModel(2))
            paintChips()
        }
        box.addView(preset)
        base.setText(prefs.getString("ai_base", ""))
        base.isSingleLine = true
        key.setText(prefs.getString("ai_key", ""))
        key.hint = "Kunci API"
        key.isSingleLine = true
        key.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        model.setText(prefs.getString("ai_model", ""))
        model.isSingleLine = true
        paintChips()
        yt.hint = "Kunci YouTube Data API v3 (untuk musik, opsional)"
        yt.setText(prefs.getString("yt_key", ""))
        yt.isSingleLine = true
        yt.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        box.addView(base)
        box.addView(key)
        box.addView(model)
        box.addView(yt)
        AlertDialog.Builder(this)
            .setTitle("Asisten AI")
            .setMessage("Kunci disimpan hanya di HP ini. Kolom base URL dan model yang kosong memakai nilai bawaan (Gemini).")
            .setView(box)
            .setPositiveButton("Simpan") { _, _ ->
                val kk = key.text.toString().trim()
                if (kk.isNotEmpty() && (kk.length > 200 || kk.any { it.isWhitespace() })) {
                    toast("Kunci tidak valid: harus satu baris tanpa spasi. Tempel hanya kuncinya.")
                    return@setPositiveButton
                }
                prefs.edit()
                    .putInt("ai_provider", prov)
                    .putString("ai_base", base.text.toString().trim())
                    .putString("ai_key", key.text.toString().trim())
                    .putString("ai_model", model.text.toString().trim())
                    .putString("yt_key", yt.text.toString().trim())
                    .apply()
                toast("Tersimpan")
                refreshStatus()
            }
            .setNegativeButton("Batal", null)
            .show()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(dp(22), dp(44), dp(22), dp(24))

        val head = LinearLayout(this)
        head.orientation = LinearLayout.HORIZONTAL
        head.gravity = Gravity.CENTER_VERTICAL
        head.addView(AvatarView(this, Art.face(this), red, orange), LinearLayout.LayoutParams(dp(60), dp(60)))
        val titles = LinearLayout(this)
        titles.orientation = LinearLayout.VERTICAL
        val title = TextView(this)
        title.text = "VEXED"
        title.textSize = 26f
        title.typeface = Typeface.DEFAULT_BOLD
        title.letterSpacing = 0.2f
        title.setTextColor(white)
        titles.addView(title)
        val sub = TextView(this)
        sub.text = "Final Edition  ·  v6.0"
        sub.textSize = 12f
        sub.setTextColor(gray)
        titles.addView(sub)
        val tlp = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        tlp.leftMargin = dp(12)
        head.addView(titles, tlp)
        root.addView(head)

        status = label("", 13f, gray)
        root.addView(status)

        root.addView(label("IZIN", 12f, orange))
        root.addView(btn("Izin tampil di atas aplikasi lain") {
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
        })
        root.addView(btn("Hubungkan Shizuku") { connectShizuku() })
        root.addView(btn("Izin Telepon (tolak panggilan)") {
            requestPermissions(
                arrayOf(Manifest.permission.READ_PHONE_STATE, Manifest.permission.ANSWER_PHONE_CALLS), 2
            )
        })
        root.addView(btn("Izin Jangan Ganggu") {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS))
        })

        root.addView(label("PANEL", 12f, orange))
        root.addView(btn("Mulai VeXed", true) {
            if (!Settings.canDrawOverlays(this)) {
                toast("Beri izin overlay dulu")
            } else {
                startForegroundService(Intent(this, OverlayService::class.java))
                toast("Ketuk logo VeXed di tepi layar")
            }
        })
        root.addView(btn("Hentikan VeXed") {
            stopService(Intent(this, OverlayService::class.java))
        })

        root.addView(label("ASISTEN AI", 12f, orange))
        root.addView(btn("Atur kunci API & model robot") { aiDialog() })
        root.addView(btn("Izin mikrofon (voice changer)") {
            requestPermissions(arrayOf("android.permission.RECORD_AUDIO"), 7)
        })

        root.addView(label("CADANGAN (lewat rish)", 12f, orange))
        root.addView(btn("Salin: izin overlay") {
            copy("appops set com.neopanel.app SYSTEM_ALERT_WINDOW allow")
        })
        root.addView(btn("Salin: izin DUMP (FPS tanpa Shizuku di aplikasi)") {
            copy("pm grant com.neopanel.app android.permission.DUMP")
        })

        val scroll = ScrollView(this)
        scroll.setBackgroundColor(0xFF0E1018.toInt())
        scroll.addView(root)
        setContentView(scroll)

        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
    }

    override fun onResume() {
        super.onResume()
        refreshStatus()
    }

    private fun refreshStatus() {
        val ov = Settings.canDrawOverlays(this)
        val shz = Sh.ready()
        val ph = checkSelfPermission(Manifest.permission.READ_PHONE_STATE) == PackageManager.PERMISSION_GRANTED &&
            checkSelfPermission(Manifest.permission.ANSWER_PHONE_CALLS) == PackageManager.PERMISSION_GRANTED
        val dnd = getSystemService(NotificationManager::class.java).isNotificationPolicyAccessGranted
        fun s(b: Boolean) = if (b) "aktif" else "belum"
        val ai = !getSharedPreferences("vexed", MODE_PRIVATE).getString("ai_key", "").isNullOrBlank()
        status.text = "Overlay: ${s(ov)}\nShizuku: ${s(shz)}\nTelepon: ${s(ph)}\nJangan Ganggu: ${s(dnd)}\nKunci AI: ${if (ai) "terpasang" else "belum"}\nMikrofon: ${s(checkSelfPermission("android.permission.RECORD_AUDIO") == PackageManager.PERMISSION_GRANTED)}"
    }
}
