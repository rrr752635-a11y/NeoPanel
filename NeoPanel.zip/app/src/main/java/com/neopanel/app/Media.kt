package com.neopanel.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.provider.MediaStore

class MediaItem(val uri: Uri, val name: String, val isVideo: Boolean)

/** Cari file media terbaru di galeri. Butuh izin baca media (READ_MEDIA_IMAGES/VIDEO atau
 * READ_EXTERNAL_STORAGE di Android lama). Jalankan di thread latar. */
object Media {
    fun latest(ctx: Context, video: Boolean): MediaItem? {
        val collection = if (video) MediaStore.Video.Media.EXTERNAL_CONTENT_URI
        else MediaStore.Images.Media.EXTERNAL_CONTENT_URI
        val nameCol = if (video) MediaStore.Video.Media.DISPLAY_NAME else MediaStore.Images.Media.DISPLAY_NAME
        val dateCol = if (video) MediaStore.Video.Media.DATE_ADDED else MediaStore.Images.Media.DATE_ADDED
        val idCol = if (video) MediaStore.Video.Media._ID else MediaStore.Images.Media._ID
        val proj = arrayOf(idCol, nameCol)
        val cur = try {
            ctx.contentResolver.query(collection, proj, null, null, "$dateCol DESC LIMIT 1")
        } catch (e: Exception) {
            null
        } ?: return null
        cur.use {
            if (!it.moveToFirst()) return null
            val id = it.getLong(it.getColumnIndexOrThrow(idCol))
            val name = it.getString(it.getColumnIndexOrThrow(nameCol)) ?: "media"
            val uri = Uri.withAppendedPath(collection, id.toString())
            return MediaItem(uri, name, video)
        }
    }

    /** Decode bitmap dengan downsample supaya aman buat ditampilkan di bubble chat (maks sisi ~900px). */
    fun decodeDownsampled(ctx: Context, uri: Uri, maxSide: Int = 900): Bitmap? {
        return try {
            val opts = BitmapFactory.Options()
            opts.inJustDecodeBounds = true
            ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
            var sample = 1
            while (opts.outWidth / sample > maxSide || opts.outHeight / sample > maxSide) sample *= 2
            val opts2 = BitmapFactory.Options()
            opts2.inSampleSize = sample
            ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts2) }
        } catch (e: Exception) {
            null
        }
    }

    /** Thumbnail video (API 29+ pakai loadThumbnail, di bawahnya fallback null -> ditampilkan sebagai ikon saja). */
    fun videoThumb(ctx: Context, uri: Uri, w: Int, h: Int): Bitmap? {
        return try {
            if (android.os.Build.VERSION.SDK_INT >= 29) {
                ctx.contentResolver.loadThumbnail(uri, android.util.Size(w, h), null)
            } else {
                null
            }
        } catch (e: Exception) {
            null
        }
    }
}
