package com.neopanel.app

class BrainCtx(
    val ram: Int, val temp: Int, val battery: Int, val fps: Int, val ping: Int,
    val game: String, val sessionMin: Long
)

/**
 * VeXed AI bawaan: asisten lokal berbasis pengetahuan (bukan model bahasa besar).
 * Jalan tanpa internet dan tanpa kunci API. Untuk obrolan bebas, hubungkan Gemini/API lain.
 */
object VexBrain {
    private class Rule(val keys: List<String>, val out: (BrainCtx) -> String)

    private fun fpsAdvice(c: BrainCtx): String {
        val now = if (c.fps in 1..120) "FPS-mu sekarang sekitar ${c.fps}. " else ""
        return now + "Coba berurutan: (1) turunkan grafis dan matikan bayangan di game, (2) nyalakan Mode Game di tab BOOSTER, " +
            "(3) bersihkan RAM, (4) lepas casing dan jauhkan dari tempat panas, (5) kunci refresh rate ke nilai stabil. " +
            "Kalau FPS-nya anjlok setelah lama main, biasanya karena HP panas."
    }

    private fun heatAdvice(c: BrainCtx): String {
        val t = if (c.temp > 0) "Suhu baterai sekarang ${c.temp}°C. " else ""
        val lvl = when {
            c.temp >= 45 -> "Itu sudah panas sekali, istirahatkan HP dulu. "
            c.temp >= 40 -> "Itu mulai hangat. "
            else -> ""
        }
        return t + lvl + "Kurangi panas: lepas casing, jangan main sambil mengisi daya, turunkan kecerahan, dan matikan refresh rate maksimum bila tidak perlu."
    }

    private val rules: List<Rule> = listOf(
        Rule(listOf("fps", "lag", "patah", "ngelag", "drop", "nge-lag")) { c -> fpsAdvice(c) },
        Rule(listOf("panas", "suhu", "overheat", "hangat")) { c -> heatAdvice(c) },
        Rule(listOf("ping", "koneksi", "jaringan", "sinyal", "delay")) { c ->
            val p = if (c.ping >= 0) "Ping-mu ${c.ping} ms. " else ""
            p + "Untuk ping lebih stabil: dekati router atau pakai 5 GHz, tutup aplikasi yang mengunduh, coba DNS Cepat di tab JARINGAN, dan hindari main saat ada yang streaming di jaringan yang sama."
        },
        Rule(listOf("baterai", "boros", "charger", "cas ", "ngecas")) { c ->
            "Baterai ${c.battery}%. Hemat baterai: turunkan kecerahan, kunci refresh ke 60 Hz, matikan HUD detail, dan hindari main sambil mengisi daya agar tidak panas."
        },
        Rule(listOf("ram", "memori", "penuh")) { c ->
            "RAM terpakai ${c.ram}%. Ketuk Bersihkan RAM di tab BOOSTER atau bilang \"bersihkan ram\". Boost butuh Shizuku aktif."
        },
        Rule(listOf("crosshair", "bidik", "titik tengah")) {
            "Tahan tile Crosshair di tab GAME untuk mengatur bentuk, warna, ukuran, celah, transparansi, dan posisi. Atau bilang \"pasang crosshair\"."
        },
        Rule(listOf("launcher", "profil", "buka game", "daftar game")) {
            "Buka game dari Launcher: ketuk untuk membuka, tahan di launcher melayang untuk profil khusus (HUD, crosshair, boost, DND, dan lainnya yang aktif otomatis)."
        },
        Rule(listOf("youtube", "musik", "lagu", "nonton", "video")) {
            "Tile YouTube di tab GAME membuka pemutar melayang tanpa API. Tarik sudut kanan-bawah untuk ubah ukuran, dan ketuk Ketik saat ingin mencari."
        },
        Rule(listOf("voice", "pengubah suara", "efek suara", "soundboard")) {
            "Voice changer ada 12 efek dan butuh izin mikrofon (Pengaturan di aplikasi VeXed). Pakai headset supaya tidak berdengung. Suaranya hanya diputar di HP-mu, tidak masuk ke voice chat game tanpa root."
        },
        Rule(listOf("kunci aplikasi", "app lock", "applock", "privasi", "pin ")) {
            "Kunci Aplikasi ada di tab Kunci di aplikasi VeXed: buat PIN, aktifkan layanan aksesibilitas, lalu nyalakan. Semua aplikasi dikunci kecuali yang kamu bebaskan, dan sidik jari bisa dipakai."
        },
        Rule(listOf("shizuku", "rish", "izin overlay", "overlay")) {
            "Shizuku membuka FPS asli, Boost, dan screenshot untuk robot. Nyalakan Wireless Debugging lalu Hubungkan Shizuku di Beranda. Perintah rish ada di Pengaturan, bagian Cadangan."
        },
        Rule(listOf("gemini", "api", "kunci api", "token", "model ai")) {
            "Untuk obrolan bebas, isi kunci Gemini (atau API lain) lewat aplikasi VeXed > Pengaturan > Atur kunci API. Tanpa kunci, aku tetap bisa bantu soal VeXed dan tips performa."
        },
        Rule(listOf("terjemah", "translate")) {
            "Buka tile Penerjemah di tab GAME, atau bilang \"terjemahkan layar\". Penerjemahan butuh kunci API; mode layar butuh Shizuku juga."
        },
        Rule(listOf("statistik", "waktu layar", "berapa lama main", "screen time")) { c ->
            val s = if (c.sessionMin > 0) "Sesi ${c.game.ifEmpty { "game" }} sudah ${c.sessionMin} menit. " else ""
            s + "Waktu layar harian ada di Beranda (perlu layanan Kunci aktif)."
        },
        Rule(listOf("tips", "saran", "rekomendasi", "gimana biar")) { c ->
            when {
                c.temp >= 42 -> heatAdvice(c)
                c.fps in 1..30 -> fpsAdvice(c)
                c.ram >= 85 -> "RAM-mu sudah ${c.ram}%. Bersihkan RAM dulu sebelum lanjut main."
                else -> "Kondisi HP-mu aman: RAM ${c.ram}%, suhu ${c.temp}°C, baterai ${c.battery}%. Nyalakan Mode Game untuk performa terbaik, dan jangan lupa istirahat tiap 45 menit."
            }
        },
        Rule(listOf("fitur", "bisa apa", "apa saja", "bantu apa")) {
            "Aku bisa: buka game, nyalakan HUD dan crosshair, Mode Game, bersihkan RAM, screenshot, putar YouTube, buka penerjemah dan voice changer, plus tips FPS, suhu, dan jaringan. Hubungkan Gemini untuk obrolan bebas."
        },
        Rule(listOf("siapa kamu", "kamu siapa", "nama kamu", "namamu")) {
            "Aku Vex, asisten VeXed. Versi bawaan ini jalan di HP-mu tanpa internet; kalau kamu isi kunci API, aku jadi lebih pintar ngobrol."
        },
        Rule(listOf("halo", "hai", "hi ", "pagi", "siang", "sore", "malam", "assalam")) { c ->
            "Halo! Aku siap bantu. Kondisi HP: RAM ${c.ram}%, suhu ${c.temp}°C, baterai ${c.battery}%. Mau ngapain?"
        },
        Rule(listOf("makasih", "terima kasih", "thanks", "thx")) { "Sama-sama! Kalau butuh lagi, ketuk aku." },
        Rule(listOf("bosan", "capek", "lelah", "sedih", "kesal", "bete")) {
            "Istirahat sebentar itu penting. Minum dulu, regangkan badan, lalu lanjut main kalau sudah segar. Aku di sini."
        }
    )

    fun reply(q: String, c: BrainCtx, style: Int): String {
        val s = " " + q.lowercase().trim() + " "
        var best: Rule? = null
        var bestScore = 0
        for (r in rules) {
            var sc = 0
            for (k in r.keys) if (s.contains(k)) sc += if (k.length >= 5) 2 else 1
            if (sc > bestScore) { bestScore = sc; best = r }
        }
        val out = best?.out?.invoke(c)
        val text = out ?: when (style) {
            0 -> "Hmm, itu di luar yang kupahami, Kak. Aku paham tips performa, fitur VeXed, dan perintah seperti \"nyalakan hud\". Hubungkan Gemini di Pengaturan untuk obrolan bebas."
            1 -> "Belum nyambung nih. Aku jago tips performa dan fitur VeXed. Mau obrolan bebas? Hubungkan Gemini di Pengaturan."
            else -> "Pertanyaan itu di luar kemampuan asisten bawaan. Hubungkan API di Pengaturan untuk jawaban penuh."
        }
        return text
    }
}
