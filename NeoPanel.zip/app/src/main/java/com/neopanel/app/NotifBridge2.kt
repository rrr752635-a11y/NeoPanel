package com.neopanel.app

import android.app.Notification
import android.app.PendingIntent
import android.app.RemoteInput
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

class NotifMsg(
    val key: String,
    val pkg: String,
    val sender: String,
    val text: String,
    val remoteInputKey: String?,
    val replyIntent: PendingIntent?
)

/**
 * Jembatan ke layanan pembaca notifikasi. Hanya memantau notifikasi WhatsApp (tidak membaca
 * aplikasi lain), dan HANYA menampilkan ringkasan + menyiapkan draft balasan. Pengiriman balasan
 * memakai tombol "Balas" resmi bawaan notifikasi WhatsApp sendiri (RemoteInput Android, mekanisme
 * yang sama dipakai jam tangan/mobil untuk balas tanpa membuka aplikasi), dan HANYA terjadi kalau
 * pengguna sendiri menekan tombol Kirim di jendela VeXed setelah membaca/mengedit draftnya.
 * Tidak pernah mengirim apa pun secara otomatis tanpa sepengetahuan pengguna.
 */
object NotifBridge {
    @Volatile var service: NotifListener? = null
    val watched = setOf("com.whatsapp", "com.whatsapp.w4b")
    @Volatile var onMessage: ((NotifMsg) -> Unit)? = null

    fun enabled(ctx: Context): Boolean {
        if (service != null) return true
        val v = Settings.Secure.getString(ctx.contentResolver, "enabled_notification_listeners") ?: return false
        return v.contains(ctx.packageName)
    }

    fun sendReply(ctx: Context, msg: NotifMsg, text: String): Boolean {
        val intent = msg.replyIntent ?: return false
        val key = msg.remoteInputKey ?: return false
        return try {
            val results = Bundle()
            results.putCharSequence(key, text)
            val input = RemoteInput.Builder(key).build()
            val data = Intent()
            RemoteInput.addResultsToIntent(arrayOf(input), data, results)
            intent.send(ctx, 0, data)
            true
        } catch (e: Throwable) {
            false
        }
    }
}

class NotifListener : NotificationListenerService() {
    override fun onListenerConnected() {
        NotifBridge.service = this
    }

    override fun onListenerDisconnected() {
        if (NotifBridge.service === this) NotifBridge.service = null
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        val s = sbn ?: return
        if (s.packageName !in NotifBridge.watched) return
        val n = s.notification ?: return
        val extras = n.extras
        val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString() ?: return
        val text = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString() ?: ""
        if (text.isBlank()) return

        var replyKey: String? = null
        var replyIntent: PendingIntent? = null
        n.actions?.forEach { a ->
            val inputs = a.remoteInputs
            if (inputs != null && inputs.isNotEmpty()) {
                replyKey = inputs[0].resultKey
                replyIntent = a.actionIntent
            }
        }
        val msg = NotifMsg(s.key, s.packageName, title, text, replyKey, replyIntent)
        NotifBridge.onMessage?.invoke(msg)
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification?) {
    }
}
