package com.neopanel.app

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaRecorder
import android.os.Process

/** Pengubah suara real-time: mikrofon -> efek -> speaker/headset. Butuh izin RECORD_AUDIO. */
class VoiceEngine {
    @Volatile var preset = 0          // 0 normal, 1 tupai, 2 berat, 3 robot, 4 alien, 5 gema
    @Volatile var gain = 1.0f
    @Volatile var running = false
        private set
    private var thread: Thread? = null

    private val rate = 16000
    private val size = 4096
    private val mask = size - 1
    private val buf = FloatArray(size)
    private var w = 0
    private var ph = 0f
    private val win = 1024f
    private var rm = 0.0
    private val esize = 8192
    private val echo = FloatArray(esize)
    private var ew = 0

    private fun ratio(p: Int): Float = when (p) {
        1 -> 1.6f
        2 -> 0.7f
        3 -> 0.92f
        4 -> 1.3f
        else -> 1f
    }

    private fun tap(d: Float): Float {
        val pos = w - d
        val i0 = Math.floor(pos.toDouble()).toInt()
        val f = pos - i0
        val a = buf[i0 and mask]
        val b = buf[(i0 + 1) and mask]
        return a + (b - a) * f
    }

    private fun process(x: Float, p: Int): Float {
        buf[w and mask] = x
        var y = x
        val r = ratio(p)
        if (r != 1f) {
            ph += (1f - r) / win
            if (ph >= 1f) ph -= 1f
            if (ph < 0f) ph += 1f
            val d1 = ph * win + 2f
            var p2 = ph + 0.5f
            if (p2 >= 1f) p2 -= 1f
            val d2 = p2 * win + 2f
            val s = Math.sin(Math.PI * ph).toFloat()
            val g1 = s * s
            y = tap(d1) * g1 + tap(d2) * (1f - g1)
        }
        w++
        if (p == 3 || p == 4) {
            rm += 2.0 * Math.PI * (if (p == 3) 70.0 else 35.0) / rate
            if (rm > 2.0 * Math.PI) rm -= 2.0 * Math.PI
            y *= (0.3 + 0.9 * Math.abs(Math.sin(rm))).toFloat()
        }
        if (p == 5) {
            val e = echo[(ew - 4000) and (esize - 1)]
            y += e * 0.45f
            echo[ew and (esize - 1)] = y
            ew++
        }
        return y
    }

    /** Mengembalikan pesan error, atau null kalau berhasil. */
    fun start(): String? {
        if (running) return null
        val minIn = AudioRecord.getMinBufferSize(rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val minOut = AudioTrack.getMinBufferSize(rate, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
        if (minIn <= 0 || minOut <= 0) return "perangkat tidak mendukung"
        val rec = try {
            AudioRecord(
                MediaRecorder.AudioSource.MIC, rate, AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT, minIn * 2
            )
        } catch (e: Throwable) {
            return "izin mikrofon belum diberikan"
        }
        if (rec.state != AudioRecord.STATE_INITIALIZED) {
            rec.release()
            return "mikrofon tidak bisa dibuka (izin atau dipakai app lain)"
        }
        val trk = try {
            AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build()
                )
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setSampleRate(rate)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build()
                )
                .setBufferSizeInBytes(minOut * 2)
                .setTransferMode(AudioTrack.MODE_STREAM)
                .setPerformanceMode(AudioTrack.PERFORMANCE_MODE_LOW_LATENCY)
                .build()
        } catch (e: Throwable) {
            rec.release()
            return "gagal membuka keluaran audio"
        }
        running = true
        thread = Thread {
            try {
                Process.setThreadPriority(Process.THREAD_PRIORITY_URGENT_AUDIO)
                rec.startRecording()
                trk.play()
                val b = ShortArray(512)
                while (running) {
                    val n = rec.read(b, 0, b.size)
                    if (n <= 0) continue
                    val p = preset
                    val g = gain
                    for (i in 0 until n) {
                        val y = process(b[i] / 32768f, p) * g
                        b[i] = (y * 32767f).coerceIn(-32768f, 32767f).toInt().toShort()
                    }
                    trk.write(b, 0, n)
                }
            } catch (e: Throwable) {
            } finally {
                try { rec.stop() } catch (e: Throwable) { }
                rec.release()
                try { trk.stop() } catch (e: Throwable) { }
                trk.release()
                running = false
            }
        }.also { it.start() }
        return null
    }

    fun stop() {
        running = false
        thread = null
    }
}
