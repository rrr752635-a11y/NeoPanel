package com.neopanel.app

import android.content.Context
import android.content.SharedPreferences
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.os.SystemClock
import android.text.Html
import android.view.View
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/**
 * Robot pendamping (digambar lewat Canvas).
 * mood: 0 diam, 1 berpikir, 2 bicara, 3 senang.
 * play(): 1 berputar, 2 lompat, 3 goyang, 4 pusing, 5 joget, 6 melambai, 7 cinta.
 */
class RobotView(ctx: Context, private val accent: Int, private val accent2: Int) : View(ctx) {
    var mood = 0
    var dragging = false
    private var act = 0
    private var actAt = 0L
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val box = RectF()
    private val path = Path()

    fun play(a: Int) {
        act = a
        actAt = SystemClock.uptimeMillis()
        invalidate()
    }

    val acting: Boolean get() = act != 0

    private fun durOf(a: Int): Long = when (a) {
        1 -> 1000L
        2 -> 700L
        3 -> 1000L
        4 -> 2000L
        5 -> 2000L
        6 -> 1400L
        else -> 1600L
    }

    private val ticker = object : Runnable {
        override fun run() {
            invalidate()
            postDelayed(this, if (act != 0 || dragging || mood != 0) 40L else 70L)
        }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        removeCallbacks(ticker)
        post(ticker)
    }

    override fun onDetachedFromWindow() {
        removeCallbacks(ticker)
        super.onDetachedFromWindow()
    }

    private fun rr(l: Float, tp: Float, r: Float, b: Float, rad: Float, c: Canvas) {
        box.set(l, tp, r, b)
        c.drawRoundRect(box, rad, rad, paint)
    }

    private fun heart(c: Canvas, x: Float, y: Float, s: Float) {
        c.drawCircle(x - s * 0.25f, y - s * 0.12f, s * 0.3f, paint)
        c.drawCircle(x + s * 0.25f, y - s * 0.12f, s * 0.3f, paint)
        path.reset()
        path.moveTo(x - s * 0.52f, y - s * 0.02f)
        path.lineTo(x + s * 0.52f, y - s * 0.02f)
        path.lineTo(x, y + s * 0.55f)
        path.close()
        c.drawPath(path, paint)
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val u = minOf(w, h) / 100f
        val now = SystemClock.uptimeMillis()
        val sec = now / 1000.0
        if (act != 0 && now - actAt > durOf(act)) act = 0
        val ad = (now - actAt).toDouble()
        val prog = if (act != 0) (ad / durOf(act)).toFloat() else 0f

        var bob = (Math.sin(sec * 3.0) * 2.5 * u).toFloat()
        var rot = 0f
        var sx = 1f
        var sy = 1f
        when (act) {
            1 -> sx = Math.cos(prog * 4.0 * Math.PI).toFloat()
            2 -> {
                bob -= (Math.sin(prog * Math.PI) * 11.0 * u).toFloat()
                if (prog < 0.12f || prog > 0.9f) { sx = 1.1f; sy = 0.9f }
            }
            3 -> rot = (Math.sin(ad * 0.03) * 14.0).toFloat()
            4 -> rot = (Math.sin(ad * 0.012) * 10.0).toFloat()
            5 -> {
                rot = (Math.sin(ad * 0.02) * 12.0).toFloat()
                bob = (-Math.abs(Math.sin(ad * 0.012)) * 6.0 * u).toFloat()
            }
        }
        val jx = if (dragging) (Math.sin(sec * 60.0) * 1.2 * u).toFloat() else 0f
        val back = sx < 0f
        val ax = Math.max(0.08f, Math.abs(sx))

        c.save()
        c.translate(w / 2f + jx, h / 2f + bob)
        c.rotate(rot)
        c.scale(ax, sy)
        c.translate(-50f * u, -50f * u)

        // antena
        paint.shader = null
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 3f * u
        paint.color = 0xFF9AA0B5.toInt()
        c.drawLine(50f * u, 15f * u, 50f * u, 27f * u, paint)
        paint.style = Paint.Style.FILL
        val lit = ((now / 300) % 2L == 0L) || mood == 1 || act == 5
        paint.color = if (lit) accent2 else 0xFF4A506A.toInt()
        c.drawCircle(50f * u, 11f * u, 4.6f * u, paint)

        // telinga
        paint.color = accent
        rr(9f * u, 47f * u, 18f * u, 67f * u, 3f * u, c)
        rr(82f * u, 47f * u, 91f * u, 67f * u, 3f * u, c)

        // tangan
        paint.color = accent2
        var lhy = 82f * u
        var rhy = 82f * u
        var rhx = 93f * u
        if (act == 6) {
            rhy = (82f - 34f * Math.sin(Math.min(1f, prog * 2f) * Math.PI).toFloat()) * u
            rhx = (93f + 5f * Math.sin(ad * 0.03).toFloat()) * u
        } else if (act == 5) {
            lhy = (80f - 22f * Math.abs(Math.sin(ad * 0.012)).toFloat()) * u
            rhy = (80f - 22f * Math.abs(Math.cos(ad * 0.012)).toFloat()) * u
        }
        c.drawCircle(7f * u, lhy, 6.5f * u, paint)
        c.drawCircle(rhx, rhy, 6.5f * u, paint)

        // kepala
        paint.shader = LinearGradient(0f, 26f * u, 0f, 88f * u, accent, accent2, Shader.TileMode.CLAMP)
        rr(17f * u, 26f * u, 83f * u, 88f * u, 17f * u, c)
        paint.shader = null

        if (back) {
            paint.color = 0x55000000
            for (k in 0..2) rr(30f * u, (44f + k * 12f) * u, 70f * u, (48f + k * 12f) * u, 2f * u, c)
        } else {
            paint.color = 0xFF0E1018.toInt()
            rr(25f * u, 36f * u, 75f * u, 78f * u, 12f * u, c)
            drawFace(c, u, now, sec, ad)
        }

        // bintang pusing
        if (act == 4) {
            paint.style = Paint.Style.FILL
            paint.color = 0xFFFFD43B.toInt()
            for (k in 0..2) {
                val a = sec * 6.0 + k * 2.0944
                c.drawCircle((50f + 24f * Math.cos(a).toFloat()) * u, (16f + 6f * Math.sin(a).toFloat()) * u, 2.6f * u, paint)
            }
        }
        // hati naik
        if (act == 7) {
            paint.style = Paint.Style.FILL
            for (k in 0..2) {
                val ph = ((prog * 1.4f + k * 0.3f) % 1f)
                paint.color = 0xFFFF4F8B.toInt()
                paint.alpha = ((1f - ph) * 255).toInt()
                heart(c, (30f + k * 20f) * u, (34f - 46f * ph) * u, 9f * u)
            }
            paint.alpha = 255
        }
        c.restore()
    }

    private fun drawFace(c: Canvas, u: Float, now: Long, sec: Double, ad: Double) {
        val happy = mood == 3 || act == 2 || act == 5 || act == 7 || act == 6
        val blink = (now % 3300L) < 140L
        val look = (Math.sin(sec * 0.9) * 2.0 * u).toFloat()
        val ey = 53f * u
        paint.style = Paint.Style.FILL
        when {
            dragging -> {
                paint.color = 0xFFFFFFFF.toInt()
                c.drawCircle(40f * u, ey, 7f * u, paint)
                c.drawCircle(60f * u, ey, 7f * u, paint)
                paint.color = 0xFF0E1018.toInt()
                c.drawCircle(40f * u + look, ey, 3f * u, paint)
                c.drawCircle(60f * u + look, ey, 3f * u, paint)
                paint.color = 0xFF3DFF9A.toInt()
                c.drawCircle(50f * u, 68f * u, 3.4f * u, paint)
                return
            }
            act == 4 -> {
                paint.style = Paint.Style.STROKE
                paint.strokeWidth = 1.8f * u
                paint.color = 0xFF3DFF9A.toInt()
                for (side in 0..1) {
                    val cx = (if (side == 0) 40f else 60f) * u
                    path.reset()
                    for (k in 0..36) {
                        val a = k * 0.5 + ad * 0.02
                        val r = (0.4f + k * 0.17f) * u
                        val px = cx + (r * Math.cos(a)).toFloat()
                        val py = ey + (r * Math.sin(a)).toFloat()
                        if (k == 0) path.moveTo(px, py) else path.lineTo(px, py)
                    }
                    c.drawPath(path, paint)
                }
                paint.style = Paint.Style.FILL
            }
            happy -> {
                paint.style = Paint.Style.STROKE
                paint.strokeWidth = 2.6f * u
                paint.strokeCap = Paint.Cap.ROUND
                paint.color = 0xFF3DFF9A.toInt()
                box.set(34f * u + look, ey - 5f * u, 46f * u + look, ey + 6f * u)
                c.drawArc(box, 200f, 140f, false, paint)
                box.set(54f * u + look, ey - 5f * u, 66f * u + look, ey + 6f * u)
                c.drawArc(box, 200f, 140f, false, paint)
                paint.style = Paint.Style.FILL
            }
            else -> {
                val eyeH = if (blink) 2f * u else if (mood == 1) 7f * u else 12f * u
                paint.color = if (mood == 1) 0xFFFFD43B.toInt() else 0xFF3DFF9A.toInt()
                val y0 = ey - eyeH / 2f
                rr(34f * u + look, y0, 45f * u + look, y0 + eyeH, 3f * u, c)
                rr(55f * u + look, y0, 66f * u + look, y0 + eyeH, 3f * u, c)
            }
        }
        // mulut
        paint.color = 0xFF3DFF9A.toInt()
        if (mood == 2 || act == 5) {
            val open = (4f + 5f * Math.abs(Math.sin(sec * 11.0)).toFloat()) * u
            rr(43f * u, 66f * u, 57f * u, 66f * u + open, 2.5f * u, c)
        } else if (happy) {
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = 2.4f * u
            paint.strokeCap = Paint.Cap.ROUND
            box.set(42f * u, 60f * u, 58f * u, 72f * u)
            c.drawArc(box, 20f, 140f, false, paint)
            paint.style = Paint.Style.FILL
        } else if (mood == 1) {
            val k = ((now / 300) % 3L).toInt()
            for (i in 0..2) {
                paint.color = if (i <= k) 0xFFFFD43B.toInt() else 0xFF4A506A.toInt()
                c.drawCircle((41f + i * 9f) * u, 69f * u, 2.1f * u, paint)
            }
        } else if (act == 4) {
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = 2f * u
            path.reset()
            for (k in 0..8) {
                val px = (42f + k * 2f) * u
                val py = (68f + (if (k % 2 == 0) -2f else 2f)) * u
                if (k == 0) path.moveTo(px, py) else path.lineTo(px, py)
            }
            c.drawPath(path, paint)
            paint.style = Paint.Style.FILL
        } else {
            rr(43f * u, 67f * u, 57f * u, 69.5f * u, 1.2f * u, c)
        }
    }
}

/** Pencarian ringan lewat Wikipedia (tanpa kunci). Jalankan di thread latar. */
object Web {
    fun search(q: String): String {
        for (lang in arrayOf("id", "en")) {
            val r = wiki(lang, q)
            if (r.isNotEmpty()) return r
        }
        return ""
    }

    private fun wiki(lang: String, q: String): String {
        val url = "https://$lang.wikipedia.org/w/api.php?action=query&format=json&prop=extracts" +
            "&exintro=1&explaintext=1&exchars=700&generator=search&gsrlimit=2&gsrsearch=" +
            URLEncoder.encode(q, "UTF-8")
        val con = URL(url).openConnection() as HttpURLConnection
        try {
            con.connectTimeout = 8000
            con.readTimeout = 10000
            con.setRequestProperty("User-Agent", "VeXed/5 (Android overlay app)")
            if (con.responseCode !in 200..299) return ""
            val j = JSONObject(con.inputStream.bufferedReader().use { it.readText() })
            val pages = j.optJSONObject("query")?.optJSONObject("pages") ?: return ""
            val sb = StringBuilder()
            val ks = pages.keys()
            while (ks.hasNext()) {
                val pg = pages.getJSONObject(ks.next())
                sb.append(pg.optString("title")).append(": ").append(pg.optString("extract").trim()).append("\n\n")
            }
            return sb.toString().trim()
        } catch (e: Exception) {
            return ""
        } finally {
            con.disconnect()
        }
    }
}

/** Klien tipis: Anthropic Messages API (provider 0) atau OpenAI-compatible /chat/completions (provider 1). Jalankan di thread latar. */
object Ai {
    // provider: 0 Anthropic, 1 OpenAI-compatible, 2 Gemini (default)
    fun defBase(p: Int) = when (p) {
        0 -> "https://api.anthropic.com"
        1 -> "https://router.bangunweb.com/v1"
        else -> "https://generativelanguage.googleapis.com/v1beta"
    }

    fun defModel(p: Int) = when (p) {
        0 -> "claude-haiku-5-5"
        1 -> "bw-swift"
        else -> "gemini-4-hydrogen"
    }

    /** Sekali jalan: pindahkan pengaturan lama ke Gemini sebagai default. */
    fun migrate(prefs: SharedPreferences) {
        if (prefs.getBoolean("gem_v1", false)) return
        val e = prefs.edit()
        e.putInt("ai_provider", 2).remove("ai_base").remove("ai_model")
        if ((prefs.getString("ai_key", "") ?: "").startsWith("bwr_")) e.remove("ai_key")
        e.putBoolean("gem_v1", true).apply()
    }

    private fun askGemini(
        base: String, k: String, model: String, system: String,
        msgs: List<Pair<String, String>>, image: String?
    ): String {
        val b = base.trim().trimEnd('/')
        val body = JSONObject()
        body.put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system))))
        val contents = JSONArray()
        for ((idx, m) in msgs.withIndex()) {
            val parts = JSONArray()
            parts.put(JSONObject().put("text", m.second))
            if (image != null && idx == msgs.lastIndex && m.first == "user") {
                parts.put(JSONObject().put("inlineData",
                    JSONObject().put("mimeType", "image/jpeg").put("data", image)))
            }
            contents.put(JSONObject().put("role", if (m.first == "assistant") "model" else "user").put("parts", parts))
        }
        body.put("contents", contents)
        body.put("generationConfig", JSONObject().put("maxOutputTokens", 1024))
        val mid = model.trim().removePrefix("models/")
        val con = URL("$b/models/$mid:generateContent").openConnection() as HttpURLConnection
        try {
            con.requestMethod = "POST"
            con.connectTimeout = 15000
            con.readTimeout = 60000
            con.doOutput = true
            con.setRequestProperty("content-type", "application/json")
            con.setRequestProperty("x-goog-api-key", k)
            con.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            val code = con.responseCode
            val stream = if (code in 200..299) con.inputStream else con.errorStream
            val text = stream?.bufferedReader()?.use { it.readText() } ?: ""
            if (code !in 200..299) throw RuntimeException(errMsg(code, text, mid))
            val j = JSONObject(text)
            val cands = j.optJSONArray("candidates")
            if (cands == null || cands.length() == 0) {
                val why = j.optJSONObject("promptFeedback")?.optString("blockReason") ?: ""
                if (why.isNotEmpty()) throw RuntimeException("diblokir filter Gemini ($why)")
                return ""
            }
            val parts = cands.getJSONObject(0).optJSONObject("content")?.optJSONArray("parts") ?: return ""
            val sb = StringBuilder()
            for (i in 0 until parts.length()) sb.append(parts.getJSONObject(i).optString("text"))
            return sb.toString().trim()
        } finally {
            con.disconnect()
        }
    }

    fun ask(
        provider: Int, base: String, key: String, model: String,
        system: String, msgs: List<Pair<String, String>>, image: String? = null
    ): String {
        val k = key.trim()
        if (k.isEmpty() || k.any { it.isWhitespace() || it.code < 32 }) {
            throw RuntimeException("isi kolom kunci API bukan kunci yang benar (ada spasi/baris baru). Buka aplikasi VeXed > Atur kunci API, hapus isinya, lalu tempel hanya kunci bwr_live_...")
        }
        if (provider == 2) return askGemini(base, k, model, system, msgs, image)
        val b = base.trim().trimEnd('/')
        val body = JSONObject()
        body.put("model", model)
        body.put("max_tokens", 600)
        val arr = JSONArray()
        val url: String
        if (provider == 0) {
            url = if (b.endsWith("/v1")) "$b/messages" else "$b/v1/messages"
            body.put("system", system)
        } else {
            url = "$b/chat/completions"
            arr.put(JSONObject().put("role", "system").put("content", system))
        }
        for ((idx, m) in msgs.withIndex()) {
            val o = JSONObject().put("role", m.first)
            if (image != null && idx == msgs.lastIndex && m.first == "user") {
                val parts = JSONArray()
                if (provider == 0) {
                    parts.put(JSONObject().put("type", "image").put("source",
                        JSONObject().put("type", "base64").put("media_type", "image/jpeg").put("data", image)))
                    parts.put(JSONObject().put("type", "text").put("text", m.second))
                } else {
                    parts.put(JSONObject().put("type", "text").put("text", m.second))
                    parts.put(JSONObject().put("type", "image_url").put("image_url",
                        JSONObject().put("url", "data:image/jpeg;base64,$image")))
                }
                o.put("content", parts)
            } else {
                o.put("content", m.second)
            }
            arr.put(o)
        }
        body.put("messages", arr)

        val con = URL(url).openConnection() as HttpURLConnection
        try {
            con.requestMethod = "POST"
            con.connectTimeout = 15000
            con.readTimeout = 60000
            con.doOutput = true
            con.setRequestProperty("content-type", "application/json")
            if (provider == 0) {
                con.setRequestProperty("x-api-key", k)
                con.setRequestProperty("anthropic-version", "2023-06-01")
            } else {
                con.setRequestProperty("Authorization", "Bearer $k")
            }
            con.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            val code = con.responseCode
            val stream = if (code in 200..299) con.inputStream else con.errorStream
            val text = stream?.bufferedReader()?.use { it.readText() } ?: ""
            if (code !in 200..299) throw RuntimeException(errMsg(code, text, model))
            val j = JSONObject(text)
            if (provider == 0) {
                val content = j.optJSONArray("content") ?: return ""
                val sb = StringBuilder()
                for (i in 0 until content.length()) {
                    val blk = content.getJSONObject(i)
                    if (blk.optString("type") == "text") sb.append(blk.optString("text"))
                }
                return sb.toString().trim()
            }
            val ch = j.optJSONArray("choices") ?: return ""
            if (ch.length() == 0) return ""
            return ch.getJSONObject(0).optJSONObject("message")?.optString("content")?.trim() ?: ""
        } finally {
            con.disconnect()
        }
    }

    private fun errMsg(code: Int, body: String, model: String): String {
        val m = try {
            val e = JSONObject(body).opt("error")
            if (e is JSONObject) e.optString("message") else e?.toString()
        } catch (ex: Exception) {
            null
        }
        val suf = if (m.isNullOrEmpty()) "" else ": $m"
        return when (code) {
            400 -> "permintaan ditolak$suf"
            401 -> "kunci API salah$suf"
            402 -> "saldo/token habis$suf"
            403 -> "akses ditolak$suf"
            404 -> "model \"$model\" atau alamat API tidak ditemukan$suf"
            429 -> "terlalu banyak permintaan atau kuota habis$suf"
            else -> "error $code$suf"
        }
    }
}

class YtItem(val id: String, val title: String, val channel: String)

/** YouTube Data API v3: hanya pencarian metadata. Pemutaran lewat IFrame resmi di WebView. */
object Yt {
    fun search(key: String, q: String): List<YtItem> {
        val url = "https://www.googleapis.com/youtube/v3/search?part=snippet&type=video&videoEmbeddable=true" +
            "&maxResults=15&q=" + URLEncoder.encode(q, "UTF-8") + "&key=" + URLEncoder.encode(key, "UTF-8")
        val con = URL(url).openConnection() as HttpURLConnection
        try {
            con.connectTimeout = 12000
            con.readTimeout = 15000
            val code = con.responseCode
            val stream = if (code in 200..299) con.inputStream else con.errorStream
            val text = stream?.bufferedReader()?.use { it.readText() } ?: ""
            if (code !in 200..299) {
                val m = try { JSONObject(text).optJSONObject("error")?.optString("message") } catch (e: Exception) { null }
                throw RuntimeException("YouTube $code" + (if (m.isNullOrEmpty()) "" else ": $m"))
            }
            val items = JSONObject(text).optJSONArray("items") ?: return emptyList()
            val out = ArrayList<YtItem>()
            for (i in 0 until items.length()) {
                val it = items.getJSONObject(i)
                val id = it.optJSONObject("id")?.optString("videoId") ?: ""
                if (id.isEmpty()) continue
                val sn = it.optJSONObject("snippet")
                val title = Html.fromHtml(sn?.optString("title") ?: "", Html.FROM_HTML_MODE_LEGACY).toString()
                val ch = Html.fromHtml(sn?.optString("channelTitle") ?: "", Html.FROM_HTML_MODE_LEGACY).toString()
                out.add(YtItem(id, title, ch))
            }
            return out
        } finally {
            con.disconnect()
        }
    }
}
