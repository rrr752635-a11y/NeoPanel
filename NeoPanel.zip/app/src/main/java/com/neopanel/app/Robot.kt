package com.neopanel.app

import android.content.Context
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Shader
import android.view.View
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** Robot pendamping yang digambar lewat Canvas. mood: 0 diam, 1 berpikir, 2 bicara. */
class RobotView(ctx: Context, private val accent: Int, private val accent2: Int) : View(ctx) {
    var mood = 0
    private var t = 0L
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val box = RectF()

    // ~14 fps saja supaya ringan buat game
    private val ticker = object : Runnable {
        override fun run() {
            t += 70
            invalidate()
            postDelayed(this, 70)
        }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        removeCallbacks(ticker)
        post(ticker)
    }

    override fun onDetachedFromWindow() {
        removeCallbacks(ticker)
        super.onDetachedFromWindow()
    }

    private fun rr(l: Float, tp: Float, r: Float, b: Float, rad: Float, c: Canvas) {
        box.set(l, tp, r, b)
        c.drawRoundRect(box, rad, rad, paint)
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val u = minOf(w, h) / 100f
        val sec = t / 1000.0
        val bob = (Math.sin(sec * 3.0) * 2.5 * u).toFloat()
        c.save()
        c.translate(w / 2f - 50f * u, h / 2f - 50f * u + bob)

        // antena
        paint.shader = null
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 3f * u
        paint.color = 0xFF9AA0B5.toInt()
        c.drawLine(50f * u, 15f * u, 50f * u, 27f * u, paint)
        paint.style = Paint.Style.FILL
        val lit = ((t / 400) % 2L == 0L) || mood == 1
        paint.color = if (lit) accent2 else 0xFF4A506A.toInt()
        c.drawCircle(50f * u, 11f * u, 4.6f * u, paint)

        // telinga
        paint.color = accent
        rr(9f * u, 47f * u, 18f * u, 67f * u, 3f * u, c)
        rr(82f * u, 47f * u, 91f * u, 67f * u, 3f * u, c)

        // kepala
        paint.shader = LinearGradient(0f, 26f * u, 0f, 88f * u, accent, accent2, Shader.TileMode.CLAMP)
        rr(17f * u, 26f * u, 83f * u, 88f * u, 17f * u, c)
        paint.shader = null

        // layar wajah
        paint.color = 0xFF0E1018.toInt()
        rr(25f * u, 36f * u, 75f * u, 78f * u, 12f * u, c)

        // mata
        val blink = (t % 3300L) < 140L
        val look = (Math.sin(sec * 0.9) * 2.0 * u).toFloat()
        val eyeH = if (blink) 2f * u else if (mood == 1) 7f * u else 12f * u
        paint.color = if (mood == 1) 0xFFFFD43B.toInt() else 0xFF3DFF9A.toInt()
        val ey = 53f * u - eyeH / 2f
        rr(34f * u + look, ey, 45f * u + look, ey + eyeH, 3f * u, c)
        rr(55f * u + look, ey, 66f * u + look, ey + eyeH, 3f * u, c)

        // mulut
        paint.color = 0xFF3DFF9A.toInt()
        if (mood == 2) {
            val open = (4f + 5f * Math.abs(Math.sin(sec * 11.0)).toFloat()) * u
            rr(43f * u, 66f * u, 57f * u, 66f * u + open, 2.5f * u, c)
        } else if (mood == 1) {
            val k = ((t / 300) % 3L).toInt()
            for (i in 0..2) {
                paint.color = if (i <= k) 0xFFFFD43B.toInt() else 0xFF4A506A.toInt()
                c.drawCircle((41f + i * 9f) * u, 69f * u, 2.1f * u, paint)
            }
        } else {
            rr(43f * u, 67f * u, 57f * u, 69.5f * u, 1.2f * u, c)
        }
        c.restore()
    }
}

/** Klien tipis ke Anthropic Messages API. Jalankan di thread latar. */
object Ai {
    fun ask(key: String, model: String, system: String, msgs: List<Pair<String, String>>): String {
        val body = JSONObject()
        body.put("model", model)
        body.put("max_tokens", 600)
        body.put("system", system)
        val arr = JSONArray()
        for (m in msgs) {
            arr.put(JSONObject().put("role", m.first).put("content", m.second))
        }
        body.put("messages", arr)

        val con = URL("https://api.anthropic.com/v1/messages").openConnection() as HttpURLConnection
        try {
            con.requestMethod = "POST"
            con.connectTimeout = 15000
            con.readTimeout = 40000
            con.doOutput = true
            con.setRequestProperty("content-type", "application/json")
            con.setRequestProperty("x-api-key", key)
            con.setRequestProperty("anthropic-version", "2023-06-01")
            con.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            val code = con.responseCode
            val stream = if (code in 200..299) con.inputStream else con.errorStream
            val text = stream?.bufferedReader()?.use { it.readText() } ?: ""
            if (code !in 200..299) throw RuntimeException(errMsg(code, text, model))
            val content = JSONObject(text).optJSONArray("content") ?: return ""
            val sb = StringBuilder()
            for (i in 0 until content.length()) {
                val b = content.getJSONObject(i)
                if (b.optString("type") == "text") sb.append(b.optString("text"))
            }
            return sb.toString().trim()
        } finally {
            con.disconnect()
        }
    }

    private fun errMsg(code: Int, body: String, model: String): String {
        val m = try {
            JSONObject(body).optJSONObject("error")?.optString("message")
        } catch (e: Exception) {
            null
        }
        return when (code) {
            401 -> "kunci API salah"
            403 -> "akses ditolak, cek izin akun"
            404 -> "model \"$model\" tidak ditemukan"
            429 -> "terlalu banyak permintaan atau saldo habis"
            else -> "error $code" + (if (m.isNullOrEmpty()) "" else ": $m")
        }
    }
}
