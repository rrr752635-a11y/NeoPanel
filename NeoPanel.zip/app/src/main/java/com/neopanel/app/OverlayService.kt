package com.neopanel.app

import android.animation.ObjectAnimator
import android.animation.PropertyValuesHolder
import android.animation.ValueAnimator
import android.app.ActivityManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.TrafficStats
import android.net.Uri
import android.os.BatteryManager
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.os.VibrationEffect
import android.os.Vibrator
import android.provider.Settings
import android.text.Editable
import android.text.InputType
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.TextWatcher
import android.text.style.ForegroundColorSpan
import android.text.style.RelativeSizeSpan
import android.util.DisplayMetrics
import android.view.Choreographer
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.animation.DecelerateInterpolator
import android.view.inputmethod.EditorInfo
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.net.InetSocketAddress
import java.net.Socket

class OverlayService : Service() {

    private lateinit var wm: WindowManager
    private val main = Handler(Looper.getMainLooper())
    private val prefs by lazy { getSharedPreferences("neo", MODE_PRIVATE) }

    // ---- jendela ----
    private var orb: View? = null
    private var orbParams: WindowManager.LayoutParams? = null
    private var orbAnim: ObjectAnimator? = null
    private var panel: View? = null
    private var panelClosedAt = 0L
    private var crosshair: CrossView? = null
    private var stats: TextView? = null
    private var browser: View? = null
    private var web: WebView? = null
    private var calc: View? = null
    private var notes: View? = null
    private var timerWin: View? = null
    private var timerCleanup: (() -> Unit)? = null
    private var dim: View? = null
    private var dimIdx = 0
    private var lock: View? = null
    private var appsWin: View? = null
    private var settingsWin: View? = null
    private var cascade = 0

    // ---- HUD ----
    @Volatile private var running = false
    @Volatile private var ping = -1L
    @Volatile private var realFps = -1
    private var frames = 0
    private var uiFps = 0
    private var useChoreo = false
    private var choreoActive = false
    private var pingThread: Thread? = null
    private var fpsThread: Thread? = null
    private var lastRx = 0L
    private var lastTx = 0L
    private var lastNet = 0L

    // ---- tema ----
    private val themes = arrayOf(
        intArrayOf(0xFF7C5CFF.toInt(), 0xFF00E5FF.toInt()),
        intArrayOf(0xFF00C853.toInt(), 0xFFB2FF59.toInt()),
        intArrayOf(0xFFFF1744.toInt(), 0xFFFF9100.toInt()),
        intArrayOf(0xFF2979FF.toInt(), 0xFF18FFFF.toInt()),
        intArrayOf(0xFFF50057.toInt(), 0xFFFF80AB.toInt())
    )
    private val themeNames = arrayOf("Neon Ungu", "Hijau Matrix", "Merah Gamer", "Biru Es", "Pink Neon")
    private var accent = 0xFF7C5CFF.toInt()
    private var cyan = 0xFF00E5FF.toInt()
    private val textColor = 0xFFE8EAF6.toInt()
    private val gray = 0xFF9AA0B5.toInt()
    private val cGreen = 0xFF3DFF9A.toInt()
    private val cYellow = 0xFFFFD43B.toInt()
    private val cRed = 0xFFFF5470.toInt()
    private val xhColors = intArrayOf(
        0xFF00FF88.toInt(), 0xFFFF3B5C.toInt(), 0xFF00E5FF.toInt(),
        0xFFFFE600.toInt(), 0xFFFFFFFF.toInt()
    )
    private val dimModes = intArrayOf(
        0x40000000, 0x73000000, 0xA6000000.toInt(), 0xCC000000.toInt(), 0x33FF9800
    )
    private val dimNames = arrayOf("Redup 25%", "Redup 45%", "Redup 65%", "Redup 80%", "Filter hangat")
    private val pingHosts = arrayOf("1.1.1.1", "8.8.8.8", "208.67.222.222")
    private val pingNames = arrayOf("1.1.1.1 (Cloudflare)", "8.8.8.8 (Google)", "208.67.222.222 (OpenDNS)")

    private val fNoFocus = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
    private val fNoTouch = WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
    private val fLimits = WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
    private val fModal = WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
    private val fOutside = WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH
    private val fHw = WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED
    private val MATCH = WindowManager.LayoutParams.MATCH_PARENT
    private val WRAP = WindowManager.LayoutParams.WRAP_CONTENT

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        loadTheme()
        startForeground(1, buildNotification())
        addOrb()
    }

    override fun onDestroy() {
        running = false
        main.removeCallbacks(tick)
        main.removeCallbacks(fadeRunnable)
        timerCleanup?.invoke()
        closePanel(false)
        closeBrowser()
        removeOrb()
        for (v in listOf(calc, notes, appsWin, settingsWin, dim, lock, crosshair, stats)) safeRemove(v)
        calc = null; notes = null; appsWin = null; settingsWin = null
        dim = null; lock = null; crosshair = null; stats = null
        super.onDestroy()
    }

    // =====================================================
    //  UTIL
    // =====================================================

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun lp(w: Int, h: Int, flags: Int) = WindowManager.LayoutParams(
        w, h, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
        flags or fHw, PixelFormat.TRANSLUCENT
    )

    private fun safeRemove(v: View?) {
        if (v == null) return
        try { wm.removeView(v) } catch (e: Exception) { }
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    @Suppress("DEPRECATION")
    private fun screen(): IntArray {
        val dm = DisplayMetrics()
        wm.defaultDisplay.getRealMetrics(dm)
        return intArrayOf(dm.widthPixels, dm.heightPixels)
    }

    private fun loadTheme() {
        val t = themes[prefs.getInt("theme", 0) % themes.size]
        accent = t[0]
        cyan = t[1]
    }

    private fun buildNotification(): Notification {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("neo", "NeoPanel", NotificationManager.IMPORTANCE_MIN)
        )
        return Notification.Builder(this, "neo")
            .setContentTitle("NeoPanel aktif")
            .setSmallIcon(android.R.drawable.ic_menu_manage)
            .build()
    }

    private fun SpannableStringBuilder.addSpan(t: String, color: Int, rel: Float = 1f) {
        val s = length
        append(t)
        setSpan(ForegroundColorSpan(color), s, length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        if (rel != 1f) setSpan(RelativeSizeSpan(rel), s, length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
    }

    private fun darkBg(radius: Int, alpha: Int = 0xF2) =
        GradientDrawable(
            GradientDrawable.Orientation.TL_BR,
            intArrayOf((alpha shl 24) or 0x1B2030, (alpha shl 24) or 0x121521)
        ).apply { cornerRadius = dp(radius).toFloat() }

    private fun glowFrame(content: View, radius: Int): FrameLayout = FrameLayout(this).apply {
        setPadding(dp(2), dp(2), dp(2), dp(2))
        background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(accent, cyan))
            .apply { cornerRadius = dp(radius + 2).toFloat() }
        addView(content)
    }

    private fun pillBg(active: Boolean) = GradientDrawable(
        GradientDrawable.Orientation.TL_BR,
        if (active) intArrayOf(accent, cyan) else intArrayOf(0xFF2A3045.toInt(), 0xFF1A1E2D.toInt())
    ).apply { cornerRadius = dp(14).toFloat() }

    private fun pill(label: String, active: Boolean = false) = TextView(this).apply {
        text = label
        textSize = 12f
        typeface = Typeface.DEFAULT_BOLD
        gravity = Gravity.CENTER
        setTextColor(textColor)
        setPadding(dp(12), dp(9), dp(12), dp(9))
        background = pillBg(active)
    }

    private fun windowHeader(title: String, onClose: () -> Unit): LinearLayout {
        val h = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(8), dp(4), dp(6), dp(8))
        }
        h.addView(TextView(this).apply {
            text = title
            textSize = 13f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(textColor)
        }, LinearLayout.LayoutParams(0, WRAP, 1f))
        h.addView(TextView(this).apply {
            text = "geser"
            textSize = 10f
            setTextColor(gray)
        })
        h.addView(TextView(this).apply {
            text = "✕"
            textSize = 16f
            setTextColor(textColor)
            setPadding(dp(14), dp(4), dp(6), dp(4))
            setOnClickListener { onClose() }
        })
        return h
    }

    private fun popIn(v: View) {
        v.alpha = 0f
        v.scaleX = 0.92f
        v.scaleY = 0.92f
        v.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(200)
            .setInterpolator(DecelerateInterpolator()).start()
    }

    private fun cascadePos(p: WindowManager.LayoutParams) {
        p.gravity = Gravity.TOP or Gravity.START
        p.x = dp(24 + 18 * (cascade % 6))
        p.y = dp(90 + 24 * (cascade % 6))
        cascade++
    }

    private fun makeDraggable(
        dragHandle: View, window: View, p: WindowManager.LayoutParams, onTap: (() -> Unit)? = null
    ) {
        var sx = 0f
        var sy = 0f
        var ox = 0
        var oy = 0
        var moved = false
        dragHandle.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ox = p.x; oy = p.y; moved = false }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - sx
                    val dy = e.rawY - sy
                    if (!moved && (Math.abs(dx) > dp(5) || Math.abs(dy) > dp(5))) moved = true
                    if (moved) {
                        p.x = ox + dx.toInt()
                        p.y = oy + dy.toInt()
                        try { wm.updateViewLayout(window, p) } catch (ex: Exception) { }
                    }
                }
                MotionEvent.ACTION_UP -> { if (!moved && onTap != null) onTap() }
            }
            true
        }
    }

    private fun vibrate() {
        try {
            val v = getSystemService(Vibrator::class.java)
            v.vibrate(VibrationEffect.createOneShot(600, VibrationEffect.DEFAULT_AMPLITUDE))
        } catch (e: Exception) { }
    }

    // ---- info sistem ----

    private fun battery(): Pair<Int, Int> {
        val i = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val lvl = i?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = i?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        val temp = (i?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0) / 10
        return Pair(if (lvl < 0) 0 else lvl * 100 / scale, temp)
    }

    private fun memInfo(): ActivityManager.MemoryInfo {
        val mi = ActivityManager.MemoryInfo()
        getSystemService(ActivityManager::class.java).getMemoryInfo(mi)
        return mi
    }

    private fun ramPct(): Int {
        val mi = memInfo()
        return (100 - mi.availMem * 100 / mi.totalMem).toInt()
    }

    private fun hasDump() =
        checkSelfPermission("android.permission.DUMP") == PackageManager.PERMISSION_GRANTED

    private fun fmtSpeed(b: Long): String {
        val x = if (b < 0) 0L else b
        return if (x >= 1_048_576L) String.format("%.1f MB/s", x / 1048576f)
        else "${x / 1024} KB/s"
    }

    // =====================================================
    //  ORB (tombol gestur fisik, bisa dipindah)
    // =====================================================

    private fun orbSizePx(): Int {
        val d = intArrayOf(44, 54, 66)
        return dp(d[prefs.getInt("orbSize", 1) % 3])
    }

    private fun fadeAlpha(): Float {
        val a = floatArrayOf(0.35f, 0.6f, 1f)
        return a[prefs.getInt("orbFade", 1) % 3]
    }

    private val fadeRunnable = Runnable {
        orb?.animate()?.alpha(fadeAlpha())?.setDuration(500)?.start()
    }

    private fun orbWake() {
        main.removeCallbacks(fadeRunnable)
        orb?.animate()?.alpha(1f)?.setDuration(120)?.start()
    }

    private fun orbSchedule() {
        main.removeCallbacks(fadeRunnable)
        main.postDelayed(fadeRunnable, 2500)
    }

    private fun removeOrb() {
        orbAnim?.cancel()
        orbAnim = null
        safeRemove(orb)
        orb = null
        orbParams = null
    }

    private fun addOrb() {
        val size = orbSizePx()
        val v = TextView(this).apply {
            text = "⚡"
            textSize = size / resources.displayMetrics.density * 0.40f
            gravity = Gravity.CENTER
            setTextColor(0xFFFFFFFF.toInt())
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(accent, cyan)).apply {
                shape = GradientDrawable.OVAL
                setStroke(dp(2), 0xAAFFFFFF.toInt())
            }
        }
        val sc = screen()
        val p = lp(size, size, fNoFocus or fLimits)
        p.gravity = Gravity.TOP or Gravity.START
        val right = prefs.getInt("orbSide", 1) == 1
        p.x = if (right) sc[0] - size else 0
        p.y = (prefs.getFloat("orbYf", 0.45f) * sc[1]).toInt()

        orbAnim = ObjectAnimator.ofPropertyValuesHolder(
            v,
            PropertyValuesHolder.ofFloat("scaleX", 1f, 1.08f),
            PropertyValuesHolder.ofFloat("scaleY", 1f, 1.08f)
        ).apply {
            duration = 1100
            repeatCount = ValueAnimator.INFINITE
            repeatMode = ValueAnimator.REVERSE
            start()
        }

        var sx = 0f
        var sy = 0f
        var ox = 0
        var oy = 0
        var moved = false
        v.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    sx = e.rawX; sy = e.rawY; ox = p.x; oy = p.y; moved = false
                    orbWake()
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - sx
                    val dy = e.rawY - sy
                    if (!moved && (Math.abs(dx) > dp(6) || Math.abs(dy) > dp(6))) {
                        moved = true
                        if (panel != null) closePanel()
                    }
                    if (moved) {
                        p.x = ox + dx.toInt()
                        p.y = oy + dy.toInt()
                        try { wm.updateViewLayout(v, p) } catch (ex: Exception) { }
                    }
                }
                MotionEvent.ACTION_UP -> {
                    if (moved) snapOrb(v, p)
                    else if (panel != null) closePanel()
                    else if (SystemClock.uptimeMillis() - panelClosedAt > 350) showPanel()
                    orbSchedule()
                }
                MotionEvent.ACTION_CANCEL -> orbSchedule()
            }
            true
        }
        wm.addView(v, p)
        orb = v
        orbParams = p
        orbSchedule()
    }

    private fun snapOrb(v: View, p: WindowManager.LayoutParams) {
        val sc = screen()
        val size = p.width
        val toRight = p.x + size / 2 > sc[0] / 2
        val targetX = if (toRight) sc[0] - size else 0
        val targetY = p.y.coerceIn(dp(24), maxOf(dp(24), sc[1] - size - dp(24)))
        prefs.edit()
            .putInt("orbSide", if (toRight) 1 else 0)
            .putFloat("orbYf", targetY.toFloat() / sc[1])
            .apply()
        val fromX = p.x
        val fromY = p.y
        ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 240
            interpolator = DecelerateInterpolator()
            addUpdateListener { a ->
                val f = a.animatedValue as Float
                p.x = (fromX + (targetX - fromX) * f).toInt()
                p.y = (fromY + (targetY - fromY) * f).toInt()
                try { wm.updateViewLayout(v, p) } catch (ex: Exception) { }
            }
            start()
        }
    }

    // =====================================================
    //  PANEL
    // =====================================================

    private fun tile(
        emoji: String, label: String, active: Boolean,
        onLong: (() -> Unit)? = null, onClick: () -> Unit
    ): TextView {
        val sb = SpannableStringBuilder()
        sb.append(emoji)
        sb.setSpan(RelativeSizeSpan(1.8f), 0, emoji.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        sb.append("\n").append(label)
        return TextView(this).apply {
            text = sb
            setTextColor(textColor)
            textSize = 10f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setPadding(dp(4), dp(12), dp(4), dp(10))
            val colors = if (active) intArrayOf(accent, cyan)
            else intArrayOf(0xFF2A3045.toInt(), 0xFF1A1E2D.toInt())
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR, colors).apply {
                cornerRadius = dp(16).toFloat()
                setStroke(dp(1), if (active) 0x66FFFFFF else 0x22FFFFFF)
            }
            setOnTouchListener { v, e ->
                when (e.actionMasked) {
                    MotionEvent.ACTION_DOWN -> {
                        v.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
                        v.animate().scaleX(0.92f).scaleY(0.92f).setDuration(80).start()
                    }
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL ->
                        v.animate().scaleX(1f).scaleY(1f).setDuration(120).start()
                }
                false
            }
            setOnClickListener { onClick() }
            if (onLong != null) setOnLongClickListener { onLong(); true }
        }
    }

    private fun cell() = LinearLayout.LayoutParams(0, WRAP, 1f)
        .apply { setMargins(dp(4), dp(4), dp(4), dp(4)) }

    private fun rowOf(vararg vs: View) = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        for (v in vs) addView(v, cell())
    }

    private fun dndOn(): Boolean {
        val nm = getSystemService(NotificationManager::class.java)
        return nm.isNotificationPolicyAccessGranted &&
            nm.currentInterruptionFilter == NotificationManager.INTERRUPTION_FILTER_ALARMS
    }

    private fun showPanel() {
        if (panel != null) return
        val sc = screen()
        val tiles = ArrayList<View>()
        fun t(v: TextView): TextView { tiles.add(v); return v }
        val pw = dp(300)

        val inner = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(8), dp(12), dp(8), dp(8))
            background = darkBg(26)
        }

        // header
        val head = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(8), 0, dp(6), dp(8))
        }
        val titleCol = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        titleCol.addView(TextView(this).apply {
            text = "NEO PANEL"
            textSize = 17f
            typeface = Typeface.DEFAULT_BOLD
            letterSpacing = 0.12f
            setTextColor(textColor)
        })
        val bt = battery()
        titleCol.addView(TextView(this).apply {
            text = "RAM ${ramPct()}%  ·  ${bt.second}°C  ·  ${bt.first}%"
            textSize = 11f
            setTextColor(gray)
        })
        head.addView(titleCol, LinearLayout.LayoutParams(0, WRAP, 1f))
        head.addView(TextView(this).apply {
            text = "✕"
            textSize = 18f
            setTextColor(textColor)
            setPadding(dp(12), dp(4), dp(8), dp(4))
            setOnClickListener { closePanel() }
        })
        inner.addView(head)

        // banner mode game
        val banner = TextView(this).apply {
            text = "🎮  MODE GAME  ·  satu ketuk"
            textSize = 13f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setTextColor(0xFFFFFFFF.toInt())
            setPadding(0, dp(13), 0, dp(13))
            background = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(accent, cyan))
                .apply { cornerRadius = dp(16).toFloat() }
            setOnClickListener { closePanel(); gameMode() }
        }
        inner.addView(banner, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, WRAP)
            .apply { setMargins(dp(4), dp(2), dp(4), dp(6)) })
        tiles.add(banner)

        inner.addView(rowOf(
            t(tile("🎯", "Crosshair", crosshair != null, onLong = { cycleCrosshair() }) {
                closePanel(); toggleCrosshair()
            }),
            t(tile("🔕", "Senyap", dndOn()) { closePanel(); toggleDnd() }),
            t(tile("🌐", "Browser", browser != null) { closePanel(); toggleBrowser() })
        ))
        inner.addView(rowOf(
            t(tile("📝", "Catatan", notes != null) { closePanel(); toggleNotes() }),
            t(tile("🧮", "Kalkulator", calc != null) { closePanel(); toggleCalc() }),
            t(tile("⏱", "Timer", timerWin != null) { closePanel(); toggleTimer() })
        ))
        inner.addView(rowOf(
            t(tile("📊", "FPS · Ping", stats != null) { closePanel(); toggleStats() }),
            t(tile("🚀", "Bersihkan") { closePanel(); cleanRam() }),
            t(tile("🌙", "Redup", dim != null, onLong = { removeDim() }) { closePanel(); cycleDim() })
        ))
        inner.addView(rowOf(
            t(tile("🔒", "Kunci") { closePanel(); toggleLock() }),
            t(tile("🚪", "Aplikasi", appsWin != null) { closePanel(); toggleApps() }),
            t(tile("⚙️", "Setelan", settingsWin != null) { closePanel(); toggleSettings() })
        ))

        inner.addView(TextView(this).apply {
            text = "Tahan Crosshair: ganti gaya  ·  Tahan Redup: matikan"
            textSize = 10f
            gravity = Gravity.CENTER
            setTextColor(gray)
            setPadding(0, dp(6), 0, dp(2))
        })
        inner.addView(TextView(this).apply {
            text = "Keluar dari NeoPanel"
            textSize = 12f
            gravity = Gravity.CENTER
            setTextColor(cRed)
            setPadding(0, dp(8), 0, dp(6))
            setOnClickListener { stopSelf() }
        })

        inner.measure(
            View.MeasureSpec.makeMeasureSpec(pw - dp(4), View.MeasureSpec.EXACTLY),
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
        )
        val ph = minOf(inner.measuredHeight + dp(4), sc[1] - dp(48))
        val sv = ScrollView(this).apply {
            isVerticalScrollBarEnabled = false
            addView(inner)
        }
        val root = glowFrame(sv, 26)

        val p = lp(pw, ph, fNoFocus or fModal or fOutside)
        p.gravity = Gravity.TOP or Gravity.START
        val orbSize = orbParams?.width ?: dp(54)
        val right = prefs.getInt("orbSide", 1) == 1
        p.x = if (right) maxOf(dp(6), sc[0] - orbSize - pw - dp(10))
        else minOf(orbSize + dp(10), maxOf(dp(6), sc[0] - pw - dp(6)))
        val cy = (orbParams?.y ?: (sc[1] / 2)) + orbSize / 2
        p.y = (cy - ph / 2).coerceIn(dp(24), maxOf(dp(24), sc[1] - ph - dp(24)))

        root.setOnTouchListener { _, e ->
            if (e.action == MotionEvent.ACTION_OUTSIDE) { closePanel(); true } else false
        }

        val dir = if (right) 1 else -1
        root.alpha = 0f
        root.translationX = (dp(40) * dir).toFloat()
        wm.addView(root, p)
        panel = root
        root.animate().alpha(1f).translationX(0f).setDuration(230)
            .setInterpolator(DecelerateInterpolator()).start()
        tiles.forEachIndexed { i, v ->
            v.alpha = 0f
            v.translationY = dp(14).toFloat()
            v.animate().alpha(1f).translationY(0f)
                .setStartDelay(50L + i * 35L).setDuration(220)
                .setInterpolator(DecelerateInterpolator()).start()
        }
    }

    private fun closePanel(animated: Boolean = true) {
        val v = panel ?: return
        panel = null
        panelClosedAt = SystemClock.uptimeMillis()
        if (!animated) { safeRemove(v); return }
        val dir = if (prefs.getInt("orbSide", 1) == 1) 1 else -1
        v.animate().alpha(0f).translationX((dp(30) * dir).toFloat()).setDuration(150)
            .withEndAction { safeRemove(v) }.start()
    }

    // =====================================================
    //  MODE GAME
    // =====================================================

    private fun gameMode() {
        val nm = getSystemService(NotificationManager::class.java)
        if (nm.isNotificationPolicyAccessGranted) {
            nm.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_ALARMS)
        }
        cleanRam()
        if (stats == null) toggleStats()
        if (crosshair == null) toggleCrosshair()
        toast("Mode Game aktif")
    }

    // =====================================================
    //  CROSSHAIR
    // =====================================================

    private inner class CrossView : View(this@OverlayService) {
        var shape = 0
        var color = 0
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG)

        override fun onDraw(canvas: Canvas) {
            val k = floatArrayOf(0.8f, 1.2f, 1.7f)[prefs.getInt("xhSize", 1) % 3]
            paint.color = color
            paint.strokeWidth = dp(2).toFloat() * k.coerceAtLeast(1f)
            val cx = width / 2f
            val cy = height / 2f
            val gap = dp(4).toFloat() * k
            val len = dp(11).toFloat() * k
            paint.style = Paint.Style.STROKE
            when (shape) {
                0, 3 -> {
                    canvas.drawLine(cx - gap - len, cy, cx - gap, cy, paint)
                    canvas.drawLine(cx + gap, cy, cx + gap + len, cy, paint)
                    canvas.drawLine(cx, cy - gap - len, cx, cy - gap, paint)
                    canvas.drawLine(cx, cy + gap, cx, cy + gap + len, paint)
                }
                2 -> canvas.drawCircle(cx, cy, dp(10).toFloat() * k, paint)
            }
            if (shape == 1 || shape == 2 || shape == 3) {
                paint.style = Paint.Style.FILL
                canvas.drawCircle(cx, cy, dp(2).toFloat() * k, paint)
            }
        }
    }

    private fun applyXh(v: CrossView) {
        val idx = prefs.getInt("xh", 0)
        v.shape = idx % 4
        v.color = xhColors[(idx / 4) % xhColors.size]
        v.invalidate()
    }

    private fun cycleCrosshair() {
        val total = 4 * xhColors.size
        val idx = (prefs.getInt("xh", 0) + 1) % total
        prefs.edit().putInt("xh", idx).apply()
        crosshair?.let { applyXh(it) }
        toast("Gaya crosshair ${idx + 1}/$total")
    }

    private fun toggleCrosshair() {
        if (crosshair != null) {
            safeRemove(crosshair)
            crosshair = null
            return
        }
        val v = CrossView()
        applyXh(v)
        val p = lp(dp(96), dp(96), fNoFocus or fNoTouch or fLimits)
        p.gravity = Gravity.CENTER
        wm.addView(v, p)
        crosshair = v
    }

    // =====================================================
    //  SENYAP (Jangan Ganggu)
    // =====================================================

    private fun toggleDnd() {
        val nm = getSystemService(NotificationManager::class.java)
        if (!nm.isNotificationPolicyAccessGranted) {
            toast("Beri izin Jangan Ganggu dulu")
            startActivity(
                Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
            return
        }
        val on = nm.currentInterruptionFilter == NotificationManager.INTERRUPTION_FILTER_ALARMS
        nm.setInterruptionFilter(
            if (on) NotificationManager.INTERRUPTION_FILTER_ALL
            else NotificationManager.INTERRUPTION_FILTER_ALARMS
        )
        toast(if (on) "Senyap mati" else "Senyap nyala")
    }

    // =====================================================
    //  BERSIHKAN RAM
    // =====================================================

    private fun cleanRam() {
        val am = getSystemService(ActivityManager::class.java)
        val before = memInfo().availMem / 1048576
        var n = 0
        for (ai in packageManager.getInstalledApplications(0)) {
            if (ai.packageName == packageName) continue
            if ((ai.flags and ApplicationInfo.FLAG_SYSTEM) != 0) continue
            try { am.killBackgroundProcesses(ai.packageName); n++ } catch (e: Exception) { }
        }
        main.postDelayed({
            val after = memInfo().availMem / 1048576
            toast("$n app ditutup · RAM bebas $before → $after MB")
        }, 900)
    }

    // =====================================================
    //  REDUP / FILTER LAYAR
    // =====================================================

    private fun cycleDim() {
        val v = dim
        if (v == null) {
            dimIdx = 0
            val nv = View(this).apply { setBackgroundColor(dimModes[0]) }
            wm.addView(nv, lp(MATCH, MATCH, fNoFocus or fNoTouch or fLimits))
            dim = nv
            toast(dimNames[0])
            return
        }
        dimIdx++
        if (dimIdx >= dimModes.size) {
            removeDim()
            return
        }
        v.setBackgroundColor(dimModes[dimIdx])
        toast(dimNames[dimIdx])
    }

    private fun removeDim() {
        if (dim == null) return
        safeRemove(dim)
        dim = null
        toast("Redup mati")
    }

    // =====================================================
    //  KUNCI LAYAR
    // =====================================================

    private fun toggleLock() {
        if (lock != null) {
            safeRemove(lock)
            lock = null
            return
        }
        val root = FrameLayout(this)
        root.setBackgroundColor(0x01000000)
        root.setOnTouchListener { _, _ -> true }
        val badge = TextView(this).apply {
            text = "🔒  Layar terkunci  ·  tahan di sini untuk membuka"
            textSize = 12f
            setTextColor(textColor)
            setPadding(dp(14), dp(10), dp(14), dp(10))
            background = darkBg(18, 0xE6)
            alpha = 0.85f
        }
        badge.setOnLongClickListener {
            safeRemove(lock)
            lock = null
            toast("Layar terbuka")
            true
        }
        val blp = FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT,
            Gravity.TOP or Gravity.CENTER_HORIZONTAL
        )
        blp.topMargin = dp(60)
        root.addView(badge, blp)
        wm.addView(root, lp(MATCH, MATCH, fNoFocus or fLimits))
        lock = root
        toast("Layar dikunci")
    }

    // =====================================================
    //  HUD FPS / PING / MS
    // =====================================================

    private val frameCb = object : Choreographer.FrameCallback {
        override fun doFrame(frameTimeNanos: Long) {
            frames++
            if (running && useChoreo) Choreographer.getInstance().postFrameCallback(this)
            else choreoActive = false
        }
    }

    private val tick = object : Runnable {
        override fun run() {
            if (!running) return
            val s = stats ?: return
            if (useChoreo) { uiFps = frames; frames = 0 }
            val real = realFps
            val fps = if (real >= 0) real else uiFps
            val fpsColor = when {
                fps >= 50 -> cGreen
                fps >= 30 -> cYellow
                else -> cRed
            }
            val pg = ping
            val msColor = when {
                pg < 0 -> gray
                pg < 60 -> cGreen
                pg < 120 -> cYellow
                else -> cRed
            }
            val sb = SpannableStringBuilder()
            sb.addSpan("$fps", fpsColor, 1.6f)
            sb.addSpan(if (real >= 0) " FPS   " else " FPS*   ", gray, 0.8f)
            sb.addSpan(if (pg < 0) "--" else "$pg", msColor, 1.6f)
            sb.addSpan(" ms", gray, 0.8f)

            if (prefs.getInt("hudMode", 0) == 0) {
                val bt = battery()
                sb.addSpan("\nRAM ${ramPct()}%  ·  ${bt.second}°C  ·  ${bt.first}%", gray, 0.75f)
                val rx = TrafficStats.getTotalRxBytes()
                val tx = TrafficStats.getTotalTxBytes()
                val nowT = SystemClock.elapsedRealtime()
                var down = 0L
                var up = 0L
                if (lastNet != 0L && rx >= 0 && tx >= 0) {
                    val dt = maxOf(1L, nowT - lastNet)
                    down = (rx - lastRx) * 1000 / dt
                    up = (tx - lastTx) * 1000 / dt
                }
                lastRx = rx; lastTx = tx; lastNet = nowT
                sb.addSpan("\n↓ ${fmtSpeed(down)}   ↑ ${fmtSpeed(up)}", gray, 0.75f)
            }
            s.text = sb
            main.postDelayed(this, 1000)
        }
    }

    private fun toggleStats() {
        if (stats != null) {
            running = false
            main.removeCallbacks(tick)
            safeRemove(stats)
            stats = null
            return
        }
        val t = TextView(this).apply {
            text = "..."
            textSize = 12f
            setTextColor(textColor)
            typeface = Typeface.DEFAULT_BOLD
            setPadding(dp(12), dp(7), dp(14), dp(7))
            background = GradientDrawable().apply {
                setColor(0xD9141824.toInt())
                cornerRadius = dp(16).toFloat()
                setStroke(dp(1), accent)
            }
        }
        val p = lp(WRAP, WRAP, fNoFocus or fLimits)
        p.gravity = Gravity.TOP or Gravity.START
        p.x = dp(12)
        p.y = dp(40)
        makeDraggable(t, t, p) {
            val m = prefs.getInt("hudMode", 0)
            prefs.edit().putInt("hudMode", 1 - m).apply()
            main.removeCallbacks(tick)
            main.post(tick)
        }
        wm.addView(t, p)
        stats = t
        t.alpha = 0f
        t.animate().alpha(1f).setDuration(250).start()

        running = true
        frames = 0
        lastNet = 0L
        useChoreo = !hasDump()
        if (useChoreo && !choreoActive) {
            choreoActive = true
            Choreographer.getInstance().postFrameCallback(frameCb)
        }
        main.removeCallbacks(tick)
        main.postDelayed(tick, 700)
        startPing()
        startFpsThread()
    }

    private fun startPing() {
        if (pingThread?.isAlive == true) return
        pingThread = Thread {
            while (running) {
                val host = pingHosts[prefs.getInt("pingHost", 0) % pingHosts.size]
                val t0 = System.nanoTime()
                ping = try {
                    Socket().use { it.connect(InetSocketAddress(host, 443), 1500) }
                    (System.nanoTime() - t0) / 1_000_000
                } catch (e: Exception) {
                    -1L
                }
                try { Thread.sleep(2000) } catch (e: InterruptedException) { return@Thread }
            }
        }.also { it.start() }
    }

    private fun startFpsThread() {
        if (fpsThread?.isAlive == true) return
        fpsThread = Thread {
            var layer: String? = null
            var lastScan = 0L
            while (running) {
                if (hasDump()) {
                    val now = System.nanoTime()
                    if (lastScan == 0L || now - lastScan > 5_000_000_000L) {
                        val fg = foregroundPkg()
                        if (fg != null && fg != packageName) layer = findLayer(fg)
                        lastScan = now
                    }
                    realFps = layer?.let { readFps(it) } ?: -1
                } else {
                    realFps = -1
                }
                try { Thread.sleep(1000) } catch (e: InterruptedException) { return@Thread }
            }
        }.also { it.start() }
    }

    private fun foregroundPkg(): String? {
        return try {
            val p = ProcessBuilder("/system/bin/dumpsys", "activity", "activities")
                .redirectErrorStream(true).start()
            val br = p.inputStream.bufferedReader()
            val re = Regex("""ActivityRecord\{\S+ u\d+ ([\w.]+)/""")
            var pkg: String? = null
            var line = br.readLine()
            while (line != null) {
                if (line.contains("ResumedActivity")) {
                    val m = re.find(line)
                    if (m != null) { pkg = m.groupValues[1]; break }
                }
                line = br.readLine()
            }
            p.destroy()
            pkg
        } catch (e: Exception) {
            null
        }
    }

    private fun findLayer(pkg: String): String? {
        return try {
            val p = ProcessBuilder("/system/bin/dumpsys", "SurfaceFlinger", "--list")
                .redirectErrorStream(true).start()
            val layers = p.inputStream.bufferedReader().readLines().map { it.trim() }
            p.destroy()
            val c = layers.filter { it.contains(pkg) }
            c.firstOrNull { it.contains("SurfaceView") && it.contains("BLAST") }
                ?: c.firstOrNull { it.contains("SurfaceView") }
                ?: c.firstOrNull { it.contains("$pkg/") }
                ?: c.firstOrNull()
        } catch (e: Exception) {
            null
        }
    }

    private fun readFps(layer: String): Int? {
        return try {
            val p = ProcessBuilder("/system/bin/dumpsys", "SurfaceFlinger", "--latency", layer)
                .redirectErrorStream(true).start()
            val lines = p.inputStream.bufferedReader().readLines()
            p.destroy()
            val now = System.nanoTime()
            var count = 0
            var valid = 0
            for (i in 1 until lines.size) {
                val parts = lines[i].trim().split(Regex("\\s+"))
                if (parts.size < 3) continue
                val t = parts[1].toLongOrNull() ?: continue
                if (t <= 0L || t == Long.MAX_VALUE) continue
                valid++
                if (t > now - 1_000_000_000L && t <= now + 200_000_000L) count++
            }
            if (valid == 0) null else count
        } catch (e: Exception) {
            null
        }
    }

    // =====================================================
    //  CATATAN
    // =====================================================

    private fun toggleNotes() {
        if (notes != null) {
            safeRemove(notes)
            notes = null
            return
        }
        var cur = prefs.getInt("noteCur", 0)

        val edit = EditText(this).apply {
            hint = "Tulis catatan..."
            setHintTextColor(0xFF7A8099.toInt())
            setTextColor(textColor)
            textSize = 14f
            gravity = Gravity.TOP or Gravity.START
            minLines = 7
            maxLines = 12
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or
                InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
            setPadding(dp(10), dp(8), dp(10), dp(8))
            background = GradientDrawable().apply {
                setColor(0x33000000)
                cornerRadius = dp(12).toFloat()
            }
            setText(prefs.getString("note$cur", ""))
        }
        edit.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) {
                prefs.edit().putString("note$cur", s?.toString() ?: "").apply()
            }
        })

        val chips = ArrayList<TextView>()
        fun refreshChips() {
            chips.forEachIndexed { i, c -> c.background = pillBg(i == cur) }
        }
        val tabs = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        for (i in 0 until 5) {
            val c = pill("${i + 1}")
            c.setOnClickListener {
                cur = i
                prefs.edit().putInt("noteCur", i).apply()
                edit.setText(prefs.getString("note$i", ""))
                edit.setSelection(edit.text.length)
                refreshChips()
            }
            chips.add(c)
            tabs.addView(c, LinearLayout.LayoutParams(0, WRAP, 1f).apply { setMargins(dp(3), dp(2), dp(3), dp(8)) })
        }
        refreshChips()

        val copyBtn = pill("Salin")
        copyBtn.setOnClickListener {
            getSystemService(ClipboardManager::class.java)
                .setPrimaryClip(ClipData.newPlainText("catatan", edit.text.toString()))
            toast("Catatan disalin")
        }
        val clearBtn = pill("Hapus")
        clearBtn.setOnClickListener { edit.setText("") }
        val foot = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            addView(copyBtn, LinearLayout.LayoutParams(0, WRAP, 1f).apply { setMargins(dp(3), dp(8), dp(3), 0) })
            addView(clearBtn, LinearLayout.LayoutParams(0, WRAP, 1f).apply { setMargins(dp(3), dp(8), dp(3), 0) })
        }

        val inner = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(8), dp(8), dp(8), dp(10))
            background = darkBg(22)
        }
        val header = windowHeader("📝 Catatan") { safeRemove(notes); notes = null }
        inner.addView(header)
        inner.addView(tabs)
        inner.addView(edit)
        inner.addView(foot)

        val root = glowFrame(inner, 22)
        val p = lp(dp(300), WRAP, fModal or fLimits)
        cascadePos(p)
        p.softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN
        makeDraggable(header, root, p)
        wm.addView(root, p)
        notes = root
        popIn(root)
    }

    // =====================================================
    //  TIMER / STOPWATCH
    // =====================================================

    private fun toggleTimer() {
        if (timerWin != null) {
            timerCleanup?.invoke()
            return
        }
        var mode = 0
        var base = 0L
        var startAt = 0L
        var going = false
        var target = 5 * 60_000L

        val big = TextView(this).apply {
            text = "00:00"
            textSize = 40f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setTextColor(textColor)
            setPadding(0, dp(6), 0, dp(10))
        }
        val startBtn = pill("▶ Mulai", true)
        val resetBtn = pill("↺ Reset")
        val modeBtn = pill("⏱ Stopwatch")
        val presets = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            visibility = View.GONE
        }

        fun elapsed(): Long = base + (if (going) SystemClock.elapsedRealtime() - startAt else 0L)
        fun shown(): Long = if (mode == 0) elapsed() else maxOf(0L, target - elapsed())
        fun fmt(ms: Long): String {
            val s = ms / 1000
            val h = s / 3600
            val m = (s % 3600) / 60
            val sec = s % 60
            return if (h > 0) String.format("%d:%02d:%02d", h, m, sec)
            else String.format("%02d:%02d", m, sec)
        }

        val ticker = object : Runnable {
            override fun run() {
                big.text = fmt(shown())
                if (going && mode == 1 && shown() == 0L) {
                    going = false
                    base = 0L
                    startBtn.text = "▶ Mulai"
                    vibrate()
                    toast("Timer selesai")
                }
                if (going) main.postDelayed(this, 200)
            }
        }

        fun resetAll() {
            going = false
            base = 0L
            main.removeCallbacks(ticker)
            startBtn.text = "▶ Mulai"
            big.text = fmt(shown())
        }

        startBtn.setOnClickListener {
            if (!going) {
                if (mode == 1 && shown() == 0L) base = 0L
                going = true
                startAt = SystemClock.elapsedRealtime()
                startBtn.text = "⏸ Jeda"
                main.removeCallbacks(ticker)
                main.post(ticker)
            } else {
                base += SystemClock.elapsedRealtime() - startAt
                going = false
                startBtn.text = "▶ Mulai"
                main.removeCallbacks(ticker)
                big.text = fmt(shown())
            }
        }
        resetBtn.setOnClickListener { resetAll() }
        modeBtn.setOnClickListener {
            mode = 1 - mode
            modeBtn.text = if (mode == 0) "⏱ Stopwatch" else "⏳ Timer"
            presets.visibility = if (mode == 1) View.VISIBLE else View.GONE
            resetAll()
        }
        for (m in intArrayOf(5, 10, 15, 30, 60)) {
            val c = pill("${m}m")
            c.setOnClickListener { target = m * 60_000L; resetAll() }
            presets.addView(c, LinearLayout.LayoutParams(0, WRAP, 1f).apply { setMargins(dp(2), dp(6), dp(2), dp(2)) })
        }

        val btnRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            addView(startBtn, LinearLayout.LayoutParams(0, WRAP, 1f).apply { setMargins(dp(3), dp(6), dp(3), 0) })
            addView(resetBtn, LinearLayout.LayoutParams(0, WRAP, 1f).apply { setMargins(dp(3), dp(6), dp(3), 0) })
        }

        val inner = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(8), dp(8), dp(8), dp(10))
            background = darkBg(22)
        }
        val header = windowHeader("⏱ Timer") { timerCleanup?.invoke() }
        inner.addView(header)
        inner.addView(big)
        inner.addView(modeBtn)
        inner.addView(presets)
        inner.addView(btnRow)

        val root = glowFrame(inner, 22)
        val p = lp(dp(260), WRAP, fNoFocus or fLimits)
        cascadePos(p)
        makeDraggable(header, root, p)
        wm.addView(root, p)
        timerWin = root
        timerCleanup = {
            main.removeCallbacks(ticker)
            safeRemove(timerWin)
            timerWin = null
            timerCleanup = null
        }
        popIn(root)
    }

    // =====================================================
    //  KALKULATOR
    // =====================================================

    private fun toggleCalc() {
        if (calc != null) {
            safeRemove(calc)
            calc = null
            return
        }
        var acc = 0.0
        var op = ' '
        var cur = "0"
        var fresh = true

        val display = TextView(this).apply {
            text = "0"
            textSize = 30f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(textColor)
            gravity = Gravity.END
            maxLines = 1
            setPadding(dp(8), dp(6), dp(12), dp(10))
        }

        fun fmt(d: Double): String {
            if (d.isNaN()) return "NaN"
            val s = d.toString()
            return if (s.endsWith(".0")) s.dropLast(2) else s
        }

        fun calcResult(): Double {
            val b = cur.toDoubleOrNull() ?: 0.0
            return when (op) {
                '+' -> acc + b
                '-' -> acc - b
                '×' -> acc * b
                '÷' -> if (b == 0.0) Double.NaN else acc / b
                else -> b
            }
        }

        fun press(k: String) {
            val c = k[0]
            if (c.isDigit()) {
                if (fresh || cur == "NaN") { cur = k; fresh = false }
                else cur = if (cur == "0") k else cur + k
            } else when (k) {
                "." -> {
                    if (fresh || cur == "NaN") { cur = "0."; fresh = false }
                    else if (!cur.contains(".")) cur += "."
                }
                "C" -> { acc = 0.0; op = ' '; cur = "0"; fresh = true }
                "⌫" -> {
                    cur = if (cur.length > 1 && cur != "NaN") cur.dropLast(1) else "0"
                    if (cur == "-") cur = "0"
                }
                "%" -> cur = fmt((cur.toDoubleOrNull() ?: 0.0) / 100)
                "=" -> if (op != ' ') {
                    acc = calcResult()
                    cur = fmt(acc)
                    op = ' '
                    fresh = true
                }
                else -> {
                    if (!fresh) { acc = calcResult(); cur = fmt(acc) }
                    op = c
                    fresh = true
                }
            }
            display.text = if (cur == "NaN") "Error" else cur
        }

        fun key(label: String, isOp: Boolean): TextView = TextView(this).apply {
            text = label
            textSize = 18f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setTextColor(textColor)
            setPadding(0, dp(12), 0, dp(12))
            background = pillBg(isOp)
            setOnTouchListener { v, e ->
                when (e.actionMasked) {
                    MotionEvent.ACTION_DOWN ->
                        v.animate().scaleX(0.92f).scaleY(0.92f).setDuration(60).start()
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL ->
                        v.animate().scaleX(1f).scaleY(1f).setDuration(100).start()
                }
                false
            }
            setOnClickListener { press(label) }
        }

        val inner = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(8), dp(8), dp(8), dp(8))
            background = darkBg(22)
        }
        val header = windowHeader("🧮 Kalkulator") { safeRemove(calc); calc = null }
        inner.addView(header)
        inner.addView(display)

        val rows = listOf(
            listOf("C" to 1f, "⌫" to 1f, "%" to 1f, "÷" to 1f),
            listOf("7" to 1f, "8" to 1f, "9" to 1f, "×" to 1f),
            listOf("4" to 1f, "5" to 1f, "6" to 1f, "-" to 1f),
            listOf("1" to 1f, "2" to 1f, "3" to 1f, "+" to 1f),
            listOf("0" to 2f, "." to 1f, "=" to 1f)
        )
        for (r in rows) {
            val rowView = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            for ((label, w) in r) {
                val isOp = label == "÷" || label == "×" || label == "-" || label == "+" || label == "="
                val lpk = LinearLayout.LayoutParams(0, WRAP, w)
                lpk.setMargins(dp(3), dp(3), dp(3), dp(3))
                rowView.addView(key(label, isOp), lpk)
            }
            inner.addView(rowView)
        }

        val root = glowFrame(inner, 22)
        val p = lp(dp(250), WRAP, fNoFocus or fLimits)
        cascadePos(p)
        makeDraggable(header, root, p)
        wm.addView(root, p)
        calc = root
        popIn(root)
    }

    // =====================================================
    //  BROWSER
    // =====================================================

    private fun toggleBrowser() {
        if (browser != null) {
            closeBrowser()
            return
        }
        val inner = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(8), dp(8), dp(8), dp(8))
            background = darkBg(22)
        }
        val header = windowHeader("🌐 Browser") { closeBrowser() }

        val urlBox = EditText(this).apply {
            hint = "Cari atau ketik alamat"
            setHintTextColor(0xFF7A8099.toInt())
            setTextColor(textColor)
            textSize = 13f
            isSingleLine = true
            imeOptions = EditorInfo.IME_ACTION_GO
        }

        val wv = WebView(this).apply {
            settings.javaScriptEnabled = true
            webViewClient = WebViewClient()
            loadUrl("https://www.google.com")
        }
        web = wv

        urlBox.setOnEditorActionListener { v, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_GO) {
                var u = v.text.toString().trim()
                if (!u.startsWith("http")) {
                    u = if (u.contains(".") && !u.contains(" ")) "https://$u"
                    else "https://www.google.com/search?q=" + Uri.encode(u)
                }
                wv.loadUrl(u)
                true
            } else false
        }

        inner.addView(header)
        inner.addView(urlBox)
        inner.addView(wv, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))

        val root = glowFrame(inner, 22)
        val p = lp(dp(300), dp(400), fModal or fLimits)
        cascadePos(p)
        p.softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN
        makeDraggable(header, root, p)
        wm.addView(root, p)
        browser = root
        popIn(root)
    }

    private fun closeBrowser() {
        web?.destroy()
        web = null
        safeRemove(browser)
        browser = null
    }

    // =====================================================
    //  LAUNCHER APLIKASI
    // =====================================================

    private fun launchPkg(pkg: String) {
        val i = packageManager.getLaunchIntentForPackage(pkg) ?: return
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try { startActivity(i) } catch (e: Exception) { toast("Tidak bisa membuka aplikasi") }
    }

    private fun toggleApps() {
        if (appsWin != null) {
            safeRemove(appsWin)
            appsWin = null
            return
        }
        val pm = packageManager
        val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(q, 0)
            .map { Pair(it.loadLabel(pm).toString(), it.activityInfo.packageName) }
            .filter { it.second != packageName }
            .sortedBy { it.first.lowercase() }

        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        fun fill(query: String) {
            list.removeAllViews()
            var n = 0
            for (a in apps) {
                if (query.isNotEmpty() && !a.first.contains(query, ignoreCase = true)) continue
                val row = TextView(this).apply {
                    text = a.first
                    textSize = 14f
                    setTextColor(textColor)
                    setPadding(dp(12), dp(11), dp(12), dp(11))
                }
                row.setOnClickListener {
                    launchPkg(a.second)
                    safeRemove(appsWin)
                    appsWin = null
                }
                list.addView(row)
                n++
                if (n >= 80) break
            }
        }
        fill("")

        val search = EditText(this).apply {
            hint = "Cari aplikasi"
            setHintTextColor(0xFF7A8099.toInt())
            setTextColor(textColor)
            textSize = 13f
            isSingleLine = true
        }
        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) { fill(s?.toString()?.trim() ?: "") }
        })

        val inner = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(8), dp(8), dp(8), dp(8))
            background = darkBg(22)
        }
        val header = windowHeader("🚪 Aplikasi") { safeRemove(appsWin); appsWin = null }
        inner.addView(header)
        inner.addView(search)
        val sv = ScrollView(this).apply { addView(list) }
        inner.addView(sv, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))

        val root = glowFrame(inner, 22)
        val p = lp(dp(300), dp(420), fModal or fLimits)
        cascadePos(p)
        p.softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN
        makeDraggable(header, root, p)
        wm.addView(root, p)
        appsWin = root
        popIn(root)
    }

    // =====================================================
    //  SETELAN
    // =====================================================

    private fun refreshSettings() {
        safeRemove(settingsWin)
        settingsWin = null
        toggleSettings()
    }

    private fun toggleSettings() {
        if (settingsWin != null) {
            safeRemove(settingsWin)
            settingsWin = null
            return
        }
        val inner = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(8), dp(8), dp(8), dp(10))
            background = darkBg(22)
        }
        val header = windowHeader("⚙️ Setelan") { safeRemove(settingsWin); settingsWin = null }
        inner.addView(header)

        fun srow(label: String, value: String, onTap: () -> Unit) {
            val r = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(6), dp(4), dp(6), dp(4))
            }
            r.addView(TextView(this).apply {
                text = label
                textSize = 13f
                setTextColor(textColor)
            }, LinearLayout.LayoutParams(0, WRAP, 1f))
            val v = pill(value, true)
            v.textSize = 11f
            v.setOnClickListener { onTap() }
            r.addView(v)
            inner.addView(r)
        }

        fun cyc(key: String, def: Int, n: Int, after: () -> Unit) {
            prefs.edit().putInt(key, (prefs.getInt(key, def) + 1) % n).apply()
            after()
            refreshSettings()
        }

        val sizeNames = arrayOf("Kecil", "Sedang", "Besar")

        srow("Tema warna", themeNames[prefs.getInt("theme", 0) % themes.size]) {
            cyc("theme", 0, themes.size) { loadTheme(); removeOrb(); addOrb() }
        }
        srow("Ukuran tombol orb", sizeNames[prefs.getInt("orbSize", 1) % 3]) {
            cyc("orbSize", 1, 3) { removeOrb(); addOrb() }
        }
        srow("Orb memudar", arrayOf("Sangat samar", "Samar", "Tidak")[prefs.getInt("orbFade", 1) % 3]) {
            cyc("orbFade", 1, 3) { removeOrb(); addOrb() }
        }
        srow("Tampilan HUD", arrayOf("Lengkap", "Ringkas")[prefs.getInt("hudMode", 0) % 2]) {
            cyc("hudMode", 0, 2) { main.removeCallbacks(tick); if (running) main.post(tick) }
        }
        srow("Ukuran crosshair", sizeNames[prefs.getInt("xhSize", 1) % 3]) {
            cyc("xhSize", 1, 3) { crosshair?.invalidate() }
        }
        srow("Gaya crosshair", "${prefs.getInt("xh", 0) + 1}/${4 * xhColors.size}") {
            cycleCrosshair()
            refreshSettings()
        }
        srow("Server ping", pingNames[prefs.getInt("pingHost", 0) % pingHosts.size]) {
            cyc("pingHost", 0, pingHosts.size) { }
        }

        inner.addView(TextView(this).apply {
            text = "Tip: ketuk HUD FPS untuk ganti Lengkap/Ringkas. Seret orb ke mana saja, otomatis menempel ke tepi."
            textSize = 10f
            setTextColor(gray)
            setPadding(dp(6), dp(8), dp(6), 0)
        })

        val root = glowFrame(inner, 22)
        val p = lp(dp(320), WRAP, fNoFocus or fLimits)
        cascadePos(p)
        makeDraggable(header, root, p)
        wm.addView(root, p)
        settingsWin = root
        popIn(root)
    }
}
