package com.neopanel.app

import android.animation.ObjectAnimator
import android.animation.ValueAnimator
import android.app.ActivityManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.BroadcastReceiver
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioAttributes
import android.media.AudioDeviceCallback
import android.media.AudioDeviceInfo
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioTrack
import android.net.TrafficStats
import android.net.Uri
import android.net.wifi.WifiManager
import android.os.BatteryManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.provider.Settings
import android.telecom.TelecomManager
import android.telephony.TelephonyManager
import android.text.Editable
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.TextWatcher
import android.text.style.ForegroundColorSpan
import android.text.style.RelativeSizeSpan
import android.view.Choreographer
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.animation.DecelerateInterpolator
import android.view.inputmethod.EditorInfo
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Space
import android.widget.TextView
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject
import java.net.InetSocketAddress
import java.net.Socket
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class OverlayService : Service() {

    private lateinit var wm: WindowManager
    private val main = Handler(Looper.getMainLooper())
    private val prefs by lazy { getSharedPreferences("vexed", MODE_PRIVATE) }

    // ---- view / jendela ----
    private var handle: View? = null
    private val handleAnims = ArrayList<ObjectAnimator>()
    private var panel: View? = null
    private var crosshair: CrossView? = null
    private var hud: View? = null
    private var hudText: TextView? = null
    private var hudGraph: GraphView? = null
    private var browser: View? = null
    private var web: WebView? = null
    private var calc: View? = null
    private var notesWin: View? = null
    private var notesBody: LinearLayout? = null
    private var notesTitle: TextView? = null
    private var swWin: View? = null
    private var swText: TextView? = null
    private var sbWin: View? = null
    private var settingsWin: View? = null
    private var awakeView: View? = null
    private var lockView: View? = null

    // ---- state ----
    private var selectedTab = 0
    private var hudDetail = false
    private var boostOn = false
    private var recording = false
    private var callBlock = false
    private var callRegistered = false
    private var headsetOnly = false
    private var devCb: AudioDeviceCallback? = null
    private var savedRing = -1
    private var savedNotif = -1
    private var lowLat: WifiManager.WifiLock? = null
    private var torchOn = false
    private var swRunning = false
    private var swBase = 0L
    private var swAcc = 0L

    @Volatile private var running = false
    @Volatile private var ping = -1L
    @Volatile private var loss = 0
    @Volatile private var jitter = 0
    @Volatile private var realFps = -1
    @Volatile private var cpuPct = -1
    @Volatile private var gpuPct = -1
    @Volatile private var tempC = -1
    private var prevTotal = 0L
    private var prevIdle = 0L
    private var rxPrev = -1L
    private var txPrev = -1L
    private var rxKb = 0L
    private var txKb = 0L
    private var frames = 0
    private var uiFps = 0
    private var useChoreo = false
    private var choreoActive = false
    private var pingThread: Thread? = null
    private var samplerThread: Thread? = null

    // ---- tema ----
    private val themes = listOf(
        0xFFFF2D55.toInt() to 0xFFFF7A18.toInt(),
        0xFF7C5CFF.toInt() to 0xFF00E5FF.toInt(),
        0xFF00E676.toInt() to 0xFF00E5FF.toInt(),
        0xFF00B0FF.toInt() to 0xFF7C5CFF.toInt(),
        0xFFFFC107.toInt() to 0xFFFF5252.toInt()
    )
    private var accent = 0xFFFF2D55.toInt()
    private var accent2 = 0xFFFF7A18.toInt()
    private val textColor = 0xFFE8EAF6.toInt()
    private val gray = 0xFF9AA0B5.toInt()
    private val cGreen = 0xFF3DFF9A.toInt()
    private val cYellow = 0xFFFFD43B.toInt()
    private val cRed = 0xFFFF5470.toInt()
    private val darkTop = 0xF2181B28.toInt()
    private val darkBottom = 0xF20D0F17.toInt()
    private val xhColors = intArrayOf(
        0xFF00FF88.toInt(), 0xFFFF3B5C.toInt(), 0xFF00E5FF.toInt(),
        0xFFFFE600.toInt(), 0xFFFFFFFF.toInt()
    )

    private val fNoFocus = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
    private val fNoTouch = WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
    private val fLimits = WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
    private val fModal = WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
    private val fOutside = WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH
    private val fHw = WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED
    private val fKeepOn = WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON
    private val wrap = WindowManager.LayoutParams.WRAP_CONTENT

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val th = themes[prefs.getInt("theme", 0).coerceIn(0, themes.size - 1)]
        accent = th.first
        accent2 = th.second
        startForeground(1, buildNotification())
        addHandle()
    }

    override fun onDestroy() {
        running = false
        swRunning = false
        recording = false
        main.removeCallbacks(tick)
        main.removeCallbacks(swTick)
        handleAnims.forEach { it.cancel() }
        closePanel(false)
        closeBrowser()
        for (v in listOf(calc, notesWin, swWin, sbWin, settingsWin, awakeView, lockView, crosshair, hud, handle)) {
            safeRemove(v)
        }
        if (callRegistered) {
            try { unregisterReceiver(callReceiver) } catch (e: Exception) { }
        }
        val cb = devCb
        if (cb != null) {
            try { getSystemService(AudioManager::class.java).unregisterAudioDeviceCallback(cb) } catch (e: Exception) { }
        }
        headsetOnly = false
        applyHeadset()
        try { lowLat?.release() } catch (e: Exception) { }
        Thread { Sh.run("pkill -2 screenrecord 2>/dev/null") }.start()
        super.onDestroy()
    }

    // ================= util =================

    private fun dens() = resources.displayMetrics.density
    private fun dp(v: Int) = (v * dens()).toInt()
    private fun screenW() = resources.displayMetrics.widthPixels
    private fun screenH() = resources.displayMetrics.heightPixels

    private fun lp(w: Int, h: Int, flags: Int) = WindowManager.LayoutParams(
        w, h, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
        flags or fHw, PixelFormat.TRANSLUCENT
    )

    private fun safeRemove(v: View?) {
        if (v == null) return
        try { wm.removeView(v) } catch (e: Exception) { }
    }

    private fun closeView(v: View?) {
        if (v == null) return
        v.animate().alpha(0f).scaleX(0.92f).scaleY(0.92f).setDuration(130)
            .withEndAction { safeRemove(v) }.start()
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    private fun copyText(label: String, text: String) {
        getSystemService(ClipboardManager::class.java)
            .setPrimaryClip(ClipData.newPlainText(label, text))
    }

    private fun stamp() = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())

    private fun buildNotification(): Notification {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("vexed", "VeXed", NotificationManager.IMPORTANCE_MIN)
        )
        return Notification.Builder(this, "vexed")
            .setContentTitle("VeXed aktif")
            .setSmallIcon(android.R.drawable.ic_menu_manage)
            .build()
    }

    private fun SpannableStringBuilder.addSpan(t: String, color: Int, rel: Float = 1f) {
        val s = length
        append(t)
        setSpan(ForegroundColorSpan(color), s, length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        if (rel != 1f) setSpan(RelativeSizeSpan(rel), s, length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
    }

    private fun putSetting(ns: String, key: String, value: String): Boolean {
        if (Sh.ready()) {
            Sh.run("settings put $ns $key $value")
            return true
        }
        return try {
            when (ns) {
                "global" -> Settings.Global.putString(contentResolver, key, value)
                "secure" -> Settings.Secure.putString(contentResolver, key, value)
                else -> Settings.System.putString(contentResolver, key, value)
            }
        } catch (e: Exception) {
            false
        }
    }

    private fun sharpFrame(content: View, cut: Int = 14): FrameLayout {
        val f = FrameLayout(this)
        f.setPadding(dp(4), dp(4), dp(4), dp(4))
        f.background = ChamferDrawable(darkTop, darkBottom, accent, dp(cut).toFloat(), dens(), true)
        f.addView(content)
        return f
    }

    private fun pill(label: String, primary: Boolean = false, onClick: () -> Unit): TextView {
        val t = TextView(this)
        t.text = label
        t.textSize = 12f
        t.typeface = Typeface.DEFAULT_BOLD
        t.setTextColor(textColor)
        t.gravity = Gravity.CENTER
        t.setPadding(dp(14), dp(10), dp(14), dp(10))
        t.background = if (primary)
            ChamferDrawable(accent, accent2, 0xFFFFFFFF.toInt(), dp(8).toFloat(), dens(), false)
        else
            ChamferDrawable(0xFF262B3D.toInt(), 0xFF171A26.toInt(), 0xFF3A4057.toInt(), dp(8).toFloat(), dens(), false)
        t.setOnClickListener { onClick() }
        return t
    }

    private fun windowHeader(title: String, onClose: () -> Unit): Pair<LinearLayout, TextView> {
        val h = LinearLayout(this)
        h.orientation = LinearLayout.HORIZONTAL
        h.gravity = Gravity.CENTER_VERTICAL
        h.setPadding(dp(6), dp(2), dp(2), dp(8))
        h.addView(LogoView(this, textColor, accent), LinearLayout.LayoutParams(dp(16), dp(16)))
        val tv = TextView(this)
        tv.text = title
        tv.textSize = 12f
        tv.typeface = Typeface.DEFAULT_BOLD
        tv.letterSpacing = 0.08f
        tv.setTextColor(textColor)
        tv.setPadding(dp(8), 0, 0, 0)
        h.addView(tv, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        val close = IconView(this, Icons.CLOSE, textColor)
        close.setPadding(dp(5), dp(5), dp(5), dp(5))
        close.setOnClickListener { onClose() }
        h.addView(close, LinearLayout.LayoutParams(dp(28), dp(28)))
        return Pair(h, tv)
    }

    private fun windowColumn(): LinearLayout {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        c.setPadding(dp(10), dp(10), dp(10), dp(10))
        return c
    }

    private fun openWindow(
        inner: View, header: View, w: Int, h: Int, focusable: Boolean, x: Int, y: Int
    ): View {
        val root = sharpFrame(inner)
        val flags = if (focusable) (fModal or fLimits) else (fNoFocus or fLimits)
        val p = lp(w, h, flags)
        p.gravity = Gravity.TOP or Gravity.START
        p.x = x
        p.y = y
        if (focusable) p.softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN
        makeDraggable(header, root, p)
        root.alpha = 0f
        root.scaleX = 0.92f
        root.scaleY = 0.92f
        wm.addView(root, p)
        root.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(220)
            .setInterpolator(DecelerateInterpolator()).start()
        return root
    }

    private fun makeDraggable(dragView: View, window: View, p: WindowManager.LayoutParams) {
        makeDraggableTap(dragView, window, p) { }
    }

    private fun makeDraggableTap(
        dragView: View, window: View, p: WindowManager.LayoutParams, onTap: () -> Unit
    ) {
        var sx = 0f
        var sy = 0f
        var ox = 0
        var oy = 0
        var moved = false
        dragView.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ox = p.x; oy = p.y; moved = false }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - sx
                    val dy = e.rawY - sy
                    if (!moved && (Math.abs(dx) > dp(6) || Math.abs(dy) > dp(6))) moved = true
                    if (moved) {
                        p.x = ox + dx.toInt()
                        p.y = oy + dy.toInt()
                        try { wm.updateViewLayout(window, p) } catch (ex: Exception) { }
                    }
                }
                MotionEvent.ACTION_UP -> { if (!moved) onTap() }
            }
            true
        }
    }

    private fun seekRow(title: String, lo: Int, hi: Int, value: Int, onChange: (Int) -> Unit): View {
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        val tv = TextView(this)
        tv.text = title
        tv.textSize = 11f
        tv.setTextColor(gray)
        tv.setPadding(dp(4), dp(8), 0, 0)
        col.addView(tv)
        val sb = SeekBar(this)
        sb.max = hi - lo
        sb.progress = (value - lo).coerceIn(0, hi - lo)
        sb.progressTintList = ColorStateList.valueOf(accent)
        sb.thumbTintList = ColorStateList.valueOf(accent2)
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                if (fromUser) onChange(p + lo)
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        col.addView(sb)
        return col
    }

    // ================= info sistem =================

    private fun battery(): Pair<Int, Int> {
        val i = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val lvl = i?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = i?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        val temp = (i?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0) / 10
        return Pair(if (lvl < 0) 0 else lvl * 100 / scale, temp)
    }

    private fun memInfo(): ActivityManager.MemoryInfo {
        val mi = ActivityManager.MemoryInfo()
        getSystemService(ActivityManager::class.java).getMemoryInfo(mi)
        return mi
    }

    private fun ramPct(): Int {
        val mi = memInfo()
        return (100 - mi.availMem * 100 / mi.totalMem).toInt()
    }

    private fun hasDump() =
        checkSelfPermission("android.permission.DUMP") == PackageManager.PERMISSION_GRANTED

    // ================= logo (tombol gestur) =================

    private fun handleSize() = dp(prefs.getInt("hsize", 48))
    private fun handleRight() = prefs.getBoolean("hright", true)

    private fun addHandle() {
        val size = handleSize()
        val v = FrameLayout(this)
        v.background = ChamferDrawable(0xFF1B1F2E.toInt(), 0xFF0E1018.toInt(), accent, dp(10).toFloat(), dens(), true)
        val mg = (size * 0.24f).toInt()
        val llp = FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT)
        llp.setMargins(mg, mg, mg, mg)
        v.addView(LogoView(this, textColor, accent), llp)
        v.alpha = prefs.getInt("halpha", 90) / 100f

        for (prop in arrayOf("scaleX", "scaleY")) {
            handleAnims.add(ObjectAnimator.ofFloat(v, prop, 1f, 1.07f).apply {
                duration = 1400
                repeatCount = ValueAnimator.INFINITE
                repeatMode = ValueAnimator.REVERSE
                start()
            })
        }
        val p = lp(size, size, fNoFocus or fLimits)
        p.gravity = Gravity.TOP or Gravity.START
        p.x = if (handleRight()) screenW() - size else 0
        p.y = (prefs.getFloat("hy", 0.45f) * screenH()).toInt().coerceIn(0, screenH() - size)

        var sx = 0f
        var sy = 0f
        var ox = 0
        var oy = 0
        var dragging = false
        v.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    sx = e.rawX; sy = e.rawY; ox = p.x; oy = p.y; dragging = false
                    v.animate().alpha(1f).setDuration(120).start()
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - sx
                    val dy = e.rawY - sy
                    if (!dragging && (Math.abs(dx) > dp(8) || Math.abs(dy) > dp(8))) dragging = true
                    if (dragging) {
                        p.x = (ox + dx).toInt().coerceIn(0, screenW() - size)
                        p.y = (oy + dy).toInt().coerceIn(0, screenH() - size)
                        try { wm.updateViewLayout(v, p) } catch (ex: Exception) { }
                    }
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    v.animate().alpha(prefs.getInt("halpha", 90) / 100f).setDuration(300).start()
                    if (dragging) {
                        snapHandle(v, p, size)
                    } else if (e.actionMasked == MotionEvent.ACTION_UP) {
                        if (panel == null) showPanel() else closePanel()
                    }
                }
            }
            true
        }
        wm.addView(v, p)
        handle = v
    }

    private fun snapHandle(v: View, p: WindowManager.LayoutParams, size: Int) {
        val right = p.x + size / 2 > screenW() / 2
        val target = if (right) screenW() - size else 0
        prefs.edit().putBoolean("hright", right)
            .putFloat("hy", p.y.toFloat() / screenH()).apply()
        ValueAnimator.ofInt(p.x, target).apply {
            duration = 180
            addUpdateListener {
                p.x = it.animatedValue as Int
                try { wm.updateViewLayout(v, p) } catch (e: Exception) { }
            }
            start()
        }
    }

    private fun rebuildHandle() {
        handleAnims.forEach { it.cancel() }
        handleAnims.clear()
        safeRemove(handle)
        handle = null
        addHandle()
    }

    // ================= panel utama (tab) =================

    private fun tile(
        icon: Int, label: String, active: Boolean,
        onLong: (() -> Unit)? = null, onClick: () -> Unit
    ): LinearLayout {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.gravity = Gravity.CENTER
        box.minimumHeight = dp(76)
        box.setPadding(dp(4), dp(10), dp(4), dp(8))
        box.background = if (active)
            ChamferDrawable(accent, accent2, 0xFFFFFFFF.toInt(), dp(9).toFloat(), dens(), true)
        else
            ChamferDrawable(0xFF262B3D.toInt(), 0xFF171A26.toInt(), 0xFF3A4057.toInt(), dp(9).toFloat(), dens(), false)
        val ic = IconView(this, icon, if (active) 0xFFFFFFFF.toInt() else accent2)
        box.addView(ic, LinearLayout.LayoutParams(dp(24), dp(24)))
        val tv = TextView(this)
        tv.text = label
        tv.textSize = 10f
        tv.typeface = Typeface.DEFAULT_BOLD
        tv.gravity = Gravity.CENTER
        tv.maxLines = 2
        tv.setTextColor(textColor)
        tv.setPadding(0, dp(5), 0, 0)
        box.addView(tv)
        box.setOnTouchListener { v, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN ->
                    v.animate().scaleX(0.93f).scaleY(0.93f).setDuration(80).start()
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL ->
                    v.animate().scaleX(1f).scaleY(1f).setDuration(120).start()
            }
            false
        }
        box.setOnClickListener { onClick() }
        if (onLong != null) box.setOnLongClickListener { onLong(); true }
        return box
    }

    private fun cell() = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        .apply { setMargins(dp(4), dp(4), dp(4), dp(4)) }

    private fun grid(vararg tiles: View): LinearLayout {
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        var i = 0
        while (i < tiles.size) {
            val r = LinearLayout(this)
            r.orientation = LinearLayout.HORIZONTAL
            for (k in 0 until 3) {
                val v: View = if (i + k < tiles.size) tiles[i + k] else Space(this)
                r.addView(v, cell())
            }
            col.addView(r)
            i += 3
        }
        return col
    }

    private fun note(text: String): TextView {
        val t = TextView(this)
        t.text = text
        t.textSize = 10f
        t.setTextColor(gray)
        t.setPadding(dp(6), dp(8), dp(6), dp(2))
        return t
    }

    private fun refreshPanel() {
        closePanel(false)
        showPanel(false)
    }

    private val tabNames = arrayOf("PERFORMA", "NOTIF", "REKAM", "JARINGAN", "SENTUH", "ALAT")

    private fun fillTab(content: LinearLayout) {
        content.removeAllViews()
        when (selectedTab) {
            0 -> content.addView(grid(
                tile(Icons.ROCKET, "Boost", boostOn) { closePanel(); toggleBoost() },
                tile(Icons.CHART, "FPS HUD", hud != null) { closePanel(); toggleHud() },
                tile(Icons.CPU, "Monitor", hud != null && hudDetail) { closePanel(); toggleMonitor() },
                tile(Icons.MEM, "Bersihkan RAM", false) { closePanel(); cleanRam() },
                tile(Icons.SUN, "Layar Aktif", awakeView != null) { closePanel(); toggleAwake() },
                tile(Icons.CROSSHAIR, "Crosshair", crosshair != null, onLong = { cycleCrosshair() }) {
                    closePanel(); toggleCrosshair()
                }
            ))
            1 -> {
                content.addView(grid(
                    tile(Icons.DND, "Jangan Ganggu", dndOn()) { closePanel(); toggleDnd() },
                    tile(Icons.BELLOFF, "Blokir Pop-up", headsUpOff()) { closePanel(); togglePopup() },
                    tile(Icons.PHONEOFF, "Tolak Panggilan", callBlock) { closePanel(); toggleCallBlock() },
                    tile(Icons.HEADSET, "Headset Only", headsetOnly) { closePanel(); toggleHeadset() },
                    tile(Icons.LOCK, "Kunci Sentuh", lockView != null) { closePanel(); toggleLock() }
                ))
                content.addView(note("Tolak Panggilan menolak semua panggilan masuk (belum ada daftar VIP)."))
            }
            2 -> {
                content.addView(grid(
                    tile(Icons.REC, "Rekam ${recLabel()}", recording, onLong = { cycleBitrate() }) {
                        closePanel(); toggleRecord()
                    },
                    tile(Icons.SHOT, "Screenshot", false) { closePanel(); takeShot() },
                    tile(Icons.SPEAKER, "Soundboard", sbWin != null) { closePanel(); toggleSoundboard() }
                ))
                val am = getSystemService(AudioManager::class.java)
                content.addView(seekRow(
                    "Volume media", 0, am.getStreamMaxVolume(AudioManager.STREAM_MUSIC),
                    am.getStreamVolume(AudioManager.STREAM_MUSIC)
                ) { am.setStreamVolume(AudioManager.STREAM_MUSIC, it, 0) })
                content.addView(note("Tahan Rekam untuk ganti bitrate. Rekaman tanpa suara."))
            }
            3 -> {
                content.addView(grid(
                    tile(Icons.CHART, "Monitor Jaringan", hud != null && hudDetail) { closePanel(); toggleMonitor() },
                    tile(Icons.SHIELD, "DNS Cepat", dnsFast()) { closePanel(); toggleDns() },
                    tile(Icons.WIFI, "Wi-Fi", wifiOn()) { closePanel(); toggleWifi() },
                    tile(Icons.DATA, "Data Seluler", dataOn()) { closePanel(); toggleData() },
                    tile(Icons.BOLT, "Low Latency", lowLat?.isHeld == true) { closePanel(); toggleLowLat() }
                ))
                content.addView(note("DNS Cepat memakai Cloudflare (1.1.1.1). Ping asli game tidak bisa dipercepat."))
            }
            4 -> {
                val names = arrayOf("Normal", "Cepat", "Maks")
                content.addView(grid(
                    tile(Icons.TOUCH, "Respons ${names[prefs.getInt("touch", 0).coerceIn(0, 2)]}", prefs.getInt("touch", 0) > 0) {
                        cycleTouch(); refreshPanel()
                    },
                    tile(Icons.ANIM, "Animasi Cepat", animFast()) { toggleAnim(); refreshPanel() },
                    tile(Icons.SAT, "Warna ${satLabel()}", prefs.getInt("sat", 0) > 0) { cycleSat(); refreshPanel() }
                ))
                content.addView(note("Polling rate sentuh tidak bisa diubah tanpa root. Respons mengatur jeda tekan-tahan."))
            }
            else -> content.addView(grid(
                tile(Icons.NOTE, "Catatan", notesWin != null) { closePanel(); toggleNotes() },
                tile(Icons.CALC, "Kalkulator", calc != null) { closePanel(); toggleCalc() },
                tile(Icons.TIMER, "Stopwatch", swWin != null) { closePanel(); toggleStopwatch() },
                tile(Icons.GLOBE, "Browser", browser != null) { closePanel(); toggleBrowser() },
                tile(Icons.FLASH, "Senter", torchOn) { closePanel(); toggleTorch() },
                tile(Icons.GEAR, "Pengaturan", settingsWin != null) { closePanel(); toggleSettings() }
            ))
        }
    }

    private fun showPanel(animate: Boolean = true) {
        if (panel != null) return
        val right = handleRight()

        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(8), dp(8), dp(8), dp(6))

        val head = LinearLayout(this)
        head.orientation = LinearLayout.HORIZONTAL
        head.gravity = Gravity.CENTER_VERTICAL
        head.setPadding(dp(4), 0, dp(4), 0)
        head.addView(LogoView(this, textColor, accent), LinearLayout.LayoutParams(dp(30), dp(30)))
        val titles = LinearLayout(this)
        titles.orientation = LinearLayout.VERTICAL
        val title = TextView(this)
        title.text = "VEXED"
        title.textSize = 16f
        title.typeface = Typeface.DEFAULT_BOLD
        title.letterSpacing = 0.2f
        title.setTextColor(textColor)
        titles.addView(title)
        val bt = battery()
        val sys = TextView(this)
        sys.text = "RAM ${ramPct()}%  ·  ${bt.second}°C  ·  ${bt.first}%"
        sys.textSize = 10f
        sys.setTextColor(gray)
        titles.addView(sys)
        val tlp = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        tlp.leftMargin = dp(10)
        head.addView(titles, tlp)
        col.addView(head)

        val tabIcons = intArrayOf(Icons.ROCKET, Icons.BELLOFF, Icons.REC, Icons.WIFI, Icons.TOUCH, Icons.GEAR)
        val bar = LinearLayout(this)
        bar.orientation = LinearLayout.HORIZONTAL
        bar.setPadding(0, dp(10), 0, dp(2))
        for (i in tabIcons.indices) {
            val cellV = LinearLayout(this)
            cellV.orientation = LinearLayout.VERTICAL
            cellV.gravity = Gravity.CENTER_HORIZONTAL
            cellV.addView(
                IconView(this, tabIcons[i], if (i == selectedTab) accent2 else gray),
                LinearLayout.LayoutParams(dp(26), dp(26))
            )
            val ul = View(this)
            ul.setBackgroundColor(if (i == selectedTab) accent else 0x00000000)
            val ulp = LinearLayout.LayoutParams(dp(22), dp(2))
            ulp.topMargin = dp(4)
            cellV.addView(ul, ulp)
            cellV.setOnClickListener {
                selectedTab = i
                refreshPanel()
            }
            bar.addView(cellV, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        }
        col.addView(bar)

        val tabTitle = TextView(this)
        tabTitle.text = tabNames[selectedTab.coerceIn(0, tabNames.size - 1)]
        tabTitle.textSize = 10f
        tabTitle.letterSpacing = 0.2f
        tabTitle.typeface = Typeface.DEFAULT_BOLD
        tabTitle.setTextColor(accent)
        tabTitle.setPadding(dp(6), dp(6), 0, dp(4))
        col.addView(tabTitle)

        val content = LinearLayout(this)
        content.orientation = LinearLayout.VERTICAL
        fillTab(content)
        col.addView(content)

        val exit = TextView(this)
        exit.text = "KELUAR"
        exit.textSize = 11f
        exit.letterSpacing = 0.2f
        exit.typeface = Typeface.DEFAULT_BOLD
        exit.gravity = Gravity.CENTER
        exit.setTextColor(cRed)
        exit.setPadding(0, dp(10), 0, dp(6))
        exit.setOnClickListener { stopSelf() }
        col.addView(exit)

        val sv = ScrollView(this)
        sv.isVerticalScrollBarEnabled = false
        sv.addView(col)
        val root = sharpFrame(sv, 16)

        val p = lp(dp(318), wrap, fNoFocus or fModal or fOutside)
        p.gravity = (if (right) Gravity.END else Gravity.START) or Gravity.CENTER_VERTICAL
        p.x = dp(6)
        root.setOnTouchListener { _, e ->
            if (e.action == MotionEvent.ACTION_OUTSIDE) { closePanel(); true } else false
        }
        wm.addView(root, p)
        panel = root

        if (animate) {
            root.alpha = 0f
            root.translationX = dp(40).toFloat() * (if (right) 1 else -1)
            root.animate().alpha(1f).translationX(0f).setDuration(220)
                .setInterpolator(DecelerateInterpolator()).start()
            val tiles = ArrayList<View>()
            collectTiles(content, tiles)
            tiles.forEachIndexed { i, v ->
                v.alpha = 0f
                v.translationY = dp(12).toFloat()
                v.animate().alpha(1f).translationY(0f)
                    .setStartDelay(50L + i * 30L).setDuration(200)
                    .setInterpolator(DecelerateInterpolator()).start()
            }
        }
    }

    private fun collectTiles(v: View, out: ArrayList<View>) {
        if (v is LinearLayout && v.isClickable) { out.add(v); return }
        if (v is android.view.ViewGroup) {
            for (i in 0 until v.childCount) collectTiles(v.getChildAt(i), out)
        }
    }

    private fun closePanel(animated: Boolean = true) {
        val v = panel ?: return
        panel = null
        if (!animated) { safeRemove(v); return }
        val dir = if (handleRight()) 1 else -1
        v.animate().alpha(0f).translationX(dp(30).toFloat() * dir).setDuration(150)
            .withEndAction { safeRemove(v) }.start()
    }

    // ================= pengaturan =================

    private fun toggleSettings() {
        if (settingsWin != null) { closeView(settingsWin); settingsWin = null; return }
        val hd = windowHeader("PENGATURAN") { closeView(settingsWin); settingsWin = null }
        val header = hd.first
        val inner = windowColumn()
        inner.addView(header)

        val tt = TextView(this)
        tt.text = "Tema warna"
        tt.textSize = 11f
        tt.setTextColor(gray)
        tt.setPadding(dp(4), dp(4), 0, 0)
        inner.addView(tt)
        val themeRow = LinearLayout(this)
        themeRow.orientation = LinearLayout.HORIZONTAL
        val cur = prefs.getInt("theme", 0)
        themes.forEachIndexed { i, th ->
            val dot = LogoView(this, th.first, th.second)
            dot.background = ChamferDrawable(
                0xFF1B1F2E.toInt(), 0xFF0E1018.toInt(),
                if (cur == i) 0xFFFFFFFF.toInt() else th.first, dp(6).toFloat(), dens(), false
            )
            dot.setPadding(dp(6), dp(6), dp(6), dp(6))
            dot.setOnClickListener {
                prefs.edit().putInt("theme", i).apply()
                accent = th.first
                accent2 = th.second
                rebuildHandle()
                closeView(settingsWin)
                settingsWin = null
                toast("Tema diganti. Buka ulang jendela agar warnanya berubah.")
            }
            val lpd = LinearLayout.LayoutParams(dp(40), dp(40))
            lpd.setMargins(dp(4), dp(6), dp(4), dp(6))
            themeRow.addView(dot, lpd)
        }
        inner.addView(themeRow)

        inner.addView(seekRow("Ukuran logo", 36, 72, prefs.getInt("hsize", 48)) {
            prefs.edit().putInt("hsize", it).apply()
            rebuildHandle()
        })
        inner.addView(seekRow("Transparansi logo", 20, 100, prefs.getInt("halpha", 90)) {
            prefs.edit().putInt("halpha", it).apply()
            handle?.alpha = it / 100f
        })

        val reset = pill("Reset posisi logo") {
            prefs.edit().putBoolean("hright", true).putFloat("hy", 0.45f).apply()
            rebuildHandle()
            toast("Posisi logo direset")
        }
        val rlp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        rlp.setMargins(0, dp(12), 0, dp(4))
        inner.addView(reset, rlp)

        settingsWin = openWindow(inner, header, dp(290), wrap, false, dp(30), dp(110))
    }

    // ================= crosshair =================

    private inner class CrossView : View(this@OverlayService) {
        var shape = 0
        var color = 0
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG)

        override fun onDraw(canvas: Canvas) {
            paint.color = color
            paint.strokeWidth = dp(2).toFloat()
            val cx = width / 2f
            val cy = height / 2f
            val gap = dp(4).toFloat()
            val len = dp(11).toFloat()
            paint.style = Paint.Style.STROKE
            when (shape) {
                0, 3 -> {
                    canvas.drawLine(cx - gap - len, cy, cx - gap, cy, paint)
                    canvas.drawLine(cx + gap, cy, cx + gap + len, cy, paint)
                    canvas.drawLine(cx, cy - gap - len, cx, cy - gap, paint)
                    canvas.drawLine(cx, cy + gap, cx, cy + gap + len, paint)
                }
                2 -> canvas.drawCircle(cx, cy, dp(10).toFloat(), paint)
            }
            if (shape == 1 || shape == 2 || shape == 3) {
                paint.style = Paint.Style.FILL
                canvas.drawCircle(cx, cy, dp(2).toFloat(), paint)
            }
        }
    }

    private fun applyXh(v: CrossView) {
        val idx = prefs.getInt("xh", 0)
        v.shape = idx % 4
        v.color = xhColors[(idx / 4) % xhColors.size]
        v.invalidate()
    }

    private fun cycleCrosshair() {
        val total = 4 * xhColors.size
        val idx = (prefs.getInt("xh", 0) + 1) % total
        prefs.edit().putInt("xh", idx).apply()
        crosshair?.let { applyXh(it) }
        toast("Gaya crosshair ${idx + 1}/$total")
    }

    private fun toggleCrosshair() {
        if (crosshair != null) {
            safeRemove(crosshair)
            crosshair = null
            return
        }
        val v = CrossView()
        applyXh(v)
        val p = lp(dp(48), dp(48), fNoFocus or fNoTouch or fLimits)
        p.gravity = Gravity.CENTER
        wm.addView(v, p)
        crosshair = v
    }

    // ================= notifikasi & panggilan =================

    private fun dndOn(): Boolean {
        val nm = getSystemService(NotificationManager::class.java)
        return nm.isNotificationPolicyAccessGranted &&
            nm.currentInterruptionFilter == NotificationManager.INTERRUPTION_FILTER_ALARMS
    }

    private fun toggleDnd() {
        val nm = getSystemService(NotificationManager::class.java)
        if (!nm.isNotificationPolicyAccessGranted) {
            toast("Beri izin Jangan Ganggu dulu")
            startActivity(
                Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
            return
        }
        val on = nm.currentInterruptionFilter == NotificationManager.INTERRUPTION_FILTER_ALARMS
        nm.setInterruptionFilter(
            if (on) NotificationManager.INTERRUPTION_FILTER_ALL
            else NotificationManager.INTERRUPTION_FILTER_ALARMS
        )
        toast(if (on) "Jangan Ganggu mati" else "Jangan Ganggu nyala")
    }

    private fun headsUpOff() =
        Settings.Global.getString(contentResolver, "heads_up_notifications_enabled") == "0"

    private fun togglePopup() {
        val off = headsUpOff()
        val ok = putSetting("global", "heads_up_notifications_enabled", if (off) "1" else "0")
        toast(
            if (!ok) "Butuh Shizuku aktif"
            else if (off) "Pop-up notifikasi nyala kembali"
            else "Pop-up notifikasi diblokir"
        )
    }

    private val callReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            val st = intent?.getStringExtra(TelephonyManager.EXTRA_STATE)
            if (callBlock && st == TelephonyManager.EXTRA_STATE_RINGING) {
                try {
                    val tm = getSystemService(TelecomManager::class.java)
                    tm.endCall()
                    toast("Panggilan ditolak otomatis")
                } catch (e: Exception) {
                    toast("Izin telepon belum aktif")
                }
            }
        }
    }

    private fun phonePerm() =
        checkSelfPermission("android.permission.READ_PHONE_STATE") == PackageManager.PERMISSION_GRANTED &&
            checkSelfPermission("android.permission.ANSWER_PHONE_CALLS") == PackageManager.PERMISSION_GRANTED

    private fun toggleCallBlock() {
        if (callBlock) {
            callBlock = false
            toast("Tolak panggilan mati")
            return
        }
        if (!phonePerm() && Sh.ready()) {
            Sh.run(
                "pm grant $packageName android.permission.READ_PHONE_STATE; " +
                    "pm grant $packageName android.permission.ANSWER_PHONE_CALLS"
            )
        }
        if (!phonePerm()) {
            toast("Beri izin Telepon lewat aplikasi VeXed")
            return
        }
        if (!callRegistered) {
            registerReceiver(callReceiver, IntentFilter(TelephonyManager.ACTION_PHONE_STATE_CHANGED))
            callRegistered = true
        }
        callBlock = true
        toast("Panggilan masuk akan ditolak")
    }

    private fun headsetConnected(am: AudioManager): Boolean =
        am.getDevices(AudioManager.GET_DEVICES_OUTPUTS).any {
            it.type == AudioDeviceInfo.TYPE_WIRED_HEADSET ||
                it.type == AudioDeviceInfo.TYPE_WIRED_HEADPHONES ||
                it.type == AudioDeviceInfo.TYPE_BLUETOOTH_A2DP ||
                it.type == AudioDeviceInfo.TYPE_BLUETOOTH_SCO ||
                it.type == AudioDeviceInfo.TYPE_USB_HEADSET
        }

    private fun applyHeadset() {
        val am = getSystemService(AudioManager::class.java)
        try {
            if (headsetOnly && !headsetConnected(am)) {
                if (savedRing < 0) {
                    savedRing = am.getStreamVolume(AudioManager.STREAM_RING)
                    savedNotif = am.getStreamVolume(AudioManager.STREAM_NOTIFICATION)
                }
                am.setStreamVolume(AudioManager.STREAM_RING, 0, 0)
                am.setStreamVolume(AudioManager.STREAM_NOTIFICATION, 0, 0)
            } else if (savedRing >= 0) {
                am.setStreamVolume(AudioManager.STREAM_RING, savedRing, 0)
                am.setStreamVolume(AudioManager.STREAM_NOTIFICATION, savedNotif, 0)
                savedRing = -1
                savedNotif = -1
            }
        } catch (e: Exception) {
            toast("Butuh izin Jangan Ganggu agar volume bisa diatur")
        }
    }

    private fun toggleHeadset() {
        val am = getSystemService(AudioManager::class.java)
        headsetOnly = !headsetOnly
        if (headsetOnly) {
            val cb = object : AudioDeviceCallback() {
                override fun onAudioDevicesAdded(addedDevices: Array<out AudioDeviceInfo>?) { applyHeadset() }
                override fun onAudioDevicesRemoved(removedDevices: Array<out AudioDeviceInfo>?) { applyHeadset() }
            }
            devCb = cb
            am.registerAudioDeviceCallback(cb, main)
        } else {
            val cb = devCb
            if (cb != null) am.unregisterAudioDeviceCallback(cb)
            devCb = null
        }
        applyHeadset()
        toast(if (headsetOnly) "Dering dan notifikasi hanya lewat headset" else "Headset Only mati")
    }

    // ================= senter, layar aktif, kunci sentuh =================

    private fun toggleTorch() {
        try {
            val cm = getSystemService(CameraManager::class.java)
            val id = cm.cameraIdList.firstOrNull {
                cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            }
            if (id == null) {
                toast("Perangkat tidak punya senter")
                return
            }
            torchOn = !torchOn
            cm.setTorchMode(id, torchOn)
            toast(if (torchOn) "Senter nyala" else "Senter mati")
        } catch (e: Exception) {
            torchOn = false
            toast("Senter gagal dinyalakan")
        }
    }

    private fun toggleAwake() {
        if (awakeView != null) {
            safeRemove(awakeView)
            awakeView = null
            toast("Layar kembali normal")
            return
        }
        val v = View(this)
        val p = lp(1, 1, fNoFocus or fNoTouch or fKeepOn)
        p.gravity = Gravity.TOP or Gravity.START
        wm.addView(v, p)
        awakeView = v
        toast("Layar tetap menyala")
    }

    private fun toggleLock() {
        if (lockView != null) {
            safeRemove(lockView)
            lockView = null
            return
        }
        val root = FrameLayout(this)
        root.setBackgroundColor(0x01000000)
        root.setOnTouchListener { _, _ -> true }
        val hint = LinearLayout(this)
        hint.orientation = LinearLayout.HORIZONTAL
        hint.gravity = Gravity.CENTER_VERTICAL
        hint.setPadding(dp(16), dp(10), dp(18), dp(10))
        hint.background = ChamferDrawable(0xE6181B28.toInt(), 0xE60D0F17.toInt(), accent, dp(10).toFloat(), dens(), true)
        hint.addView(IconView(this, Icons.LOCK, accent2), LinearLayout.LayoutParams(dp(20), dp(20)))
        val tv = TextView(this)
        tv.text = "Tahan untuk membuka"
        tv.textSize = 12f
        tv.typeface = Typeface.DEFAULT_BOLD
        tv.setTextColor(textColor)
        tv.setPadding(dp(8), 0, 0, 0)
        hint.addView(tv)
        hint.setOnClickListener { }
        hint.setOnLongClickListener { toggleLock(); true }
        val hl = FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT,
            Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
        )
        hl.bottomMargin = dp(70)
        root.addView(hint, hl)
        val p = lp(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT, fNoFocus or fLimits)
        wm.addView(root, p)
        lockView = root
        toast("Sentuhan dikunci")
    }

    // ================= performa: boost & RAM =================

    private fun cleanRam() {
        val am = getSystemService(ActivityManager::class.java)
        val before = memInfo().availMem / 1048576
        var n = 0
        for (ai in packageManager.getInstalledApplications(0)) {
            if (ai.packageName == packageName) continue
            if ((ai.flags and ApplicationInfo.FLAG_SYSTEM) != 0) continue
            try { am.killBackgroundProcesses(ai.packageName); n++ } catch (e: Exception) { }
        }
        main.postDelayed({
            val after = memInfo().availMem / 1048576
            toast("$n app ditutup · RAM bebas $before → $after MB")
        }, 900)
    }

    private fun toggleBoost() {
        if (!Sh.ready()) {
            toast("Boost butuh Shizuku aktif")
            return
        }
        boostOn = !boostOn
        val on = boostOn
        toast(if (on) "Boost aktif" else "Boost mati")
        Thread {
            if (on) {
                val pkg = foregroundPkg()
                val sb = StringBuilder()
                sb.append("cmd power set-fixed-performance-mode-enabled true 2>&1; ")
                sb.append("cmd power set-adaptive-power-saver-enabled false 2>&1; ")
                sb.append("settings put global low_power 0 2>&1; ")
                if (pkg != null && pkg != packageName) {
                    sb.append("cmd game mode performance $pkg 2>&1; ")
                    sb.append("cmd game set --mode performance $pkg 2>&1; ")
                }
                Sh.run(sb.toString())
                main.post { cleanRam() }
            } else {
                Sh.run(
                    "cmd power set-fixed-performance-mode-enabled false 2>&1; " +
                        "cmd power set-adaptive-power-saver-enabled true 2>&1"
                )
            }
        }.start()
    }

    // ================= rekam layar & screenshot =================

    private fun recLabel() = arrayOf("4M", "8M", "12M")[prefs.getInt("recbr", 1).coerceIn(0, 2)]

    private fun cycleBitrate() {
        val n = (prefs.getInt("recbr", 1) + 1) % 3
        prefs.edit().putInt("recbr", n).apply()
        toast("Bitrate rekam ${recLabel()}bps")
    }

    private fun toggleRecord() {
        if (!Sh.ready()) {
            toast("Rekam layar butuh Shizuku aktif")
            return
        }
        if (recording) {
            recording = false
            Thread { Sh.run("pkill -2 screenrecord 2>&1 || killall -2 screenrecord 2>&1") }.start()
            toast("Rekaman dihentikan. Cek Movies/VeXed")
            return
        }
        recording = true
        val br = intArrayOf(4, 8, 12)[prefs.getInt("recbr", 1).coerceIn(0, 2)] * 1_000_000
        toast("Merekam layar (tanpa suara)")
        Thread {
            while (recording) {
                val f = "/sdcard/Movies/VeXed/VeXed_${stamp()}.mp4"
                Sh.run("mkdir -p /sdcard/Movies/VeXed")
                val t0 = SystemClock.elapsedRealtime()
                val p = Sh.start("screenrecord --bit-rate $br '$f' 2>&1")
                try { p?.waitFor() } catch (e: Exception) { }
                if (p == null || SystemClock.elapsedRealtime() - t0 < 2000) {
                    recording = false
                    main.post { toast("Rekam layar gagal") }
                }
            }
        }.start()
    }

    private fun takeShot() {
        if (!Sh.ready()) {
            toast("Screenshot butuh Shizuku aktif")
            return
        }
        val file = "/sdcard/Pictures/VeXed/VeXed_${stamp()}.png"
        handle?.visibility = View.INVISIBLE
        hud?.visibility = View.INVISIBLE
        Thread {
            try { Thread.sleep(450) } catch (e: InterruptedException) { }
            Sh.run(
                "mkdir -p /sdcard/Pictures/VeXed; screencap -p '$file' 2>&1; " +
                    "am broadcast -a android.intent.action.MEDIA_SCANNER_SCAN_FILE -d file://$file >/dev/null 2>&1"
            )
            main.post {
                handle?.visibility = View.VISIBLE
                hud?.visibility = View.VISIBLE
                toast("Tersimpan di Pictures/VeXed")
            }
        }.start()
    }

    // ================= soundboard =================

    private fun gen(sec: Double, f: (Double, Double) -> Double): ShortArray {
        val sr = 22050
        val n = (sr * sec).toInt()
        val out = ShortArray(n)
        for (i in 0 until n) {
            val t = i / sr.toDouble()
            val env = minOf(1.0, i / 200.0) * minOf(1.0, (n - i) / 400.0)
            val v = (f(t, sec) * env * 12000).toInt().coerceIn(-32000, 32000)
            out[i] = v.toShort()
        }
        return out
    }

    private fun synth(kind: Int): ShortArray = when (kind) {
        0 -> gen(0.7) { t, _ ->
            if (Math.sin(2 * Math.PI * 440 * t) + 0.6 * Math.sin(2 * Math.PI * 554 * t) > 0) 0.7 else -0.7
        }
        1 -> gen(0.35) { t, d -> Math.sin(2 * Math.PI * (1800 * t - 1500 * t * t / (2 * d))) }
        2 -> gen(0.3) { t, _ ->
            Math.sin(2 * Math.PI * (if (t < 0.1) 988.0 else 1319.0) * t) * Math.exp(-3 * t)
        }
        3 -> gen(0.45) { t, _ ->
            Math.sin(2 * Math.PI * (45 * t + 20 * (1 - Math.exp(-6 * t)))) * Math.exp(-5 * t)
        }
        4 -> gen(0.9) { t, _ ->
            Math.sin(2 * Math.PI * (if (((t * 4).toInt() % 2) == 0) 800.0 else 600.0) * t)
        }
        5 -> gen(0.9) { t, d -> (Math.random() * 2 - 1) * Math.sin(Math.PI * t / d) }
        6 -> gen(1.0) { t, _ ->
            val f = if (t < 0.25) 392.0 else if (t < 0.5) 370.0 else if (t < 0.75) 349.0 else 330.0
            Math.sin(2 * Math.PI * f * t)
        }
        else -> gen(0.6) { t, _ -> Math.sin(2 * Math.PI * 880 * t) * Math.exp(-5 * t) }
    }

    private fun playSound(kind: Int) {
        Thread {
            try {
                val data = synth(kind)
                val track = AudioTrack.Builder()
                    .setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_GAME)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                            .build()
                    )
                    .setAudioFormat(
                        AudioFormat.Builder()
                            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                            .setSampleRate(22050)
                            .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                            .build()
                    )
                    .setBufferSizeInBytes(data.size * 2)
                    .setTransferMode(AudioTrack.MODE_STATIC)
                    .build()
                track.write(data, 0, data.size)
                track.play()
                Thread.sleep(data.size * 1000L / 22050 + 150)
                track.release()
            } catch (e: Exception) {
            }
        }.start()
    }

    private fun toggleSoundboard() {
        if (sbWin != null) { closeView(sbWin); sbWin = null; return }
        val hd = windowHeader("SOUNDBOARD") { closeView(sbWin); sbWin = null }
        val header = hd.first
        val inner = windowColumn()
        inner.addView(header)
        val names = arrayOf("Klakson", "Laser", "Koin", "Drum", "Alarm", "Sorak", "Sedih", "Ding")
        for (r in 0 until 2) {
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            for (k in 0 until 4) {
                val idx = r * 4 + k
                val b = pill(names[idx]) { playSound(idx) }
                b.textSize = 11f
                b.setPadding(dp(6), dp(12), dp(6), dp(12))
                row.addView(b, cell())
            }
            inner.addView(row)
        }
        inner.addView(note("Suara keluar lewat speaker. Rekan hanya mendengar bila mikrofon menangkapnya."))
        sbWin = openWindow(inner, header, dp(300), wrap, false, dp(30), dp(200))
    }

    // ================= jaringan =================

    private fun dnsFast() =
        Settings.Global.getString(contentResolver, "private_dns_mode") == "hostname"

    private fun toggleDns() {
        val on = dnsFast()
        val ok = if (on) putSetting("global", "private_dns_mode", "opportunistic")
        else (putSetting("global", "private_dns_specifier", "one.one.one.one") &&
            putSetting("global", "private_dns_mode", "hostname"))
        toast(if (!ok) "Butuh Shizuku aktif" else if (on) "DNS kembali otomatis" else "DNS Cepat aktif")
    }

    private fun wifiMgr() = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager

    private fun wifiOn() = try { wifiMgr().isWifiEnabled } catch (e: Exception) { false }

    private fun dataOn() = Settings.Global.getString(contentResolver, "mobile_data") == "1"

    private fun toggleWifi() {
        if (!Sh.ready()) { toast("Butuh Shizuku aktif"); return }
        val on = wifiOn()
        Thread { Sh.run("svc wifi ${if (on) "disable" else "enable"}") }.start()
        toast(if (on) "Wi-Fi dimatikan" else "Wi-Fi dinyalakan")
    }

    private fun toggleData() {
        if (!Sh.ready()) { toast("Butuh Shizuku aktif"); return }
        val on = dataOn()
        Thread { Sh.run("svc data ${if (on) "disable" else "enable"}") }.start()
        toast(if (on) "Data seluler dimatikan" else "Data seluler dinyalakan")
    }

    private fun toggleLowLat() {
        val cur = lowLat
        if (cur != null && cur.isHeld) {
            cur.release()
            lowLat = null
            toast("Low latency mati")
            return
        }
        try {
            val mode = if (Build.VERSION.SDK_INT >= 29) WifiManager.WIFI_MODE_FULL_LOW_LATENCY
            else WifiManager.WIFI_MODE_FULL_HIGH_PERF
            val lock = wifiMgr().createWifiLock(mode, "vexed")
            lock.acquire()
            lowLat = lock
            toast("Wi-Fi low latency aktif")
        } catch (e: Exception) {
            toast("Low latency gagal diaktifkan")
        }
    }

    // ================= sentuh & visual =================

    private fun cycleTouch() {
        val n = (prefs.getInt("touch", 0) + 1) % 3
        val lpt = intArrayOf(400, 300, 220)[n]
        val mpt = intArrayOf(300, 250, 200)[n]
        val ok = putSetting("secure", "long_press_timeout", lpt.toString()) &&
            putSetting("secure", "multi_press_timeout", mpt.toString())
        if (ok) {
            prefs.edit().putInt("touch", n).apply()
            toast("Respons sentuh: ${arrayOf("Normal", "Cepat", "Maks")[n]}")
        } else {
            toast("Butuh Shizuku aktif")
        }
    }

    private fun animFast() =
        Settings.Global.getString(contentResolver, "window_animation_scale") == "0.5"

    private fun toggleAnim() {
        val v = if (animFast()) "1.0" else "0.5"
        val ok = putSetting("global", "window_animation_scale", v) &&
            putSetting("global", "transition_animation_scale", v) &&
            putSetting("global", "animator_duration_scale", v)
        toast(if (!ok) "Butuh Shizuku aktif" else if (v == "0.5") "Animasi dipercepat" else "Animasi normal")
    }

    private fun satLabel() = arrayOf("1.0x", "1.3x", "1.6x", "2.0x")[prefs.getInt("sat", 0).coerceIn(0, 3)]

    private fun cycleSat() {
        if (!Sh.ready()) { toast("Butuh Shizuku aktif"); return }
        val n = (prefs.getInt("sat", 0) + 1) % 4
        val v = floatArrayOf(1.0f, 1.3f, 1.6f, 2.0f)[n]
        prefs.edit().putInt("sat", n).apply()
        Thread { Sh.run("service call SurfaceFlinger 1022 f $v") }.start()
        toast("Saturasi warna ${satLabel()} (bergantung perangkat)")
    }

    // ================= HUD =================

    private inner class GraphView : View(this@OverlayService) {
        private val n = 40
        private val f = IntArray(n)
        private val m = IntArray(n)
        private var idx = 0
        private val pf = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = dp(1).toFloat() * 1.6f
            color = cGreen
        }
        private val pm = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = dp(1).toFloat()
            color = accent2
        }

        fun push(fv: Int, pv: Int) {
            f[idx] = fv
            m[idx] = pv
            idx = (idx + 1) % n
            invalidate()
        }

        override fun onDraw(canvas: Canvas) {
            val w = width.toFloat()
            val h = height.toFloat()
            line(canvas, f, 120, pf, w, h)
            line(canvas, m, 200, pm, w, h)
        }

        private fun line(canvas: Canvas, d: IntArray, max: Int, paint: Paint, w: Float, h: Float) {
            val path = Path()
            for (k in 0 until n) {
                val i = (idx + k) % n
                val x = k * w / (n - 1)
                val y = h - (d[i].coerceIn(0, max) / max.toFloat()) * h
                if (k == 0) path.moveTo(x, y) else path.lineTo(x, y)
            }
            canvas.drawPath(path, paint)
        }
    }

    private val frameCb = object : Choreographer.FrameCallback {
        override fun doFrame(frameTimeNanos: Long) {
            frames++
            if (running && useChoreo) Choreographer.getInstance().postFrameCallback(this)
            else choreoActive = false
        }
    }

    private fun hudSpan(): SpannableStringBuilder {
        val real = realFps
        val fps = if (real >= 0) real else uiFps
        val fpsColor = if (fps >= 50) cGreen else if (fps >= 30) cYellow else cRed
        val pg = ping
        val msColor = if (pg < 0) gray else if (pg < 60) cGreen else if (pg < 120) cYellow else cRed
        val sb = SpannableStringBuilder()
        sb.addSpan("$fps", fpsColor)
        sb.addSpan(if (real >= 0) " FPS" else " FPS*", gray, 0.85f)
        sb.addSpan("  ·  ", gray, 0.85f)
        sb.addSpan(if (pg < 0) "--" else "$pg", msColor)
        sb.addSpan(" ms", gray, 0.85f)
        if (hudDetail) {
            val cpu = if (cpuPct >= 0) "$cpuPct%" else "--"
            val gpu = if (gpuPct >= 0) "$gpuPct%" else "--"
            val t = if (tempC > 0) tempC else battery().second
            sb.addSpan("\nCPU $cpu   GPU $gpu   RAM ${ramPct()}%", gray, 0.85f)
            sb.addSpan("\n$t°C   ↓${rxKb}K  ↑${txKb}K", gray, 0.85f)
            sb.addSpan("\nloss $loss%   jitter ${jitter}ms", gray, 0.85f)
        }
        return sb
    }

    private val tick = object : Runnable {
        override fun run() {
            if (!running) return
            val s = hudText ?: return
            if (useChoreo) { uiFps = frames; frames = 0 }
            val rx = TrafficStats.getTotalRxBytes()
            val tx = TrafficStats.getTotalTxBytes()
            if (rxPrev >= 0 && rx >= 0) {
                rxKb = (rx - rxPrev) / 1024
                txKb = (tx - txPrev) / 1024
            }
            rxPrev = rx
            txPrev = tx
            s.text = hudSpan()
            val fps = if (realFps >= 0) realFps else uiFps
            val pg = ping
            hudGraph?.push(fps, if (pg < 0) 0 else pg.toInt())
            main.postDelayed(this, 1000)
        }
    }

    private fun applyHudMode() {
        hudGraph?.visibility = if (hudDetail) View.VISIBLE else View.GONE
        hudText?.text = hudSpan()
    }

    private fun toggleMonitor() {
        if (hud == null) {
            hudDetail = true
            toggleHud()
        } else {
            hudDetail = !hudDetail
            applyHudMode()
        }
    }

    private fun toggleHud() {
        if (hud != null) {
            running = false
            main.removeCallbacks(tick)
            safeRemove(hud)
            hud = null
            hudText = null
            hudGraph = null
            return
        }
        val txt = TextView(this)
        txt.text = "--"
        txt.textSize = 10f
        txt.typeface = Typeface.DEFAULT_BOLD
        txt.setTextColor(textColor)
        val g = GraphView()
        g.visibility = if (hudDetail) View.VISIBLE else View.GONE
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(9), dp(5), dp(10), dp(5))
        box.background = ChamferDrawable(0xE6181B28.toInt(), 0xE60D0F17.toInt(), accent, dp(6).toFloat(), dens(), false)
        box.addView(txt)
        val glp = LinearLayout.LayoutParams(dp(110), dp(18))
        glp.topMargin = dp(3)
        box.addView(g, glp)

        val p = lp(wrap, wrap, fNoFocus or fLimits)
        p.gravity = Gravity.TOP or Gravity.START
        p.x = dp(10)
        p.y = dp(36)
        makeDraggableTap(box, box, p) {
            hudDetail = !hudDetail
            applyHudMode()
        }
        box.alpha = 0f
        wm.addView(box, p)
        box.animate().alpha(1f).setDuration(250).start()
        hud = box
        hudText = txt
        hudGraph = g

        running = true
        frames = 0
        rxPrev = -1L
        useChoreo = !(Sh.ready() || hasDump())
        if (useChoreo && !choreoActive) {
            choreoActive = true
            Choreographer.getInstance().postFrameCallback(frameCb)
        }
        main.removeCallbacks(tick)
        main.postDelayed(tick, 700)
        startPing()
        startSampler()
    }

    private fun startPing() {
        if (pingThread?.isAlive == true) return
        pingThread = Thread {
            val hist = ArrayList<Long>()
            while (running) {
                val t0 = System.nanoTime()
                val r = try {
                    Socket().use { it.connect(InetSocketAddress("1.1.1.1", 443), 1500) }
                    (System.nanoTime() - t0) / 1_000_000
                } catch (e: Exception) {
                    -1L
                }
                ping = r
                hist.add(r)
                if (hist.size > 10) hist.removeAt(0)
                loss = hist.count { it < 0 } * 100 / hist.size
                val ok = hist.filter { it >= 0 }
                var sum = 0L
                for (i in 1 until ok.size) sum += Math.abs(ok[i] - ok[i - 1])
                jitter = if (ok.size > 1) (sum / (ok.size - 1)).toInt() else 0
                try { Thread.sleep(1500) } catch (e: InterruptedException) { return@Thread }
            }
        }.also { it.start() }
    }

    private fun startSampler() {
        if (samplerThread?.isAlive == true) return
        samplerThread = Thread {
            var layer: String? = null
            var lastScan = 0L
            var n = 0
            while (running) {
                if (Sh.ready() || hasDump()) {
                    val now = System.nanoTime()
                    if (lastScan == 0L || now - lastScan > 5_000_000_000L) {
                        val fg = foregroundPkg()
                        if (fg != null && fg != packageName) layer = findLayer(fg)
                        lastScan = now
                    }
                    realFps = layer?.let { readFps(it) } ?: -1
                } else {
                    realFps = -1
                }
                if (hudDetail && Sh.ready() && n % 2 == 0) readHw()
                n++
                try { Thread.sleep(1000) } catch (e: InterruptedException) { return@Thread }
            }
        }.also { it.start() }
    }

    private fun foregroundPkg(): String? {
        val out = Sh.sys("dumpsys activity activities 2>/dev/null | grep -m 1 ResumedActivity")
        val m = Regex("""ActivityRecord\{\S+ u\d+ ([\w.]+)/""").find(out)
        return m?.groupValues?.get(1)
    }

    private fun findLayer(pkg: String): String? {
        val layers = Sh.sys("dumpsys SurfaceFlinger --list 2>/dev/null").lines().map { it.trim() }
        val c = layers.filter { it.contains(pkg) }
        return c.firstOrNull { it.contains("SurfaceView") && it.contains("BLAST") }
            ?: c.firstOrNull { it.contains("SurfaceView") }
            ?: c.firstOrNull { it.contains("$pkg/") }
            ?: c.firstOrNull()
    }

    private fun readFps(layer: String): Int? {
        val q = layer.replace("'", "'\\''")
        val lines = Sh.sys("dumpsys SurfaceFlinger --latency '$q' 2>/dev/null").lines()
        val now = System.nanoTime()
        var count = 0
        var valid = 0
        for (i in 1 until lines.size) {
            val parts = lines[i].trim().split(Regex("\\s+"))
            if (parts.size < 3) continue
            val t = parts[1].toLongOrNull() ?: continue
            if (t <= 0L || t == Long.MAX_VALUE) continue
            valid++
            if (t > now - 1_000_000_000L && t <= now + 200_000_000L) count++
        }
        return if (valid == 0) null else count
    }

    private fun readHw() {
        val script = "head -n1 /proc/stat; echo '--'; " +
            "cat /sys/class/kgsl/kgsl-3d0/gpubusy 2>/dev/null; echo '--'; " +
            "cat /sys/kernel/gpu/gpu_busy 2>/dev/null; echo '--'; " +
            "cat /sys/kernel/ged/hal/gpu_utilization 2>/dev/null; echo '--'; " +
            "for z in /sys/class/thermal/thermal_zone*; do " +
            "echo \"\$(cat \$z/type 2>/dev/null) \$(cat \$z/temp 2>/dev/null)\"; done"
        val out = Sh.run(script)
        if (out.isEmpty()) return
        val secs = ArrayList<List<String>>()
        var cur = ArrayList<String>()
        for (line in out.lines()) {
            if (line.trim() == "--") {
                secs.add(cur)
                cur = ArrayList()
            } else {
                cur.add(line)
            }
        }
        secs.add(cur)

        // CPU
        val cpuLine = secs.getOrNull(0)?.firstOrNull()
        if (cpuLine != null) {
            val v = cpuLine.trim().split(Regex("\\s+")).drop(1).mapNotNull { it.toLongOrNull() }
            if (v.size >= 5) {
                val idle = v[3] + v[4]
                val total = v.sum()
                if (prevTotal > 0) {
                    val dt = total - prevTotal
                    val di = idle - prevIdle
                    if (dt > 0) cpuPct = ((dt - di) * 100 / dt).toInt().coerceIn(0, 100)
                }
                prevTotal = total
                prevIdle = idle
            }
        }

        // GPU (bergantung SoC)
        var g = -1
        val num = Regex("\\d+")
        val k = secs.getOrNull(1)?.firstOrNull()
        if (k != null) {
            val nums = num.findAll(k).map { it.value.toLong() }.toList()
            if (nums.size >= 2 && nums[1] > 0) g = (nums[0] * 100 / nums[1]).toInt()
        }
        if (g < 0) {
            val l = secs.getOrNull(2)?.firstOrNull()
            val x = if (l != null) num.find(l)?.value?.toIntOrNull() else null
            if (x != null) g = x
        }
        if (g < 0) {
            val l = secs.getOrNull(3)?.firstOrNull()
            val x = if (l != null) num.find(l)?.value?.toIntOrNull() else null
            if (x != null) g = x
        }
        gpuPct = if (g in 0..100) g else -1

        // suhu
        val temps = ArrayList<Pair<String, Int>>()
        for (ln in secs.last()) {
            val tk = ln.trim().split(Regex("\\s+"))
            val raw = tk.lastOrNull()?.toIntOrNull() ?: continue
            val tc = if (raw > 1000) raw / 1000 else raw
            if (tc in 10..120) temps.add(Pair(tk.dropLast(1).joinToString(" "), tc))
        }
        val pick = temps.firstOrNull {
            val n = it.first.lowercase()
            n.contains("cpu") || n.contains("soc") || n.contains("tsens") || n.contains("ap")
        } ?: temps.maxByOrNull { it.second }
        tempC = pick?.second ?: -1
    }

    // ================= catatan =================

    private fun loadNotes(): JSONArray = try {
        JSONArray(prefs.getString("notes", "[]"))
    } catch (e: Exception) {
        JSONArray()
    }

    private fun saveNotes(a: JSONArray) {
        prefs.edit().putString("notes", a.toString()).apply()
    }

    private fun toggleNotes() {
        if (notesWin != null) { closeNotes(); return }
        val hd = windowHeader("CATATAN") { closeNotes() }
        val header = hd.first
        notesTitle = hd.second
        val body = LinearLayout(this)
        body.orientation = LinearLayout.VERTICAL
        notesBody = body
        val inner = windowColumn()
        inner.addView(header)
        inner.addView(body)
        notesWin = openWindow(inner, header, dp(300), wrap, true, dp(24), dp(90))
        notesShowList()
    }

    private fun closeNotes() {
        closeView(notesWin)
        notesWin = null
        notesBody = null
        notesTitle = null
    }

    private fun notesShowList() {
        val body = notesBody ?: return
        body.removeAllViews()
        notesTitle?.text = "CATATAN"
        body.addView(pill("+  Catatan baru", true) {
            val old = loadNotes()
            val na = JSONArray()
            na.put(JSONObject().put("t", "").put("ts", System.currentTimeMillis()))
            for (i in 0 until old.length()) na.put(old.get(i))
            saveNotes(na)
            notesShowEditor(0)
        })
        val arr = loadNotes()
        val list = LinearLayout(this)
        list.orientation = LinearLayout.VERTICAL
        if (arr.length() == 0) list.addView(note("Belum ada catatan."))
        val fmt = SimpleDateFormat("d MMM HH:mm", Locale.getDefault())
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            val raw = o.optString("t", "").trim()
            val preview = if (raw.isEmpty()) "(kosong)" else raw.lines().first().take(42)
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER_VERTICAL
            row.setPadding(dp(12), dp(10), dp(6), dp(10))
            row.background = ChamferDrawable(0xFF262B3D.toInt(), 0xFF171A26.toInt(), 0xFF3A4057.toInt(), dp(8).toFloat(), dens(), false)
            row.setOnClickListener { notesShowEditor(i) }
            val col = LinearLayout(this)
            col.orientation = LinearLayout.VERTICAL
            val pv = TextView(this)
            pv.text = preview
            pv.setTextColor(textColor)
            pv.textSize = 13f
            pv.maxLines = 1
            col.addView(pv)
            val dt = TextView(this)
            dt.text = fmt.format(Date(o.optLong("ts", 0L)))
            dt.setTextColor(gray)
            dt.textSize = 10f
            col.addView(dt)
            row.addView(col, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            val del = IconView(this, Icons.TRASH, cRed)
            del.setPadding(dp(5), dp(5), dp(5), dp(5))
            del.setOnClickListener {
                val a2 = loadNotes()
                a2.remove(i)
                saveNotes(a2)
                notesShowList()
            }
            row.addView(del, LinearLayout.LayoutParams(dp(30), dp(30)))
            val rlp = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
            )
            rlp.setMargins(0, dp(4), 0, dp(4))
            list.addView(row, rlp)
        }
        val sv = ScrollView(this)
        sv.addView(list)
        body.addView(sv, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(240)))
    }

    private fun notesShowEditor(idx: Int) {
        val body = notesBody ?: return
        body.removeAllViews()
        notesTitle?.text = "EDIT CATATAN"
        val arr = loadNotes()
        val o = arr.optJSONObject(idx)
        if (o == null) { notesShowList(); return }
        val et = EditText(this)
        et.setText(o.optString("t", ""))
        et.hint = "Tulis di sini..."
        et.setHintTextColor(0xFF7A8099.toInt())
        et.setTextColor(textColor)
        et.textSize = 14f
        et.gravity = Gravity.TOP or Gravity.START
        et.minLines = 8
        et.maxLines = 12
        et.setPadding(dp(12), dp(10), dp(12), dp(10))
        et.background = ChamferDrawable(0xFF1E2233.toInt(), 0xFF171A26.toInt(), 0xFF3A4057.toInt(), dp(8).toFloat(), dens(), false)
        et.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) {
                o.put("t", s?.toString() ?: "")
                o.put("ts", System.currentTimeMillis())
                saveNotes(arr)
            }
        })
        body.addView(et, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
        ))
        val actions = LinearLayout(this)
        actions.orientation = LinearLayout.HORIZONTAL
        actions.addView(pill("Kembali") { notesShowList() }, cell())
        actions.addView(pill("Salin") {
            copyText("catatan", et.text.toString())
            toast("Catatan disalin")
        }, cell())
        body.addView(actions)
        et.requestFocus()
    }

    // ================= stopwatch =================

    private fun swElapsed(): Long =
        swAcc + (if (swRunning) SystemClock.elapsedRealtime() - swBase else 0L)

    private fun swFmt(ms: Long): String =
        String.format(Locale.US, "%02d:%02d.%02d", ms / 60000, (ms / 1000) % 60, (ms / 10) % 100)

    private val swTick = object : Runnable {
        override fun run() {
            val t = swText ?: return
            t.text = swFmt(swElapsed())
            if (swRunning) main.postDelayed(this, 50)
        }
    }

    private fun toggleStopwatch() {
        if (swWin != null) {
            swRunning = false
            main.removeCallbacks(swTick)
            closeView(swWin)
            swWin = null
            swText = null
            return
        }
        swAcc = 0L
        swRunning = false
        val hd = windowHeader("STOPWATCH") { toggleStopwatch() }
        val header = hd.first
        val time = TextView(this)
        time.text = "00:00.00"
        time.textSize = 34f
        time.typeface = Typeface.DEFAULT_BOLD
        time.setTextColor(textColor)
        time.gravity = Gravity.CENTER
        time.setPadding(0, dp(8), 0, dp(10))
        swText = time

        val startBtn = pill("Mulai", true) { }
        startBtn.setOnClickListener {
            if (swRunning) {
                swAcc = swElapsed()
                swRunning = false
                startBtn.text = "Lanjut"
            } else {
                swBase = SystemClock.elapsedRealtime()
                swRunning = true
                startBtn.text = "Jeda"
                main.post(swTick)
            }
        }
        val resetBtn = pill("Reset") {
            swAcc = 0L
            swBase = SystemClock.elapsedRealtime()
            time.text = swFmt(0L)
        }
        val actions = LinearLayout(this)
        actions.orientation = LinearLayout.HORIZONTAL
        actions.addView(startBtn, cell())
        actions.addView(resetBtn, cell())

        val inner = windowColumn()
        inner.addView(header)
        inner.addView(time)
        inner.addView(actions)
        swWin = openWindow(inner, header, dp(240), wrap, false, dp(40), dp(150))
    }

    // ================= kalkulator =================

    private fun toggleCalc() {
        if (calc != null) {
            closeView(calc)
            calc = null
            return
        }
        var acc = 0.0
        var op = ' '
        var cur = "0"
        var fresh = true

        val display = TextView(this)
        display.text = "0"
        display.textSize = 28f
        display.typeface = Typeface.DEFAULT_BOLD
        display.setTextColor(textColor)
        display.gravity = Gravity.END
        display.maxLines = 1
        display.setPadding(dp(8), dp(6), dp(12), dp(10))

        fun fmt(d: Double): String {
            if (d.isNaN()) return "NaN"
            val s = d.toString()
            return if (s.endsWith(".0")) s.dropLast(2) else s
        }

        fun calcResult(): Double {
            val b = cur.toDoubleOrNull() ?: 0.0
            return when (op) {
                '+' -> acc + b
                '-' -> acc - b
                '×' -> acc * b
                '÷' -> if (b == 0.0) Double.NaN else acc / b
                else -> b
            }
        }

        fun press(k: String) {
            val c = k[0]
            if (c.isDigit()) {
                if (fresh || cur == "NaN") { cur = k; fresh = false }
                else cur = if (cur == "0") k else cur + k
            } else when (k) {
                "." -> {
                    if (fresh || cur == "NaN") { cur = "0."; fresh = false }
                    else if (!cur.contains(".")) cur += "."
                }
                "C" -> { acc = 0.0; op = ' '; cur = "0"; fresh = true }
                "⌫" -> {
                    cur = if (cur.length > 1 && cur != "NaN") cur.dropLast(1) else "0"
                    if (cur == "-") cur = "0"
                }
                "%" -> cur = fmt((cur.toDoubleOrNull() ?: 0.0) / 100)
                "=" -> if (op != ' ') {
                    acc = calcResult()
                    cur = fmt(acc)
                    op = ' '
                    fresh = true
                }
                else -> {
                    if (!fresh) { acc = calcResult(); cur = fmt(acc) }
                    op = c
                    fresh = true
                }
            }
            display.text = if (cur == "NaN") "Error" else cur
        }

        fun key(label: String, isOp: Boolean): TextView {
            val kv = TextView(this)
            kv.text = label
            kv.textSize = 18f
            kv.typeface = Typeface.DEFAULT_BOLD
            kv.gravity = Gravity.CENTER
            kv.setTextColor(textColor)
            kv.setPadding(0, dp(12), 0, dp(12))
            kv.background = if (isOp)
                ChamferDrawable(accent, accent2, 0xFFFFFFFF.toInt(), dp(7).toFloat(), dens(), false)
            else
                ChamferDrawable(0xFF262B3D.toInt(), 0xFF171A26.toInt(), 0xFF3A4057.toInt(), dp(7).toFloat(), dens(), false)
            kv.setOnTouchListener { v, e ->
                when (e.actionMasked) {
                    MotionEvent.ACTION_DOWN ->
                        v.animate().scaleX(0.92f).scaleY(0.92f).setDuration(60).start()
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL ->
                        v.animate().scaleX(1f).scaleY(1f).setDuration(100).start()
                }
                false
            }
            kv.setOnClickListener { press(label) }
            return kv
        }

        val hd = windowHeader("KALKULATOR") { closeView(calc); calc = null }
        val header = hd.first
        val inner = windowColumn()
        inner.addView(header)
        inner.addView(display)

        val rows = listOf(
            listOf("C" to 1f, "⌫" to 1f, "%" to 1f, "÷" to 1f),
            listOf("7" to 1f, "8" to 1f, "9" to 1f, "×" to 1f),
            listOf("4" to 1f, "5" to 1f, "6" to 1f, "-" to 1f),
            listOf("1" to 1f, "2" to 1f, "3" to 1f, "+" to 1f),
            listOf("0" to 2f, "." to 1f, "=" to 1f)
        )
        val ops = listOf("÷", "×", "-", "+", "=")
        for (r in rows) {
            val rowView = LinearLayout(this)
            rowView.orientation = LinearLayout.HORIZONTAL
            for ((label, w) in r) {
                val lpk = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, w)
                lpk.setMargins(dp(3), dp(3), dp(3), dp(3))
                rowView.addView(key(label, label in ops), lpk)
            }
            inner.addView(rowView)
        }
        calc = openWindow(inner, header, dp(250), wrap, false, dp(30), dp(120))
    }

    // ================= browser =================

    private fun toggleBrowser() {
        if (browser != null) {
            closeBrowser()
            return
        }
        val hd = windowHeader("BROWSER") { closeBrowser() }
        val header = hd.first
        val inner = windowColumn()

        val urlBox = EditText(this)
        urlBox.hint = "Cari atau ketik alamat"
        urlBox.setHintTextColor(0xFF7A8099.toInt())
        urlBox.setTextColor(textColor)
        urlBox.textSize = 13f
        urlBox.isSingleLine = true
        urlBox.imeOptions = EditorInfo.IME_ACTION_GO

        val wv = WebView(this)
        wv.settings.javaScriptEnabled = true
        wv.webViewClient = WebViewClient()
        wv.loadUrl("https://www.google.com")
        web = wv

        urlBox.setOnEditorActionListener { v, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_GO) {
                var u = v.text.toString().trim()
                if (!u.startsWith("http")) {
                    u = if (u.contains(".") && !u.contains(" ")) "https://$u"
                    else "https://www.google.com/search?q=" + Uri.encode(u)
                }
                wv.loadUrl(u)
                true
            } else false
        }

        inner.addView(header)
        inner.addView(urlBox)
        inner.addView(wv, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))
        browser = openWindow(inner, header, dp(300), dp(400), true, dp(20), dp(80))
    }

    private fun closeBrowser() {
        web?.destroy()
        web = null
        closeView(browser)
        browser = null
    }
}
