package com.neopanel.app

import android.animation.AnimatorListenerAdapter
import android.animation.ObjectAnimator
import android.animation.ValueAnimator
import android.app.ActivityManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.BroadcastReceiver
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioAttributes
import android.media.AudioDeviceCallback
import android.media.AudioDeviceInfo
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioTrack
import android.net.TrafficStats
import android.net.Uri
import android.net.wifi.WifiManager
import android.os.BatteryManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.provider.Settings
import android.telecom.TelecomManager
import android.telephony.TelephonyManager
import android.text.Editable
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.TextUtils
import android.text.TextWatcher
import android.text.style.ForegroundColorSpan
import android.text.style.RelativeSizeSpan
import android.view.Choreographer
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.animation.DecelerateInterpolator
import android.view.inputmethod.EditorInfo
import android.text.Html
import android.webkit.CookieManager
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Space
import android.widget.TextView
import android.widget.Toast
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.util.Base64
import android.view.animation.OvershootInterpolator
import java.io.ByteArrayOutputStream
import org.json.JSONArray
import org.json.JSONObject
import java.net.InetSocketAddress
import java.net.Socket
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class OverlayService : Service() {

    private lateinit var wm: WindowManager
    private val main = Handler(Looper.getMainLooper())
    private val prefs by lazy { getSharedPreferences("vexed", MODE_PRIVATE) }

    // ---- view / jendela ----
    private var handle: View? = null
    private val handleAnims = ArrayList<ObjectAnimator>()
    private var panel: View? = null
    private var crosshair: CrossView? = null
    private var hud: View? = null
    private var hudText: TextView? = null
    private var hudGraph: GraphView? = null
    private var browser: View? = null
    private var web: WebView? = null
    private var calc: View? = null
    private var notesWin: View? = null
    private var notesBody: LinearLayout? = null
    private var notesTitle: TextView? = null
    private var swWin: View? = null
    private var swText: TextView? = null
    private var sbWin: View? = null
    private var settingsWin: View? = null
    private var awakeView: View? = null
    private var lockView: View? = null
    private var robotWin: View? = null
    private var robotView: RobotView? = null
    private var robotParams: WindowManager.LayoutParams? = null
    private var chatWin: View? = null
    private var chatList: LinearLayout? = null
    private var chatScroll: ScrollView? = null
    private var bubbleWin: View? = null
    private var clockWin: View? = null
    private var launcherWin: View? = null
    private var voiceWin: View? = null
    private val voice = VoiceEngine()
    private var trWin: View? = null
    private var trOut: TextView? = null
    private var scanWin: View? = null
    private var bubbleParams: WindowManager.LayoutParams? = null
    private var bubbleW = 0
    private var robotStart = 0L
    private var lastRest = 0L
    private var gameMode = false
    private var tubeWin: View? = null
    private var tubeWeb: WebView? = null
    private var tubeFull: View? = null
    private var tubeCb: WebChromeClient.CustomViewCallback? = null
    private var radialWin: View? = null
    private var profWin: View? = null
    private var sessionStart = 0L
    private var sessionName = ""
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var stt: SpeechRecognizer? = null
    private var listening = false
    private var musicWin: View? = null
    private var musicListView: LinearLayout? = null
    private var ytWin: View? = null
    private var ytWeb: WebView? = null
    private var ytTitle: TextView? = null
    private val ytList = ArrayList<YtItem>()
    private var ytIdx = -1
    private var ytPaused = false
    @Volatile private var sbVol = 1f
    private var crossWin: View? = null
    private var crossPreview: CrossView? = null
    private var crossParams: WindowManager.LayoutParams? = null
    private var panelHolder: ScrollView? = null
    private var panelParams: WindowManager.LayoutParams? = null
    private var closingPanel: View? = null
    private var panelClosedAt = 0L
    private var gamePkg: String? = null
    private var lastTickMs = 0L
    private val hudFmt = SimpleDateFormat("HH:mm:ss", Locale.getDefault())
    @Volatile private var fpsProc: Process? = null
    @Volatile private var streamLayer: String? = null
    @Volatile private var zeroRuns = 0
    @Volatile private var fpsPkg: String? = null
    @Volatile private var fpsNote = ""
    private var fpsReader: Thread? = null

    // ---- state ----
    private var selectedTab = 0
    private var hudDetail = false
    private var boostOn = false
    private var recording = false
    private var recStart = 0L
    private var callBlock = false
    private var callRegistered = false
    private var headsetOnly = false
    private var devCb: AudioDeviceCallback? = null
    private var savedRing = -1
    private var savedNotif = -1
    private var lowLat: WifiManager.WifiLock? = null
    private var torchOn = false
    private var swRunning = false
    private var swBase = 0L
    private var swAcc = 0L

    @Volatile private var running = false
    @Volatile private var ping = -1L
    @Volatile private var loss = 0
    @Volatile private var jitter = 0
    @Volatile private var realFps = -1
    @Volatile private var cpuPct = -1
    @Volatile private var gpuPct = -1
    @Volatile private var tempC = -1
    private var prevTotal = 0L
    private var prevIdle = 0L
    private var rxPrev = -1L
    private var txPrev = -1L
    private var rxKb = 0L
    private var txKb = 0L
    private var frames = 0
    private var uiFps = 0
    private var useChoreo = false
    private var choreoActive = false
    private var pingThread: Thread? = null
    private var samplerThread: Thread? = null

    // ---- tema ----
    private val themes = listOf(
        0xFFFF2D55.toInt() to 0xFFFF7A18.toInt(),
        0xFF7C5CFF.toInt() to 0xFF00E5FF.toInt(),
        0xFF00E676.toInt() to 0xFF00E5FF.toInt(),
        0xFF00B0FF.toInt() to 0xFF7C5CFF.toInt(),
        0xFFFFC107.toInt() to 0xFFFF5252.toInt(),
        0xFFFF5A1F.toInt() to 0xFFFFA23A.toInt()
    )
    private var accent = 0xFFFF2D55.toInt()
    private var accent2 = 0xFFFF7A18.toInt()
    private val textColor = 0xFFE8EAF6.toInt()
    private val gray = 0xFF9AA0B5.toInt()
    private val cGreen = 0xFF3DFF9A.toInt()
    private val cYellow = 0xFFFFD43B.toInt()
    private val cRed = 0xFFFF5470.toInt()
    private val darkTop = 0xF2181B28.toInt()
    private val darkBottom = 0xF20D0F17.toInt()
    private val xhColors = intArrayOf(
        0xFF00FF88.toInt(), 0xFFFF3B5C.toInt(), 0xFF00E5FF.toInt(),
        0xFFFFE600.toInt(), 0xFFFFFFFF.toInt()
    )

    private val fNoFocus = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
    private val fNoTouch = WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
    private val fLimits = WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
    private val fModal = WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
    private val fOutside = WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH
    private val fHw = WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED
    private val fKeepOn = WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON
    private val wrap = WindowManager.LayoutParams.WRAP_CONTENT

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val pkg = intent?.getStringExtra("launch_pkg")
        if (!pkg.isNullOrEmpty()) main.post { launchByPkg(pkg) }
        return START_STICKY
    }

    private fun launchByPkg(pkg: String) {
        val pm = packageManager
        if (pm.getLaunchIntentForPackage(pkg) == null) { toast("Tidak bisa membuka aplikasi ini"); return }
        val label = try { pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString() } catch (e: Exception) { pkg }
        val icon = try { pm.getApplicationIcon(pkg) } catch (e: Exception) { null }
        launchApp(AppItem(pkg, label, icon, true))
    }

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        Ai.migrate(prefs)
        if (!prefs.getBoolean("flame_v6", false)) prefs.edit().putInt("theme", 5).putBoolean("flame_v6", true).apply()
        initTts()
        val th = themes[prefs.getInt("theme", 0).coerceIn(0, themes.size - 1)]
        accent = th.first
        accent2 = th.second
        startForeground(1, buildNotification())
        addHandle()
        main.postDelayed(companionTick, 30000)
    }

    override fun onDestroy() {
        running = false
        swRunning = false
        recording = false
        main.removeCallbacks(tick)
        main.removeCallbacks(swTick)
        main.removeCallbacks(clockTick)
        main.removeCallbacks(companionTick)
        main.removeCallbacks(idleTick)
        main.removeCallbacks(bubbleHide)
        stopStream()
        voice.stop()
        try { ytWeb?.destroy() } catch (e: Exception) { }
        try { tts?.shutdown(); stt?.destroy() } catch (e: Exception) { }
        try { tubeWeb?.destroy() } catch (e: Exception) { }
        handleAnims.forEach { it.cancel() }
        closePanel(false)
        closeBrowser()
        for (v in listOf(calc, notesWin, swWin, sbWin, settingsWin, awakeView, lockView, crosshair, hud, handle,
            robotWin, chatWin, bubbleWin, clockWin, launcherWin, crossWin, voiceWin, scanWin, trWin, musicWin, ytWin, tubeWin, tubeFull, radialWin, profWin, islandWin, closingPanel)) {
            safeRemove(v)
        }
        if (callRegistered) {
            try { unregisterReceiver(callReceiver) } catch (e: Exception) { }
        }
        val cb = devCb
        if (cb != null) {
            try { getSystemService(AudioManager::class.java).unregisterAudioDeviceCallback(cb) } catch (e: Exception) { }
        }
        headsetOnly = false
        applyHeadset()
        try { lowLat?.release() } catch (e: Exception) { }
        Thread { Sh.run("pkill -2 screenrecord 2>/dev/null") }.start()
        super.onDestroy()
    }

    // ================= util =================

    private fun dens() = resources.displayMetrics.density
    private fun dp(v: Int) = (v * dens()).toInt()
    private fun screenW() = resources.displayMetrics.widthPixels
    private fun screenH() = resources.displayMetrics.heightPixels

    private fun lp(w: Int, h: Int, flags: Int) = WindowManager.LayoutParams(
        w, h, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
        flags or fHw, PixelFormat.TRANSLUCENT
    )

    /**
     * Liquid Glass: buramkan apa yang ada di BELAKANG jendela ini (Android 12+ saja).
     * Dipakai hanya untuk jendela panel/dialog (bukan HUD, robot, jam, atau crosshair),
     * supaya elemen kecil yang menempel di layar game tetap tajam.
     */
    private fun glassify(p: WindowManager.LayoutParams) {
        if (Build.VERSION.SDK_INT >= 31 && prefs.getBoolean("glass_blur", true)) {
            p.flags = p.flags or WindowManager.LayoutParams.FLAG_BLUR_BEHIND
            p.blurBehindRadius = dp(28)
        }
    }

    private fun safeRemove(v: View?) {
        if (v == null) return
        try { wm.removeView(v) } catch (e: Exception) { }
    }

    private fun closeView(v: View?) {
        if (v == null) return
        v.animate().alpha(0f).scaleX(0.92f).scaleY(0.92f).setDuration(130)
            .withEndAction { safeRemove(v) }.start()
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    private fun copyText(label: String, text: String) {
        getSystemService(ClipboardManager::class.java)
            .setPrimaryClip(ClipData.newPlainText(label, text))
    }

    private fun stamp() = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())

    private fun buildNotification(): Notification {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("vexed", "VeXed", NotificationManager.IMPORTANCE_MIN)
        )
        return Notification.Builder(this, "vexed")
            .setContentTitle("VeXed aktif")
            .setSmallIcon(android.R.drawable.ic_menu_manage)
            .build()
    }

    private fun SpannableStringBuilder.addSpan(t: String, color: Int, rel: Float = 1f) {
        val s = length
        append(t)
        setSpan(ForegroundColorSpan(color), s, length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        if (rel != 1f) setSpan(RelativeSizeSpan(rel), s, length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
    }

    private fun putSetting(ns: String, key: String, value: String): Boolean {
        if (Sh.ready()) {
            Sh.run("settings put $ns $key $value")
            return true
        }
        return try {
            when (ns) {
                "global" -> Settings.Global.putString(contentResolver, key, value)
                "secure" -> Settings.Secure.putString(contentResolver, key, value)
                else -> Settings.System.putString(contentResolver, key, value)
            }
        } catch (e: Exception) {
            false
        }
    }

    private fun sharpFrame(content: View, cut: Int = 14): FrameLayout {
        val f = FrameLayout(this)
        f.setPadding(dp(5), dp(5), dp(5), dp(5))
        f.background = GlassDrawable(accent, accent2, dp(cut).toFloat(), dens())
        f.addView(content)
        return f
    }

    private fun pill(label: String, primary: Boolean = false, onClick: () -> Unit): TextView {
        val t = TextView(this)
        t.text = label
        t.textSize = 12f
        t.typeface = Typeface.DEFAULT_BOLD
        t.setTextColor(textColor)
        t.gravity = Gravity.CENTER
        t.setPadding(dp(14), dp(10), dp(14), dp(10))
        t.background = if (primary)
            ChamferDrawable(accent, accent2, 0xFFFFFFFF.toInt(), dp(8).toFloat(), dens(), false)
        else
            ChamferDrawable(0xFF262B3D.toInt(), 0xFF171A26.toInt(), 0xFF3A4057.toInt(), dp(8).toFloat(), dens(), false)
        t.setOnClickListener { onClick() }
        return t
    }

    private fun windowHeader(title: String, onClose: () -> Unit): Pair<LinearLayout, TextView> {
        val h = LinearLayout(this)
        h.orientation = LinearLayout.HORIZONTAL
        h.gravity = Gravity.CENTER_VERTICAL
        h.setPadding(dp(6), dp(2), dp(2), dp(8))
        h.addView(LogoView(this, textColor, accent), LinearLayout.LayoutParams(dp(16), dp(16)))
        val tv = TextView(this)
        tv.text = title
        tv.textSize = 12f
        tv.typeface = Typeface.DEFAULT_BOLD
        tv.letterSpacing = 0.08f
        tv.setTextColor(textColor)
        tv.setPadding(dp(8), 0, 0, 0)
        h.addView(tv, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        val close = IconView(this, Icons.CLOSE, textColor)
        close.setPadding(dp(5), dp(5), dp(5), dp(5))
        close.setOnClickListener { onClose() }
        h.addView(close, LinearLayout.LayoutParams(dp(28), dp(28)))
        return Pair(h, tv)
    }

    private fun windowColumn(): LinearLayout {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        c.setPadding(dp(10), dp(10), dp(10), dp(10))
        return c
    }

    private fun openWindow(
        inner: View, header: View, w: Int, h: Int, focusable: Boolean, x: Int, y: Int
    ): View {
        val root: FrameLayout = sharpFrame(inner)
        val flags = if (focusable) (fModal or fLimits) else (fNoFocus or fLimits)
        val p = lp(w, h, flags)
        glassify(p)
        p.gravity = Gravity.TOP or Gravity.START
        p.x = x
        p.y = y
        if (focusable) p.softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN
        makeDraggable(header, root, p)
        addGrip(root, p)
        root.alpha = 0f
        root.scaleX = 0.92f
        root.scaleY = 0.92f
        wm.addView(root, p)
        root.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(220)
            .setInterpolator(DecelerateInterpolator()).start()
        return root
    }

    /** Sistem resize: tarik sudut kanan-bawah untuk mengubah ukuran jendela. */
    private fun addGrip(root: FrameLayout, p: WindowManager.LayoutParams) {
        val grip = GripView(this, accent2)
        var sx = 0f
        var sy = 0f
        var w0 = 0
        var h0 = 0
        grip.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; w0 = root.width; h0 = root.height }
                MotionEvent.ACTION_MOVE -> {
                    p.width = (w0 + (e.rawX - sx)).toInt().coerceIn(dp(170), maxOf(dp(170), screenW()))
                    p.height = (h0 + (e.rawY - sy)).toInt().coerceIn(dp(110), maxOf(dp(110), screenH()))
                    try { wm.updateViewLayout(root, p) } catch (ex: Exception) { }
                }
            }
            true
        }
        root.addView(grip, FrameLayout.LayoutParams(dp(26), dp(26), Gravity.BOTTOM or Gravity.END))
    }

    private fun makeDraggable(dragView: View, window: View, p: WindowManager.LayoutParams) {
        makeDraggableTap(dragView, window, p) { }
    }

    private fun makeDraggableTap(
        dragView: View, window: View, p: WindowManager.LayoutParams,
        onEnd: (() -> Unit)? = null, onMove: (() -> Unit)? = null,
        onLong: (() -> Unit)? = null, onTap: () -> Unit
    ) {
        var sx = 0f
        var sy = 0f
        var ox = 0
        var oy = 0
        var moved = false
        var longDone = false
        val longRun = Runnable {
            if (!moved) {
                longDone = true
                onLong?.invoke()
            }
        }
        dragView.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    sx = e.rawX; sy = e.rawY; ox = p.x; oy = p.y; moved = false; longDone = false
                    if (onLong != null) main.postDelayed(longRun, 520L)
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - sx
                    val dy = e.rawY - sy
                    if (!moved && (Math.abs(dx) > dp(6) || Math.abs(dy) > dp(6))) {
                        moved = true
                        main.removeCallbacks(longRun)
                    }
                    if (moved) {
                        p.x = ox + dx.toInt()
                        p.y = oy + dy.toInt()
                        try { wm.updateViewLayout(window, p) } catch (ex: Exception) { }
                        onMove?.invoke()
                    }
                }
                MotionEvent.ACTION_UP -> {
                    main.removeCallbacks(longRun)
                    if (longDone) { } else if (!moved) onTap() else onEnd?.invoke()
                }
                MotionEvent.ACTION_CANCEL -> main.removeCallbacks(longRun)
            }
            true
        }
    }

    private fun seekRow(title: String, lo: Int, hi: Int, value: Int, onChange: (Int) -> Unit): View {
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        val tv = TextView(this)
        tv.text = title
        tv.textSize = 11f
        tv.setTextColor(gray)
        tv.setPadding(dp(4), dp(8), 0, 0)
        col.addView(tv)
        val sb = SeekBar(this)
        sb.max = hi - lo
        sb.progress = (value - lo).coerceIn(0, hi - lo)
        sb.progressTintList = ColorStateList.valueOf(accent)
        sb.thumbTintList = ColorStateList.valueOf(accent2)
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                if (fromUser) onChange(p + lo)
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        col.addView(sb)
        return col
    }

    // ================= info sistem =================

    private fun battery(): Pair<Int, Int> {
        val i = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val lvl = i?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = i?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        val temp = (i?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0) / 10
        return Pair(if (lvl < 0) 0 else lvl * 100 / scale, temp)
    }

    private fun memInfo(): ActivityManager.MemoryInfo {
        val mi = ActivityManager.MemoryInfo()
        getSystemService(ActivityManager::class.java).getMemoryInfo(mi)
        return mi
    }

    private fun ramPct(): Int {
        val mi = memInfo()
        return (100 - mi.availMem * 100 / mi.totalMem).toInt()
    }

    private fun hasDump() =
        checkSelfPermission("android.permission.DUMP") == PackageManager.PERMISSION_GRANTED

    // ================= logo (tombol gestur) =================

    private fun handleSize() = dp(prefs.getInt("hsize", 48))
    private fun handleRight() = prefs.getBoolean("hright", true)

    private fun addHandle() {
        val size = handleSize()
        val v = FrameLayout(this)
        v.background = ChamferDrawable(0xFF1B1F2E.toInt(), 0xFF0E1018.toInt(), accent, dp(10).toFloat(), dens(), true)
        val mg = (size * 0.24f).toInt()
        val llp = FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT)
        llp.setMargins(mg, mg, mg, mg)
        v.addView(LogoView(this, textColor, accent), llp)
        v.alpha = prefs.getInt("halpha", 90) / 100f

        val p = lp(size, size, fNoFocus or fLimits)
        p.gravity = Gravity.TOP or Gravity.START
        p.x = if (handleRight()) screenW() - size else 0
        p.y = (prefs.getFloat("hy", 0.45f) * screenH()).toInt().coerceIn(0, screenH() - size)

        var sx = 0f
        var sy = 0f
        var ox = 0
        var oy = 0
        var dragging = false
        v.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    sx = e.rawX; sy = e.rawY; ox = p.x; oy = p.y; dragging = false
                    v.animate().alpha(1f).setDuration(120).start()
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - sx
                    val dy = e.rawY - sy
                    if (!dragging && (Math.abs(dx) > dp(8) || Math.abs(dy) > dp(8))) dragging = true
                    if (dragging) {
                        p.x = (ox + dx).toInt().coerceIn(0, screenW() - size)
                        p.y = (oy + dy).toInt().coerceIn(0, screenH() - size)
                        try { wm.updateViewLayout(v, p) } catch (ex: Exception) { }
                    }
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    v.animate().alpha(prefs.getInt("halpha", 90) / 100f).setDuration(300).start()
                    if (dragging) {
                        snapHandle(v, p, size)
                    } else if (e.actionMasked == MotionEvent.ACTION_UP) {
                        if (panel != null) {
                            closePanel()
                        } else if (SystemClock.uptimeMillis() - panelClosedAt > 350L) {
                            showPanel()
                        }
                    }
                }
            }
            true
        }
        wm.addView(v, p)
        handle = v
    }

    private fun snapHandle(v: View, p: WindowManager.LayoutParams, size: Int) {
        val right = p.x + size / 2 > screenW() / 2
        val target = if (right) screenW() - size else 0
        prefs.edit().putBoolean("hright", right)
            .putFloat("hy", p.y.toFloat() / screenH()).apply()
        ValueAnimator.ofInt(p.x, target).apply {
            duration = 180
            addUpdateListener {
                p.x = it.animatedValue as Int
                try { wm.updateViewLayout(v, p) } catch (e: Exception) { }
            }
            start()
        }
    }

    private fun rebuildHandle() {
        handleAnims.forEach { it.cancel() }
        handleAnims.clear()
        safeRemove(handle)
        handle = null
        addHandle()
    }

    // ================= panel utama (tab) =================

    private fun tile(
        icon: Int, label: String, active: Boolean,
        onLong: (() -> Unit)? = null, onClick: () -> Unit
    ): LinearLayout {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.gravity = Gravity.CENTER
        box.minimumHeight = dp(76)
        box.setPadding(dp(4), dp(10), dp(4), dp(8))
        box.background = if (active)
            ChamferDrawable(accent, accent2, 0xFFFFFFFF.toInt(), dp(9).toFloat(), dens(), true)
        else
            ChamferDrawable(0xFF262B3D.toInt(), 0xFF171A26.toInt(), 0xFF3A4057.toInt(), dp(9).toFloat(), dens(), false)
        val ic = IconView(this, icon, if (active) 0xFFFFFFFF.toInt() else accent2)
        box.addView(ic, LinearLayout.LayoutParams(dp(24), dp(24)))
        val tv = TextView(this)
        tv.text = label
        tv.textSize = 10f
        tv.typeface = Typeface.DEFAULT_BOLD
        tv.gravity = Gravity.CENTER
        tv.maxLines = 2
        tv.setTextColor(textColor)
        tv.setPadding(0, dp(5), 0, 0)
        box.addView(tv)
        box.setOnTouchListener { v, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN ->
                    v.animate().scaleX(0.93f).scaleY(0.93f).setDuration(80).start()
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL ->
                    v.animate().scaleX(1f).scaleY(1f).setDuration(120).start()
            }
            false
        }
        box.setOnClickListener { onClick() }
        if (onLong != null) box.setOnLongClickListener { onLong(); true }
        return box
    }

    private fun cell() = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        .apply { setMargins(dp(4), dp(4), dp(4), dp(4)) }

    private fun grid(vararg tiles: View): LinearLayout {
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        var i = 0
        while (i < tiles.size) {
            val r = LinearLayout(this)
            r.orientation = LinearLayout.HORIZONTAL
            for (k in 0 until 3) {
                val v: View = if (i + k < tiles.size) tiles[i + k] else Space(this)
                r.addView(v, cell())
            }
            col.addView(r)
            i += 3
        }
        return col
    }

    private fun note(text: String): TextView {
        val t = TextView(this)
        t.text = text
        t.textSize = 10f
        t.setTextColor(gray)
        t.setPadding(dp(6), dp(8), dp(6), dp(2))
        return t
    }

    private fun refreshPanel() {
        val holder = panelHolder ?: return
        holder.removeAllViews()
        holder.addView(buildPanelBody())
        fitPanel()
        holder.alpha = 0.5f
        holder.animate().alpha(1f).setDuration(140).start()
    }

    private fun measurePanelHeight(body: View): Int {
        val w = dp(318) - dp(8)
        body.measure(
            View.MeasureSpec.makeMeasureSpec(w, View.MeasureSpec.EXACTLY),
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
        )
        return minOf(body.measuredHeight + dp(8), screenH() - dp(24))
    }

    private fun fitPanel() {
        val root = panel ?: return
        val p = panelParams ?: return
        val body = panelHolder?.getChildAt(0) ?: return
        val h = measurePanelHeight(body)
        if (p.height != h) {
            p.height = h
            try { wm.updateViewLayout(root, p) } catch (e: Exception) { }
        }
    }

    private val tabNames = arrayOf("GAME", "PERFORMA", "NOTIF", "REKAM", "JARINGAN", "SENTUH", "ALAT", "BOOSTER")

    private fun fillTab(content: LinearLayout) {
        content.removeAllViews()
        when (selectedTab) {
            0 -> {
                content.addView(grid(
                    tile(Icons.GAME, "Game Launcher", launcherWin != null) { closePanel(); toggleLauncher() },
                    tile(Icons.ROBOT, "Asisten AI", robotWin != null) { closePanel(); toggleRobot() },
                    tile(Icons.CLOCK, "Jam Digital", clockWin != null) { closePanel(); toggleClock() },
                    tile(Icons.CROSSHAIR, "Crosshair", crosshair != null, onLong = { closePanel(); toggleCrossSettings() }) {
                        closePanel(); toggleCrosshair()
                    },
                    tile(Icons.GEAR, "Atur Crosshair", crossWin != null) { closePanel(); toggleCrossSettings() },
                    tile(Icons.CHART, "FPS HUD", hud != null) { closePanel(); toggleHud() },
                    tile(Icons.MIC, "Voice Changer", voice.running) { closePanel(); toggleVoice() },
                    tile(Icons.GLOBE, "Penerjemah", trWin != null) { closePanel(); toggleTranslator() },
                    tile(Icons.ROCKET, "Mode Game", gameMode) { closePanel(); toggleGameMode() },
                    tile(Icons.PLAY, "YouTube", tubeWin != null) { closePanel(); toggleYouTube() }
                ))
                content.addView(note("Ketuk robot untuk bertanya atau minta tolong. Tahan Crosshair untuk mengaturnya."))
            }
            1 -> content.addView(grid(
                tile(Icons.ROCKET, "Boost", boostOn) { closePanel(); toggleBoost() },
                tile(Icons.CHART, "FPS HUD", hud != null) { closePanel(); toggleHud() },
                tile(Icons.CPU, "Monitor", hud != null && hudDetail) { closePanel(); toggleMonitor() },
                tile(Icons.MEM, "Bersihkan RAM", false) { closePanel(); cleanRam() },
                tile(Icons.SUN, "Layar Aktif", awakeView != null) { closePanel(); toggleAwake() },
                tile(Icons.CROSSHAIR, "Crosshair", crosshair != null, onLong = { closePanel(); toggleCrossSettings() }) {
                    closePanel(); toggleCrosshair()
                }
            ))
            2 -> {
                content.addView(grid(
                    tile(Icons.DND, "Jangan Ganggu", dndOn()) { closePanel(); toggleDnd() },
                    tile(Icons.BELLOFF, "Blokir Pop-up", headsUpOff()) { closePanel(); togglePopup() },
                    tile(Icons.PHONEOFF, "Tolak Panggilan", callBlock) { closePanel(); toggleCallBlock() },
                    tile(Icons.HEADSET, "Headset Only", headsetOnly) { closePanel(); toggleHeadset() },
                    tile(Icons.LOCK, "Kunci Sentuh", lockView != null) { closePanel(); toggleLock() }
                ))
                content.addView(note("Tolak Panggilan menolak semua panggilan masuk (belum ada daftar VIP)."))
            }
            3 -> {
                content.addView(grid(
                    tile(Icons.REC, "Rekam ${recLabel()}", recording, onLong = { cycleBitrate() }) {
                        closePanel(); toggleRecord()
                    },
                    tile(Icons.SHOT, "Screenshot", false) { closePanel(); takeShot() },
                    tile(Icons.SPEAKER, "Soundboard", sbWin != null) { closePanel(); toggleSoundboard() }
                ))
                val am = getSystemService(AudioManager::class.java)
                content.addView(seekRow(
                    "Volume media", 0, am.getStreamMaxVolume(AudioManager.STREAM_MUSIC),
                    am.getStreamVolume(AudioManager.STREAM_MUSIC)
                ) { am.setStreamVolume(AudioManager.STREAM_MUSIC, it, 0) })
                content.addView(note("Tahan Rekam untuk ganti bitrate. Rekaman tanpa suara."))
            }
            4 -> {
                content.addView(grid(
                    tile(Icons.CHART, "Monitor Jaringan", hud != null && hudDetail) { closePanel(); toggleMonitor() },
                    tile(Icons.SHIELD, "DNS Cepat", dnsFast()) { closePanel(); toggleDns() },
                    tile(Icons.WIFI, "Wi-Fi", wifiOn()) { closePanel(); toggleWifi() },
                    tile(Icons.DATA, "Data Seluler", dataOn()) { closePanel(); toggleData() },
                    tile(Icons.BOLT, "Low Latency", lowLat?.isHeld == true) { closePanel(); toggleLowLat() }
                ))
                content.addView(note("DNS Cepat memakai Cloudflare (1.1.1.1). Ping asli game tidak bisa dipercepat."))
            }
            5 -> {
                val names = arrayOf("Normal", "Cepat", "Maks")
                content.addView(grid(
                    tile(Icons.TOUCH, "Respons ${names[prefs.getInt("touch", 0).coerceIn(0, 2)]}", prefs.getInt("touch", 0) > 0) {
                        cycleTouch(); refreshPanel()
                    },
                    tile(Icons.ANIM, "Animasi Cepat", animFast()) { toggleAnim(); refreshPanel() },
                    tile(Icons.SAT, "Warna ${satLabel()}", prefs.getInt("sat", 0) > 0) { cycleSat(); refreshPanel() }
                ))
                content.addView(note("Polling rate sentuh tidak bisa diubah tanpa root. Respons mengatur jeda tekan-tahan."))
            }
            7 -> {
                content.addView(grid(
                    tile(Icons.ROCKET, "Mode Game", gameMode) { closePanel(); toggleGameMode() },
                    tile(Icons.ROCKET, "Boost", boostOn) { closePanel(); toggleBoost() },
                    tile(Icons.MEM, "Bersihkan RAM", false) { closePanel(); cleanRam() },
                    tile(Icons.MEM, "Bersihkan Cache", false) { closePanel(); trimCaches() },
                    tile(Icons.CPU, "Refresh Maks", prefs.getBoolean("refmax", false)) { toggleRefresh(); refreshPanel() },
                    tile(Icons.SUN, "Terang Maks", prefs.getBoolean("brmax", false)) { toggleBright(); refreshPanel() },
                    tile(Icons.SUN, "Layar Aktif", awakeView != null) { closePanel(); toggleAwake() }
                ))
                content.addView(note("Mode Game = Boost + Jangan Ganggu + FPS HUD. Refresh rate dan kecerahan bergantung perangkat."))
            }
            else -> content.addView(grid(
                tile(Icons.NOTE, "Catatan", notesWin != null) { closePanel(); toggleNotes() },
                tile(Icons.CALC, "Kalkulator", calc != null) { closePanel(); toggleCalc() },
                tile(Icons.TIMER, "Stopwatch", swWin != null) { closePanel(); toggleStopwatch() },
                tile(Icons.GLOBE, "Browser", browser != null) { closePanel(); toggleBrowser() },
                tile(Icons.FLASH, "Senter", torchOn) { closePanel(); toggleTorch() },
                tile(Icons.GEAR, "Pengaturan", settingsWin != null) { closePanel(); toggleSettings() }
            ))
        }
    }

    private fun buildPanelBody(): LinearLayout {
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(8), dp(8), dp(8), dp(6))

        val head = LinearLayout(this)
        head.orientation = LinearLayout.HORIZONTAL
        head.gravity = Gravity.CENTER_VERTICAL
        head.setPadding(dp(8), dp(8), dp(8), dp(8))
        head.background = ChamferDrawable(
            (accent and 0x00FFFFFF) or 0x55000000, (accent2 and 0x00FFFFFF) or 0x18000000,
            (accent and 0x00FFFFFF) or 0x99000000.toInt(), dp(10).toFloat(), dens(), false
        )
        head.addView(AvatarView(this, null, accent, accent2), LinearLayout.LayoutParams(dp(46), dp(46)))
        val titles = LinearLayout(this)
        titles.orientation = LinearLayout.VERTICAL
        val title = TextView(this)
        title.text = "VEXED"
        title.textSize = 16f
        title.typeface = Typeface.DEFAULT_BOLD
        title.letterSpacing = 0.2f
        title.setTextColor(textColor)
        titles.addView(title)
        val hello = TextView(this)
        hello.text = "${greet()}, Kak!"
        hello.textSize = 10.5f
        hello.setTextColor(gray)
        titles.addView(hello)
        val tlp = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        tlp.leftMargin = dp(10)
        head.addView(titles, tlp)
        col.addView(head)

        val bt = battery()
        val ram = ramPct()
        val chips = LinearLayout(this)
        chips.orientation = LinearLayout.HORIZONTAL
        chips.setPadding(0, dp(6), 0, 0)
        chips.addView(statChip("RAM $ram%", if (ram >= 85) cRed else if (ram >= 70) cYellow else cGreen), cell())
        chips.addView(statChip("${bt.second}°C", if (bt.second >= 43) cRed else if (bt.second >= 38) cYellow else cGreen), cell())
        chips.addView(statChip("${bt.first}%", if (bt.first <= 20) cRed else cGreen), cell())
        val last = if (sessionStart > 0L) "Main ${(SystemClock.elapsedRealtime() - sessionStart) / 60000L}m"
        else if (hud != null && realFps >= 0) "$realFps FPS" else "Siap"
        chips.addView(statChip(last, textColor), cell())
        col.addView(chips)
        val shim = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(2))
        shim.topMargin = dp(8)
        col.addView(ShimmerBar(this, accent, accent2), shim)

        val tabIcons = intArrayOf(
            Icons.GAME, Icons.ROCKET, Icons.BELLOFF, Icons.REC, Icons.WIFI, Icons.TOUCH, Icons.GEAR, Icons.BOLT
        )
        val bar = LinearLayout(this)
        bar.orientation = LinearLayout.HORIZONTAL
        bar.setPadding(0, dp(10), 0, dp(2))
        for (i in tabIcons.indices) {
            val cellV = LinearLayout(this)
            cellV.orientation = LinearLayout.VERTICAL
            cellV.gravity = Gravity.CENTER_HORIZONTAL
            cellV.addView(
                IconView(this, tabIcons[i], if (i == selectedTab) 0xFFFFFFFF.toInt() else gray),
                LinearLayout.LayoutParams(dp(24), dp(24))
            )
            cellV.setPadding(0, dp(7), 0, dp(7))
            if (i == selectedTab) {
                cellV.background = ChamferDrawable(accent, accent2, 0x00FFFFFF, dp(6).toFloat(), dens(), false)
            }
            cellV.setOnClickListener {
                if (selectedTab != i) {
                    selectedTab = i
                    refreshPanel()
                }
            }
            val clp = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            clp.setMargins(dp(2), 0, dp(2), 0)
            bar.addView(cellV, clp)
        }
        col.addView(bar)

        val tabTitle = TextView(this)
        tabTitle.text = tabNames[selectedTab.coerceIn(0, tabNames.size - 1)]
        tabTitle.textSize = 10f
        tabTitle.letterSpacing = 0.2f
        tabTitle.typeface = Typeface.DEFAULT_BOLD
        tabTitle.setTextColor(accent)
        tabTitle.setPadding(dp(6), dp(6), 0, dp(4))
        col.addView(tabTitle)

        val content = LinearLayout(this)
        content.orientation = LinearLayout.VERTICAL
        fillTab(content)
        col.addView(content)

        val exit = TextView(this)
        exit.text = "KELUAR"
        exit.textSize = 11f
        exit.letterSpacing = 0.2f
        exit.typeface = Typeface.DEFAULT_BOLD
        exit.gravity = Gravity.CENTER
        exit.setTextColor(cRed)
        exit.setPadding(0, dp(10), 0, dp(6))
        exit.setOnClickListener { stopSelf() }
        col.addView(exit)
        return col
    }

    private fun showPanel(animate: Boolean = true) {
        if (panel != null) return
        // buang sisa panel yang masih animasi tutup supaya tidak numpuk
        closingPanel?.let { it.animate().cancel(); safeRemove(it); closingPanel = null }
        val right = handleRight()

        val sv = ScrollView(this)
        sv.isVerticalScrollBarEnabled = false
        val body = buildPanelBody()
        sv.addView(body)
        panelHolder = sv
        val root = sharpFrame(sv, 16)

        val p = lp(dp(318), measurePanelHeight(body), fNoFocus or fModal or fOutside)
        glassify(p)
        p.gravity = (if (right) Gravity.END else Gravity.START) or Gravity.CENTER_VERTICAL
        p.x = dp(6)
        root.setOnTouchListener { _, e ->
            if (e.action == MotionEvent.ACTION_OUTSIDE) { closePanel(); true } else false
        }
        wm.addView(root, p)
        panel = root
        panelParams = p

        if (animate) {
            root.alpha = 0f
            root.translationX = dp(40).toFloat() * (if (right) 1 else -1)
            root.animate().alpha(1f).translationX(0f).setDuration(200)
                .setInterpolator(DecelerateInterpolator()).start()
            val tiles = ArrayList<View>()
            collectTiles(body, tiles)
            tiles.forEachIndexed { i, v ->
                v.alpha = 0f
                v.translationY = dp(10).toFloat()
                v.animate().alpha(1f).translationY(0f)
                    .setStartDelay(40L + i * 25L).setDuration(180)
                    .setInterpolator(DecelerateInterpolator()).start()
            }
        }
    }

    private fun collectTiles(v: View, out: ArrayList<View>) {
        if (v is LinearLayout && v.isClickable) { out.add(v); return }
        if (v is android.view.ViewGroup) {
            for (i in 0 until v.childCount) collectTiles(v.getChildAt(i), out)
        }
    }

    private fun closePanel(animated: Boolean = true) {
        val v = panel ?: return
        panel = null
        panelHolder = null
        panelParams = null
        panelClosedAt = SystemClock.uptimeMillis()
        v.animate().cancel()
        if (!animated) { safeRemove(v); return }
        closingPanel = v
        val dir = if (handleRight()) 1 else -1
        v.animate().alpha(0f).translationX(dp(30).toFloat() * dir).setDuration(140)
            .withEndAction {
                safeRemove(v)
                if (closingPanel === v) closingPanel = null
            }.start()
    }

    // ================= pengaturan =================

    private fun toggleSettings() {
        if (settingsWin != null) { closeView(settingsWin); settingsWin = null; return }
        val hd = windowHeader("PENGATURAN") { closeView(settingsWin); settingsWin = null }
        val header = hd.first
        val inner = windowColumn()
        inner.addView(header)

        val tt = TextView(this)
        tt.text = "Tema warna"
        tt.textSize = 11f
        tt.setTextColor(gray)
        tt.setPadding(dp(4), dp(4), 0, 0)
        inner.addView(tt)
        val themeRow = LinearLayout(this)
        themeRow.orientation = LinearLayout.HORIZONTAL
        val cur = prefs.getInt("theme", 0)
        themes.forEachIndexed { i, th ->
            val dot = LogoView(this, th.first, th.second)
            dot.background = ChamferDrawable(
                0xFF1B1F2E.toInt(), 0xFF0E1018.toInt(),
                if (cur == i) 0xFFFFFFFF.toInt() else th.first, dp(6).toFloat(), dens(), false
            )
            dot.setPadding(dp(6), dp(6), dp(6), dp(6))
            dot.setOnClickListener {
                prefs.edit().putInt("theme", i).apply()
                accent = th.first
                accent2 = th.second
                rebuildHandle()
                closeView(settingsWin)
                settingsWin = null
                toast("Tema diganti. Buka ulang jendela agar warnanya berubah.")
            }
            val lpd = LinearLayout.LayoutParams(dp(40), dp(40))
            lpd.setMargins(dp(4), dp(6), dp(4), dp(6))
            themeRow.addView(dot, lpd)
        }
        inner.addView(themeRow)

        inner.addView(seekRow("Ukuran logo", 36, 72, prefs.getInt("hsize", 48)) {
            prefs.edit().putInt("hsize", it).apply()
            rebuildHandle()
        })
        inner.addView(seekRow("Transparansi logo", 20, 100, prefs.getInt("halpha", 90)) {
            prefs.edit().putInt("halpha", it).apply()
            handle?.alpha = it / 100f
        })
        inner.addView(seekRow("Ukuran robot", 44, 130, prefs.getInt("rb_size", 76)) { v ->
            prefs.edit().putInt("rb_size", v).apply()
            val rp = robotParams
            val rv = robotWin
            if (rp != null && rv != null) {
                rp.width = dp(v)
                rp.height = dp(v)
                try { wm.updateViewLayout(rv, rp) } catch (e: Exception) { }
                placeBubble()
            }
        })
        inner.addView(label("Tampilan"))
        if (Build.VERSION.SDK_INT >= 31) {
            inner.addView(switchChip("Kaca buram (Liquid Glass)", "glass_blur", true))
        } else {
            inner.addView(note("Efek kaca buram penuh butuh Android 12 ke atas. Di HP-mu, jendela tetap tampil semi-transparan tanpa blur nyata."))
        }
        inner.addView(label("Dynamic Island"))
        val isChip = switchChip("Aktif", "island_on", true)
        isChip.setOnClickListener {
            val on = !prefs.getBoolean("island_on", true)
            prefs.edit().putBoolean("island_on", on).apply()
            toggleIslandSetting(on)
            isChip.text = if (on) "Aktif ✓" else "Aktif"
        }
        inner.addView(isChip)
        inner.addView(seekRow("Posisi dari atas", 0, 160, (prefs.getInt("island_y", dp(14)) / dens()).toInt()) { v ->
            val px = dp(v)
            prefs.edit().putInt("island_y", px).apply()
            val p = islandParams
            if (p != null) { p.y = px; try { wm.updateViewLayout(islandWin, p) } catch (e: Exception) { } }
        })
        inner.addView(note("Pil kecil di atas layar menampilkan status singkat (Boost, rekam, Mode Game, dan peringatan FPS/suhu). Ketuk untuk membuka chat Vex, atau lihat status kalau sedang aktif."))
        inner.addView(label("Gaya bicara Vex"))
        inner.addView(chipRow(listOf("Manis", "Santai", "Formal"), prefs.getInt("persona", 0), textSz = 11f) {
            prefs.edit().putInt("persona", it).apply()
        })
        inner.addView(label("Tampilan robot"))
        inner.addView(chipRow(listOf("Anime", "Klasik"), prefs.getInt("rb_skin", 1), textSz = 11f) {
            prefs.edit().putInt("rb_skin", it).apply()
            if (robotWin != null) { closeRobot(); toggleRobot() }
        })

        val hc = pill(if (prefs.getBoolean("hud_clock", true)) "Jam di HUD: aktif" else "Jam di HUD: mati") { }
        hc.setOnClickListener {
            val on = !prefs.getBoolean("hud_clock", true)
            prefs.edit().putBoolean("hud_clock", on).apply()
            hc.text = if (on) "Jam di HUD: aktif" else "Jam di HUD: mati"
            hudText?.text = hudSpan()
        }
        val hlp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        hlp.setMargins(0, dp(12), 0, 0)
        inner.addView(hc, hlp)

        val reset = pill("Reset posisi logo") {
            prefs.edit().putBoolean("hright", true).putFloat("hy", 0.45f).apply()
            rebuildHandle()
            toast("Posisi logo direset")
        }
        val rlp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        rlp.setMargins(0, dp(12), 0, dp(4))
        inner.addView(reset, rlp)

        val body = LinearLayout(this)
        body.orientation = LinearLayout.VERTICAL
        val kids = (1 until inner.childCount).map { inner.getChildAt(it) }
        for (v in kids) {
            inner.removeView(v)
            body.addView(v)
        }
        val ssv = ScrollView(this)
        ssv.isVerticalScrollBarEnabled = false
        ssv.addView(body)
        inner.addView(ssv, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))
        settingsWin = openWindow(inner, header, dp(290), minOf(dp(560), screenH() - dp(40)), false, dp(30), dp(30))
    }

    // ================= crosshair =================

    private inner class CrossView : View(this@OverlayService) {
        var shape = 1
        var color = 0xFF00FF88.toInt()
        var len = 11
        var thick = 2
        var gap = 4
        var dot = 3
        var outline = true
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG)

        override fun onDraw(canvas: Canvas) {
            val cx = width / 2f
            val cy = height / 2f
            if (outline) pass(canvas, cx, cy, 0xFF000000.toInt(), dens() * 1.6f)
            pass(canvas, cx, cy, color, 0f)
        }

        private fun pass(c: Canvas, cx: Float, cy: Float, col: Int, extra: Float) {
            paint.color = col
            paint.strokeCap = Paint.Cap.BUTT
            val th = dp(thick).toFloat() + extra
            val g = dp(gap).toFloat()
            val l = dp(len).toFloat()
            val ex = extra / 2f
            paint.strokeWidth = th
            paint.style = Paint.Style.STROKE
            when (shape) {
                0, 1 -> {
                    c.drawLine(cx - g - l - ex, cy, cx - g + ex, cy, paint)
                    c.drawLine(cx + g - ex, cy, cx + g + l + ex, cy, paint)
                    c.drawLine(cx, cy - g - l - ex, cx, cy - g + ex, paint)
                    c.drawLine(cx, cy + g - ex, cx, cy + g + l + ex, paint)
                }
                3, 4 -> c.drawCircle(cx, cy, g + l / 2f, paint)
                5 -> {
                    val k = 0.7071f
                    val a = g * k
                    val b = (g + l) * k
                    c.drawLine(cx - b, cy - b, cx - a, cy - a, paint)
                    c.drawLine(cx + a, cy + a, cx + b, cy + b, paint)
                    c.drawLine(cx + a, cy - a, cx + b, cy - b, paint)
                    c.drawLine(cx - a, cy + a, cx - b, cy + b, paint)
                }
            }
            if (shape == 1 || shape == 2 || shape == 4) {
                paint.style = Paint.Style.FILL
                c.drawCircle(cx, cy, dp(dot) / 2f + ex, paint)
            }
        }
    }

    private fun applyXh(v: CrossView) {
        v.shape = prefs.getInt("xh_shape", 1)
        v.color = prefs.getInt("xh_col", 0xFF00FF88.toInt())
        v.len = prefs.getInt("xh_len", 11)
        v.thick = prefs.getInt("xh_th", 2)
        v.gap = prefs.getInt("xh_gap", 4)
        v.dot = prefs.getInt("xh_dot", 3)
        v.outline = prefs.getBoolean("xh_out", true)
        v.alpha = prefs.getInt("xh_alpha", 100) / 100f
        v.invalidate()
    }

    private fun crossBox() =
        dp(prefs.getInt("xh_gap", 4) + prefs.getInt("xh_len", 11) + prefs.getInt("xh_th", 2) + 8) * 2

    private fun refreshCross() {
        crosshair?.let { v ->
            applyXh(v)
            val p = crossParams
            if (p != null) {
                val s = crossBox()
                p.width = s
                p.height = s
                p.x = dp(prefs.getInt("xh_ox", 0))
                p.y = dp(prefs.getInt("xh_oy", 0))
                try { wm.updateViewLayout(v, p) } catch (e: Exception) { }
            }
        }
        crossPreview?.let { applyXh(it) }
    }

    private fun toggleCrosshair() {
        if (crosshair != null) {
            safeRemove(crosshair)
            crosshair = null
            crossParams = null
            return
        }
        val v = CrossView()
        applyXh(v)
        val s = crossBox()
        val p = lp(s, s, fNoFocus or fNoTouch or fLimits)
        p.gravity = Gravity.CENTER
        p.x = dp(prefs.getInt("xh_ox", 0))
        p.y = dp(prefs.getInt("xh_oy", 0))
        wm.addView(v, p)
        crosshair = v
        crossParams = p
    }

    private fun closeCross() {
        closeView(crossWin)
        crossWin = null
        crossPreview = null
    }

    private fun chipRow(labels: List<String>, selected: Int, textSz: Float = 14f, onPick: (Int) -> Unit): LinearLayout {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        val chips = ArrayList<TextView>()
        fun style(t: TextView, on: Boolean) {
            t.background = if (on)
                ChamferDrawable(accent, accent2, 0xFFFFFFFF.toInt(), dp(6).toFloat(), dens(), false)
            else
                ChamferDrawable(0xFF262B3D.toInt(), 0xFF171A26.toInt(), 0xFF3A4057.toInt(), dp(6).toFloat(), dens(), false)
        }
        labels.forEachIndexed { i, s ->
            val t = TextView(this)
            t.text = s
            t.textSize = textSz
            t.typeface = Typeface.DEFAULT_BOLD
            t.setTextColor(textColor)
            t.gravity = Gravity.CENTER
            t.setPadding(dp(4), dp(8), dp(4), dp(8))
            style(t, i == selected)
            t.setOnClickListener {
                chips.forEachIndexed { k, c -> style(c, k == i) }
                onPick(i)
            }
            chips.add(t)
            row.addView(t, cell())
        }
        return row
    }

    private fun switchChip(label: String, key: String, def: Boolean): TextView {
        val t = TextView(this)
        t.textSize = 11f
        t.typeface = Typeface.DEFAULT_BOLD
        t.setTextColor(textColor)
        t.gravity = Gravity.CENTER
        t.setPadding(dp(4), dp(8), dp(4), dp(8))
        fun paintIt() {
            val on = prefs.getBoolean(key, def)
            t.text = if (on) "$label ✓" else label
            t.background = if (on)
                ChamferDrawable(accent, accent2, 0xFFFFFFFF.toInt(), dp(6).toFloat(), dens(), false)
            else
                ChamferDrawable(0xFF262B3D.toInt(), 0xFF171A26.toInt(), 0xFF3A4057.toInt(), dp(6).toFloat(), dens(), false)
        }
        paintIt()
        t.setOnClickListener {
            prefs.edit().putBoolean(key, !prefs.getBoolean(key, def)).apply()
            paintIt()
        }
        return t
    }

    private fun xhSeek(title: String, key: String, lo: Int, hi: Int, def: Int): View {
        var tv: TextView? = null
        val cur = prefs.getInt(key, def)
        val col = seekRow("$title: $cur", lo, hi, cur) { v ->
            prefs.edit().putInt(key, v).apply()
            tv?.text = "$title: $v"
            refreshCross()
        }
        tv = (col as LinearLayout).getChildAt(0) as TextView
        return col
    }

    private fun label(text: String): TextView {
        val t = TextView(this)
        t.text = text
        t.textSize = 11f
        t.setTextColor(gray)
        t.setPadding(dp(4), dp(10), 0, dp(2))
        return t
    }

    private fun toggleCrossSettings() {
        if (crossWin != null) { closeCross(); return }
        val hd = windowHeader("CROSSHAIR") { closeCross() }
        val header = hd.first
        val inner = windowColumn()
        inner.addView(header)

        val prev = CrossView()
        crossPreview = prev
        applyXh(prev)
        val pb = FrameLayout(this)
        pb.background = ChamferDrawable(0xFF2B3347.toInt(), 0xFF171C28.toInt(), 0xFF3A4057.toInt(), dp(8).toFloat(), dens(), false)
        pb.addView(prev, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))
        inner.addView(pb, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(96)))

        val body = LinearLayout(this)
        body.orientation = LinearLayout.VERTICAL
        val sv = ScrollView(this)
        sv.isVerticalScrollBarEnabled = false
        sv.addView(body)
        inner.addView(sv, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))

        body.addView(label("Bentuk"))
        body.addView(chipRow(listOf("+", "+•", "•", "○", "○•", "×"), prefs.getInt("xh_shape", 1)) {
            prefs.edit().putInt("xh_shape", it).apply()
            refreshCross()
        })

        body.addView(label("Warna"))
        val swatches = intArrayOf(
            0xFF00FF88.toInt(), 0xFFFF3B5C.toInt(), 0xFF00E5FF.toInt(), 0xFFFFE600.toInt(),
            0xFFFFFFFF.toInt(), 0xFFFF7A18.toInt(), 0xFFB26BFF.toInt(), 0xFFFF4FD8.toInt()
        )
        val sw = LinearLayout(this)
        sw.orientation = LinearLayout.HORIZONTAL
        for (c in swatches) {
            val v = View(this)
            v.background = ChamferDrawable(c, c, 0xFFFFFFFF.toInt(), dp(4).toFloat(), dens(), false)
            v.setOnClickListener {
                prefs.edit().putInt("xh_col", c).apply()
                refreshCross()
            }
            val l = LinearLayout.LayoutParams(0, dp(28), 1f)
            l.setMargins(dp(2), dp(2), dp(2), dp(2))
            sw.addView(v, l)
        }
        body.addView(sw)
        val hsv = FloatArray(3)
        Color.colorToHSV(prefs.getInt("xh_col", 0xFF00FF88.toInt()), hsv)
        body.addView(seekRow("Warna bebas (geser)", 0, 360, hsv[0].toInt()) { h ->
            prefs.edit().putInt("xh_col", Color.HSVToColor(floatArrayOf(h.toFloat(), 1f, 1f))).apply()
            refreshCross()
        })

        body.addView(xhSeek("Panjang", "xh_len", 2, 40, 11))
        body.addView(xhSeek("Ketebalan", "xh_th", 1, 8, 2))
        body.addView(xhSeek("Celah tengah", "xh_gap", 0, 24, 4))
        body.addView(xhSeek("Ukuran titik", "xh_dot", 2, 10, 3))
        body.addView(xhSeek("Transparansi", "xh_alpha", 20, 100, 100))
        body.addView(xhSeek("Geser horizontal", "xh_ox", -120, 120, 0))
        body.addView(xhSeek("Geser vertikal", "xh_oy", -120, 120, 0))

        val opts = LinearLayout(this)
        opts.orientation = LinearLayout.HORIZONTAL
        val outlineChip = switchChip("Garis tepi", "xh_out", true)
        outlineChip.setOnClickListener {
            prefs.edit().putBoolean("xh_out", !prefs.getBoolean("xh_out", true)).apply()
            val on = prefs.getBoolean("xh_out", true)
            outlineChip.text = if (on) "Garis tepi ✓" else "Garis tepi"
            outlineChip.background = if (on)
                ChamferDrawable(accent, accent2, 0xFFFFFFFF.toInt(), dp(6).toFloat(), dens(), false)
            else
                ChamferDrawable(0xFF262B3D.toInt(), 0xFF171A26.toInt(), 0xFF3A4057.toInt(), dp(6).toFloat(), dens(), false)
            refreshCross()
        }
        opts.addView(outlineChip, cell())
        opts.addView(pill("Tampilkan di layar", crosshair == null) {
            toggleCrosshair()
        }, cell())
        body.addView(opts)

        val reset = pill("Reset crosshair") {
            val e = prefs.edit()
            for (k in listOf("xh_shape", "xh_col", "xh_len", "xh_th", "xh_gap", "xh_dot", "xh_alpha", "xh_ox", "xh_oy", "xh_out")) e.remove(k)
            e.apply()
            refreshCross()
            closeCross()
            toggleCrossSettings()
        }
        val rlp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        rlp.setMargins(0, dp(10), 0, dp(4))
        body.addView(reset, rlp)

        val h = minOf(dp(480), screenH() - dp(40))
        crossWin = openWindow(inner, header, dp(300), h, false, dp(24), dp(30))
    }

    // ================= notifikasi & panggilan =================

    private fun dndOn(): Boolean {
        val nm = getSystemService(NotificationManager::class.java)
        return nm.isNotificationPolicyAccessGranted &&
            nm.currentInterruptionFilter == NotificationManager.INTERRUPTION_FILTER_ALARMS
    }

    private fun toggleDnd() {
        val nm = getSystemService(NotificationManager::class.java)
        if (!nm.isNotificationPolicyAccessGranted) {
            toast("Beri izin Jangan Ganggu dulu")
            startActivity(
                Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
            return
        }
        val on = nm.currentInterruptionFilter == NotificationManager.INTERRUPTION_FILTER_ALARMS
        nm.setInterruptionFilter(
            if (on) NotificationManager.INTERRUPTION_FILTER_ALL
            else NotificationManager.INTERRUPTION_FILTER_ALARMS
        )
        toast(if (on) "Jangan Ganggu mati" else "Jangan Ganggu nyala")
    }

    private fun headsUpOff() =
        Settings.Global.getString(contentResolver, "heads_up_notifications_enabled") == "0"

    private fun togglePopup() {
        val off = headsUpOff()
        val ok = putSetting("global", "heads_up_notifications_enabled", if (off) "1" else "0")
        toast(
            if (!ok) "Butuh Shizuku aktif"
            else if (off) "Pop-up notifikasi nyala kembali"
            else "Pop-up notifikasi diblokir"
        )
    }

    private val callReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            val st = intent?.getStringExtra(TelephonyManager.EXTRA_STATE)
            if (callBlock && st == TelephonyManager.EXTRA_STATE_RINGING) {
                try {
                    val tm = getSystemService(TelecomManager::class.java)
                    tm.endCall()
                    toast("Panggilan ditolak otomatis")
                } catch (e: Exception) {
                    toast("Izin telepon belum aktif")
                }
            }
        }
    }

    private fun phonePerm() =
        checkSelfPermission("android.permission.READ_PHONE_STATE") == PackageManager.PERMISSION_GRANTED &&
            checkSelfPermission("android.permission.ANSWER_PHONE_CALLS") == PackageManager.PERMISSION_GRANTED

    private fun toggleCallBlock() {
        if (callBlock) {
            callBlock = false
            toast("Tolak panggilan mati")
            return
        }
        if (!phonePerm() && Sh.ready()) {
            Sh.run(
                "pm grant $packageName android.permission.READ_PHONE_STATE; " +
                    "pm grant $packageName android.permission.ANSWER_PHONE_CALLS"
            )
        }
        if (!phonePerm()) {
            toast("Beri izin Telepon lewat aplikasi VeXed")
            return
        }
        if (!callRegistered) {
            registerReceiver(callReceiver, IntentFilter(TelephonyManager.ACTION_PHONE_STATE_CHANGED))
            callRegistered = true
        }
        callBlock = true
        toast("Panggilan masuk akan ditolak")
    }

    private fun headsetConnected(am: AudioManager): Boolean =
        am.getDevices(AudioManager.GET_DEVICES_OUTPUTS).any {
            it.type == AudioDeviceInfo.TYPE_WIRED_HEADSET ||
                it.type == AudioDeviceInfo.TYPE_WIRED_HEADPHONES ||
                it.type == AudioDeviceInfo.TYPE_BLUETOOTH_A2DP ||
                it.type == AudioDeviceInfo.TYPE_BLUETOOTH_SCO ||
                it.type == AudioDeviceInfo.TYPE_USB_HEADSET
        }

    private fun applyHeadset() {
        val am = getSystemService(AudioManager::class.java)
        try {
            if (headsetOnly && !headsetConnected(am)) {
                if (savedRing < 0) {
                    savedRing = am.getStreamVolume(AudioManager.STREAM_RING)
                    savedNotif = am.getStreamVolume(AudioManager.STREAM_NOTIFICATION)
                }
                am.setStreamVolume(AudioManager.STREAM_RING, 0, 0)
                am.setStreamVolume(AudioManager.STREAM_NOTIFICATION, 0, 0)
            } else if (savedRing >= 0) {
                am.setStreamVolume(AudioManager.STREAM_RING, savedRing, 0)
                am.setStreamVolume(AudioManager.STREAM_NOTIFICATION, savedNotif, 0)
                savedRing = -1
                savedNotif = -1
            }
        } catch (e: Exception) {
            toast("Butuh izin Jangan Ganggu agar volume bisa diatur")
        }
    }

    private fun toggleHeadset() {
        val am = getSystemService(AudioManager::class.java)
        headsetOnly = !headsetOnly
        if (headsetOnly) {
            val cb = object : AudioDeviceCallback() {
                override fun onAudioDevicesAdded(addedDevices: Array<out AudioDeviceInfo>?) { applyHeadset() }
                override fun onAudioDevicesRemoved(removedDevices: Array<out AudioDeviceInfo>?) { applyHeadset() }
            }
            devCb = cb
            am.registerAudioDeviceCallback(cb, main)
        } else {
            val cb = devCb
            if (cb != null) am.unregisterAudioDeviceCallback(cb)
            devCb = null
        }
        applyHeadset()
        toast(if (headsetOnly) "Dering dan notifikasi hanya lewat headset" else "Headset Only mati")
    }

    // ================= senter, layar aktif, kunci sentuh =================

    private fun toggleTorch() {
        try {
            val cm = getSystemService(CameraManager::class.java)
            val id = cm.cameraIdList.firstOrNull {
                cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            }
            if (id == null) {
                toast("Perangkat tidak punya senter")
                return
            }
            torchOn = !torchOn
            cm.setTorchMode(id, torchOn)
            toast(if (torchOn) "Senter nyala" else "Senter mati")
        } catch (e: Exception) {
            torchOn = false
            toast("Senter gagal dinyalakan")
        }
    }

    private fun toggleAwake() {
        if (awakeView != null) {
            safeRemove(awakeView)
            awakeView = null
            toast("Layar kembali normal")
            return
        }
        val v = View(this)
        val p = lp(1, 1, fNoFocus or fNoTouch or fKeepOn)
        p.gravity = Gravity.TOP or Gravity.START
        wm.addView(v, p)
        awakeView = v
        toast("Layar tetap menyala")
    }

    private fun toggleLock() {
        if (lockView != null) {
            safeRemove(lockView)
            lockView = null
            return
        }
        val root = FrameLayout(this)
        root.setBackgroundColor(0x01000000)
        root.setOnTouchListener { _, _ -> true }
        val hint = LinearLayout(this)
        hint.orientation = LinearLayout.HORIZONTAL
        hint.gravity = Gravity.CENTER_VERTICAL
        hint.setPadding(dp(16), dp(10), dp(18), dp(10))
        hint.background = ChamferDrawable(0xE6181B28.toInt(), 0xE60D0F17.toInt(), accent, dp(10).toFloat(), dens(), true)
        hint.addView(IconView(this, Icons.LOCK, accent2), LinearLayout.LayoutParams(dp(20), dp(20)))
        val tv = TextView(this)
        tv.text = "Tahan untuk membuka"
        tv.textSize = 12f
        tv.typeface = Typeface.DEFAULT_BOLD
        tv.setTextColor(textColor)
        tv.setPadding(dp(8), 0, 0, 0)
        hint.addView(tv)
        hint.setOnClickListener { }
        hint.setOnLongClickListener { toggleLock(); true }
        val hl = FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT,
            Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
        )
        hl.bottomMargin = dp(70)
        root.addView(hint, hl)
        val p = lp(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT, fNoFocus or fLimits)
        wm.addView(root, p)
        lockView = root
        toast("Sentuhan dikunci")
    }

    // ================= performa: boost & RAM =================

    private fun cleanRam() {
        val am = getSystemService(ActivityManager::class.java)
        val before = memInfo().availMem / 1048576
        var n = 0
        for (ai in packageManager.getInstalledApplications(0)) {
            if (ai.packageName == packageName) continue
            if ((ai.flags and ApplicationInfo.FLAG_SYSTEM) != 0) continue
            try { am.killBackgroundProcesses(ai.packageName); n++ } catch (e: Exception) { }
        }
        main.postDelayed({
            val after = memInfo().availMem / 1048576
            toast("$n app ditutup · RAM bebas $before → $after MB")
            islandPeek(Icons.MEM, "RAM dibersihkan ($n app ditutup)", cGreen, 2800L)
        }, 900)
    }

    private fun toggleBoost() {
        if (!Sh.ready()) {
            toast("Boost butuh Shizuku aktif")
            return
        }
        boostOn = !boostOn
        val on = boostOn
        toast(if (on) "Boost aktif" else "Boost mati")
        islandPeek(Icons.ROCKET, if (on) "Boost aktif" else "Boost mati", if (on) cGreen else gray)
        islandRefreshPersistent()
        Thread {
            if (on) {
                val pkg = foregroundPkg()
                val sb = StringBuilder()
                sb.append("cmd power set-fixed-performance-mode-enabled true 2>&1; ")
                sb.append("cmd power set-adaptive-power-saver-enabled false 2>&1; ")
                sb.append("settings put global low_power 0 2>&1; ")
                if (pkg != null && pkg != packageName) {
                    sb.append("cmd game mode performance $pkg 2>&1; ")
                    sb.append("cmd game set --mode performance $pkg 2>&1; ")
                }
                Sh.run(sb.toString())
                main.post { cleanRam() }
            } else {
                Sh.run(
                    "cmd power set-fixed-performance-mode-enabled false 2>&1; " +
                        "cmd power set-adaptive-power-saver-enabled true 2>&1"
                )
            }
        }.start()
    }

    // ================= rekam layar & screenshot =================

    private fun recLabel() = arrayOf("4M", "8M", "12M")[prefs.getInt("recbr", 1).coerceIn(0, 2)]

    private fun cycleBitrate() {
        val n = (prefs.getInt("recbr", 1) + 1) % 3
        prefs.edit().putInt("recbr", n).apply()
        toast("Bitrate rekam ${recLabel()}bps")
    }

    private fun toggleRecord() {
        if (!Sh.ready()) {
            toast("Rekam layar butuh Shizuku aktif")
            return
        }
        if (recording) {
            recording = false
            Thread { Sh.run("pkill -2 screenrecord 2>&1 || killall -2 screenrecord 2>&1") }.start()
            toast("Rekaman dihentikan. Cek Movies/VeXed")
            islandPeek(Icons.REC, "Rekaman disimpan ke Movies/VeXed", cGreen, 3200L)
            islandRefreshPersistent()
            return
        }
        recording = true
        recStart = SystemClock.elapsedRealtime()
        val br = intArrayOf(4, 8, 12)[prefs.getInt("recbr", 1).coerceIn(0, 2)] * 1_000_000
        toast("Merekam layar (tanpa suara)")
        islandPeek(Icons.REC, "Mulai merekam layar", cRed, 2400L)
        islandRefreshPersistent()
        Thread {
            while (recording) {
                val f = "/sdcard/Movies/VeXed/VeXed_${stamp()}.mp4"
                Sh.run("mkdir -p /sdcard/Movies/VeXed")
                val t0 = SystemClock.elapsedRealtime()
                val p = Sh.start("screenrecord --bit-rate $br '$f' 2>&1")
                try { p?.waitFor() } catch (e: Exception) { }
                if (p == null || SystemClock.elapsedRealtime() - t0 < 2000) {
                    recording = false
                    main.post { toast("Rekam layar gagal") }
                }
            }
        }.start()
    }

    private fun takeShot() {
        if (!Sh.ready()) {
            toast("Screenshot butuh Shizuku aktif")
            return
        }
        val file = "/sdcard/Pictures/VeXed/VeXed_${stamp()}.png"
        handle?.visibility = View.INVISIBLE
        hud?.visibility = View.INVISIBLE
        Thread {
            try { Thread.sleep(450) } catch (e: InterruptedException) { }
            Sh.run(
                "mkdir -p /sdcard/Pictures/VeXed; screencap -p '$file' 2>&1; " +
                    "am broadcast -a android.intent.action.MEDIA_SCANNER_SCAN_FILE -d file://$file >/dev/null 2>&1"
            )
            main.post {
                handle?.visibility = View.VISIBLE
                hud?.visibility = View.VISIBLE
                toast("Tersimpan di Pictures/VeXed")
                islandPeek(Icons.CAMERA, "Screenshot tersimpan", cGreen, 2200L)
            }
        }.start()
    }

    // ================= soundboard =================

    private fun gen(sec: Double, f: (Double, Double) -> Double): ShortArray {
        val sr = 22050
        val n = (sr * sec).toInt()
        val out = ShortArray(n)
        for (i in 0 until n) {
            val t = i / sr.toDouble()
            val env = minOf(1.0, i / 200.0) * minOf(1.0, (n - i) / 400.0)
            val v = (f(t, sec) * env * 12000).toInt().coerceIn(-32000, 32000)
            out[i] = v.toShort()
        }
        return out
    }

    private fun synth(kind: Int): ShortArray = when (kind) {
        0 -> gen(0.7) { t, _ ->
            if (Math.sin(2 * Math.PI * 440 * t) + 0.6 * Math.sin(2 * Math.PI * 554 * t) > 0) 0.7 else -0.7
        }
        1 -> gen(0.35) { t, d -> Math.sin(2 * Math.PI * (1800 * t - 1500 * t * t / (2 * d))) }
        2 -> gen(0.3) { t, _ ->
            Math.sin(2 * Math.PI * (if (t < 0.1) 988.0 else 1319.0) * t) * Math.exp(-3 * t)
        }
        3 -> gen(0.45) { t, _ ->
            Math.sin(2 * Math.PI * (45 * t + 20 * (1 - Math.exp(-6 * t)))) * Math.exp(-5 * t)
        }
        4 -> gen(0.9) { t, _ ->
            Math.sin(2 * Math.PI * (if (((t * 4).toInt() % 2) == 0) 800.0 else 600.0) * t)
        }
        5 -> gen(0.9) { t, d -> (Math.random() * 2 - 1) * Math.sin(Math.PI * t / d) }
        6 -> gen(1.0) { t, _ ->
            val f = if (t < 0.25) 392.0 else if (t < 0.5) 370.0 else if (t < 0.75) 349.0 else 330.0
            Math.sin(2 * Math.PI * f * t)
        }
        7 -> gen(0.6) { t, _ -> Math.sin(2 * Math.PI * 880 * t) * Math.exp(-5 * t) }
        8 -> gen(1.2) { t, _ ->
            Math.sin(2 * Math.PI * (900 * t + 300 * (1 - Math.cos(4 * Math.PI * t)) / (4 * Math.PI)))
        }
        9 -> gen(0.9) { t, _ ->
            ((Math.random() * 2 - 1) * 0.8 + Math.sin(2 * Math.PI * 55 * t)) * Math.exp(-4.5 * t)
        }
        10 -> gen(0.5) { t, _ ->
            val f = doubleArrayOf(523.0, 659.0, 784.0, 1047.0, 1319.0)[minOf(4, (t / 0.09).toInt())]
            Math.sin(2 * Math.PI * f * t) * 0.8
        }
        11 -> gen(1.1) { t, _ ->
            val f = doubleArrayOf(392.0, 349.0, 311.0, 262.0)[minOf(3, (t / 0.27).toInt())]
            if (Math.sin(2 * Math.PI * f * t) > 0) 0.5 else -0.5
        }
        12 -> gen(0.8) { t, _ ->
            val f = doubleArrayOf(392.0, 494.0, 587.0, 784.0, 988.0, 1175.0)[minOf(5, (t / 0.1).toInt())]
            Math.sin(2 * Math.PI * f * t) * Math.exp(-1.5 * t)
        }
        13 -> gen(0.15) { t, _ -> Math.sin(2 * Math.PI * (900 - 3500 * t) * t) * Math.exp(-14 * t) }
        14 -> gen(0.7) { t, d ->
            Math.sin(2 * Math.PI * (400 * t + 300 * d / Math.PI * (1 - Math.cos(Math.PI * t / d))))
        }
        else -> gen(0.5) { t, _ ->
            val k = (t * 8).toInt()
            val local = t * 8 - k
            if (k % 2 == 0 && k < 6) (Math.random() * 2 - 1) * Math.exp(-30 * local) else 0.0
        }
    }

    private fun playSound(kind: Int) {
        val vol = sbVol
        Thread {
            try {
                val data = synth(kind)
                val track = AudioTrack.Builder()
                    .setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_GAME)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                            .build()
                    )
                    .setAudioFormat(
                        AudioFormat.Builder()
                            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                            .setSampleRate(22050)
                            .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                            .build()
                    )
                    .setBufferSizeInBytes(data.size * 2)
                    .setTransferMode(AudioTrack.MODE_STATIC)
                    .build()
                track.write(data, 0, data.size)
                track.setVolume(vol)
                track.play()
                Thread.sleep(data.size * 1000L / 22050 + 150)
                track.release()
            } catch (e: Exception) {
            }
        }.start()
    }

    // ================= jaringan =================

    private fun dnsFast() =
        Settings.Global.getString(contentResolver, "private_dns_mode") == "hostname"

    private fun toggleDns() {
        val on = dnsFast()
        val ok = if (on) putSetting("global", "private_dns_mode", "opportunistic")
        else (putSetting("global", "private_dns_specifier", "one.one.one.one") &&
            putSetting("global", "private_dns_mode", "hostname"))
        toast(if (!ok) "Butuh Shizuku aktif" else if (on) "DNS kembali otomatis" else "DNS Cepat aktif")
    }

    private fun wifiMgr() = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager

    private fun wifiOn() = try { wifiMgr().isWifiEnabled } catch (e: Exception) { false }

    private fun dataOn() = Settings.Global.getString(contentResolver, "mobile_data") == "1"

    private fun toggleWifi() {
        if (!Sh.ready()) { toast("Butuh Shizuku aktif"); return }
        val on = wifiOn()
        Thread { Sh.run("svc wifi ${if (on) "disable" else "enable"}") }.start()
        toast(if (on) "Wi-Fi dimatikan" else "Wi-Fi dinyalakan")
    }

    private fun toggleData() {
        if (!Sh.ready()) { toast("Butuh Shizuku aktif"); return }
        val on = dataOn()
        Thread { Sh.run("svc data ${if (on) "disable" else "enable"}") }.start()
        toast(if (on) "Data seluler dimatikan" else "Data seluler dinyalakan")
    }

    private fun toggleLowLat() {
        val cur = lowLat
        if (cur != null && cur.isHeld) {
            cur.release()
            lowLat = null
            toast("Low latency mati")
            return
        }
        try {
            val mode = if (Build.VERSION.SDK_INT >= 29) WifiManager.WIFI_MODE_FULL_LOW_LATENCY
            else WifiManager.WIFI_MODE_FULL_HIGH_PERF
            val lock = wifiMgr().createWifiLock(mode, "vexed")
            lock.acquire()
            lowLat = lock
            toast("Wi-Fi low latency aktif")
        } catch (e: Exception) {
            toast("Low latency gagal diaktifkan")
        }
    }

    // ================= sentuh & visual =================

    private fun cycleTouch() {
        val n = (prefs.getInt("touch", 0) + 1) % 3
        val lpt = intArrayOf(400, 300, 220)[n]
        val mpt = intArrayOf(300, 250, 200)[n]
        val ok = putSetting("secure", "long_press_timeout", lpt.toString()) &&
            putSetting("secure", "multi_press_timeout", mpt.toString())
        if (ok) {
            prefs.edit().putInt("touch", n).apply()
            toast("Respons sentuh: ${arrayOf("Normal", "Cepat", "Maks")[n]}")
        } else {
            toast("Butuh Shizuku aktif")
        }
    }

    private fun animFast() =
        Settings.Global.getString(contentResolver, "window_animation_scale") == "0.5"

    private fun toggleAnim() {
        val v = if (animFast()) "1.0" else "0.5"
        val ok = putSetting("global", "window_animation_scale", v) &&
            putSetting("global", "transition_animation_scale", v) &&
            putSetting("global", "animator_duration_scale", v)
        toast(if (!ok) "Butuh Shizuku aktif" else if (v == "0.5") "Animasi dipercepat" else "Animasi normal")
    }

    private fun satLabel() = arrayOf("1.0x", "1.3x", "1.6x", "2.0x")[prefs.getInt("sat", 0).coerceIn(0, 3)]

    private fun cycleSat() {
        if (!Sh.ready()) { toast("Butuh Shizuku aktif"); return }
        val n = (prefs.getInt("sat", 0) + 1) % 4
        val v = floatArrayOf(1.0f, 1.3f, 1.6f, 2.0f)[n]
        prefs.edit().putInt("sat", n).apply()
        Thread { Sh.run("service call SurfaceFlinger 1022 f $v") }.start()
        toast("Saturasi warna ${satLabel()} (bergantung perangkat)")
    }

    // ================= HUD =================

    private inner class GraphView : View(this@OverlayService) {
        private val n = 40
        private val f = IntArray(n)
        private val m = IntArray(n)
        private var idx = 0
        private val pf = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = dp(1).toFloat() * 1.6f
            color = cGreen
        }
        private val pm = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = dp(1).toFloat()
            color = accent2
        }

        fun push(fv: Int, pv: Int) {
            f[idx] = fv
            m[idx] = pv
            idx = (idx + 1) % n
            invalidate()
        }

        override fun onDraw(canvas: Canvas) {
            val w = width.toFloat()
            val h = height.toFloat()
            line(canvas, f, 120, pf, w, h)
            line(canvas, m, 200, pm, w, h)
        }

        private fun line(canvas: Canvas, d: IntArray, max: Int, paint: Paint, w: Float, h: Float) {
            val path = Path()
            for (k in 0 until n) {
                val i = (idx + k) % n
                val x = k * w / (n - 1)
                val y = h - (d[i].coerceIn(0, max) / max.toFloat()) * h
                if (k == 0) path.moveTo(x, y) else path.lineTo(x, y)
            }
            canvas.drawPath(path, paint)
        }
    }

    private val frameCb = object : Choreographer.FrameCallback {
        override fun doFrame(frameTimeNanos: Long) {
            frames++
            if (running && useChoreo) Choreographer.getInstance().postFrameCallback(this)
            else choreoActive = false
        }
    }

    private fun hudSpan(): SpannableStringBuilder {
        val real = realFps
        val fps = if (real >= 0) real else if (useChoreo) uiFps else -1
        val fpsColor = if (fps < 0) gray else if (fps >= 50) cGreen else if (fps >= 30) cYellow else cRed
        val pg = ping
        val msColor = if (pg < 0) gray else if (pg < 60) cGreen else if (pg < 120) cYellow else cRed
        val sb = SpannableStringBuilder()
        sb.addSpan(if (fps < 0) "--" else "$fps", fpsColor)
        sb.addSpan(if (real >= 0 || fps < 0) " FPS" else " FPS*", gray, 0.85f)
        sb.addSpan("  ·  ", gray, 0.85f)
        sb.addSpan(if (pg < 0) "--" else "$pg", msColor)
        sb.addSpan(" ms", gray, 0.85f)
        if (prefs.getBoolean("hud_clock", true)) {
            sb.addSpan("  ·  ", gray, 0.85f)
            sb.addSpan(hudFmt.format(Date()), textColor, 0.85f)
        }
        if (hudDetail) {
            val cpu = if (cpuPct >= 0) "$cpuPct%" else "--"
            val gpu = if (gpuPct >= 0) "$gpuPct%" else "--"
            val t = if (tempC > 0) tempC else battery().second
            sb.addSpan("\nCPU $cpu   GPU $gpu   RAM ${ramPct()}%", gray, 0.85f)
            sb.addSpan("\n$t°C   ↓${rxKb}K/s  ↑${txKb}K/s", gray, 0.85f)
            sb.addSpan("\nloss $loss%   jitter ${jitter}ms", gray, 0.85f)
            if (fpsNote.isNotEmpty()) sb.addSpan("\n$fpsNote", gray, 0.75f)
        }
        return sb
    }

    private val tick = object : Runnable {
        override fun run() {
            if (!running) return
            val s = hudText ?: return
            val now = SystemClock.elapsedRealtime()
            val dt = if (lastTickMs == 0L) 500L else (now - lastTickMs).coerceAtLeast(1L)
            lastTickMs = now
            if (useChoreo) { uiFps = (frames * 1000L / dt).toInt(); frames = 0 }
            val rx = TrafficStats.getTotalRxBytes()
            val tx = TrafficStats.getTotalTxBytes()
            if (rxPrev >= 0 && rx >= 0) {
                rxKb = (rx - rxPrev) * 1000L / dt / 1024L
                txKb = (tx - txPrev) * 1000L / dt / 1024L
            }
            rxPrev = rx
            txPrev = tx
            s.text = hudSpan()
            val fps = if (realFps >= 0) realFps else uiFps
            val pg = ping
            hudGraph?.push(fps, if (pg < 0) 0 else pg.toInt())
            main.postDelayed(this, 500)
        }
    }

    private fun applyHudMode() {
        hudGraph?.visibility = if (hudDetail) View.VISIBLE else View.GONE
        hudText?.text = hudSpan()
    }

    private fun toggleMonitor() {
        if (hud == null) {
            hudDetail = true
            toggleHud()
        } else {
            hudDetail = !hudDetail
            applyHudMode()
        }
    }

    private fun toggleHud() {
        if (hud != null) {
            running = false
            stopStream()
            main.removeCallbacks(tick)
            safeRemove(hud)
            hud = null
            hudText = null
            hudGraph = null
            return
        }
        val txt = TextView(this)
        txt.text = "--"
        txt.textSize = 10f
        txt.typeface = Typeface.DEFAULT_BOLD
        txt.setTextColor(textColor)
        val g = GraphView()
        g.visibility = if (hudDetail) View.VISIBLE else View.GONE
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(9), dp(5), dp(10), dp(5))
        box.background = ChamferDrawable(0xE6181B28.toInt(), 0xE60D0F17.toInt(), accent, dp(6).toFloat(), dens(), false)
        box.addView(txt)
        val glp = LinearLayout.LayoutParams(dp(110), dp(18))
        glp.topMargin = dp(3)
        box.addView(g, glp)

        val p = lp(wrap, wrap, fNoFocus or fLimits)
        p.gravity = Gravity.TOP or Gravity.START
        p.x = dp(10)
        p.y = dp(36)
        makeDraggableTap(box, box, p) {
            hudDetail = !hudDetail
            applyHudMode()
        }
        box.alpha = 0f
        wm.addView(box, p)
        box.animate().alpha(1f).setDuration(250).start()
        hud = box
        hudText = txt
        hudGraph = g

        running = true
        frames = 0
        lastTickMs = 0L
        realFps = -1
        fpsNote = ""
        rxPrev = -1L
        useChoreo = !(Sh.ready() || hasDump())
        if (useChoreo && !choreoActive) {
            choreoActive = true
            Choreographer.getInstance().postFrameCallback(frameCb)
        }
        main.removeCallbacks(tick)
        main.postDelayed(tick, 400)
        startPing()
        startSampler()
    }

    private fun startPing() {
        if (pingThread?.isAlive == true) return
        pingThread = Thread {
            val hist = ArrayList<Long>()
            while (running) {
                val t0 = System.nanoTime()
                val r = try {
                    Socket().use { it.connect(InetSocketAddress("1.1.1.1", 443), 1500) }
                    (System.nanoTime() - t0) / 1_000_000
                } catch (e: Exception) {
                    -1L
                }
                ping = r
                hist.add(r)
                if (hist.size > 10) hist.removeAt(0)
                loss = hist.count { it < 0 } * 100 / hist.size
                val ok = hist.filter { it >= 0 }
                var sum = 0L
                for (i in 1 until ok.size) sum += Math.abs(ok[i] - ok[i - 1])
                jitter = if (ok.size > 1) (sum / (ok.size - 1)).toInt() else 0
                try { Thread.sleep(1500) } catch (e: InterruptedException) { return@Thread }
            }
        }.also { it.start() }
    }

    // ---- pembacaan FPS asli: satu shell panjang yang terus menerus membaca timestamp frame ----

    private fun stopStream() {
        val pr = fpsProc
        fpsProc = null
        streamLayer = null
        try { pr?.destroy() } catch (e: Throwable) { }
        fpsReader?.interrupt()
        fpsReader = null
    }

    private fun startStream(layer: String) {
        stopStream()
        val q = layer.replace("'", "'\\''")
        val cmd = "while true; do dumpsys SurfaceFlinger --latency '$q' 2>/dev/null; " +
            "echo __END__ || break; sleep 0.4; done"
        val pr = Sh.startSys(cmd) ?: return
        fpsProc = pr
        streamLayer = layer
        zeroRuns = 0
        fpsReader = Thread {
            try {
                val br = pr.inputStream.bufferedReader()
                val buf = ArrayList<String>()
                while (running) {
                    val line = br.readLine() ?: break
                    if (line.trim() == "__END__") {
                        val f = parseFps(buf)
                        buf.clear()
                        if (f == null) {
                            realFps = -1
                            zeroRuns = 3
                        } else {
                            realFps = f
                            zeroRuns = if (f == 0) zeroRuns + 1 else 0
                        }
                    } else {
                        buf.add(line)
                    }
                }
            } catch (e: Throwable) {
            }
            if (fpsProc === pr) streamLayer = null
        }.also { it.start() }
    }

    /** Hitung FPS dari keluaran `dumpsys SurfaceFlinger --latency`. null = tidak ada data valid. */
    private fun parseFps(lines: List<String>): Int? {
        if (lines.size < 2) return null
        val ts = ArrayList<Long>()
        var latest = 0L
        var oldest = Long.MAX_VALUE
        for (i in 1 until lines.size) {
            val parts = lines[i].trim().split(Regex("\\s+"))
            if (parts.size < 3) continue
            val t = parts[1].toLongOrNull() ?: continue
            if (t <= 0L || t == Long.MAX_VALUE) continue
            ts.add(t)
            if (t > latest) latest = t
            if (t < oldest) oldest = t
        }
        if (ts.isEmpty()) return null
        if (System.nanoTime() - latest > 1_500_000_000L) return 0
        val span = latest - oldest
        if (span in 1 until 1_000_000_000L) {
            // buffer kurang dari 1 detik (FPS tinggi): skala ke 1 detik
            return ((ts.size - 1) * 1_000_000_000.0 / span).toInt()
        }
        var c = 0
        for (t in ts) if (t > latest - 1_000_000_000L) c++
        return c
    }

    private fun startSampler() {
        if (samplerThread?.isAlive == true) return
        samplerThread = Thread {
            var n = 0
            var lastScan = 0L
            while (running) {
                if (Sh.ready() || hasDump()) {
                    val now = SystemClock.elapsedRealtime()
                    val due = now - lastScan >= 3000L || (streamLayer == null && now - lastScan >= 1500L)
                    if (due) {
                        lastScan = now
                        var fg = foregroundPkg() ?: gamePkg
                        if (fg == null || fg == packageName) fg = fpsPkg
                        if (fg == null) {
                            fpsNote = "FPS: buka game dulu"
                        } else {
                            val changed = fg != fpsPkg
                            fpsPkg = fg
                            if (changed || streamLayer == null || zeroRuns >= 3) {
                                val l = pickLayer(fg)
                                if (l == null) {
                                    stopStream()
                                    realFps = -1
                                    fpsNote = "FPS: layer $fg tidak terbaca"
                                } else {
                                    if (l != streamLayer) startStream(l)
                                    zeroRuns = 0
                                    fpsNote = "FPS: $fg"
                                }
                            }
                        }
                    }
                } else {
                    stopStream()
                    realFps = -1
                    fpsNote = "FPS asli butuh Shizuku atau izin DUMP"
                }
                if (hudDetail && Sh.ready() && n % 2 == 0) readHw()
                n++
                try { Thread.sleep(1000) } catch (e: InterruptedException) { return@Thread }
            }
            stopStream()
        }.also { it.start() }
    }

    private fun foregroundPkg(): String? {
        val rx = Regex("""\bu\d+ ([\w.]+)/""")
        val a = Sh.sys("dumpsys activity activities 2>/dev/null | grep -E 'topResumedActivity|ResumedActivity' | head -n 4")
        rx.find(a)?.let { return it.groupValues[1] }
        val b = Sh.sys("dumpsys window 2>/dev/null | grep -E 'mCurrentFocus|mFocusedApp' | head -n 4")
        return rx.find(b)?.groupValues?.get(1)
    }

    /** Pilih layer game yang benar-benar sedang menggambar (FPS tertinggi di antara kandidat). */
    private fun pickLayer(pkg: String): String? {
        val layers = Sh.sys("dumpsys SurfaceFlinger --list 2>/dev/null").lines().map { it.trim() }
        val c = layers.filter { it.contains(pkg) }.sortedBy {
            when {
                it.contains("SurfaceView") && it.contains("BLAST") -> 0
                it.contains("SurfaceView") -> 1
                it.contains("BLAST") -> 2
                else -> 3
            }
        }.take(6)
        if (c.isEmpty()) return null
        var best: String? = null
        var bestFps = -1
        for (l in c) {
            val q = l.replace("'", "'\\''")
            val f = parseFps(Sh.sys("dumpsys SurfaceFlinger --latency '$q' 2>/dev/null").lines()) ?: continue
            if (f > bestFps) { best = l; bestFps = f }
        }
        return best ?: c.first()
    }

    private fun readHw() {
        val script = "head -n1 /proc/stat; echo '--'; " +
            "cat /sys/class/kgsl/kgsl-3d0/gpubusy 2>/dev/null; echo '--'; " +
            "cat /sys/kernel/gpu/gpu_busy 2>/dev/null; echo '--'; " +
            "cat /sys/kernel/ged/hal/gpu_utilization 2>/dev/null; echo '--'; " +
            "for z in /sys/class/thermal/thermal_zone*; do " +
            "echo \"\$(cat \$z/type 2>/dev/null) \$(cat \$z/temp 2>/dev/null)\"; done"
        val out = Sh.run(script)
        if (out.isEmpty()) return
        val secs = ArrayList<List<String>>()
        var cur = ArrayList<String>()
        for (line in out.lines()) {
            if (line.trim() == "--") {
                secs.add(cur)
                cur = ArrayList()
            } else {
                cur.add(line)
            }
        }
        secs.add(cur)

        // CPU
        val cpuLine = secs.getOrNull(0)?.firstOrNull()
        if (cpuLine != null) {
            val v = cpuLine.trim().split(Regex("\\s+")).drop(1).mapNotNull { it.toLongOrNull() }
            if (v.size >= 5) {
                val idle = v[3] + v[4]
                val total = v.sum()
                if (prevTotal > 0) {
                    val dt = total - prevTotal
                    val di = idle - prevIdle
                    if (dt > 0) cpuPct = ((dt - di) * 100 / dt).toInt().coerceIn(0, 100)
                }
                prevTotal = total
                prevIdle = idle
            }
        }

        // GPU (bergantung SoC)
        var g = -1
        val num = Regex("\\d+")
        val k = secs.getOrNull(1)?.firstOrNull()
        if (k != null) {
            val nums = num.findAll(k).map { it.value.toLong() }.toList()
            if (nums.size >= 2 && nums[1] > 0) g = (nums[0] * 100 / nums[1]).toInt()
        }
        if (g < 0) {
            val l = secs.getOrNull(2)?.firstOrNull()
            val x = if (l != null) num.find(l)?.value?.toIntOrNull() else null
            if (x != null) g = x
        }
        if (g < 0) {
            val l = secs.getOrNull(3)?.firstOrNull()
            val x = if (l != null) num.find(l)?.value?.toIntOrNull() else null
            if (x != null) g = x
        }
        gpuPct = if (g in 0..100) g else -1

        // suhu
        val temps = ArrayList<Pair<String, Int>>()
        for (ln in secs.last()) {
            val tk = ln.trim().split(Regex("\\s+"))
            val raw = tk.lastOrNull()?.toIntOrNull() ?: continue
            val tc = if (raw > 1000) raw / 1000 else raw
            if (tc in 10..120) temps.add(Pair(tk.dropLast(1).joinToString(" "), tc))
        }
        val pick = temps.firstOrNull {
            val n = it.first.lowercase()
            n.contains("cpu") || n.contains("soc") || n.contains("tsens") || n.contains("ap")
        } ?: temps.maxByOrNull { it.second }
        tempC = pick?.second ?: -1
    }

    // ================= catatan =================

    private fun loadNotes(): JSONArray = try {
        JSONArray(prefs.getString("notes", "[]"))
    } catch (e: Exception) {
        JSONArray()
    }

    private fun saveNotes(a: JSONArray) {
        prefs.edit().putString("notes", a.toString()).apply()
    }

    private fun toggleNotes() {
        if (notesWin != null) { closeNotes(); return }
        val hd = windowHeader("CATATAN") { closeNotes() }
        val header = hd.first
        notesTitle = hd.second
        val body = LinearLayout(this)
        body.orientation = LinearLayout.VERTICAL
        notesBody = body
        val inner = windowColumn()
        inner.addView(header)
        inner.addView(body)
        notesWin = openWindow(inner, header, dp(300), wrap, true, dp(24), dp(90))
        notesShowList()
    }

    private fun closeNotes() {
        closeView(notesWin)
        notesWin = null
        notesBody = null
        notesTitle = null
    }

    private fun notesShowList() {
        val body = notesBody ?: return
        body.removeAllViews()
        notesTitle?.text = "CATATAN"
        body.addView(pill("+  Catatan baru", true) {
            val old = loadNotes()
            val na = JSONArray()
            na.put(JSONObject().put("t", "").put("ts", System.currentTimeMillis()))
            for (i in 0 until old.length()) na.put(old.get(i))
            saveNotes(na)
            notesShowEditor(0)
        })
        val arr = loadNotes()
        val list = LinearLayout(this)
        list.orientation = LinearLayout.VERTICAL
        if (arr.length() == 0) list.addView(note("Belum ada catatan."))
        val fmt = SimpleDateFormat("d MMM HH:mm", Locale.getDefault())
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            val raw = o.optString("t", "").trim()
            val preview = if (raw.isEmpty()) "(kosong)" else raw.lines().first().take(42)
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER_VERTICAL
            row.setPadding(dp(12), dp(10), dp(6), dp(10))
            row.background = ChamferDrawable(0xFF262B3D.toInt(), 0xFF171A26.toInt(), 0xFF3A4057.toInt(), dp(8).toFloat(), dens(), false)
            row.setOnClickListener { notesShowEditor(i) }
            val col = LinearLayout(this)
            col.orientation = LinearLayout.VERTICAL
            val pv = TextView(this)
            pv.text = preview
            pv.setTextColor(textColor)
            pv.textSize = 13f
            pv.maxLines = 1
            col.addView(pv)
            val dt = TextView(this)
            dt.text = fmt.format(Date(o.optLong("ts", 0L)))
            dt.setTextColor(gray)
            dt.textSize = 10f
            col.addView(dt)
            row.addView(col, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            val del = IconView(this, Icons.TRASH, cRed)
            del.setPadding(dp(5), dp(5), dp(5), dp(5))
            del.setOnClickListener {
                val a2 = loadNotes()
                a2.remove(i)
                saveNotes(a2)
                notesShowList()
            }
            row.addView(del, LinearLayout.LayoutParams(dp(30), dp(30)))
            val rlp = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
            )
            rlp.setMargins(0, dp(4), 0, dp(4))
            list.addView(row, rlp)
        }
        val sv = ScrollView(this)
        sv.addView(list)
        body.addView(sv, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(240)))
    }

    private fun notesShowEditor(idx: Int) {
        val body = notesBody ?: return
        body.removeAllViews()
        notesTitle?.text = "EDIT CATATAN"
        val arr = loadNotes()
        val o = arr.optJSONObject(idx)
        if (o == null) { notesShowList(); return }
        val et = EditText(this)
        et.setText(o.optString("t", ""))
        et.hint = "Tulis di sini..."
        et.setHintTextColor(0xFF7A8099.toInt())
        et.setTextColor(textColor)
        et.textSize = 14f
        et.gravity = Gravity.TOP or Gravity.START
        et.minLines = 8
        et.maxLines = 12
        et.setPadding(dp(12), dp(10), dp(12), dp(10))
        et.background = ChamferDrawable(0xFF1E2233.toInt(), 0xFF171A26.toInt(), 0xFF3A4057.toInt(), dp(8).toFloat(), dens(), false)
        et.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) {
                o.put("t", s?.toString() ?: "")
                o.put("ts", System.currentTimeMillis())
                saveNotes(arr)
            }
        })
        body.addView(et, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
        ))
        val actions = LinearLayout(this)
        actions.orientation = LinearLayout.HORIZONTAL
        actions.addView(pill("Kembali") { notesShowList() }, cell())
        actions.addView(pill("Salin") {
            copyText("catatan", et.text.toString())
            toast("Catatan disalin")
        }, cell())
        body.addView(actions)
        et.requestFocus()
    }

    // ================= stopwatch =================

    private fun swElapsed(): Long =
        swAcc + (if (swRunning) SystemClock.elapsedRealtime() - swBase else 0L)

    private fun swFmt(ms: Long): String =
        String.format(Locale.US, "%02d:%02d.%02d", ms / 60000, (ms / 1000) % 60, (ms / 10) % 100)

    private val swTick = object : Runnable {
        override fun run() {
            val t = swText ?: return
            t.text = swFmt(swElapsed())
            if (swRunning) main.postDelayed(this, 50)
        }
    }

    private fun toggleStopwatch() {
        if (swWin != null) {
            swRunning = false
            main.removeCallbacks(swTick)
            closeView(swWin)
            swWin = null
            swText = null
            return
        }
        swAcc = 0L
        swRunning = false
        val hd = windowHeader("STOPWATCH") { toggleStopwatch() }
        val header = hd.first
        val time = TextView(this)
        time.text = "00:00.00"
        time.textSize = 34f
        time.typeface = Typeface.DEFAULT_BOLD
        time.setTextColor(textColor)
        time.gravity = Gravity.CENTER
        time.setPadding(0, dp(8), 0, dp(10))
        swText = time

        val startBtn = pill("Mulai", true) { }
        startBtn.setOnClickListener {
            if (swRunning) {
                swAcc = swElapsed()
                swRunning = false
                startBtn.text = "Lanjut"
            } else {
                swBase = SystemClock.elapsedRealtime()
                swRunning = true
                startBtn.text = "Jeda"
                main.post(swTick)
            }
        }
        val resetBtn = pill("Reset") {
            swAcc = 0L
            swBase = SystemClock.elapsedRealtime()
            time.text = swFmt(0L)
        }
        val actions = LinearLayout(this)
        actions.orientation = LinearLayout.HORIZONTAL
        actions.addView(startBtn, cell())
        actions.addView(resetBtn, cell())

        val inner = windowColumn()
        inner.addView(header)
        inner.addView(time)
        inner.addView(actions)
        swWin = openWindow(inner, header, dp(240), wrap, false, dp(40), dp(150))
    }

    // ================= kalkulator =================

    private fun toggleCalc() {
        if (calc != null) {
            closeView(calc)
            calc = null
            return
        }
        var acc = 0.0
        var op = ' '
        var cur = "0"
        var fresh = true

        val display = TextView(this)
        display.text = "0"
        display.textSize = 28f
        display.typeface = Typeface.DEFAULT_BOLD
        display.setTextColor(textColor)
        display.gravity = Gravity.END
        display.maxLines = 1
        display.setPadding(dp(8), dp(6), dp(12), dp(10))

        fun fmt(d: Double): String {
            if (d.isNaN()) return "NaN"
            val s = d.toString()
            return if (s.endsWith(".0")) s.dropLast(2) else s
        }

        fun calcResult(): Double {
            val b = cur.toDoubleOrNull() ?: 0.0
            return when (op) {
                '+' -> acc + b
                '-' -> acc - b
                '×' -> acc * b
                '÷' -> if (b == 0.0) Double.NaN else acc / b
                else -> b
            }
        }

        fun press(k: String) {
            val c = k[0]
            if (c.isDigit()) {
                if (fresh || cur == "NaN") { cur = k; fresh = false }
                else cur = if (cur == "0") k else cur + k
            } else when (k) {
                "." -> {
                    if (fresh || cur == "NaN") { cur = "0."; fresh = false }
                    else if (!cur.contains(".")) cur += "."
                }
                "C" -> { acc = 0.0; op = ' '; cur = "0"; fresh = true }
                "⌫" -> {
                    cur = if (cur.length > 1 && cur != "NaN") cur.dropLast(1) else "0"
                    if (cur == "-") cur = "0"
                }
                "%" -> cur = fmt((cur.toDoubleOrNull() ?: 0.0) / 100)
                "=" -> if (op != ' ') {
                    acc = calcResult()
                    cur = fmt(acc)
                    op = ' '
                    fresh = true
                }
                else -> {
                    if (!fresh) { acc = calcResult(); cur = fmt(acc) }
                    op = c
                    fresh = true
                }
            }
            display.text = if (cur == "NaN") "Error" else cur
        }

        fun key(label: String, isOp: Boolean): TextView {
            val kv = TextView(this)
            kv.text = label
            kv.textSize = 18f
            kv.typeface = Typeface.DEFAULT_BOLD
            kv.gravity = Gravity.CENTER
            kv.setTextColor(textColor)
            kv.setPadding(0, dp(12), 0, dp(12))
            kv.background = if (isOp)
                ChamferDrawable(accent, accent2, 0xFFFFFFFF.toInt(), dp(7).toFloat(), dens(), false)
            else
                ChamferDrawable(0xFF262B3D.toInt(), 0xFF171A26.toInt(), 0xFF3A4057.toInt(), dp(7).toFloat(), dens(), false)
            kv.setOnTouchListener { v, e ->
                when (e.actionMasked) {
                    MotionEvent.ACTION_DOWN ->
                        v.animate().scaleX(0.92f).scaleY(0.92f).setDuration(60).start()
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL ->
                        v.animate().scaleX(1f).scaleY(1f).setDuration(100).start()
                }
                false
            }
            kv.setOnClickListener { press(label) }
            return kv
        }

        val hd = windowHeader("KALKULATOR") { closeView(calc); calc = null }
        val header = hd.first
        val inner = windowColumn()
        inner.addView(header)
        inner.addView(display)

        val rows = listOf(
            listOf("C" to 1f, "⌫" to 1f, "%" to 1f, "÷" to 1f),
            listOf("7" to 1f, "8" to 1f, "9" to 1f, "×" to 1f),
            listOf("4" to 1f, "5" to 1f, "6" to 1f, "-" to 1f),
            listOf("1" to 1f, "2" to 1f, "3" to 1f, "+" to 1f),
            listOf("0" to 2f, "." to 1f, "=" to 1f)
        )
        val ops = listOf("÷", "×", "-", "+", "=")
        for (r in rows) {
            val rowView = LinearLayout(this)
            rowView.orientation = LinearLayout.HORIZONTAL
            for ((label, w) in r) {
                val lpk = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, w)
                lpk.setMargins(dp(3), dp(3), dp(3), dp(3))
                rowView.addView(key(label, label in ops), lpk)
            }
            inner.addView(rowView)
        }
        calc = openWindow(inner, header, dp(250), wrap, false, dp(30), dp(120))
    }

    // ================= browser =================

    private fun toggleBrowser() {
        if (browser != null) {
            closeBrowser()
            return
        }
        val hd = windowHeader("BROWSER") { closeBrowser() }
        val header = hd.first
        val inner = windowColumn()

        val urlBox = EditText(this)
        urlBox.hint = "Cari atau ketik alamat"
        urlBox.setHintTextColor(0xFF7A8099.toInt())
        urlBox.setTextColor(textColor)
        urlBox.textSize = 13f
        urlBox.isSingleLine = true
        urlBox.imeOptions = EditorInfo.IME_ACTION_GO

        val wv = WebView(this)
        wv.settings.javaScriptEnabled = true
        wv.webViewClient = WebViewClient()
        wv.loadUrl("https://www.google.com")
        web = wv

        urlBox.setOnEditorActionListener { v, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_GO) {
                var u = v.text.toString().trim()
                if (!u.startsWith("http")) {
                    u = if (u.contains(".") && !u.contains(" ")) "https://$u"
                    else "https://www.google.com/search?q=" + Uri.encode(u)
                }
                wv.loadUrl(u)
                true
            } else false
        }

        inner.addView(header)
        inner.addView(urlBox)
        inner.addView(wv, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))
        browser = openWindow(inner, header, dp(300), dp(400), true, dp(20), dp(80))
    }

    private fun closeBrowser() {
        web?.destroy()
        web = null
        closeView(browser)
        browser = null
    }

    // ================= game launcher =================

    private class AppItem(val pkg: String, val label: String, val icon: Drawable?, val game: Boolean)

    private var appCache: List<AppItem>? = null
    private var launcherList: LinearLayout? = null
    private var launchFilter = 0
    private var launchQuery = ""
    private var launcherAnim = true

    private val gameHints = listOf(
        "pubg", "tencent", "mobilelegends", "moonton", "freefire", "garena", "supercell", "activision",
        "mihoyo", "hoyoverse", "roblox", "mojang", "epicgames", "netease", "riotgames", "lilithgames",
        "proximabeta", "levelinfinite", "gameloft", "konami", "ubisoft", "miniclip", "playrix", "habby",
        "krafton", "valve", "nintendo", "bandainamco", "kiloo", "rovio", "zynga", "scopely", "voodoo",
        "ketchapp", "innersloth", "devsisters", "nexon", "com.ea.", "unity3d", ".game", ".games"
    )

    @Suppress("DEPRECATION")
    private fun isGameApp(ai: ApplicationInfo): Boolean {
        if (ai.category == ApplicationInfo.CATEGORY_GAME) return true
        if ((ai.flags and ApplicationInfo.FLAG_IS_GAME) != 0) return true
        val p = ai.packageName.lowercase()
        return gameHints.any { p.contains(it) }
    }

    private fun favs(): MutableSet<String> = try {
        val a = JSONArray(prefs.getString("favs", "[]"))
        val s = LinkedHashSet<String>()
        for (i in 0 until a.length()) s.add(a.getString(i))
        s
    } catch (e: Exception) {
        LinkedHashSet()
    }

    private fun saveFavs(s: Set<String>) {
        prefs.edit().putString("favs", JSONArray(s.toList()).toString()).apply()
    }

    private fun loadApps(done: () -> Unit) {
        Thread {
            val pm = packageManager
            val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            val list = ArrayList<AppItem>()
            val seen = HashSet<String>()
            for (ri in pm.queryIntentActivities(intent, 0)) {
                val ai = ri.activityInfo.applicationInfo
                val pkg = ai.packageName
                if (pkg == packageName || !seen.add(pkg)) continue
                val label = try { ri.loadLabel(pm).toString() } catch (e: Exception) { pkg }
                val icon = try { ri.loadIcon(pm) } catch (e: Exception) { null }
                list.add(AppItem(pkg, label, icon, isGameApp(ai)))
            }
            list.sortBy { it.label.lowercase() }
            appCache = list
            main.post { done() }
        }.start()
    }

    private fun closeLauncher() {
        closeView(launcherWin)
        launcherWin = null
        launcherList = null
    }

    private fun toggleLauncher() {
        if (launcherWin != null) { closeLauncher(); return }
        launcherAnim = true
        val hd = windowHeader("GAME LAUNCHER") { closeLauncher() }
        val header = hd.first
        val inner = windowColumn()
        inner.addView(header)
        val hi = LinearLayout(this)
        hi.orientation = LinearLayout.HORIZONTAL
        hi.gravity = Gravity.CENTER_VERTICAL
        hi.setPadding(dp(4), dp(6), dp(4), dp(4))
        hi.addView(AvatarView(this, null, accent, accent2), LinearLayout.LayoutParams(dp(34), dp(34)))
        val hiT = TextView(this)
        hiT.text = "Mau main apa, Kak?"
        hiT.textSize = 12.5f
        hiT.typeface = Typeface.DEFAULT_BOLD
        hiT.setTextColor(textColor)
        hiT.setPadding(dp(10), 0, 0, 0)
        hi.addView(hiT)
        inner.addView(hi)

        val search = EditText(this)
        search.hint = "Cari game atau aplikasi"
        search.setHintTextColor(0xFF7A8099.toInt())
        search.setTextColor(textColor)
        search.textSize = 13f
        search.isSingleLine = true
        search.setText(launchQuery)
        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) {
                launchQuery = s?.toString() ?: ""
                renderLauncher()
            }
        })
        inner.addView(search)
        inner.addView(chipRow(listOf("Game", "Semua", "Favorit", "Terbaru"), launchFilter, textSz = 12f) {
            launchFilter = it
            renderLauncher()
        })

        val list = LinearLayout(this)
        list.orientation = LinearLayout.VERTICAL
        launcherList = list
        val sv = ScrollView(this)
        sv.isVerticalScrollBarEnabled = false
        sv.addView(list)
        val slp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f)
        slp.topMargin = dp(6)
        inner.addView(sv, slp)

        inner.addView(label("Otomatis saat game dibuka (tahan game = profil khusus)"))
        val r1 = LinearLayout(this)
        r1.orientation = LinearLayout.HORIZONTAL
        r1.addView(switchChip("HUD", "la_hud", true), cell())
        r1.addView(switchChip("Crosshair", "la_xh", false), cell())
        r1.addView(switchChip("Robot", "la_ai", false), cell())
        inner.addView(r1)
        val r2 = LinearLayout(this)
        r2.orientation = LinearLayout.HORIZONTAL
        r2.addView(switchChip("Boost", "la_boost", false), cell())
        r2.addView(switchChip("Jam", "la_clock", false), cell())
        r2.addView(Space(this), cell())
        inner.addView(r2)

        val h = minOf(dp(520), screenH() - dp(40))
        launcherWin = openWindow(inner, header, dp(340), h, true, dp(16), dp(24))

        if (appCache == null) {
            renderLauncher()
            loadApps { renderLauncher() }
        } else {
            renderLauncher()
        }
    }

    private fun renderLauncher() {
        val list = launcherList ?: return
        list.removeAllViews()
        val all = appCache
        if (all == null) { list.addView(note("Memuat daftar aplikasi...")); return }
        val fv = favs()
        val rec = Apps.recents(prefs)
        val q = launchQuery.trim().lowercase()
        var items = when (launchFilter) {
            0 -> all.filter { it.game || it.pkg in fv }
            2 -> all.filter { it.pkg in fv }
            3 -> rec.mapNotNull { p -> all.firstOrNull { it.pkg == p } }
            else -> all
        }
        if (q.isNotEmpty()) items = items.filter { it.label.lowercase().contains(q) || it.pkg.contains(q) }
        if (launchFilter != 3) {
            items = items.sortedWith(compareByDescending<AppItem> { it.pkg in fv }.thenBy { it.label.lowercase() })
        }
        if (items.isEmpty()) {
            list.addView(note(
                when {
                    launchFilter == 2 -> "Belum ada favorit. Ketuk bintang di pojok aplikasi."
                    launchFilter == 3 -> "Belum ada riwayat. Buka game dari sini dulu."
                    launchFilter == 0 -> "Game tidak terdeteksi otomatis. Pilih \"Semua\" lalu beri bintang."
                    else -> "Tidak ada hasil."
                }
            ))
            return
        }
        var n = 0
        if (q.isEmpty() && (launchFilter == 0 || launchFilter == 1)) {
            val recent = rec.mapNotNull { p -> all.firstOrNull { it.pkg == p } }.take(4)
            if (recent.isNotEmpty()) {
                list.addView(label("TERAKHIR DIMAINKAN"))
                n = addGrid(list, recent, fv, n)
                list.addView(label(if (launchFilter == 0) "GAME" else "SEMUA APLIKASI"))
            }
        }
        addGrid(list, items.take(160), fv, n)
        launcherAnim = false
    }

    /** Susun aplikasi dalam grid 4 kolom. Mengembalikan jumlah tile yang sudah ditambahkan (untuk urutan animasi). */
    private fun addGrid(parent: LinearLayout, items: List<AppItem>, fv: Set<String>, start: Int): Int {
        var count = start
        for (chunk in items.chunked(4)) {
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            for (a in chunk) {
                val lp = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                lp.setMargins(dp(3), dp(3), dp(3), dp(3))
                val t = appTile(a, a.pkg in fv)
                row.addView(t, lp)
                if (launcherAnim && count < 20) {
                    t.alpha = 0f
                    t.scaleX = 0.8f
                    t.scaleY = 0.8f
                    t.animate().alpha(1f).scaleX(1f).scaleY(1f).setStartDelay(count * 25L).setDuration(240)
                        .setInterpolator(OvershootInterpolator(1.2f)).start()
                }
                count++
            }
            for (k in chunk.size until 4) row.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))
            parent.addView(row)
        }
        return count
    }

    private fun appTile(a: AppItem, fav: Boolean): View {
        val box = FrameLayout(this)
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.gravity = Gravity.CENTER_HORIZONTAL
        col.setPadding(dp(3), dp(9), dp(3), dp(7))
        col.background = ChamferDrawable(0xFF1F2333.toInt(), 0xFF141722.toInt(), 0xFF2E3448.toInt(), dp(8).toFloat(), dens(), false)
        val iv = ImageView(this)
        iv.setImageDrawable(a.icon)
        col.addView(iv, LinearLayout.LayoutParams(dp(44), dp(44)))
        val tv = TextView(this)
        tv.text = a.label
        tv.textSize = 10f
        tv.setTextColor(textColor)
        tv.maxLines = 1
        tv.ellipsize = TextUtils.TruncateAt.END
        tv.gravity = Gravity.CENTER
        tv.setPadding(0, dp(4), 0, 0)
        col.addView(tv, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))
        box.addView(col, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.WRAP_CONTENT))
        val star = IconView(this, Icons.STAR, if (fav) cYellow else 0x66FFFFFF)
        star.setPadding(dp(2), dp(2), dp(2), dp(2))
        star.setOnClickListener {
            val s = favs()
            if (!s.add(a.pkg)) s.remove(a.pkg)
            saveFavs(s)
            renderLauncher()
        }
        box.addView(star, FrameLayout.LayoutParams(dp(22), dp(22), Gravity.TOP or Gravity.END))
        col.setOnClickListener { launchApp(a) }
        col.setOnLongClickListener { toggleProfile(a); true }
        return box
    }

    private fun launchApp(a: AppItem) {
        val li = packageManager.getLaunchIntentForPackage(a.pkg)
        if (li == null) { toast("Tidak bisa membuka ${a.label}"); return }
        li.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        closeLauncher()
        gamePkg = a.pkg
        sessionStart = SystemClock.elapsedRealtime()
        sessionName = a.label
        Apps.pushRecent(prefs, a.pkg)
        showLaunchSplash(a) {
            try { startActivity(li) } catch (e: Exception) { toast("Gagal membuka ${a.label}") }
        }
        main.postDelayed({
            if (pf(a.pkg, "hud", "la_hud", true) && hud == null) { hudDetail = false; toggleHud() }
            if (pf(a.pkg, "xh", "la_xh", false) && crosshair == null) toggleCrosshair()
            if (pf(a.pkg, "clock", "la_clock", false) && clockWin == null) toggleClock()
            if (pf(a.pkg, "ai", "la_ai", false) && robotWin == null) toggleRobot()
            if (pf(a.pkg, "boost", "la_boost", false) && !boostOn) toggleBoost()
            if (pf(a.pkg, "dnd", "", false) && !dndOn()) toggleDnd()
            if (pf(a.pkg, "game", "", false) && !gameMode) toggleGameMode()
            if (pf(a.pkg, "ref", "", false) && !prefs.getBoolean("refmax", false)) toggleRefresh()
            if (pf(a.pkg, "bright", "", false) && !prefs.getBoolean("brmax", false)) toggleBright()
        }, 4100)
    }

    private fun showLaunchSplash(a: AppItem, onStart: () -> Unit) {
        val sv = SplashView(this, accent, accent2, a.icon, a.label, null)
        val p = lp(
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
            fNoFocus or fNoTouch or fLimits
        )
        sv.alpha = 0f
        try { wm.addView(sv, p) } catch (e: Exception) { onStart(); return }
        sv.animate().alpha(1f).setDuration(200).start()
        val an = ValueAnimator.ofFloat(0f, 1f)
        an.duration = 2300
        an.addUpdateListener { sv.progress = it.animatedValue as Float; sv.invalidate() }
        an.start()
        main.postDelayed({ onStart() }, 1400)
        main.postDelayed({
            sv.animate().alpha(0f).setDuration(250).withEndAction { safeRemove(sv) }.start()
        }, 2400)
    }

    private fun openByName(raw: String): String {
        var name = raw.trim().lowercase()
        name = name.removePrefix("game ").removePrefix("aplikasi ").removePrefix("app ").trim()
        if (name.isEmpty()) return "Mau buka game apa?"
        val alias = mapOf("ml" to "mobile legends", "ff" to "free fire", "pubgm" to "pubg", "coc" to "clash of clans")
        name = alias[name] ?: name
        val c = appCache
        if (c == null) {
            loadApps { botReply(openByName(name)) }
            return "Sebentar, aku cek daftar aplikasimu..."
        }
        val hit = c.firstOrNull { it.label.lowercase() == name }
            ?: c.firstOrNull { it.label.lowercase().startsWith(name) }
            ?: c.firstOrNull { it.label.lowercase().contains(name) }
            ?: return "Aku tidak menemukan \"$name\" di HP-mu."
        launchApp(hit)
        return "Membuka ${hit.label}. Semoga menang!"
    }

    // ================= jam digital =================

    private var clockText: TextView? = null

    private fun clockSpan(): SpannableStringBuilder {
        val d = Date()
        val pat = if (prefs.getBoolean("clk24", true)) "HH:mm:ss" else "hh:mm:ss a"
        val sb = SpannableStringBuilder()
        sb.addSpan(SimpleDateFormat(pat, Locale.getDefault()).format(d), textColor)
        sb.addSpan("\n" + SimpleDateFormat("EEEE, d MMM yyyy", Locale("id", "ID")).format(d), gray, 0.42f)
        return sb
    }

    private val clockTick = object : Runnable {
        override fun run() {
            val t = clockText ?: return
            t.text = clockSpan()
            main.postDelayed(this, 1005L - System.currentTimeMillis() % 1000L)
        }
    }

    private fun toggleClock() {
        if (clockWin != null) {
            main.removeCallbacks(clockTick)
            closeView(clockWin)
            clockWin = null
            clockText = null
            return
        }
        val t = TextView(this)
        t.textSize = 26f
        t.typeface = Typeface.DEFAULT_BOLD
        t.gravity = Gravity.CENTER
        t.setTextColor(textColor)
        t.letterSpacing = 0.05f
        t.setPadding(dp(14), dp(6), dp(14), dp(8))
        t.text = clockSpan()
        val box = FrameLayout(this)
        box.background = ChamferDrawable(0xE6181B28.toInt(), 0xE60D0F17.toInt(), accent, dp(8).toFloat(), dens(), false)
        box.addView(t)
        val p = lp(wrap, wrap, fNoFocus or fLimits)
        p.gravity = Gravity.TOP or Gravity.START
        p.x = prefs.getInt("clk_x", dp(10))
        p.y = prefs.getInt("clk_y", dp(90))
        makeDraggableTap(box, box, p, onEnd = {
            prefs.edit().putInt("clk_x", p.x).putInt("clk_y", p.y).apply()
        }) {
            prefs.edit().putBoolean("clk24", !prefs.getBoolean("clk24", true)).apply()
            t.text = clockSpan()
        }
        box.alpha = 0f
        wm.addView(box, p)
        box.animate().alpha(1f).setDuration(220).start()
        clockWin = box
        clockText = t
        main.removeCallbacks(clockTick)
        main.postDelayed(clockTick, 1005L - System.currentTimeMillis() % 1000L)
    }

    // ================= asisten AI (robot pendamping) =================

    private val chatHistory = ArrayList<Pair<String, String>>()
    private var lastTip = 0L
    private val bubbleHide = Runnable {
        safeRemove(bubbleWin)
        bubbleWin = null
        if (chatWin == null) robotView?.mood = 0
    }

    private fun robotPx() = dp(prefs.getInt("rb_size", 76))

    private fun toggleRobot() {
        if (robotWin != null) { closeRobot(); return }
        val size = robotPx()
        val rv = RobotView(this, accent, accent2)
        if (prefs.getInt("rb_skin", 0) == 0) rv.avatar = null
        val p = lp(size, size, fNoFocus or fLimits)
        p.gravity = Gravity.TOP or Gravity.START
        p.x = prefs.getInt("rb_x", dp(14)).coerceIn(0, screenW() - size)
        p.y = prefs.getInt("rb_y", screenH() / 2).coerceIn(0, screenH() - size)
        makeDraggableTap(rv, rv, p, onEnd = {
            rv.dragging = false
            prefs.edit().putInt("rb_x", p.x).putInt("rb_y", p.y).apply()
            placeBubble()
        }, onMove = {
            rv.dragging = true
            placeBubble()
        }, onLong = {
            rv.play(7)
            showRadial()
        }) {
            rv.play(2)
            toggleChat()
        }
        rv.alpha = 0f
        wm.addView(rv, p)
        rv.animate().alpha(1f).setDuration(250).start()
        robotWin = rv
        robotView = rv
        robotParams = p
        robotStart = SystemClock.elapsedRealtime()
        lastRest = robotStart
        rv.play(1)
        val hasKey = !prefs.getString("ai_key", "").isNullOrBlank()
        say(if (hasKey) "Hai, Kak! Aku Vex. Ketuk aku untuk bantuan, tahan aku untuk menu cepat." else "Halo! Ketuk aku. Pasang kunci API di aplikasi VeXed biar aku bisa ngobrol penuh.", 5000)
        main.removeCallbacks(companionTick)
        main.postDelayed(companionTick, 25000)
        main.removeCallbacks(idleTick)
        main.postDelayed(idleTick, 4000)
    }

    private fun closeRobot() {
        main.removeCallbacks(companionTick)
        main.removeCallbacks(idleTick)
        main.removeCallbacks(bubbleHide)
        closeChat()
        safeRemove(bubbleWin)
        bubbleWin = null
        bubbleParams = null
        closeView(robotWin)
        robotWin = null
        robotView = null
        robotParams = null
    }

    /** Hitung posisi bubble di samping robot (kiri/kanan menyesuaikan sisi layar). */
    private fun positionBubble(bp: WindowManager.LayoutParams) {
        val p0 = robotParams ?: return
        val size = robotPx()
        val rightSide = p0.x + size / 2 < screenW() / 2
        val x = if (rightSide) p0.x + size - dp(2) else p0.x - bubbleW + dp(2)
        bp.x = x.coerceIn(0, maxOf(0, screenW() - bubbleW))
        bp.y = (p0.y + dp(6)).coerceIn(0, maxOf(0, screenH() - dp(60)))
    }

    /** Dipanggil saat robot digeser supaya dialog ikut bergerak. */
    private fun placeBubble() {
        val v = bubbleWin ?: return
        val bp = bubbleParams ?: return
        positionBubble(bp)
        try { wm.updateViewLayout(v, bp) } catch (e: Exception) { }
    }

    private fun say(text: String, ms: Long = 4500L) {
        if (robotWin == null || robotParams == null) return
        main.removeCallbacks(bubbleHide)
        safeRemove(bubbleWin)
        val tv = TextView(this)
        tv.text = text
        tv.textSize = 12f
        tv.setTextColor(textColor)
        tv.maxWidth = dp(220)
        tv.setPadding(dp(12), dp(8), dp(12), dp(8))
        tv.background = ChamferDrawable(0xF2181B28.toInt(), 0xF20D0F17.toInt(), accent, dp(8).toFloat(), dens(), false)
        tv.measure(
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED),
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
        )
        bubbleW = tv.measuredWidth
        val bp = lp(wrap, wrap, fNoFocus or fNoTouch or fLimits)
        bp.gravity = Gravity.TOP or Gravity.START
        positionBubble(bp)
        try { wm.addView(tv, bp) } catch (e: Exception) { return }
        bubbleWin = tv
        bubbleParams = bp
        robotView?.mood = 2
        val rightSide = (robotParams?.x ?: 0) + robotPx() / 2 < screenW() / 2
        tv.pivotX = if (rightSide) 0f else bubbleW.toFloat()
        tv.pivotY = tv.measuredHeight / 2f
        tv.alpha = 0f
        tv.scaleX = 0.5f
        tv.scaleY = 0.5f
        tv.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(220)
            .setInterpolator(OvershootInterpolator(1.4f)).start()
        main.postDelayed(bubbleHide, ms)
    }

    /** Robot melakukan gerakan acak supaya terasa hidup. */
    private val idleTick = object : Runnable {
        override fun run() {
            val rv = robotView ?: return
            if (chatWin == null && !rv.dragging && !rv.acting && rv.mood == 0) {
                rv.play(intArrayOf(1, 2, 3, 5, 6, 7, 2, 4).random())
                if (bubbleWin == null && Math.random() < 0.3) {
                    val q = quips()
                    if (q.isNotEmpty()) say(q.random(), 3500L)
                }
            }
            main.postDelayed(this, 3500L + (Math.random() * 4500.0).toLong())
        }
    }

    private val companionTick = object : Runnable {
        override fun run() {
            val now = SystemClock.elapsedRealtime()
            if ((robotWin == null || chatWin == null) && now - lastTip > 60000L) {
                val bt = battery()
                val mins = (now - (if (sessionStart > 0L) sessionStart else robotStart)) / 60000L
                val tip = when {
                    hud != null && realFps in 1..27 -> Triple("FPS-nya turun ($realFps). Coba turunkan grafis atau nyalakan Boost.", Icons.CHART, cYellow)
                    hud != null && ping > 150 -> Triple("Ping tinggi ($ping ms). Coba DNS Cepat atau pindah jaringan.", Icons.WIFI, cYellow)
                    bt.second >= 43 -> Triple("HP mulai panas (${bt.second}°C). Istirahat sebentar atau lepas casing.", Icons.THERMO, cRed)
                    ramPct() >= 92 -> Triple("RAM hampir penuh. Ketuk aku lalu bilang \"bersihkan ram\".", Icons.MEM, cYellow)
                    mins >= 45 && now - lastRest > 45 * 60000L -> Triple("Sudah $mins menit nih. Istirahat dulu, minum dan rilekskan mata ya.", Icons.CLOCK, cYellow)
                    else -> null
                }
                if (tip != null) {
                    val (msg, ic, col) = tip
                    if (msg.startsWith("Sudah")) lastRest = now
                    islandPeek(ic, msg, col, 4500L)
                    if (robotWin != null && chatWin == null) {
                        say(msg, 6000L)
                        robotView?.play(3)
                    }
                    lastTip = now
                }
            }
            main.postDelayed(this, 20000L)
        }
    }

    private fun closeChat() {
        closeView(chatWin)
        chatWin = null
        chatList = null
        chatScroll = null
    }

    private fun addMsg(text: String, mine: Boolean): TextView {
        val t = TextView(this)
        t.text = text
        t.textSize = 12.5f
        t.setTextColor(textColor)
        t.setPadding(dp(10), dp(7), dp(10), dp(7))
        t.maxWidth = if (mine) dp(220) else dp(196)
        t.background = if (mine)
            ChamferDrawable(accent, accent2, 0x00FFFFFF, dp(8).toFloat(), dens(), false)
        else
            ChamferDrawable(0xFF262B3D.toInt(), 0xFF171A26.toInt(), 0xFF3A4057.toInt(), dp(8).toFloat(), dens(), false)
        t.setOnLongClickListener { copyChat(text); true }
        val list = chatList ?: return t
        val lp = LinearLayout.LayoutParams(wrap, wrap)
        lp.gravity = if (mine) Gravity.END else Gravity.START
        lp.setMargins(0, dp(4), 0, dp(4))
        if (mine) {
            list.addView(t, lp)
        } else {
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            val alp = LinearLayout.LayoutParams(dp(30), dp(30))
            alp.rightMargin = dp(6)
            row.addView(AvatarView(this, null, accent, accent2), alp)
            row.addView(t)
            list.addView(row, lp)
        }
        chatScroll?.post { chatScroll?.fullScroll(View.FOCUS_DOWN) }
        return t
    }

    private fun removeMsg(v: TextView) {
        val row = v.parent as? View
        if (row === chatList) {
            chatList?.removeView(v)
        } else if (row != null && (row.parent as? View) === chatList) {
            chatList?.removeView(row)
        }
    }

    private fun toggleChat() {
        if (chatWin != null) { closeChat(); return }
        val hd = windowHeader("VEX") { closeChat() }
        val header = hd.first
        val inner = windowColumn()
        inner.addView(header)
        val tools = LinearLayout(this)
        tools.orientation = LinearLayout.HORIZONTAL
        tools.addView(switchChip("Suara Vex", "tts_on", false), cell())
        tools.addView(pill("Hapus chat") {
            chatHistory.clear()
            chatList?.removeAllViews()
            addMsg(greetingText(), false)
        }, cell())
        inner.addView(tools)

        val list = LinearLayout(this)
        list.orientation = LinearLayout.VERTICAL
        val sv = ScrollView(this)
        sv.isVerticalScrollBarEnabled = false
        sv.addView(list)
        inner.addView(sv, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))
        chatList = list
        chatScroll = sv

        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        val et = EditText(this)
        et.hint = "Tanya atau minta tolong..."
        et.setHintTextColor(0xFF7A8099.toInt())
        et.setTextColor(textColor)
        et.textSize = 13f
        et.isSingleLine = true
        et.imeOptions = EditorInfo.IME_ACTION_SEND
        val send = IconView(this, Icons.SEND, accent2)
        send.setPadding(dp(8), dp(8), dp(8), dp(8))
        row.addView(et, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        val mic = IconView(this, Icons.MIC, accent2)
        mic.setPadding(dp(8), dp(8), dp(8), dp(8))
        mic.setOnClickListener { listenVoice() }
        val eye = IconView(this, Icons.SHOT, accent2)
        eye.setPadding(dp(8), dp(8), dp(8), dp(8))
        eye.setOnClickListener {
            val q = et.text.toString().trim()
            et.setText("")
            askScreen(if (q.isEmpty()) "Bantu aku menyelesaikan atau memahami yang ada di layar ini." else q)
        }
        row.addView(mic, LinearLayout.LayoutParams(dp(40), dp(40)))
        row.addView(eye, LinearLayout.LayoutParams(dp(40), dp(40)))
        row.addView(send, LinearLayout.LayoutParams(dp(40), dp(40)))
        inner.addView(row)
        fun go() {
            val t = et.text.toString()
            et.setText("")
            sendChat(t)
        }
        et.setOnEditorActionListener { _, a, _ ->
            if (a == EditorInfo.IME_ACTION_SEND) { go(); true } else false
        }
        send.setOnClickListener { go() }

        val h = minOf(dp(400), screenH() - dp(80))
        chatWin = openWindow(inner, header, dp(300), h, true, dp(20), dp(50))

        if (chatHistory.isEmpty()) {
            addMsg(greetingText(), false)
        } else {
            for (m in chatHistory) {
                addMsg(m.second, m.first == "user")
                if (m.first != "user") addCopyLabel(m.second)
            }
        }
    }

    private fun copyChat(t: String) {
        val cm = getSystemService(ClipboardManager::class.java)
        cm.setPrimaryClip(ClipData.newPlainText("VeXed", t))
        toast("Disalin")
    }

    private fun addCopyLabel(text: String) {
        val list = chatList ?: return
        val c = TextView(this)
        c.text = "Salin"
        c.textSize = 10.5f
        c.setTextColor(accent2)
        c.setPadding(dp(6), dp(2), dp(6), dp(2))
        c.setOnClickListener {
            copyChat(text)
            c.text = "Tersalin"
        }
        val lp = LinearLayout.LayoutParams(wrap, wrap)
        lp.gravity = Gravity.START
        lp.setMargins(dp(40), 0, 0, dp(4))
        list.addView(c, lp)
        chatScroll?.post { chatScroll?.fullScroll(View.FOCUS_DOWN) }
    }

    private fun botReply(text: String) {
        speak(text)
        chatHistory.add("assistant" to text)
        while (chatHistory.size > 30) chatHistory.removeAt(0)
        if (chatWin != null) { addMsg(text, false); addCopyLabel(text) } else say(text.take(200), 6000L)
    }

    private fun sendChat(text: String) {
        val q = text.trim()
        if (q.isEmpty()) return
        addMsg(q, true)
        chatHistory.add("user" to q)
        val local = localCommand(q)
        if (local != null) { botReply(local); return }
        val key = prefs.getString("ai_key", "") ?: ""
        if (key.isBlank() || prefs.getInt("ai_provider", 2) == 3) {
            botReply(VexBrain.reply(q, brainCtx(), prefs.getInt("persona", 0)))
            return
        }
        val prov = prefs.getInt("ai_provider", 2)
        val model = (prefs.getString("ai_model", "") ?: "").ifBlank { Ai.defModel(prov) }
        val base = (prefs.getString("ai_base", "") ?: "").ifBlank { Ai.defBase(prov) }
        val msgs = ArrayList(chatHistory.takeLast(12))
        while (msgs.isNotEmpty() && msgs[0].first != "user") msgs.removeAt(0)
        val sys = aiSystem()
        val typing = addMsg("...", false)
        robotView?.mood = 1
        Thread {
            var reply = ""
            var err: String? = null
            try {
                reply = Ai.ask(prov, base, key, model, sys, msgs)
            } catch (e: Exception) {
                err = e.message ?: "tidak bisa terhubung"
            }
            main.post {
                robotView?.mood = 0
                removeMsg(typing)
                if (err != null) {
                    botReply("Gagal: $err")
                    botReply("Sementara kujawab dengan VeXed AI bawaan: " + VexBrain.reply(q, brainCtx(), prefs.getInt("persona", 0)))
                } else {
                    val acts = Regex("""\[\[ACT:(\w+)]]""").findAll(reply).map { it.groupValues[1] }.toList()
                    val clean = reply.replace(Regex("""\s*\[\[ACT:\w+]]"""), "").trim()
                    botReply(if (clean.isEmpty()) "Siap!" else clean)
                    for (a in acts) runAction(a)
                }
            }
        }.start()
    }

    private fun aiSystem(): String {
        val bt = battery()
        return "Kamu Vex, asisten gamer cewek anime yang melayang di atas layar HP pemain (rambut hitam-oranye, tanduk merah kecil, jaket tech). " +
            personaStyle() + " Jawab singkat (maksimal 3 kalimat), bahasa Indonesia, tanpa markdown. " +
            "Bantu soal game, FPS/lag, pengaturan, strategi umum, dan kontrol HP. " +
            "Kamu bisa menjalankan aksi di HP dengan menulis tag di akhir jawaban: " +
            "[[ACT:hud]] (FPS HUD), [[ACT:crosshair]], [[ACT:boost]], [[ACT:clock]], [[ACT:ram]] (bersihkan RAM), " +
            "[[ACT:shot]] (screenshot), [[ACT:launcher]], [[ACT:dnd]] (jangan ganggu), [[ACT:notes]], [[ACT:voice]] (voice changer), [[ACT:translate]] (penerjemah), [[ACT:gamemode]] (mode game), [[ACT:music]] (buka YouTube). " +
            "Pakai tag hanya jika pemain memintanya, dan jangan tulis tag lain. " +
            "Kondisi sekarang: game=${gamePkg ?: fpsPkg ?: "-"}, " +
            "FPS=${if (realFps >= 0) realFps.toString() else "tidak terbaca"}, " +
            "ping=${if (ping >= 0) "$ping ms" else "-"}, RAM ${ramPct()}%, " +
            "suhu baterai ${bt.second}C, baterai ${bt.first}%."
    }

    private fun runAction(name: String) {
        when (name) {
            "hud" -> toggleHud()
            "crosshair" -> toggleCrosshair()
            "boost" -> toggleBoost()
            "clock" -> toggleClock()
            "ram" -> cleanRam()
            "shot" -> takeShot()
            "launcher" -> toggleLauncher()
            "dnd" -> toggleDnd()
            "notes" -> toggleNotes()
            "voice" -> toggleVoice()
            "translate" -> toggleTranslator()
            "gamemode" -> toggleGameMode()
            "music" -> toggleYouTube()
        }
    }

    /** Perintah offline. Hanya cocok bila pesan berbentuk perintah (ada kata kerja), supaya pertanyaan biasa tetap ke AI. */
    private fun localCommand(q: String): String? {
        val s = q.lowercase().trim()
        fun has(vararg w: String) = w.any { s.contains(it) }
        if (has("jam berapa", "pukul berapa")) {
            return "Sekarang jam " + SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date()) + "."
        }
        val seeScreen = (has("lihat", "liat", "baca", "cek", "scan", "analisis", "perhatikan") && has("layar", "screen")) ||
            has("selesaikan ini", "menyelesaikan ini", "yang ada di layar", "di layar ini")
        if (has("terjemah", "translate") && has("layar", "screen")) {
            translateScreen()
            return "Oke, aku baca dan terjemahkan layarnya."
        }
        if (seeScreen) {
            askScreen(q, false)
            return "Oke, aku lihat layarmu dulu."
        }
        if (has("terjemah", "translate")) { toggleTranslator(); return "Membuka penerjemah." }
        if (has("mode game")) { toggleGameMode(); return "Mode Game diubah." }
        if (s.length > 60) return null
        fun word(w: String) = Regex("\\b$w\\b").containsMatchIn(s)
        val off = has("matikan", "tutup", "nonaktif", "hentikan", "sembunyi")
        val cmd = off || has("nyala", "hidup", "aktif", "tampil", "buka", "pasang", "munculkan", "jalankan", "ambil", "bersihkan", "bersihin", "atur", "mainkan", "putar")
        if (!cmd) return null

        if (has("sembunyi", "pergi dulu", "tutup bot", "tutup robot")) {
            main.post { closeRobot() }
            return "Oke, aku pergi dulu. Panggil lagi lewat tab GAME."
        }
        val pm = Regex("""^(?:tolong )?putar(?:kan)?\s+(?:lagu |musik )?(.+)$""").find(s)
        if (pm != null) {
            ytOpen("https://m.youtube.com/results?search_query=" + java.net.URLEncoder.encode(pm.groupValues[1], "UTF-8"))
            return "Membuka YouTube untuk \"${pm.groupValues[1]}\"."
        }
        if (word("musik") || word("lagu") || word("youtube")) { toggleYouTube(); return "Membuka YouTube." }
        val feature = word("launcher") || has("crosshair", "bidik") || word("hud") || word("fps") ||
            word("monitor") || word("voice") || word("jam") || has("terjemah", "mode game") || word("musik") || word("lagu") || word("youtube") || word("clock") || word("boost") || word("ram") ||
            has("catatan", "stopwatch", "kalkulator", "senter", "screenshot", "jangan ganggu", "performa", "daftar game", "list game")
        val app = Regex("""^(?:tolong )?(?:buka|jalankan|mainkan)\s+(.+)$""").find(s)
        if (app != null && !feature) return openByName(app.groupValues[1])

        if (word("launcher") || has("daftar game", "list game")) { toggleLauncher(); return "Membuka launcher game." }
        if (has("crosshair", "bidik")) {
            if (has("atur", "ubah", "custom", "setelan", "pengaturan")) {
                toggleCrossSettings()
                return "Membuka pengaturan crosshair."
            }
            val want = !off
            if ((crosshair != null) != want) toggleCrosshair()
            return if (want) "Crosshair dipasang." else "Crosshair dimatikan."
        }
        if (word("hud") || word("fps") || word("monitor")) {
            val want = !off
            if ((hud != null) != want) toggleHud()
            return if (want) "FPS HUD aktif." else "FPS HUD dimatikan."
        }
        if (word("jam") || word("clock")) {
            val want = !off
            if ((clockWin != null) != want) toggleClock()
            return if (want) "Jam digital dimunculkan." else "Jam digital ditutup."
        }
        if (word("voice") || has("pengubah suara")) { toggleVoice(); return "Membuka voice changer." }
        if (word("boost") || has("performa")) { toggleBoost(); return "Boost diubah (butuh Shizuku aktif)." }
        if (word("ram")) { cleanRam(); return "Membersihkan RAM..." }
        if (has("screenshot", "tangkap layar")) { takeShot(); return "Mengambil screenshot." }
        if (has("jangan ganggu")) { toggleDnd(); return "Mode Jangan Ganggu diubah." }
        if (has("catatan")) { toggleNotes(); return "Membuka catatan." }
        if (has("stopwatch")) { toggleStopwatch(); return "Stopwatch diubah." }
        if (has("kalkulator")) { toggleCalc(); return "Membuka kalkulator." }
        if (has("senter")) { toggleTorch(); return "Senter diubah." }
        return null
    }

    // ================= voice changer =================

    private fun closeVoice() {
        closeView(voiceWin)
        voiceWin = null
    }

    private fun toggleVoice() {
        if (voiceWin != null) { closeVoice(); return }
        val hd = windowHeader("VOICE CHANGER") { closeVoice() }
        val header = hd.first
        val inner = windowColumn()
        inner.addView(header)

        val meter = LevelView(this, accent, accent2) { voice.level }
        val mlp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(44))
        mlp.topMargin = dp(6)
        inner.addView(meter, mlp)

        val body = LinearLayout(this)
        body.orientation = LinearLayout.VERTICAL
        val sv = ScrollView(this)
        sv.isVerticalScrollBarEnabled = false
        sv.addView(body)
        inner.addView(sv, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))

        body.addView(label("Efek suara"))
        val chips = ArrayList<TextView>()
        fun styleChip(t: TextView, on: Boolean) {
            t.background = if (on)
                ChamferDrawable(accent, accent2, 0xFFFFFFFF.toInt(), dp(6).toFloat(), dens(), false)
            else
                ChamferDrawable(0xFF262B3D.toInt(), 0xFF171A26.toInt(), 0xFF3A4057.toInt(), dp(6).toFloat(), dens(), false)
        }
        for (r in 0 until 3) {
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            for (k in 0 until 4) {
                val i = r * 4 + k
                val t = TextView(this)
                t.text = VoiceEngine.NAMES[i]
                t.textSize = 11f
                t.typeface = Typeface.DEFAULT_BOLD
                t.setTextColor(textColor)
                t.gravity = Gravity.CENTER
                t.setPadding(dp(2), dp(10), dp(2), dp(10))
                styleChip(t, i == voice.preset)
                t.setOnClickListener {
                    voice.preset = i
                    chips.forEachIndexed { j, c -> styleChip(c, j == i) }
                    t.animate().scaleX(0.9f).scaleY(0.9f).setDuration(70).withEndAction {
                        t.animate().scaleX(1f).scaleY(1f).setDuration(110).start()
                    }.start()
                }
                chips.add(t)
                row.addView(t, cell())
            }
            body.addView(row)
        }
        body.addView(seekRow("Volume suara (%)", 50, 250, (voice.gain * 100).toInt()) { voice.gain = it / 100f })
        body.addView(seekRow("Peredam noise (0 = mati)", 0, 100, (voice.gate * 1000f).toInt()) { voice.gate = it / 1000f })

        val btn = pill(if (voice.running) "Matikan voice changer" else "Nyalakan voice changer", true) { }
        btn.setOnClickListener {
            if (voice.running) {
                voice.stop()
                btn.text = "Nyalakan voice changer"
            } else if (checkSelfPermission("android.permission.RECORD_AUDIO") != PackageManager.PERMISSION_GRANTED) {
                toast("Beri izin mikrofon dulu lewat aplikasi VeXed")
            } else {
                val e = voice.start()
                if (e != null) toast("Gagal: $e") else btn.text = "Matikan voice changer"
            }
        }
        val blp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        blp.setMargins(0, dp(12), 0, dp(4))
        body.addView(btn, blp)
        val rp = pill("Putar ulang 8 detik terakhir") {
            if (!voice.replay()) toast("Belum ada rekaman. Nyalakan dan bicara dulu.")
        }
        val rlp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        rlp.setMargins(0, dp(4), 0, dp(4))
        body.addView(rp, rlp)
        body.addView(note("Pakai headset supaya tidak berdengung. Suara hasil efek hanya diputar di HP ini, tidak bisa masuk ke voice chat game tanpa root."))
        val h = minOf(dp(520), screenH() - dp(40))
        voiceWin = openWindow(inner, header, dp(310), h, false, dp(24), dp(40))
    }

    // ================= soundboard v2 =================

    private fun toggleSoundboard() {
        if (sbWin != null) { closeView(sbWin); sbWin = null; return }
        val hd = windowHeader("SOUNDBOARD") { closeView(sbWin); sbWin = null }
        val header = hd.first
        val inner = windowColumn()
        inner.addView(header)
        val names = arrayOf(
            "Klakson", "Laser", "Koin", "Drum", "Alarm", "Sorak", "Sedih", "Ding",
            "Sirine", "Ledakan", "Power Up", "Game Over", "Level Up", "Pop", "Wow", "Ketik"
        )
        val pal = intArrayOf(
            0xFF4F46E5.toInt(), 0xFFDB2777.toInt(), 0xFF059669.toInt(), 0xFFD97706.toInt(),
            0xFF0891B2.toInt(), 0xFF7C3AED.toInt(), 0xFFE11D48.toInt(), 0xFF2563EB.toInt()
        )
        for (r in 0 until 4) {
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            for (k in 0 until 4) {
                val idx = r * 4 + k
                val c = pal[idx % pal.size]
                val dark = Color.rgb((Color.red(c) * 0.55f).toInt(), (Color.green(c) * 0.55f).toInt(), (Color.blue(c) * 0.55f).toInt())
                val b = TextView(this)
                b.text = names[idx]
                b.textSize = 10.5f
                b.typeface = Typeface.DEFAULT_BOLD
                b.setTextColor(0xFFFFFFFF.toInt())
                b.gravity = Gravity.CENTER
                b.setPadding(dp(2), dp(16), dp(2), dp(16))
                b.background = ChamferDrawable(c, dark, 0x33FFFFFF, dp(8).toFloat(), dens(), false)
                b.setOnClickListener {
                    playSound(idx)
                    b.animate().scaleX(0.88f).scaleY(0.88f).setDuration(70).withEndAction {
                        b.animate().scaleX(1f).scaleY(1f).setDuration(160)
                            .setInterpolator(OvershootInterpolator(2.2f)).start()
                    }.start()
                }
                row.addView(b, cell())
            }
            inner.addView(row)
        }
        inner.addView(seekRow("Volume efek (%)", 10, 100, (sbVol * 100).toInt()) { sbVol = it / 100f })
        inner.addView(note("Suara keluar lewat speaker. Rekan hanya mendengar bila mikrofon menangkapnya."))
        sbWin = openWindow(inner, header, dp(320), wrap, false, dp(24), dp(120))
    }

    // ================= melihat layar (AI) =================

    private fun hideAllForCapture(): List<Pair<View, Int>> {
        val vs = listOf<View?>(
            handle, hud, robotWin, chatWin, bubbleWin, clockWin, voiceWin, trWin, crossWin,
            crosshair, panel, sbWin, launcherWin
        ).filterNotNull()
        val saved = vs.map { it to it.visibility }
        for (v in vs) v.visibility = View.INVISIBLE
        return saved
    }

    /** Ambil screenshot lewat Shizuku (tanpa file), kecilkan, lalu kirim sebagai base64 JPEG. */
    private fun captureB64(done: (String?) -> Unit) {
        if (!Sh.ready()) {
            toast("Melihat layar butuh Shizuku aktif")
            done(null)
            return
        }
        val saved = hideAllForCapture()
        Thread {
            try { Thread.sleep(350) } catch (e: InterruptedException) { }
            var b64: String? = null
            try {
                val pr = Sh.start("screencap -p")
                if (pr != null) {
                    val bytes = pr.inputStream.readBytes()
                    pr.waitFor()
                    val bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
                    if (bmp != null) {
                        val m = maxOf(bmp.width, bmp.height)
                        val sc = if (m > 1024) 1024f / m else 1f
                        val s2 = if (sc < 1f)
                            Bitmap.createScaledBitmap(bmp, (bmp.width * sc).toInt(), (bmp.height * sc).toInt(), true)
                        else bmp
                        val out = ByteArrayOutputStream()
                        s2.compress(Bitmap.CompressFormat.JPEG, 72, out)
                        b64 = Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP)
                    }
                }
            } catch (e: Throwable) {
            }
            main.post {
                for ((v, vis) in saved) v.visibility = vis
                done(b64)
            }
        }.start()
    }

    private fun showScan() {
        if (scanWin != null) return
        val sv = ScanView(this, accent, accent2)
        val p = lp(
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
            fNoFocus or fNoTouch or fLimits
        )
        sv.alpha = 0f
        try { wm.addView(sv, p) } catch (e: Exception) { return }
        sv.animate().alpha(1f).setDuration(200).start()
        scanWin = sv
    }

    private fun hideScan() {
        val v = scanWin ?: return
        scanWin = null
        v.animate().alpha(0f).setDuration(250).withEndAction { safeRemove(v) }.start()
    }

    /** Panggil AI di thread latar. Bila search = true, tag [[SEARCH:...]] memicu pencarian Wikipedia lalu jawaban kedua. */
    private fun aiCall(
        system: String, msgs: List<Pair<String, String>>, image: String?, search: Boolean,
        done: (String?, String?) -> Unit
    ) {
        val key = prefs.getString("ai_key", "") ?: ""
        if (key.isBlank()) {
            done(null, "belum ada kunci API (atur di aplikasi VeXed)")
            return
        }
        val prov = prefs.getInt("ai_provider", 2)
        val model = (prefs.getString("ai_model", "") ?: "").ifBlank { Ai.defModel(prov) }
        val base = (prefs.getString("ai_base", "") ?: "").ifBlank { Ai.defBase(prov) }
        Thread {
            var reply: String? = null
            var err: String? = null
            try {
                var r = Ai.ask(prov, base, key, model, system, msgs, image)
                if (search) {
                    val m = Regex("""\[\[SEARCH:([^\]]+)]]""").find(r)
                    if (m != null) {
                        val q = m.groupValues[1].trim()
                        val info = Web.search(q)
                        val first = r.replace(Regex("""\s*\[\[SEARCH:[^\]]+]]"""), "").trim()
                        val msgs2 = ArrayList(msgs)
                        msgs2.add("assistant" to (if (first.isEmpty()) "Aku akan mencari: $q" else first))
                        msgs2.add(
                            "user" to (if (info.isEmpty())
                                "Pencarian \"$q\" tidak menemukan hasil. Jawab dengan pengetahuanmu, tanpa tag SEARCH."
                            else
                                "Hasil pencarian Wikipedia untuk \"$q\":\n$info\n\nSekarang jawab lengkap dan ringkas, tanpa tag SEARCH.")
                        )
                        r = Ai.ask(prov, base, key, model, system, msgs2, null)
                        if (info.isNotEmpty()) r = r + "\n(info tambahan dari Wikipedia: $q)"
                    }
                }
                reply = r
            } catch (e: Exception) {
                err = e.message ?: "tidak bisa terhubung"
            }
            main.post { done(reply, err) }
        }.start()
    }

    private fun visionSystem(): String {
        val bt = battery()
        return "Kamu Vex, asisten gamer cewek anime. " + personaStyle() + " Pengguna mengirim screenshot layar HP-nya " +
            "(bisa game, aplikasi, atau soal) beserta satu pertanyaan. Mulai dengan satu kalimat tentang apa yang kamu lihat " +
            "(nama game/aplikasi dan situasinya), lalu bantu menyelesaikan masalahnya langkah demi langkah. " +
            "Singkat (maksimal 6 kalimat), bahasa Indonesia, tanpa markdown. " +
            "Jika butuh data faktual tambahan (nama item, cara quest, rumus, arti istilah), tulis tepat satu tag " +
            "[[SEARCH:kata kunci singkat]] di akhir jawaban pertama; aku akan mencarikan lalu kamu menjawab lengkap. " +
            "Jika gambar tidak jelas, katakan apa adanya dan jangan mengarang. " +
            "Info perangkat: game=${gamePkg ?: fpsPkg ?: "-"}, FPS=${if (realFps >= 0) realFps.toString() else "-"}, " +
            "baterai ${bt.first}%."
    }

    private fun askScreen(q: String, echo: Boolean = true) {
        if (echo) {
            if (chatWin != null) addMsg("[layar] $q", true)
            chatHistory.add("user" to "[melihat layar] $q")
        }
        robotView?.mood = 1
        captureB64 { b64 ->
            if (b64 == null) {
                robotView?.mood = 0
                botReply("Aku gagal mengambil layar. Pastikan Shizuku aktif.")
                return@captureB64
            }
            showScan()
            val typing = addMsg("Menganalisis layar...", false)
            val shownAt = SystemClock.elapsedRealtime()
            aiCall(visionSystem(), listOf("user" to q), b64, true) { r, e ->
                val wait = maxOf(0L, 1500L - (SystemClock.elapsedRealtime() - shownAt))
                main.postDelayed({
                    hideScan()
                    robotView?.mood = 0
                    removeMsg(typing)
                    if (e != null) {
                        botReply("Gagal: $e (pastikan model mendukung gambar)")
                    } else {
                        val txt = r ?: ""
                        val acts = Regex("""\[\[ACT:(\w+)]]""").findAll(txt).map { it.groupValues[1] }.toList()
                        val clean = txt.replace(Regex("""\s*\[\[ACT:\w+]]"""), "").trim()
                        botReply(if (clean.isEmpty()) "Aku tidak menemukan apa-apa di layar." else clean)
                        robotView?.play(7)
                        for (a in acts) runAction(a)
                    }
                }, wait)
            }
        }
    }

    // ================= penerjemah =================

    private fun trLangName() = listOf("Indonesia", "Inggris", "Jepang", "Korea", "Mandarin")[prefs.getInt("tr_lang", 0).coerceIn(0, 4)]

    private fun closeTranslator() {
        closeView(trWin)
        trWin = null
        trOut = null
    }

    private fun toggleTranslator() {
        if (trWin != null) { closeTranslator(); return }
        val hd = windowHeader("PENERJEMAH") { closeTranslator() }
        val header = hd.first
        val inner = windowColumn()
        inner.addView(header)
        inner.addView(label("Terjemahkan ke"))
        inner.addView(chipRow(listOf("Indo", "Inggris", "Jepang", "Korea", "China"), prefs.getInt("tr_lang", 0), textSz = 10.5f) {
            prefs.edit().putInt("tr_lang", it).apply()
        })
        val et = EditText(this)
        et.hint = "Tulis atau tempel teks..."
        et.setHintTextColor(0xFF7A8099.toInt())
        et.setTextColor(textColor)
        et.textSize = 13f
        et.minLines = 3
        et.maxLines = 5
        et.gravity = Gravity.TOP
        inner.addView(et)
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.addView(pill("Tempel") {
            val cm = getSystemService(ClipboardManager::class.java)
            val t = cm.primaryClip?.getItemAt(0)?.coerceToText(this)?.toString()
            if (t.isNullOrEmpty()) toast("Clipboard kosong") else et.setText(t)
        }, cell())
        row.addView(pill("Terjemah", true) { translateText(et.text.toString()) }, cell())
        row.addView(pill("Layar") { translateScreen() }, cell())
        inner.addView(row)
        val out = TextView(this)
        out.text = "Hasil terjemahan muncul di sini. Ketuk untuk menyalin."
        out.textSize = 13f
        out.setTextColor(textColor)
        out.setPadding(dp(10), dp(10), dp(10), dp(10))
        out.background = ChamferDrawable(0xFF1B1F2E.toInt(), 0xFF141722.toInt(), 0xFF2E3448.toInt(), dp(8).toFloat(), dens(), false)
        out.setOnClickListener {
            val cm = getSystemService(ClipboardManager::class.java)
            cm.setPrimaryClip(ClipData.newPlainText("terjemahan", out.text))
            toast("Disalin")
        }
        val osv = ScrollView(this)
        osv.addView(out)
        val olp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f)
        olp.topMargin = dp(8)
        inner.addView(osv, olp)
        trOut = out
        val h = minOf(dp(440), screenH() - dp(60))
        trWin = openWindow(inner, header, dp(300), h, true, dp(20), dp(40))
    }

    private fun translateText(text: String) {
        val t = text.trim()
        if (t.isEmpty()) { toast("Isi teks dulu"); return }
        trOut?.text = "Menerjemahkan..."
        val sys = "Kamu penerjemah profesional. Terjemahkan teks pengguna ke bahasa ${trLangName()}. Balas HANYA hasil terjemahan, tanpa penjelasan."
        aiCall(sys, listOf("user" to t), null, false) { r, e -> trOut?.text = r ?: "Gagal: $e" }
    }

    private fun translateScreen() {
        if (trWin == null) toggleTranslator()
        trOut?.text = "Mengambil layar..."
        captureB64 { b64 ->
            if (b64 == null) {
                trOut?.text = "Gagal mengambil layar (butuh Shizuku aktif)."
                return@captureB64
            }
            showScan()
            trOut?.text = "Membaca dan menerjemahkan..."
            val sys = "Baca semua teks penting yang terlihat pada gambar layar ini, lalu terjemahkan ke bahasa ${trLangName()}. " +
                "Tampilkan terjemahannya saja, dikelompokkan per bagian layar, ringkas, tanpa markdown."
            aiCall(sys, listOf("user" to "Terjemahkan teks di layar ini."), b64, false) { r, e ->
                hideScan()
                trOut?.text = r ?: "Gagal: $e (pastikan model mendukung gambar)"
            }
        }
    }

    // ================= booster tambahan =================

    private fun toggleGameMode() {
        gameMode = !gameMode
        if (gameMode) {
            if (Sh.ready()) { if (!boostOn) toggleBoost() } else cleanRam()
            if (!dndOn()) toggleDnd()
            if (hud == null) { hudDetail = false; toggleHud() }
            toast("Mode Game aktif")
            islandPeek(Icons.ROCKET, "Mode Game aktif", cGreen, 2800L)
        } else {
            if (boostOn) toggleBoost()
            if (dndOn()) toggleDnd()
            toast("Mode Game mati")
            islandPeek(Icons.ROCKET, "Mode Game mati", gray, 2200L)
        }
        islandRefreshPersistent()
    }

    private fun toggleRefresh() {
        if (!Sh.ready()) { toast("Butuh Shizuku aktif"); return }
        val on = !prefs.getBoolean("refmax", false)
        prefs.edit().putBoolean("refmax", on).apply()
        Thread {
            if (on) Sh.run("settings put system min_refresh_rate 120.0; settings put system peak_refresh_rate 120.0; settings put system user_refresh_rate 120")
            else Sh.run("settings delete system min_refresh_rate; settings delete system peak_refresh_rate; settings delete system user_refresh_rate")
        }.start()
        toast(if (on) "Refresh rate maksimum dikunci (bergantung perangkat)" else "Refresh rate kembali normal")
    }

    private fun toggleBright() {
        if (!Sh.ready()) { toast("Butuh Shizuku aktif"); return }
        val on = !prefs.getBoolean("brmax", false)
        if (on) {
            val cur = try { Settings.System.getInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS) } catch (e: Exception) { 128 }
            prefs.edit().putBoolean("brmax", true).putInt("br_old", cur).apply()
            Thread { Sh.run("settings put system screen_brightness_mode 0; settings put system screen_brightness 255") }.start()
        } else {
            val old = prefs.getInt("br_old", 128)
            prefs.edit().putBoolean("brmax", false).apply()
            Thread { Sh.run("settings put system screen_brightness $old") }.start()
        }
        toast(if (on) "Kecerahan maksimum" else "Kecerahan dikembalikan")
    }

    private fun trimCaches() {
        if (!Sh.ready()) { toast("Butuh Shizuku aktif"); return }
        toast("Membersihkan cache...")
        Thread {
            Sh.run("pm trim-caches 999G")
            main.post { toast("Cache aplikasi dibersihkan") }
        }.start()
    }

    // ================= musik YouTube =================

    private inner class YtBridge {
        @JavascriptInterface
        fun ended() { main.post { ytNext() } }
    }

    private fun ytKey(): String {
        val k = (prefs.getString("yt_key", "") ?: "").trim()
        if (k.isNotEmpty()) return k
        return if (prefs.getInt("ai_provider", 2) == 2) (prefs.getString("ai_key", "") ?: "").trim() else ""
    }

    private fun closeMusic() {
        closeView(musicWin)
        musicWin = null
        musicListView = null
    }

    private fun closeYt() {
        try { ytWeb?.loadUrl("about:blank"); ytWeb?.destroy() } catch (e: Exception) { }
        closeView(ytWin)
        ytWin = null
        ytWeb = null
        ytTitle = null
        ytIdx = -1
        renderMusic()
    }

    private fun toggleMusic() {
        if (musicWin != null) { closeMusic(); return }
        val hd = windowHeader("MUSIK YOUTUBE") { closeMusic() }
        val header = hd.first
        val inner = windowColumn()
        inner.addView(header)

        val et = EditText(this)
        et.hint = "Cari lagu atau artis"
        et.setHintTextColor(0xFF7A8099.toInt())
        et.setTextColor(textColor)
        et.textSize = 13f
        et.isSingleLine = true
        et.imeOptions = EditorInfo.IME_ACTION_SEARCH
        et.setOnEditorActionListener { _, a, _ ->
            if (a == EditorInfo.IME_ACTION_SEARCH) { ytSearch(et.text.toString(), false); true } else false
        }
        inner.addView(et)
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        for ((label, q) in listOf("Lo-fi" to "lofi hip hop", "Gaming" to "gaming music mix", "Phonk" to "phonk mix", "EDM" to "edm mix")) {
            row.addView(pill(label) { et.setText(q); ytSearch(q, false) }, cell())
        }
        inner.addView(row)
        inner.addView(pill("Cari", true) { ytSearch(et.text.toString(), false) })

        val list = LinearLayout(this)
        list.orientation = LinearLayout.VERTICAL
        musicListView = list
        val sv = ScrollView(this)
        sv.isVerticalScrollBarEnabled = false
        sv.addView(list)
        val slp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f)
        slp.topMargin = dp(6)
        inner.addView(sv, slp)
        val h = minOf(dp(480), screenH() - dp(40))
        musicWin = openWindow(inner, header, dp(310), h, true, dp(20), dp(30))
        renderMusic()
    }

    private fun musicStatus(t: String) {
        val list = musicListView ?: return
        list.removeAllViews()
        list.addView(note(t))
    }

    private fun renderMusic() {
        val list = musicListView ?: return
        list.removeAllViews()
        if (ytList.isEmpty()) {
            list.addView(note("Cari lagu di atas. Butuh kunci YouTube Data API v3 (atur di aplikasi VeXed). Video yang melarang embed tidak bisa diputar."))
            return
        }
        for ((i, it) in ytList.withIndex()) {
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER_VERTICAL
            row.setPadding(dp(8), dp(8), dp(8), dp(8))
            val on = i == ytIdx && ytWin != null
            row.background = if (on)
                ChamferDrawable(accent, accent2, 0xFFFFFFFF.toInt(), dp(8).toFloat(), dens(), false)
            else
                ChamferDrawable(0xFF1F2333.toInt(), 0xFF141722.toInt(), 0xFF2E3448.toInt(), dp(8).toFloat(), dens(), false)
            row.addView(IconView(this, Icons.PLAY, if (on) 0xFFFFFFFF.toInt() else accent2), LinearLayout.LayoutParams(dp(24), dp(24)))
            val col = LinearLayout(this)
            col.orientation = LinearLayout.VERTICAL
            col.setPadding(dp(10), 0, 0, 0)
            val t = TextView(this)
            t.text = it.title
            t.textSize = 12.5f
            t.setTextColor(textColor)
            t.maxLines = 2
            t.ellipsize = TextUtils.TruncateAt.END
            col.addView(t)
            val ch = TextView(this)
            ch.text = it.channel
            ch.textSize = 10.5f
            ch.setTextColor(if (on) 0xFFFFFFFF.toInt() else gray)
            ch.maxLines = 1
            ch.ellipsize = TextUtils.TruncateAt.END
            col.addView(ch)
            row.addView(col, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            row.setOnClickListener { playYt(i) }
            val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
            lp.setMargins(0, 0, 0, dp(5))
            list.addView(row, lp)
        }
    }

    private fun ytSearch(q: String, playFirst: Boolean) {
        val key = ytKey()
        if (key.isEmpty()) { toast("Isi kunci YouTube di aplikasi VeXed (Atur kunci API)"); return }
        val query = q.trim()
        if (query.isEmpty()) return
        musicStatus("Mencari...")
        Thread {
            var res: List<YtItem> = emptyList()
            var err: String? = null
            try { res = Yt.search(key, query) } catch (e: Exception) { err = e.message ?: "gagal terhubung" }
            main.post {
                if (err != null) {
                    musicStatus("Gagal: $err")
                    if (playFirst) botReply("Gagal mencari lagu: $err")
                } else {
                    ytList.clear()
                    ytList.addAll(res)
                    ytIdx = -1
                    renderMusic()
                    if (ytList.isEmpty()) {
                        musicStatus("Tidak ada hasil untuk \"$query\".")
                        if (playFirst) botReply("Aku tidak menemukan \"$query\".")
                    } else if (playFirst) {
                        playYt(0)
                    }
                }
            }
        }.start()
    }

    private fun openYtPlayer() {
        val hd = windowHeader("PEMUTAR") { closeYt() }
        val header = hd.first
        val inner = windowColumn()
        inner.addView(header)
        val wv = WebView(this)
        wv.settings.javaScriptEnabled = true
        wv.settings.domStorageEnabled = true
        wv.settings.mediaPlaybackRequiresUserGesture = false
        wv.setBackgroundColor(0xFF000000.toInt())
        wv.webChromeClient = WebChromeClient()
        wv.webViewClient = WebViewClient()
        wv.addJavascriptInterface(YtBridge(), "VX")
        inner.addView(wv, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))
        val tt = TextView(this)
        tt.textSize = 11f
        tt.setTextColor(textColor)
        tt.maxLines = 1
        tt.ellipsize = TextUtils.TruncateAt.END
        tt.setPadding(dp(4), dp(4), dp(4), 0)
        inner.addView(tt)
        val ctl = LinearLayout(this)
        ctl.orientation = LinearLayout.HORIZONTAL
        val pp = pill("Jeda") { }
        pp.setOnClickListener {
            ytPaused = !ytPaused
            ytWeb?.evaluateJavascript(if (ytPaused) "pl.pauseVideo()" else "pl.playVideo()", null)
            pp.text = if (ytPaused) "Putar" else "Jeda"
        }
        ctl.addView(pill("Sebelum") { ytNext(-1) }, cell())
        ctl.addView(pp, cell())
        ctl.addView(pill("Lanjut") { ytNext(1) }, cell())
        inner.addView(ctl)
        ytWeb = wv
        ytTitle = tt
        ytPaused = false
        ytWin = openWindow(inner, header, dp(240), dp(300), false, dp(30), dp(120))
    }

    private fun playYt(i: Int) {
        if (i !in ytList.indices) return
        ytIdx = i
        val item = ytList[i]
        if (ytWin == null) openYtPlayer()
        val wv = ytWeb ?: return
        ytPaused = false
        val html = "<html><head><meta name='viewport' content='width=device-width,initial-scale=1'>" +
            "<style>html,body{margin:0;height:100%;background:#000}#p{width:100%;height:100%}</style></head><body>" +
            "<div id='p'></div><script src='https://www.youtube.com/iframe_api'></script><script>" +
            "var pl;function onYouTubeIframeAPIReady(){pl=new YT.Player('p',{width:'100%',height:'100%',videoId:'${item.id}'," +
            "playerVars:{autoplay:1,playsinline:1,rel:0},events:{onReady:function(e){e.target.playVideo();}," +
            "onStateChange:function(e){if(e.data===0){VX.ended();}}}});}</script></body></html>"
        wv.loadDataWithBaseURL("https://www.youtube.com", html, "text/html", "utf-8", null)
        ytTitle?.text = item.title
        renderMusic()
    }

    private fun ytNext(step: Int = 1) {
        if (ytList.isEmpty()) return
        val n = ytList.size
        playYt(((if (ytIdx < 0) 0 else ytIdx) + step + n) % n)
    }

    // ================= persona, suara, tampilan =================

    private fun greet(): String {
        val h = java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY)
        return when {
            h in 4..10 -> "Selamat pagi"
            h in 11..14 -> "Selamat siang"
            h in 15..17 -> "Selamat sore"
            else -> "Selamat malam"
        }
    }

    private fun greetingText() =
        "${greet()}, Kak! Aku Vex. Tanya apa saja, atau suruh aku: \"nyalakan hud\", \"buka free fire\", \"terjemahkan layar\", \"putar lagu lofi\". " +
            "Ketuk ikon kamera untuk menyuruhku melihat layarmu, atau ikon mikrofon untuk bicara."

    private fun personaStyle() = when (prefs.getInt("persona", 0)) {
        0 -> "Gaya bicaramu manis, ceria, dan sedikit usil; panggil pengguna \"Kak\"."
        1 -> "Gaya bicaramu santai seperti teman gamer."
        else -> "Gaya bicaramu sopan dan profesional."
    }

    private fun quips(): List<String> = when (prefs.getInt("persona", 0)) {
        0 -> listOf(
            "Semangat mainnya, Kak!", "Jangan lupa minum ya~", "Aku di sini kalau Kakak butuh bantuan.",
            "Awas HP-nya panas, aku pantau terus!", "Mau kuputarkan lagu, Kak?", "Tahan aku untuk menu cepat, lho."
        )
        1 -> listOf("Gas terus!", "Butuh bantuan? Ketuk aja.", "Sip, aku standby.")
        else -> emptyList()
    }

    private fun statChip(t: String, c: Int): TextView {
        val v = TextView(this)
        v.text = t
        v.textSize = 10f
        v.typeface = Typeface.DEFAULT_BOLD
        v.setTextColor(c)
        v.gravity = Gravity.CENTER
        v.setPadding(dp(4), dp(6), dp(4), dp(6))
        v.background = ChamferDrawable(0xFF262B3D.toInt(), 0xFF171A26.toInt(), 0xFF3A4057.toInt(), dp(6).toFloat(), dens(), false)
        val lp = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        lp.setMargins(dp(2), 0, dp(2), 0)
        v.layoutParams = lp
        return v
    }

    private fun initTts() {
        tts = TextToSpeech(this) { st ->
            if (st == TextToSpeech.SUCCESS) {
                tts?.setLanguage(Locale("id", "ID"))
                tts?.setPitch(1.25f)
                tts?.setSpeechRate(1.05f)
                ttsReady = true
            }
        }
    }

    private fun speak(text: String) {
        if (!ttsReady || !prefs.getBoolean("tts_on", false)) return
        val clean = text.replace(Regex("""```[\s\S]*?```"""), " kode ").replace(Regex("""[*_#`]"""), "").take(280)
        if (clean.isBlank()) return
        tts?.speak(clean, TextToSpeech.QUEUE_FLUSH, null, "vx")
    }

    private fun listenVoice() {
        if (listening) { stt?.stopListening(); return }
        if (checkSelfPermission("android.permission.RECORD_AUDIO") != PackageManager.PERMISSION_GRANTED) {
            toast("Beri izin mikrofon lewat aplikasi VeXed")
            return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            toast("Pengenalan suara tidak tersedia di HP ini")
            return
        }
        stt?.destroy()
        val r = SpeechRecognizer.createSpeechRecognizer(this)
        stt = r
        r.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) { listening = true; robotView?.mood = 1; toast("Silakan bicara, Kak...") }
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onError(error: Int) {
                listening = false
                robotView?.mood = 0
                toast("Suara tidak terdengar, coba lagi")
            }
            override fun onResults(results: Bundle?) {
                listening = false
                robotView?.mood = 0
                val t = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                if (!t.isNullOrBlank()) sendChat(t)
            }
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "id-ID")
        r.startListening(i)
    }

    // ================= menu radial di sekitar robot =================

    private class RadialItem(val label: String, val icon: Int, val act: () -> Unit)

    private fun closeRadial() {
        val v = radialWin ?: return
        radialWin = null
        v.animate().alpha(0f).setDuration(140).withEndAction { safeRemove(v) }.start()
    }

    private fun showRadial() {
        if (radialWin != null) return
        val rp = robotParams ?: return
        val size = robotPx()
        val cx = rp.x + size / 2
        val cy = rp.y + size / 2
        val items = listOf(
            RadialItem("Chat", Icons.ROBOT) { toggleChat() },
            RadialItem("HUD", Icons.CHART) { toggleHud() },
            RadialItem("Bidik", Icons.CROSSHAIR) { toggleCrosshair() },
            RadialItem("Game", Icons.GAME) { toggleLauncher() },
            RadialItem("YouTube", Icons.PLAY) { toggleYouTube() },
            RadialItem("Terjemah", Icons.GLOBE) { toggleTranslator() },
            RadialItem("Voice", Icons.MIC) { toggleVoice() },
            RadialItem("Mode", Icons.ROCKET) { toggleGameMode() }
        )
        val root = FrameLayout(this)
        root.setBackgroundColor(0x66000000)
        root.setOnClickListener { closeRadial() }
        val toRight = cx < screenW() / 2
        val start = if (toRight) -90.0 else 90.0
        val radius = dp(104).toDouble()
        items.forEachIndexed { i, it ->
            val ang = Math.toRadians(start + i * 180.0 / (items.size - 1))
            val x = (cx + radius * Math.cos(ang)).toInt().coerceIn(dp(34), screenW() - dp(34))
            val y = (cy + radius * Math.sin(ang)).toInt().coerceIn(dp(44), screenH() - dp(54))
            val col = LinearLayout(this)
            col.orientation = LinearLayout.VERTICAL
            col.gravity = Gravity.CENTER_HORIZONTAL
            val disc = FrameLayout(this)
            val gd = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(accent, accent2))
            gd.shape = GradientDrawable.OVAL
            gd.setStroke(dp(1), 0xCCFFFFFF.toInt())
            disc.background = gd
            val ic = IconView(this, it.icon, 0xFFFFFFFF.toInt())
            ic.setPadding(dp(10), dp(10), dp(10), dp(10))
            disc.addView(ic, FrameLayout.LayoutParams(dp(44), dp(44)))
            col.addView(disc, LinearLayout.LayoutParams(dp(44), dp(44)))
            val tv = TextView(this)
            tv.text = it.label
            tv.textSize = 9.5f
            tv.typeface = Typeface.DEFAULT_BOLD
            tv.setTextColor(0xFFFFFFFF.toInt())
            tv.gravity = Gravity.CENTER
            col.addView(tv, LinearLayout.LayoutParams(dp(60), wrap))
            col.setOnClickListener {
                closeRadial()
                it0(i, items)
            }
            val flp = FrameLayout.LayoutParams(dp(60), wrap)
            flp.leftMargin = x - dp(30)
            flp.topMargin = y - dp(30)
            root.addView(col, flp)
            col.alpha = 0f
            col.scaleX = 0.2f
            col.scaleY = 0.2f
            col.translationX = (cx - x).toFloat()
            col.translationY = (cy - y).toFloat()
            col.animate().alpha(1f).scaleX(1f).scaleY(1f).translationX(0f).translationY(0f)
                .setStartDelay(i * 28L).setDuration(260).setInterpolator(OvershootInterpolator(1.3f)).start()
        }
        val p = lp(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT, fNoFocus or fLimits)
        root.alpha = 0f
        try { wm.addView(root, p) } catch (e: Exception) { return }
        root.animate().alpha(1f).setDuration(150).start()
        radialWin = root
    }

    private fun it0(i: Int, items: List<RadialItem>) {
        if (i in items.indices) items[i].act()
    }

    // ================= profil per game =================

    private fun pf(pkg: String, k: String, g: String, d: Boolean) =
        prefs.getBoolean("pf_${pkg}_$k", if (g.isEmpty()) d else prefs.getBoolean(g, d))

    private fun toggleProfile(a: AppItem) {
        if (profWin != null) { closeView(profWin); profWin = null }
        val hd = windowHeader("PROFIL · ${a.label.take(18)}") { closeView(profWin); profWin = null }
        val header = hd.first
        val inner = windowColumn()
        inner.addView(header)
        inner.addView(note("Atur apa yang aktif otomatis saat game ini dibuka dari launcher."))
        val k = "pf_${a.pkg}_"
        fun row(vararg chips: TextView): LinearLayout {
            val r = LinearLayout(this)
            r.orientation = LinearLayout.HORIZONTAL
            for (c in chips) r.addView(c, cell())
            return r
        }
        inner.addView(row(
            switchChip("HUD", k + "hud", prefs.getBoolean("la_hud", true)),
            switchChip("Crosshair", k + "xh", prefs.getBoolean("la_xh", false)),
            switchChip("Robot", k + "ai", prefs.getBoolean("la_ai", false))
        ))
        inner.addView(row(
            switchChip("Boost", k + "boost", prefs.getBoolean("la_boost", false)),
            switchChip("Jam", k + "clock", prefs.getBoolean("la_clock", false)),
            switchChip("Mode Game", k + "game", false)
        ))
        inner.addView(row(
            switchChip("DND", k + "dnd", false),
            switchChip("Refresh", k + "ref", false),
            switchChip("Terang", k + "bright", false)
        ))
        val ok = pill("Selesai", true) { closeView(profWin); profWin = null }
        val olp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        olp.topMargin = dp(10)
        inner.addView(ok, olp)
        profWin = openWindow(inner, header, dp(300), wrap, false, dp(24), dp(110))
    }

    // ================= YouTube melayang (tanpa API) =================

    private fun closeTube() {
        hideTubeFull()
        try { tubeWeb?.loadUrl("about:blank"); tubeWeb?.destroy() } catch (e: Exception) { }
        closeView(tubeWin)
        tubeWin = null
        tubeWeb = null
    }

    private fun ytOpen(url: String) {
        if (tubeWin == null) toggleYouTube()
        tubeWeb?.loadUrl(url)
    }

    private fun setTubeFocus(on: Boolean) {
        val v = tubeWin ?: return
        val lp = v.layoutParams as? WindowManager.LayoutParams ?: return
        val nf = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
        lp.flags = if (on) (lp.flags and nf.inv()) else (lp.flags or nf)
        try { wm.updateViewLayout(v, lp) } catch (e: Exception) { }
    }

    private fun resizeTube(w: Int, h: Int) {
        val v = tubeWin ?: return
        val lp = v.layoutParams as? WindowManager.LayoutParams ?: return
        lp.width = w
        lp.height = h
        try { wm.updateViewLayout(v, lp) } catch (e: Exception) { }
    }

    private fun toggleYouTube() {
        if (tubeWin != null) { closeTube(); return }
        val hd = windowHeader("YOUTUBE") { closeTube() }
        val header = hd.first
        val inner = windowColumn()
        inner.addView(header)

        val wv = WebView(this)
        val ws = wv.settings
        ws.javaScriptEnabled = true
        ws.domStorageEnabled = true
        ws.mediaPlaybackRequiresUserGesture = false
        wv.setBackgroundColor(0xFF000000.toInt())
        CookieManager.getInstance().setAcceptCookie(true)
        wv.webViewClient = WebViewClient()
        wv.webChromeClient = object : WebChromeClient() {
            override fun onShowCustomView(view: View?, callback: CustomViewCallback?) { showTubeFull(view, callback) }
            override fun onHideCustomView() { hideTubeFull() }
        }
        inner.addView(wv, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))

        val r1 = LinearLayout(this)
        r1.orientation = LinearLayout.HORIZONTAL
        r1.addView(pill("Beranda") { wv.loadUrl("https://m.youtube.com") }, cell())
        r1.addView(pill("Kembali") { if (wv.canGoBack()) wv.goBack() }, cell())
        r1.addView(pill("Jeda / Putar") {
            wv.evaluateJavascript("(function(){var v=document.querySelector('video');if(v){if(v.paused){v.play();}else{v.pause();}}})()", null)
        }, cell())
        inner.addView(r1)

        val r2 = LinearLayout(this)
        r2.orientation = LinearLayout.HORIZONTAL
        val typ = pill("Ketik") { }
        var typing = false
        typ.setOnClickListener {
            typing = !typing
            setTubeFocus(typing)
            typ.text = if (typing) "Selesai" else "Ketik"
        }
        r2.addView(typ, cell())
        r2.addView(pill("Mini") { resizeTube(dp(230), dp(200)) }, cell())
        r2.addView(pill("Besar") {
            resizeTube(minOf(screenW() - dp(24), dp(360)), minOf(screenH() - dp(120), dp(520)))
        }, cell())
        inner.addView(r2)

        tubeWeb = wv
        wv.loadUrl("https://m.youtube.com")
        tubeWin = openWindow(inner, header, dp(300), dp(340), false, dp(20), dp(80))
    }

    private fun showTubeFull(view: View?, cb: WebChromeClient.CustomViewCallback?) {
        if (view == null) { cb?.onCustomViewHidden(); return }
        hideTubeFull()
        val root = FrameLayout(this)
        root.setBackgroundColor(0xFF000000.toInt())
        root.addView(view, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))
        val x = pill("Tutup layar penuh") { hideTubeFull() }
        val xl = FrameLayout.LayoutParams(FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.TOP or Gravity.END)
        xl.setMargins(0, dp(36), dp(12), 0)
        root.addView(x, xl)
        val p = lp(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT, fNoFocus or fLimits)
        try { wm.addView(root, p) } catch (e: Exception) { cb?.onCustomViewHidden(); return }
        tubeFull = root
        tubeCb = cb
    }

    private fun hideTubeFull() {
        val v = tubeFull ?: return
        tubeFull = null
        try { tubeCb?.onCustomViewHidden() } catch (e: Exception) { }
        tubeCb = null
        safeRemove(v)
    }

    private fun brainCtx(): BrainCtx {
        val bt = battery()
        val mins = if (sessionStart > 0L) (SystemClock.elapsedRealtime() - sessionStart) / 60000L else 0L
        return BrainCtx(
            ramPct(), bt.second, bt.first, realFps, ping.toInt(),
            if (sessionName.isNotEmpty()) sessionName else (gamePkg ?: ""), mins
        )
    }

    // ================= Dynamic Island =================

    private var islandWin: FrameLayout? = null
    private var islandParams: WindowManager.LayoutParams? = null
    private var islandBody: LinearLayout? = null
    private var islandIcon: IconView? = null
    private var islandDot: View? = null
    private var islandText: TextView? = null
    private var islandExpanded = false
    private var islandAnim: ValueAnimator? = null
    private var islandCollapseRun: Runnable? = null
    private var islandPersistIcon: Int? = null
    private var islandPersistColor: Int = cGreen
    private var islandPersistText: (() -> String)? = null
    private var islandTickRun: Runnable? = null

    private fun islandOn() = prefs.getBoolean("island_on", true)

    private fun islandCompactW() = dp(46)
    private fun islandCompactH() = dp(28)
    private fun islandExpandH() = dp(46)

    private fun ensureIsland(): FrameLayout? {
        if (!islandOn()) return null
        islandWin?.let { return it }
        val root = FrameLayout(this)
        root.background = GlassDrawable(accent, accent2, dp(30).toFloat(), dens(), 60)
        val body = LinearLayout(this)
        body.orientation = LinearLayout.HORIZONTAL
        body.gravity = Gravity.CENTER_VERTICAL
        body.setPadding(dp(10), 0, dp(14), 0)
        islandBody = body
        val icon = IconView(this, Icons.ROBOT, textColor)
        islandIcon = icon
        body.addView(icon, LinearLayout.LayoutParams(dp(20), dp(20)))
        val dot = View(this)
        val dgd = GradientDrawable()
        dgd.shape = GradientDrawable.OVAL
        dgd.setColor(cGreen)
        dot.background = dgd
        dot.visibility = View.GONE
        islandDot = dot
        val dlp = LinearLayout.LayoutParams(dp(8), dp(8))
        dlp.setMargins(dp(4), 0, 0, 0)
        body.addView(dot, dlp)
        val t = TextView(this)
        t.textSize = 11.5f
        t.typeface = Typeface.DEFAULT_BOLD
        t.setTextColor(textColor)
        t.maxLines = 1
        t.ellipsize = TextUtils.TruncateAt.END
        t.alpha = 0f
        islandText = t
        val tlp = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        tlp.setMargins(dp(8), 0, 0, 0)
        body.addView(t, tlp)
        root.addView(body, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))

        val p = lp(islandCompactW(), islandCompactH(), fNoFocus or fLimits)
        p.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
        p.x = prefs.getInt("island_x", 0)
        p.y = prefs.getInt("island_y", dp(14))
        makeDraggableTap(root, root, p, onEnd = {
            prefs.edit().putInt("island_x", p.x).putInt("island_y", p.y).apply()
        }) {
            islandTap()
        }
        root.alpha = 0f
        try { wm.addView(root, p) } catch (e: Exception) { return null }
        root.animate().alpha(1f).setDuration(220).start()
        islandWin = root
        islandParams = p
        return root
    }

    private fun closeIsland() {
        islandAnim?.cancel()
        islandCollapseRun?.let { main.removeCallbacks(it) }
        safeRemove(islandWin)
        islandWin = null
        islandParams = null
        islandBody = null
        islandIcon = null
        islandDot = null
        islandText = null
        islandExpanded = false
    }

    private fun toggleIslandSetting(on: Boolean) {
        prefs.edit().putBoolean("island_on", on).apply()
        if (!on) closeIsland() else ensureIsland()
    }

    private fun islandMorph(toW: Int, toH: Int, showText: Boolean) {
        val win = islandWin ?: return
        val p = islandParams ?: return
        islandAnim?.cancel()
        val fromW = if (p.width > 0) p.width else toW
        val fromH = if (p.height > 0) p.height else toH
        islandText?.animate()?.cancel()
        if (!showText) islandText?.alpha = 0f
        val a = ValueAnimator.ofFloat(0f, 1f)
        a.duration = 280
        a.interpolator = OvershootInterpolator(0.85f)
        a.addUpdateListener {
            val f = it.animatedValue as Float
            p.width = (fromW + (toW - fromW) * f).toInt()
            p.height = (fromH + (toH - fromH) * f).toInt()
            try { wm.updateViewLayout(win, p) } catch (e: Exception) { }
        }
        if (showText) {
            a.addListener(object : android.animation.AnimatorListenerAdapter() {
                override fun onAnimationEnd(animation: android.animation.Animator) {
                    islandText?.animate()?.alpha(1f)?.setDuration(140)?.start()
                }
            })
        }
        islandAnim = a
        a.start()
    }

    /** Tampilkan sebentar: melebar menampilkan ikon + teks, lalu otomatis ciut lagi. */
    private fun islandPeek(icon: Int, text: String, color: Int = accent, durationMs: Long = 3200L) {
        if (!islandOn()) return
        val win = ensureIsland() ?: return
        islandCollapseRun?.let { main.removeCallbacks(it) }
        islandIcon?.icon = icon
        islandIcon?.color = textColor
        islandIcon?.invalidate()
        islandDot?.visibility = View.GONE
        islandText?.text = text
        val w = minOf(dp(26) + dp(8) + (text.length * dp(7)) + dp(28), screenW() - dp(32))
        islandExpanded = true
        islandMorph(maxOf(w, dp(150)), islandExpandH(), true)
        val r = Runnable { islandCollapse() }
        islandCollapseRun = r
        main.postDelayed(r, durationMs)
        win.animate().cancel()
        win.scaleX = 1f
        win.scaleY = 1f
    }

    /** Ciutkan ke pil kecil; kalau ada status permanen (mis. sedang merekam), tampilkan titiknya. */
    private fun islandCollapse() {
        islandExpanded = false
        islandText?.alpha = 0f
        val pi = islandPersistIcon
        if (pi != null) {
            islandIcon?.icon = pi
            islandIcon?.color = islandPersistColor
            islandIcon?.invalidate()
            islandDot?.visibility = View.VISIBLE
            (islandDot?.background as? GradientDrawable)?.setColor(islandPersistColor)
            islandMorph(islandCompactW() + dp(10), islandCompactH(), false)
        } else {
            islandIcon?.icon = Icons.ROBOT
            islandIcon?.color = textColor
            islandIcon?.invalidate()
            islandDot?.visibility = View.GONE
            islandMorph(islandCompactW(), islandCompactH(), false)
        }
    }

    /** Status yang menempel terus selama aktif (direkam, Boost, Mode Game). null = tidak ada. */
    private fun islandSetPersistent(icon: Int?, color: Int, label: (() -> String)? = null) {
        islandPersistIcon = icon
        islandPersistColor = color
        islandPersistText = label
        if (!islandExpanded) islandCollapse()
    }

    private fun islandTap() {
        if (islandExpanded) { islandCollapse(); return }
        val label = islandPersistText?.invoke()
        if (label != null) {
            islandPeek(islandPersistIcon ?: Icons.ROBOT, label, islandPersistColor, 3000L)
        } else {
            toggleChat()
        }
    }

    /** Dipanggil tiap detik dari tick HUD saat sedang merekam, supaya penghitung waktu jalan. */
    private fun islandRecTimer(): String {
        val s = ((SystemClock.elapsedRealtime() - recStart) / 1000L).coerceAtLeast(0)
        return "Rekam %02d:%02d".format(s / 60, s % 60)
    }

    /** Pilih status permanen dengan prioritas: merekam > Mode Game > Boost > tidak ada. */
    private fun islandRefreshPersistent() {
        when {
            recording -> islandSetPersistent(Icons.REC, cRed) { islandRecTimer() }
            gameMode -> islandSetPersistent(Icons.ROCKET, cGreen) { "Mode Game aktif" }
            boostOn -> islandSetPersistent(Icons.ROCKET, cGreen) { "Boost aktif" }
            else -> islandSetPersistent(null, cGreen)
        }
    }

}
