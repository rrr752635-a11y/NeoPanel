package com.neopanel.app

import android.animation.ObjectAnimator
import android.animation.ValueAnimator
import android.app.ActivityManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.os.BatteryManager
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.provider.Settings
import android.text.Editable
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.TextWatcher
import android.text.style.ForegroundColorSpan
import android.text.style.RelativeSizeSpan
import android.util.TypedValue
import android.view.Choreographer
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.animation.DecelerateInterpolator
import android.view.inputmethod.EditorInfo
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject
import java.net.InetSocketAddress
import java.net.Socket
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class OverlayService : Service() {

    private lateinit var wm: WindowManager
    private val main = Handler(Looper.getMainLooper())
    private val prefs by lazy { getSharedPreferences("neo", MODE_PRIVATE) }

    // ---- jendela / view ----
    private var handle: View? = null
    private val handleAnims = ArrayList<ObjectAnimator>()
    private var panel: View? = null
    private var crosshair: CrossView? = null
    private var hud: View? = null
    private var hudText: TextView? = null
    private var hudGraph: GraphView? = null
    private var browser: View? = null
    private var web: WebView? = null
    private var calc: View? = null
    private var notesWin: View? = null
    private var notesBody: LinearLayout? = null
    private var notesTitle: TextView? = null
    private var swWin: View? = null
    private var swText: TextView? = null
    private var settingsWin: View? = null
    private var awakeView: View? = null
    private var lockView: View? = null

    // ---- state ----
    @Volatile private var running = false
    @Volatile private var ping = -1L
    @Volatile private var realFps = -1
    private var frames = 0
    private var uiFps = 0
    private var useChoreo = false
    private var choreoActive = false
    private var pingThread: Thread? = null
    private var fpsThread: Thread? = null
    private var torchOn = false
    private var swRunning = false
    private var swBase = 0L
    private var swAcc = 0L

    // ---- tema ----
    private val themes = listOf(
        0xFF7C5CFF.toInt() to 0xFF00E5FF.toInt(),
        0xFFFF5470.toInt() to 0xFFFFB020.toInt(),
        0xFF00C853.toInt() to 0xFF00E5FF.toInt(),
        0xFFFF4DA6.toInt() to 0xFF7C5CFF.toInt(),
        0xFFFFB020.toInt() to 0xFFFF5470.toInt()
    )
    private var accent = 0xFF7C5CFF.toInt()
    private var accent2 = 0xFF00E5FF.toInt()
    private val textColor = 0xFFE8EAF6.toInt()
    private val gray = 0xFF9AA0B5.toInt()
    private val cGreen = 0xFF3DFF9A.toInt()
    private val cYellow = 0xFFFFD43B.toInt()
    private val cRed = 0xFFFF5470.toInt()
    private val xhColors = intArrayOf(
        0xFF00FF88.toInt(), 0xFFFF3B5C.toInt(), 0xFF00E5FF.toInt(),
        0xFFFFE600.toInt(), 0xFFFFFFFF.toInt()
    )

    private val fNoFocus = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
    private val fNoTouch = WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
    private val fLimits = WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
    private val fModal = WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
    private val fOutside = WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH
    private val fHw = WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED
    private val fKeepOn = WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON
    private val wrap = WindowManager.LayoutParams.WRAP_CONTENT

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val th = themes[prefs.getInt("theme", 0).coerceIn(0, themes.size - 1)]
        accent = th.first
        accent2 = th.second
        startForeground(1, buildNotification())
        addHandle()
    }

    override fun onDestroy() {
        running = false
        swRunning = false
        main.removeCallbacks(tick)
        main.removeCallbacks(swTick)
        handleAnims.forEach { it.cancel() }
        closePanel(false)
        closeBrowser()
        for (v in listOf(calc, notesWin, swWin, settingsWin, awakeView, lockView, crosshair, hud, handle)) {
            safeRemove(v)
        }
        super.onDestroy()
    }

    // ================= util =================

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun screenW() = resources.displayMetrics.widthPixels
    private fun screenH() = resources.displayMetrics.heightPixels

    private fun lp(w: Int, h: Int, flags: Int) = WindowManager.LayoutParams(
        w, h, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
        flags or fHw, PixelFormat.TRANSLUCENT
    )

    private fun safeRemove(v: View?) {
        if (v == null) return
        try { wm.removeView(v) } catch (e: Exception) { }
    }

    private fun closeView(v: View?) {
        if (v == null) return
        v.animate().alpha(0f).scaleX(0.92f).scaleY(0.92f).setDuration(130)
            .withEndAction { safeRemove(v) }.start()
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    private fun copyText(label: String, text: String) {
        getSystemService(ClipboardManager::class.java)
            .setPrimaryClip(ClipData.newPlainText(label, text))
    }

    private fun buildNotification(): Notification {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("neo", "NeoPanel", NotificationManager.IMPORTANCE_MIN)
        )
        return Notification.Builder(this, "neo")
            .setContentTitle("NeoPanel aktif")
            .setSmallIcon(android.R.drawable.ic_menu_manage)
            .build()
    }

    private fun SpannableStringBuilder.addSpan(t: String, color: Int, rel: Float = 1f) {
        val s = length
        append(t)
        setSpan(ForegroundColorSpan(color), s, length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        if (rel != 1f) setSpan(RelativeSizeSpan(rel), s, length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
    }

    private fun darkBg(radius: Int, alpha: Int = 0xF2) =
        GradientDrawable(
            GradientDrawable.Orientation.TL_BR,
            intArrayOf((alpha shl 24) or 0x1B2030, (alpha shl 24) or 0x121521)
        ).apply { cornerRadius = dp(radius).toFloat() }

    private fun glowFrame(content: View, radius: Int): FrameLayout = FrameLayout(this).apply {
        setPadding(dp(2), dp(2), dp(2), dp(2))
        background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(accent, accent2))
            .apply { cornerRadius = dp(radius + 2).toFloat() }
        addView(content)
    }

    private fun pill(label: String, primary: Boolean = false, onClick: () -> Unit): TextView =
        TextView(this).apply {
            text = label
            textSize = 12f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(textColor)
            gravity = Gravity.CENTER
            setPadding(dp(14), dp(10), dp(14), dp(10))
            val colors = if (primary) intArrayOf(accent, accent2)
            else intArrayOf(0xFF2A3045.toInt(), 0xFF1A1E2D.toInt())
            background = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, colors)
                .apply { cornerRadius = dp(14).toFloat() }
            setOnClickListener { onClick() }
        }

    private fun windowHeader(title: String, onClose: () -> Unit): Pair<LinearLayout, TextView> {
        val tv = TextView(this).apply {
            text = title
            textSize = 12f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(textColor)
        }
        val close = TextView(this).apply {
            text = "✕"
            textSize = 16f
            setTextColor(textColor)
            setPadding(dp(12), 0, dp(4), 0)
            setOnClickListener { onClose() }
        }
        val h = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(6), dp(2), dp(6), dp(8))
        }
        h.addView(tv, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        h.addView(close)
        return Pair(h, tv)
    }

    private fun windowColumn(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(8), dp(8), dp(8), dp(8))
        background = darkBg(22)
    }

    private fun openWindow(
        inner: View, header: View, w: Int, h: Int, focusable: Boolean, x: Int, y: Int
    ): View {
        val root = glowFrame(inner, 22)
        val flags = if (focusable) (fModal or fLimits) else (fNoFocus or fLimits)
        val p = lp(w, h, flags)
        p.gravity = Gravity.TOP or Gravity.START
        p.x = x
        p.y = y
        if (focusable) p.softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN
        makeDraggable(header, root, p)
        root.alpha = 0f
        root.scaleX = 0.92f
        root.scaleY = 0.92f
        wm.addView(root, p)
        root.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(220)
            .setInterpolator(DecelerateInterpolator()).start()
        return root
    }

    private fun makeDraggable(dragHandle: View, window: View, p: WindowManager.LayoutParams) {
        var sx = 0f
        var sy = 0f
        var ox = 0
        var oy = 0
        dragHandle.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ox = p.x; oy = p.y }
                MotionEvent.ACTION_MOVE -> {
                    p.x = ox + (e.rawX - sx).toInt()
                    p.y = oy + (e.rawY - sy).toInt()
                    try { wm.updateViewLayout(window, p) } catch (ex: Exception) { }
                }
            }
            true
        }
    }

    private fun seekRow(title: String, lo: Int, hi: Int, value: Int, onChange: (Int) -> Unit): View {
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(TextView(this).apply {
            text = title
            textSize = 11f
            setTextColor(gray)
            setPadding(dp(4), dp(8), 0, 0)
        })
        val sb = SeekBar(this)
        sb.max = hi - lo
        sb.progress = (value - lo).coerceIn(0, hi - lo)
        sb.progressTintList = ColorStateList.valueOf(accent)
        sb.thumbTintList = ColorStateList.valueOf(accent2)
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                if (fromUser) onChange(p + lo)
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        col.addView(sb)
        return col
    }

    // ================= info sistem =================

    private fun battery(): Pair<Int, Int> {
        val i = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val lvl = i?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = i?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        val temp = (i?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0) / 10
        return Pair(if (lvl < 0) 0 else lvl * 100 / scale, temp)
    }

    private fun memInfo(): ActivityManager.MemoryInfo {
        val mi = ActivityManager.MemoryInfo()
        getSystemService(ActivityManager::class.java).getMemoryInfo(mi)
        return mi
    }

    private fun ramPct(): Int {
        val mi = memInfo()
        return (100 - mi.availMem * 100 / mi.totalMem).toInt()
    }

    private fun hasDump() =
        checkSelfPermission("android.permission.DUMP") == PackageManager.PERMISSION_GRANTED

    // ================= tombol gestur (handle) =================

    private fun handleSize() = dp(prefs.getInt("hsize", 46))
    private fun handleRight() = prefs.getBoolean("hright", true)

    private fun addHandle() {
        val size = handleSize()
        val v = TextView(this).apply {
            text = "✦"
            setTextSize(TypedValue.COMPLEX_UNIT_PX, size * 0.45f)
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(accent, accent2)).apply {
                shape = GradientDrawable.OVAL
                setStroke(dp(2), 0x66FFFFFF)
            }
            alpha = prefs.getInt("halpha", 85) / 100f
        }
        for (prop in arrayOf("scaleX", "scaleY")) {
            handleAnims.add(ObjectAnimator.ofFloat(v, prop, 1f, 1.1f).apply {
                duration = 1300
                repeatCount = ValueAnimator.INFINITE
                repeatMode = ValueAnimator.REVERSE
                start()
            })
        }
        val p = lp(size, size, fNoFocus or fLimits)
        p.gravity = Gravity.TOP or Gravity.START
        p.x = if (handleRight()) screenW() - size else 0
        p.y = (prefs.getFloat("hy", 0.45f) * screenH()).toInt().coerceIn(0, screenH() - size)

        var sx = 0f
        var sy = 0f
        var ox = 0
        var oy = 0
        var dragging = false
        v.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    sx = e.rawX; sy = e.rawY; ox = p.x; oy = p.y; dragging = false
                    v.animate().alpha(1f).setDuration(120).start()
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - sx
                    val dy = e.rawY - sy
                    if (!dragging && (Math.abs(dx) > dp(8) || Math.abs(dy) > dp(8))) dragging = true
                    if (dragging) {
                        p.x = (ox + dx).toInt().coerceIn(0, screenW() - size)
                        p.y = (oy + dy).toInt().coerceIn(0, screenH() - size)
                        try { wm.updateViewLayout(v, p) } catch (ex: Exception) { }
                    }
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    v.animate().alpha(prefs.getInt("halpha", 85) / 100f).setDuration(300).start()
                    if (dragging) snapHandle(v, p, size)
                    else if (e.actionMasked == MotionEvent.ACTION_UP) {
                        if (panel == null) showPanel() else closePanel()
                    }
                }
            }
            true
        }
        wm.addView(v, p)
        handle = v
    }

    private fun snapHandle(v: View, p: WindowManager.LayoutParams, size: Int) {
        val right = p.x + size / 2 > screenW() / 2
        val target = if (right) screenW() - size else 0
        prefs.edit().putBoolean("hright", right)
            .putFloat("hy", p.y.toFloat() / screenH()).apply()
        ValueAnimator.ofInt(p.x, target).apply {
            duration = 180
            addUpdateListener {
                p.x = it.animatedValue as Int
                try { wm.updateViewLayout(v, p) } catch (e: Exception) { }
            }
            start()
        }
    }

    private fun rebuildHandle() {
        handleAnims.forEach { it.cancel() }
        handleAnims.clear()
        safeRemove(handle)
        handle = null
        addHandle()
    }

    // ================= panel utama =================

    private fun tile(
        emoji: String, label: String, active: Boolean,
        onLong: (() -> Unit)? = null, onClick: () -> Unit
    ): TextView {
        val sb = SpannableStringBuilder()
        sb.append(emoji)
        sb.setSpan(RelativeSizeSpan(1.7f), 0, emoji.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        sb.append("\n").append(label)
        return TextView(this).apply {
            text = sb
            setTextColor(textColor)
            textSize = 10f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            minHeight = dp(78)
            setPadding(dp(4), dp(10), dp(4), dp(8))
            val colors = if (active) intArrayOf(accent, accent2)
            else intArrayOf(0xFF2A3045.toInt(), 0xFF1A1E2D.toInt())
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR, colors).apply {
                cornerRadius = dp(18).toFloat()
                setStroke(dp(1), if (active) 0x66FFFFFF else 0x22FFFFFF)
            }
            setOnTouchListener { v, e ->
                when (e.actionMasked) {
                    MotionEvent.ACTION_DOWN ->
                        v.animate().scaleX(0.93f).scaleY(0.93f).setDuration(80).start()
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL ->
                        v.animate().scaleX(1f).scaleY(1f).setDuration(120).start()
                }
                false
            }
            setOnClickListener { onClick() }
            if (onLong != null) setOnLongClickListener { onLong(); true }
        }
    }

    private fun cell() = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        .apply { setMargins(dp(4), dp(4), dp(4), dp(4)) }

    private fun rowOf(vararg vs: View): LinearLayout {
        val r = LinearLayout(this)
        r.orientation = LinearLayout.HORIZONTAL
        for (v in vs) r.addView(v, cell())
        return r
    }

    private fun dndOn(): Boolean {
        val nm = getSystemService(NotificationManager::class.java)
        return nm.isNotificationPolicyAccessGranted &&
            nm.currentInterruptionFilter == NotificationManager.INTERRUPTION_FILTER_ALARMS
    }

    private fun showPanel() {
        if (panel != null) return
        val tiles = ArrayList<View>()
        fun t(v: TextView): TextView { tiles.add(v); return v }

        val inner = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(10), dp(14), dp(10), dp(10))
            background = darkBg(26)
        }
        inner.addView(TextView(this).apply {
            text = "NEO PANEL"
            textSize = 16f
            typeface = Typeface.DEFAULT_BOLD
            letterSpacing = 0.12f
            setTextColor(textColor)
            setPadding(dp(8), 0, dp(8), 0)
        })
        val bt = battery()
        inner.addView(TextView(this).apply {
            text = "RAM ${ramPct()}%  ·  ${bt.second}°C  ·  ${bt.first}%"
            textSize = 11f
            setTextColor(gray)
            setPadding(dp(8), dp(2), dp(8), dp(8))
        })

        inner.addView(rowOf(
            t(tile("🎯", "Crosshair", crosshair != null, onLong = { cycleCrosshair() }) {
                closePanel(); toggleCrosshair()
            }),
            t(tile("🔕", "Jangan Ganggu", dndOn()) { closePanel(); toggleDnd() }),
            t(tile("📊", "FPS · Ping", hud != null) { closePanel(); toggleStats() })
        ))
        inner.addView(rowOf(
            t(tile("🌐", "Browser", browser != null) { closePanel(); toggleBrowser() }),
            t(tile("📝", "Catatan", notesWin != null) { closePanel(); toggleNotes() }),
            t(tile("🧮", "Kalkulator", calc != null) { closePanel(); toggleCalc() })
        ))
        inner.addView(rowOf(
            t(tile("⏱️", "Stopwatch", swWin != null) { closePanel(); toggleStopwatch() }),
            t(tile("🔦", "Senter", torchOn) { closePanel(); toggleTorch() }),
            t(tile("🚀", "Bersihkan RAM", false) { closePanel(); cleanRam() })
        ))
        inner.addView(rowOf(
            t(tile("☀️", "Layar Aktif", awakeView != null) { closePanel(); toggleAwake() }),
            t(tile("🔒", "Kunci Sentuh", lockView != null) { closePanel(); toggleLock() }),
            t(tile("⚙️", "Pengaturan", settingsWin != null) { closePanel(); toggleSettings() })
        ))

        val am = getSystemService(AudioManager::class.java)
        inner.addView(seekRow(
            "🔊 Volume media", 0, am.getStreamMaxVolume(AudioManager.STREAM_MUSIC),
            am.getStreamVolume(AudioManager.STREAM_MUSIC)
        ) { am.setStreamVolume(AudioManager.STREAM_MUSIC, it, 0) })

        inner.addView(TextView(this).apply {
            text = "Tahan Crosshair untuk ganti gaya  ·  seret tombol ✦ untuk memindah"
            textSize = 10f
            gravity = Gravity.CENTER
            setTextColor(gray)
            setPadding(0, dp(8), 0, dp(2))
        })
        inner.addView(TextView(this).apply {
            text = "Keluar"
            textSize = 12f
            gravity = Gravity.CENTER
            setTextColor(cRed)
            setPadding(0, dp(8), 0, dp(6))
            setOnClickListener { stopSelf() }
        })

        val sv = ScrollView(this)
        sv.isVerticalScrollBarEnabled = false
        sv.addView(inner)
        val root = glowFrame(sv, 26)

        val right = handleRight()
        val p = lp(dp(300), wrap, fNoFocus or fModal or fOutside)
        p.gravity = (if (right) Gravity.END else Gravity.START) or Gravity.CENTER_VERTICAL
        p.x = dp(8)
        root.setOnTouchListener { _, e ->
            if (e.action == MotionEvent.ACTION_OUTSIDE) { closePanel(); true } else false
        }

        root.alpha = 0f
        root.translationX = dp(40).toFloat() * (if (right) 1 else -1)
        wm.addView(root, p)
        panel = root
        root.animate().alpha(1f).translationX(0f).setDuration(220)
            .setInterpolator(DecelerateInterpolator()).start()
        tiles.forEachIndexed { i, v ->
            v.alpha = 0f
            v.translationY = dp(14).toFloat()
            v.animate().alpha(1f).translationY(0f)
                .setStartDelay(60L + i * 35L).setDuration(220)
                .setInterpolator(DecelerateInterpolator()).start()
        }
    }

    private fun closePanel(animated: Boolean = true) {
        val v = panel ?: return
        panel = null
        if (!animated) { safeRemove(v); return }
        val dir = if (handleRight()) 1 else -1
        v.animate().alpha(0f).translationX(dp(30).toFloat() * dir).setDuration(150)
            .withEndAction { safeRemove(v) }.start()
    }

    // ================= pengaturan =================

    private fun toggleSettings() {
        if (settingsWin != null) { closeView(settingsWin); settingsWin = null; return }
        val (header, _) = windowHeader("⚙️ Pengaturan") { closeView(settingsWin); settingsWin = null }
        val inner = windowColumn()
        inner.addView(header)

        inner.addView(TextView(this).apply {
            text = "Tema warna"
            textSize = 11f
            setTextColor(gray)
            setPadding(dp(4), dp(4), 0, 0)
        })
        val themeRow = LinearLayout(this)
        themeRow.orientation = LinearLayout.HORIZONTAL
        val cur = prefs.getInt("theme", 0)
        themes.forEachIndexed { i, th ->
            val dot = View(this)
            dot.background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(th.first, th.second)).apply {
                shape = GradientDrawable.OVAL
                setStroke(dp(2), if (cur == i) 0xFFFFFFFF.toInt() else 0x33FFFFFF)
            }
            dot.setOnClickListener {
                prefs.edit().putInt("theme", i).apply()
                accent = th.first
                accent2 = th.second
                rebuildHandle()
                closeView(settingsWin); settingsWin = null
                toast("Tema diganti. Buka ulang jendela agar warnanya berubah.")
            }
            val lpd = LinearLayout.LayoutParams(dp(34), dp(34))
            lpd.setMargins(dp(5), dp(6), dp(5), dp(6))
            themeRow.addView(dot, lpd)
        }
        inner.addView(themeRow)

        inner.addView(seekRow("Ukuran tombol ✦", 32, 72, prefs.getInt("hsize", 46)) {
            prefs.edit().putInt("hsize", it).apply()
            rebuildHandle()
        })
        inner.addView(seekRow("Transparansi tombol ✦", 20, 100, prefs.getInt("halpha", 85)) {
            prefs.edit().putInt("halpha", it).apply()
            handle?.alpha = it / 100f
        })

        val reset = pill("Reset posisi tombol") {
            prefs.edit().putBoolean("hright", true).putFloat("hy", 0.45f).apply()
            rebuildHandle()
            toast("Posisi tombol direset")
        }
        val rlp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        rlp.setMargins(0, dp(12), 0, dp(4))
        inner.addView(reset, rlp)

        settingsWin = openWindow(inner, header, dp(290), wrap, false, dp(30), dp(110))
    }

    // ================= crosshair =================

    private inner class CrossView : View(this@OverlayService) {
        var shape = 0
        var color = 0
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG)

        override fun onDraw(canvas: Canvas) {
            paint.color = color
            paint.strokeWidth = dp(2).toFloat()
            val cx = width / 2f
            val cy = height / 2f
            val gap = dp(4).toFloat()
            val len = dp(11).toFloat()
            paint.style = Paint.Style.STROKE
            when (shape) {
                0, 3 -> {
                    canvas.drawLine(cx - gap - len, cy, cx - gap, cy, paint)
                    canvas.drawLine(cx + gap, cy, cx + gap + len, cy, paint)
                    canvas.drawLine(cx, cy - gap - len, cx, cy - gap, paint)
                    canvas.drawLine(cx, cy + gap, cx, cy + gap + len, paint)
                }
                2 -> canvas.drawCircle(cx, cy, dp(10).toFloat(), paint)
            }
            if (shape == 1 || shape == 2 || shape == 3) {
                paint.style = Paint.Style.FILL
                canvas.drawCircle(cx, cy, dp(2).toFloat(), paint)
            }
        }
    }

    private fun applyXh(v: CrossView) {
        val idx = prefs.getInt("xh", 0)
        v.shape = idx % 4
        v.color = xhColors[(idx / 4) % xhColors.size]
        v.invalidate()
    }

    private fun cycleCrosshair() {
        val total = 4 * xhColors.size
        val idx = (prefs.getInt("xh", 0) + 1) % total
        prefs.edit().putInt("xh", idx).apply()
        crosshair?.let { applyXh(it) }
        toast("Gaya crosshair ${idx + 1}/$total")
    }

    private fun toggleCrosshair() {
        if (crosshair != null) {
            safeRemove(crosshair)
            crosshair = null
            return
        }
        val v = CrossView()
        applyXh(v)
        val p = lp(dp(48), dp(48), fNoFocus or fNoTouch or fLimits)
        p.gravity = Gravity.CENTER
        wm.addView(v, p)
        crosshair = v
    }

    // ================= jangan ganggu =================

    private fun toggleDnd() {
        val nm = getSystemService(NotificationManager::class.java)
        if (!nm.isNotificationPolicyAccessGranted) {
            toast("Beri izin Jangan Ganggu dulu")
            startActivity(
                Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
            return
        }
        val on = nm.currentInterruptionFilter == NotificationManager.INTERRUPTION_FILTER_ALARMS
        nm.setInterruptionFilter(
            if (on) NotificationManager.INTERRUPTION_FILTER_ALL
            else NotificationManager.INTERRUPTION_FILTER_ALARMS
        )
        toast(if (on) "Jangan Ganggu mati" else "Jangan Ganggu nyala")
    }

    // ================= senter, layar aktif, kunci sentuh =================

    private fun toggleTorch() {
        try {
            val cm = getSystemService(CameraManager::class.java)
            val id = cm.cameraIdList.firstOrNull {
                cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            } ?: run { toast("Perangkat tidak punya senter"); return }
            torchOn = !torchOn
            cm.setTorchMode(id, torchOn)
            toast(if (torchOn) "Senter nyala" else "Senter mati")
        } catch (e: Exception) {
            torchOn = false
            toast("Senter gagal dinyalakan")
        }
    }

    private fun toggleAwake() {
        if (awakeView != null) {
            safeRemove(awakeView)
            awakeView = null
            toast("Layar kembali normal")
            return
        }
        val v = View(this)
        val p = lp(1, 1, fNoFocus or fNoTouch or fKeepOn)
        p.gravity = Gravity.TOP or Gravity.START
        wm.addView(v, p)
        awakeView = v
        toast("Layar tetap menyala")
    }

    private fun toggleLock() {
        if (lockView != null) {
            safeRemove(lockView)
            lockView = null
            return
        }
        val root = FrameLayout(this)
        root.setBackgroundColor(0x01000000)
        root.setOnTouchListener { _, _ -> true }
        val hint = TextView(this).apply {
            text = "🔒  Tahan untuk membuka"
            textSize = 12f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(textColor)
            setPadding(dp(18), dp(12), dp(18), dp(12))
            background = GradientDrawable().apply {
                setColor(0xCC141824.toInt())
                cornerRadius = dp(20).toFloat()
                setStroke(dp(1), 0x5500E5FF)
            }
            setOnClickListener { }
            setOnLongClickListener { toggleLock(); true }
        }
        val hl = FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT,
            Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
        )
        hl.bottomMargin = dp(70)
        root.addView(hint, hl)
        val p = lp(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT, fNoFocus or fLimits)
        wm.addView(root, p)
        lockView = root
        toast("Sentuhan dikunci")
    }

    // ================= bersihkan RAM =================

    private fun cleanRam() {
        val am = getSystemService(ActivityManager::class.java)
        val before = memInfo().availMem / 1048576
        var n = 0
        for (ai in packageManager.getInstalledApplications(0)) {
            if (ai.packageName == packageName) continue
            if ((ai.flags and ApplicationInfo.FLAG_SYSTEM) != 0) continue
            try { am.killBackgroundProcesses(ai.packageName); n++ } catch (e: Exception) { }
        }
        main.postDelayed({
            val after = memInfo().availMem / 1048576
            toast("$n app ditutup · RAM bebas $before → $after MB")
        }, 900)
    }

    // ================= HUD FPS / ping / ms =================

    private inner class GraphView : View(this@OverlayService) {
        private val n = 40
        private val f = IntArray(n)
        private val m = IntArray(n)
        private var idx = 0
        private val pf = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = dp(2).toFloat()
            color = cGreen
        }
        private val pm = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = dp(1).toFloat()
            color = accent2
        }

        fun push(fv: Int, pv: Int) {
            f[idx] = fv
            m[idx] = pv
            idx = (idx + 1) % n
            invalidate()
        }

        override fun onDraw(canvas: Canvas) {
            val w = width.toFloat()
            val h = height.toFloat()
            line(canvas, f, 120, pf, w, h)
            line(canvas, m, 200, pm, w, h)
        }

        private fun line(canvas: Canvas, d: IntArray, max: Int, paint: Paint, w: Float, h: Float) {
            val path = Path()
            for (k in 0 until n) {
                val i = (idx + k) % n
                val x = k * w / (n - 1)
                val y = h - (d[i].coerceIn(0, max) / max.toFloat()) * h
                if (k == 0) path.moveTo(x, y) else path.lineTo(x, y)
            }
            canvas.drawPath(path, paint)
        }
    }

    private val frameCb = object : Choreographer.FrameCallback {
        override fun doFrame(frameTimeNanos: Long) {
            frames++
            if (running && useChoreo) Choreographer.getInstance().postFrameCallback(this)
            else choreoActive = false
        }
    }

    private val tick = object : Runnable {
        override fun run() {
            if (!running) return
            val s = hudText ?: return
            if (useChoreo) { uiFps = frames; frames = 0 }
            val real = realFps
            val fps = if (real >= 0) real else uiFps
            val fpsColor = when {
                fps >= 50 -> cGreen
                fps >= 30 -> cYellow
                else -> cRed
            }
            val pg = ping
            val msColor = when {
                pg < 0 -> gray
                pg < 60 -> cGreen
                pg < 120 -> cYellow
                else -> cRed
            }
            val sb = SpannableStringBuilder()
            sb.addSpan("$fps", fpsColor, 1.6f)
            sb.addSpan(if (real >= 0) " FPS   " else " FPS*   ", gray, 0.8f)
            sb.addSpan(if (pg < 0) "--" else "$pg", msColor, 1.6f)
            sb.addSpan(" ms", gray, 0.8f)
            val bt = battery()
            sb.addSpan("\nRAM ${ramPct()}%  ·  ${bt.second}°C  ·  ${bt.first}%", gray, 0.75f)
            s.text = sb
            hudGraph?.push(fps, if (pg < 0) 0 else pg.toInt())
            main.postDelayed(this, 1000)
        }
    }

    private fun toggleStats() {
        if (hud != null) {
            running = false
            main.removeCallbacks(tick)
            safeRemove(hud)
            hud = null
            hudText = null
            hudGraph = null
            return
        }
        val txt = TextView(this)
        txt.text = "..."
        txt.textSize = 12f
        txt.setTextColor(textColor)
        txt.typeface = Typeface.DEFAULT_BOLD
        val g = GraphView()
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(12), dp(8), dp(14), dp(8))
        box.background = GradientDrawable().apply {
            setColor(0xD9141824.toInt())
            cornerRadius = dp(16).toFloat()
            setStroke(dp(1), 0x5500E5FF)
        }
        box.addView(txt)
        val glp = LinearLayout.LayoutParams(dp(150), dp(30))
        glp.topMargin = dp(4)
        box.addView(g, glp)

        val p = lp(wrap, wrap, fNoFocus or fLimits)
        p.gravity = Gravity.TOP or Gravity.START
        p.x = dp(12)
        p.y = dp(40)
        makeDraggable(box, box, p)
        box.alpha = 0f
        wm.addView(box, p)
        box.animate().alpha(1f).setDuration(250).start()
        hud = box
        hudText = txt
        hudGraph = g

        running = true
        frames = 0
        useChoreo = !hasDump()
        if (useChoreo && !choreoActive) {
            choreoActive = true
            Choreographer.getInstance().postFrameCallback(frameCb)
        }
        main.removeCallbacks(tick)
        main.postDelayed(tick, 700)
        startPing()
        startFpsThread()
    }

    private fun startPing() {
        if (pingThread?.isAlive == true) return
        pingThread = Thread {
            while (running) {
                val t0 = System.nanoTime()
                ping = try {
                    Socket().use { it.connect(InetSocketAddress("1.1.1.1", 443), 1500) }
                    (System.nanoTime() - t0) / 1_000_000
                } catch (e: Exception) {
                    -1L
                }
                try { Thread.sleep(2000) } catch (e: InterruptedException) { return@Thread }
            }
        }.also { it.start() }
    }

    private fun startFpsThread() {
        if (fpsThread?.isAlive == true) return
        fpsThread = Thread {
            var layer: String? = null
            var lastScan = 0L
            while (running) {
                if (hasDump()) {
                    val now = System.nanoTime()
                    if (lastScan == 0L || now - lastScan > 5_000_000_000L) {
                        val fg = foregroundPkg()
                        if (fg != null && fg != packageName) layer = findLayer(fg)
                        lastScan = now
                    }
                    realFps = layer?.let { readFps(it) } ?: -1
                } else {
                    realFps = -1
                }
                try { Thread.sleep(1000) } catch (e: InterruptedException) { return@Thread }
            }
        }.also { it.start() }
    }

    private fun foregroundPkg(): String? {
        return try {
            val p = ProcessBuilder("/system/bin/dumpsys", "activity", "activities")
                .redirectErrorStream(true).start()
            val br = p.inputStream.bufferedReader()
            val re = Regex("""ActivityRecord\{\S+ u\d+ ([\w.]+)/""")
            var pkg: String? = null
            var line = br.readLine()
            while (line != null) {
                if (line.contains("ResumedActivity")) {
                    val m = re.find(line)
                    if (m != null) { pkg = m.groupValues[1]; break }
                }
                line = br.readLine()
            }
            p.destroy()
            pkg
        } catch (e: Exception) {
            null
        }
    }

    private fun findLayer(pkg: String): String? {
        return try {
            val p = ProcessBuilder("/system/bin/dumpsys", "SurfaceFlinger", "--list")
                .redirectErrorStream(true).start()
            val layers = p.inputStream.bufferedReader().readLines().map { it.trim() }
            p.destroy()
            val c = layers.filter { it.contains(pkg) }
            c.firstOrNull { it.contains("SurfaceView") && it.contains("BLAST") }
                ?: c.firstOrNull { it.contains("SurfaceView") }
                ?: c.firstOrNull { it.contains("$pkg/") }
                ?: c.firstOrNull()
        } catch (e: Exception) {
            null
        }
    }

    private fun readFps(layer: String): Int? {
        return try {
            val p = ProcessBuilder("/system/bin/dumpsys", "SurfaceFlinger", "--latency", layer)
                .redirectErrorStream(true).start()
            val lines = p.inputStream.bufferedReader().readLines()
            p.destroy()
            val now = System.nanoTime()
            var count = 0
            var valid = 0
            for (i in 1 until lines.size) {
                val parts = lines[i].trim().split(Regex("\\s+"))
                if (parts.size < 3) continue
                val t = parts[1].toLongOrNull() ?: continue
                if (t <= 0L || t == Long.MAX_VALUE) continue
                valid++
                if (t > now - 1_000_000_000L && t <= now + 200_000_000L) count++
            }
            if (valid == 0) null else count
        } catch (e: Exception) {
            null
        }
    }

    // ================= catatan =================

    private fun loadNotes(): JSONArray = try {
        JSONArray(prefs.getString("notes", "[]"))
    } catch (e: Exception) {
        JSONArray()
    }

    private fun saveNotes(a: JSONArray) {
        prefs.edit().putString("notes", a.toString()).apply()
    }

    private fun toggleNotes() {
        if (notesWin != null) { closeNotes(); return }
        val (header, title) = windowHeader("📝 Catatan") { closeNotes() }
        notesTitle = title
        val body = LinearLayout(this)
        body.orientation = LinearLayout.VERTICAL
        notesBody = body
        val inner = windowColumn()
        inner.addView(header)
        inner.addView(body)
        notesWin = openWindow(inner, header, dp(300), wrap, true, dp(24), dp(90))
        notesShowList()
    }

    private fun closeNotes() {
        closeView(notesWin)
        notesWin = null
        notesBody = null
        notesTitle = null
    }

    private fun notesShowList() {
        val body = notesBody ?: return
        body.removeAllViews()
        notesTitle?.text = "📝 Catatan"
        body.addView(pill("＋  Catatan baru", true) {
            val old = loadNotes()
            val na = JSONArray()
            na.put(JSONObject().put("t", "").put("ts", System.currentTimeMillis()))
            for (i in 0 until old.length()) na.put(old.get(i))
            saveNotes(na)
            notesShowEditor(0)
        })
        val arr = loadNotes()
        val list = LinearLayout(this)
        list.orientation = LinearLayout.VERTICAL
        if (arr.length() == 0) {
            list.addView(TextView(this).apply {
                text = "Belum ada catatan."
                setTextColor(gray)
                textSize = 12f
                setPadding(dp(8), dp(14), dp(8), dp(14))
            })
        }
        val fmt = SimpleDateFormat("d MMM HH:mm", Locale.getDefault())
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            val raw = o.optString("t", "").trim()
            val preview = if (raw.isEmpty()) "(kosong)" else raw.lines().first().take(42)
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER_VERTICAL
            row.setPadding(dp(12), dp(10), dp(8), dp(10))
            row.background = GradientDrawable().apply {
                setColor(0xFF1E2233.toInt())
                cornerRadius = dp(14).toFloat()
            }
            row.setOnClickListener { notesShowEditor(i) }
            val col = LinearLayout(this)
            col.orientation = LinearLayout.VERTICAL
            col.addView(TextView(this).apply {
                text = preview
                setTextColor(textColor)
                textSize = 13f
                maxLines = 1
            })
            col.addView(TextView(this).apply {
                text = fmt.format(Date(o.optLong("ts", 0L)))
                setTextColor(gray)
                textSize = 10f
            })
            row.addView(col, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            val del = TextView(this)
            del.text = "🗑"
            del.textSize = 16f
            del.setPadding(dp(12), dp(4), dp(8), dp(4))
            del.setOnClickListener {
                val a2 = loadNotes()
                a2.remove(i)
                saveNotes(a2)
                notesShowList()
            }
            row.addView(del)
            val rlp = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
            )
            rlp.setMargins(0, dp(4), 0, dp(4))
            list.addView(row, rlp)
        }
        val sv = ScrollView(this)
        sv.addView(list)
        body.addView(sv, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(240)))
    }

    private fun notesShowEditor(idx: Int) {
        val body = notesBody ?: return
        body.removeAllViews()
        notesTitle?.text = "✏️ Edit catatan"
        val arr = loadNotes()
        val o = arr.optJSONObject(idx)
        if (o == null) { notesShowList(); return }
        val et = EditText(this)
        et.setText(o.optString("t", ""))
        et.hint = "Tulis di sini..."
        et.setHintTextColor(0xFF7A8099.toInt())
        et.setTextColor(textColor)
        et.textSize = 14f
        et.gravity = Gravity.TOP or Gravity.START
        et.minLines = 8
        et.maxLines = 12
        et.setPadding(dp(12), dp(10), dp(12), dp(10))
        et.background = GradientDrawable().apply {
            setColor(0xFF1E2233.toInt())
            cornerRadius = dp(14).toFloat()
        }
        et.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) {
                o.put("t", s?.toString() ?: "")
                o.put("ts", System.currentTimeMillis())
                saveNotes(arr)
            }
        })
        body.addView(et, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
        ))
        val actions = LinearLayout(this)
        actions.orientation = LinearLayout.HORIZONTAL
        actions.addView(pill("← Kembali") { notesShowList() }, cell())
        actions.addView(pill("Salin") {
            copyText("catatan", et.text.toString())
            toast("Catatan disalin")
        }, cell())
        body.addView(actions)
        et.requestFocus()
    }

    // ================= stopwatch =================

    private fun swElapsed(): Long =
        swAcc + (if (swRunning) SystemClock.elapsedRealtime() - swBase else 0L)

    private fun swFmt(ms: Long): String =
        String.format(Locale.US, "%02d:%02d.%02d", ms / 60000, (ms / 1000) % 60, (ms / 10) % 100)

    private val swTick = object : Runnable {
        override fun run() {
            val t = swText ?: return
            t.text = swFmt(swElapsed())
            if (swRunning) main.postDelayed(this, 50)
        }
    }

    private fun toggleStopwatch() {
        if (swWin != null) {
            swRunning = false
            main.removeCallbacks(swTick)
            closeView(swWin)
            swWin = null
            swText = null
            return
        }
        swAcc = 0L
        swRunning = false
        val (header, _) = windowHeader("⏱️ Stopwatch") { toggleStopwatch() }
        val time = TextView(this)
        time.text = "00:00.00"
        time.textSize = 34f
        time.typeface = Typeface.DEFAULT_BOLD
        time.setTextColor(textColor)
        time.gravity = Gravity.CENTER
        time.setPadding(0, dp(8), 0, dp(10))
        swText = time

        val startBtn = pill("Mulai", true) { }
        startBtn.setOnClickListener {
            if (swRunning) {
                swAcc = swElapsed()
                swRunning = false
                startBtn.text = "Lanjut"
            } else {
                swBase = SystemClock.elapsedRealtime()
                swRunning = true
                startBtn.text = "Jeda"
                main.post(swTick)
            }
        }
        val resetBtn = pill("Reset") {
            swAcc = 0L
            swBase = SystemClock.elapsedRealtime()
            time.text = swFmt(0L)
        }
        val actions = LinearLayout(this)
        actions.orientation = LinearLayout.HORIZONTAL
        actions.addView(startBtn, cell())
        actions.addView(resetBtn, cell())

        val inner = windowColumn()
        inner.addView(header)
        inner.addView(time)
        inner.addView(actions)
        swWin = openWindow(inner, header, dp(240), wrap, false, dp(40), dp(150))
    }

    // ================= kalkulator =================

    private fun toggleCalc() {
        if (calc != null) {
            closeView(calc)
            calc = null
            return
        }
        var acc = 0.0
        var op = ' '
        var cur = "0"
        var fresh = true

        val display = TextView(this)
        display.text = "0"
        display.textSize = 28f
        display.typeface = Typeface.DEFAULT_BOLD
        display.setTextColor(textColor)
        display.gravity = Gravity.END
        display.maxLines = 1
        display.setPadding(dp(8), dp(6), dp(12), dp(10))

        fun fmt(d: Double): String {
            if (d.isNaN()) return "NaN"
            val s = d.toString()
            return if (s.endsWith(".0")) s.dropLast(2) else s
        }

        fun calcResult(): Double {
            val b = cur.toDoubleOrNull() ?: 0.0
            return when (op) {
                '+' -> acc + b
                '-' -> acc - b
                '×' -> acc * b
                '÷' -> if (b == 0.0) Double.NaN else acc / b
                else -> b
            }
        }

        fun press(k: String) {
            val c = k[0]
            if (c.isDigit()) {
                if (fresh || cur == "NaN") { cur = k; fresh = false }
                else cur = if (cur == "0") k else cur + k
            } else when (k) {
                "." -> {
                    if (fresh || cur == "NaN") { cur = "0."; fresh = false }
                    else if (!cur.contains(".")) cur += "."
                }
                "C" -> { acc = 0.0; op = ' '; cur = "0"; fresh = true }
                "⌫" -> {
                    cur = if (cur.length > 1 && cur != "NaN") cur.dropLast(1) else "0"
                    if (cur == "-") cur = "0"
                }
                "%" -> cur = fmt((cur.toDoubleOrNull() ?: 0.0) / 100)
                "=" -> if (op != ' ') {
                    acc = calcResult()
                    cur = fmt(acc)
                    op = ' '
                    fresh = true
                }
                else -> {
                    if (!fresh) { acc = calcResult(); cur = fmt(acc) }
                    op = c
                    fresh = true
                }
            }
            display.text = if (cur == "NaN") "Error" else cur
        }

        fun key(label: String, isOp: Boolean): TextView {
            val kv = TextView(this)
            kv.text = label
            kv.textSize = 18f
            kv.typeface = Typeface.DEFAULT_BOLD
            kv.gravity = Gravity.CENTER
            kv.setTextColor(textColor)
            kv.setPadding(0, dp(12), 0, dp(12))
            val colors = if (isOp) intArrayOf(accent, accent2)
            else intArrayOf(0xFF2A3045.toInt(), 0xFF1A1E2D.toInt())
            kv.background = GradientDrawable(GradientDrawable.Orientation.TL_BR, colors)
                .apply { cornerRadius = dp(14).toFloat() }
            kv.setOnTouchListener { v, e ->
                when (e.actionMasked) {
                    MotionEvent.ACTION_DOWN ->
                        v.animate().scaleX(0.92f).scaleY(0.92f).setDuration(60).start()
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL ->
                        v.animate().scaleX(1f).scaleY(1f).setDuration(100).start()
                }
                false
            }
            kv.setOnClickListener { press(label) }
            return kv
        }

        val (header, _) = windowHeader("🧮 Kalkulator") { closeView(calc); calc = null }
        val inner = windowColumn()
        inner.addView(header)
        inner.addView(display)

        val rows = listOf(
            listOf("C" to 1f, "⌫" to 1f, "%" to 1f, "÷" to 1f),
            listOf("7" to 1f, "8" to 1f, "9" to 1f, "×" to 1f),
            listOf("4" to 1f, "5" to 1f, "6" to 1f, "-" to 1f),
            listOf("1" to 1f, "2" to 1f, "3" to 1f, "+" to 1f),
            listOf("0" to 2f, "." to 1f, "=" to 1f)
        )
        val ops = listOf("÷", "×", "-", "+", "=")
        for (r in rows) {
            val rowView = LinearLayout(this)
            rowView.orientation = LinearLayout.HORIZONTAL
            for ((label, w) in r) {
                val lpk = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, w)
                lpk.setMargins(dp(3), dp(3), dp(3), dp(3))
                rowView.addView(key(label, label in ops), lpk)
            }
            inner.addView(rowView)
        }
        calc = openWindow(inner, header, dp(250), wrap, false, dp(30), dp(120))
    }

    // ================= browser =================

    private fun toggleBrowser() {
        if (browser != null) {
            closeBrowser()
            return
        }
        val (header, _) = windowHeader("🌐 Browser") { closeBrowser() }
        val inner = windowColumn()

        val urlBox = EditText(this)
        urlBox.hint = "Cari atau ketik alamat"
        urlBox.setHintTextColor(0xFF7A8099.toInt())
        urlBox.setTextColor(textColor)
        urlBox.textSize = 13f
        urlBox.isSingleLine = true
        urlBox.imeOptions = EditorInfo.IME_ACTION_GO

        val wv = WebView(this)
        wv.settings.javaScriptEnabled = true
        wv.webViewClient = WebViewClient()
        wv.loadUrl("https://www.google.com")
        web = wv

        urlBox.setOnEditorActionListener { v, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_GO) {
                var u = v.text.toString().trim()
                if (!u.startsWith("http")) {
                    u = if (u.contains(".") && !u.contains(" ")) "https://$u"
                    else "https://www.google.com/search?q=" + Uri.encode(u)
                }
                wv.loadUrl(u)
                true
            } else false
        }

        inner.addView(header)
        inner.addView(urlBox)
        inner.addView(wv, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))
        browser = openWindow(inner, header, dp(300), dp(400), true, dp(20), dp(80))
    }

    private fun closeBrowser() {
        web?.destroy()
        web = null
        closeView(browser)
        browser = null
    }
}
