package com.neopanel.app

import android.animation.ObjectAnimator
import android.animation.ValueAnimator
import android.app.ActivityManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.BroadcastReceiver
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioAttributes
import android.media.AudioDeviceCallback
import android.media.AudioDeviceInfo
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioTrack
import android.net.TrafficStats
import android.net.Uri
import android.net.wifi.WifiManager
import android.os.BatteryManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.provider.Settings
import android.telecom.TelecomManager
import android.telephony.TelephonyManager
import android.text.Editable
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.TextUtils
import android.text.TextWatcher
import android.text.style.ForegroundColorSpan
import android.text.style.RelativeSizeSpan
import android.view.Choreographer
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.animation.DecelerateInterpolator
import android.view.inputmethod.EditorInfo
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Space
import android.widget.TextView
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject
import java.net.InetSocketAddress
import java.net.Socket
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class OverlayService : Service() {

    private lateinit var wm: WindowManager
    private val main = Handler(Looper.getMainLooper())
    private val prefs by lazy { getSharedPreferences("vexed", MODE_PRIVATE) }

    // ---- view / jendela ----
    private var handle: View? = null
    private val handleAnims = ArrayList<ObjectAnimator>()
    private var panel: View? = null
    private var crosshair: CrossView? = null
    private var hud: View? = null
    private var hudText: TextView? = null
    private var hudGraph: GraphView? = null
    private var browser: View? = null
    private var web: WebView? = null
    private var calc: View? = null
    private var notesWin: View? = null
    private var notesBody: LinearLayout? = null
    private var notesTitle: TextView? = null
    private var swWin: View? = null
    private var swText: TextView? = null
    private var sbWin: View? = null
    private var settingsWin: View? = null
    private var awakeView: View? = null
    private var lockView: View? = null
    private var robotWin: View? = null
    private var robotView: RobotView? = null
    private var robotParams: WindowManager.LayoutParams? = null
    private var chatWin: View? = null
    private var chatList: LinearLayout? = null
    private var chatScroll: ScrollView? = null
    private var bubbleWin: View? = null
    private var clockWin: View? = null
    private var launcherWin: View? = null
    private var crossWin: View? = null
    private var crossPreview: CrossView? = null
    private var crossParams: WindowManager.LayoutParams? = null
    private var panelHolder: ScrollView? = null
    private var panelParams: WindowManager.LayoutParams? = null
    private var closingPanel: View? = null
    private var panelClosedAt = 0L
    private var gamePkg: String? = null
    private var lastTickMs = 0L
    private val hudFmt = SimpleDateFormat("HH:mm:ss", Locale.getDefault())
    @Volatile private var fpsProc: Process? = null
    @Volatile private var streamLayer: String? = null
    @Volatile private var zeroRuns = 0
    @Volatile private var fpsPkg: String? = null
    @Volatile private var fpsNote = ""
    private var fpsReader: Thread? = null

    // ---- state ----
    private var selectedTab = 0
    private var hudDetail = false
    private var boostOn = false
    private var recording = false
    private var callBlock = false
    private var callRegistered = false
    private var headsetOnly = false
    private var devCb: AudioDeviceCallback? = null
    private var savedRing = -1
    private var savedNotif = -1
    private var lowLat: WifiManager.WifiLock? = null
    private var torchOn = false
    private var swRunning = false
    private var swBase = 0L
    private var swAcc = 0L

    @Volatile private var running = false
    @Volatile private var ping = -1L
    @Volatile private var loss = 0
    @Volatile private var jitter = 0
    @Volatile private var realFps = -1
    @Volatile private var cpuPct = -1
    @Volatile private var gpuPct = -1
    @Volatile private var tempC = -1
    private var prevTotal = 0L
    private var prevIdle = 0L
    private var rxPrev = -1L
    private var txPrev = -1L
    private var rxKb = 0L
    private var txKb = 0L
    private var frames = 0
    private var uiFps = 0
    private var useChoreo = false
    private var choreoActive = false
    private var pingThread: Thread? = null
    private var samplerThread: Thread? = null

    // ---- tema ----
    private val themes = listOf(
        0xFFFF2D55.toInt() to 0xFFFF7A18.toInt(),
        0xFF7C5CFF.toInt() to 0xFF00E5FF.toInt(),
        0xFF00E676.toInt() to 0xFF00E5FF.toInt(),
        0xFF00B0FF.toInt() to 0xFF7C5CFF.toInt(),
        0xFFFFC107.toInt() to 0xFFFF5252.toInt()
    )
    private var accent = 0xFFFF2D55.toInt()
    private var accent2 = 0xFFFF7A18.toInt()
    private val textColor = 0xFFE8EAF6.toInt()
    private val gray = 0xFF9AA0B5.toInt()
    private val cGreen = 0xFF3DFF9A.toInt()
    private val cYellow = 0xFFFFD43B.toInt()
    private val cRed = 0xFFFF5470.toInt()
    private val darkTop = 0xF2181B28.toInt()
    private val darkBottom = 0xF20D0F17.toInt()
    private val xhColors = intArrayOf(
        0xFF00FF88.toInt(), 0xFFFF3B5C.toInt(), 0xFF00E5FF.toInt(),
        0xFFFFE600.toInt(), 0xFFFFFFFF.toInt()
    )

    private val fNoFocus = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
    private val fNoTouch = WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
    private val fLimits = WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
    private val fModal = WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
    private val fOutside = WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH
    private val fHw = WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED
    private val fKeepOn = WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON
    private val wrap = WindowManager.LayoutParams.WRAP_CONTENT

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val th = themes[prefs.getInt("theme", 0).coerceIn(0, themes.size - 1)]
        accent = th.first
        accent2 = th.second
        startForeground(1, buildNotification())
        addHandle()
    }

    override fun onDestroy() {
        running = false
        swRunning = false
        recording = false
        main.removeCallbacks(tick)
        main.removeCallbacks(swTick)
        main.removeCallbacks(clockTick)
        main.removeCallbacks(companionTick)
        main.removeCallbacks(bubbleHide)
        stopStream()
        handleAnims.forEach { it.cancel() }
        closePanel(false)
        closeBrowser()
        for (v in listOf(calc, notesWin, swWin, sbWin, settingsWin, awakeView, lockView, crosshair, hud, handle,
            robotWin, chatWin, bubbleWin, clockWin, launcherWin, crossWin, closingPanel)) {
            safeRemove(v)
        }
        if (callRegistered) {
            try { unregisterReceiver(callReceiver) } catch (e: Exception) { }
        }
        val cb = devCb
        if (cb != null) {
            try { getSystemService(AudioManager::class.java).unregisterAudioDeviceCallback(cb) } catch (e: Exception) { }
        }
        headsetOnly = false
        applyHeadset()
        try { lowLat?.release() } catch (e: Exception) { }
        Thread { Sh.run("pkill -2 screenrecord 2>/dev/null") }.start()
        super.onDestroy()
    }

    // ================= util =================

    private fun dens() = resources.displayMetrics.density
    private fun dp(v: Int) = (v * dens()).toInt()
    private fun screenW() = resources.displayMetrics.widthPixels
    private fun screenH() = resources.displayMetrics.heightPixels

    private fun lp(w: Int, h: Int, flags: Int) = WindowManager.LayoutParams(
        w, h, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
        flags or fHw, PixelFormat.TRANSLUCENT
    )

    private fun safeRemove(v: View?) {
        if (v == null) return
        try { wm.removeView(v) } catch (e: Exception) { }
    }

    private fun closeView(v: View?) {
        if (v == null) return
        v.animate().alpha(0f).scaleX(0.92f).scaleY(0.92f).setDuration(130)
            .withEndAction { safeRemove(v) }.start()
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    private fun copyText(label: String, text: String) {
        getSystemService(ClipboardManager::class.java)
            .setPrimaryClip(ClipData.newPlainText(label, text))
    }

    private fun stamp() = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())

    private fun buildNotification(): Notification {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("vexed", "VeXed", NotificationManager.IMPORTANCE_MIN)
        )
        return Notification.Builder(this, "vexed")
            .setContentTitle("VeXed aktif")
            .setSmallIcon(android.R.drawable.ic_menu_manage)
            .build()
    }

    private fun SpannableStringBuilder.addSpan(t: String, color: Int, rel: Float = 1f) {
        val s = length
        append(t)
        setSpan(ForegroundColorSpan(color), s, length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        if (rel != 1f) setSpan(RelativeSizeSpan(rel), s, length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
    }

    private fun putSetting(ns: String, key: String, value: String): Boolean {
        if (Sh.ready()) {
            Sh.run("settings put $ns $key $value")
            return true
        }
        return try {
            when (ns) {
                "global" -> Settings.Global.putString(contentResolver, key, value)
                "secure" -> Settings.Secure.putString(contentResolver, key, value)
                else -> Settings.System.putString(contentResolver, key, value)
            }
        } catch (e: Exception) {
            false
        }
    }

    private fun sharpFrame(content: View, cut: Int = 14): FrameLayout {
        val f = FrameLayout(this)
        f.setPadding(dp(4), dp(4), dp(4), dp(4))
        f.background = ChamferDrawable(darkTop, darkBottom, accent, dp(cut).toFloat(), dens(), true)
        f.addView(content)
        return f
    }

    private fun pill(label: String, primary: Boolean = false, onClick: () -> Unit): TextView {
        val t = TextView(this)
        t.text = label
        t.textSize = 12f
        t.typeface = Typeface.DEFAULT_BOLD
        t.setTextColor(textColor)
        t.gravity = Gravity.CENTER
        t.setPadding(dp(14), dp(10), dp(14), dp(10))
        t.background = if (primary)
            ChamferDrawable(accent, accent2, 0xFFFFFFFF.toInt(), dp(8).toFloat(), dens(), false)
        else
            ChamferDrawable(0xFF262B3D.toInt(), 0xFF171A26.toInt(), 0xFF3A4057.toInt(), dp(8).toFloat(), dens(), false)
        t.setOnClickListener { onClick() }
        return t
    }

    private fun windowHeader(title: String, onClose: () -> Unit): Pair<LinearLayout, TextView> {
        val h = LinearLayout(this)
        h.orientation = LinearLayout.HORIZONTAL
        h.gravity = Gravity.CENTER_VERTICAL
        h.setPadding(dp(6), dp(2), dp(2), dp(8))
        h.addView(LogoView(this, textColor, accent), LinearLayout.LayoutParams(dp(16), dp(16)))
        val tv = TextView(this)
        tv.text = title
        tv.textSize = 12f
        tv.typeface = Typeface.DEFAULT_BOLD
        tv.letterSpacing = 0.08f
        tv.setTextColor(textColor)
        tv.setPadding(dp(8), 0, 0, 0)
        h.addView(tv, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        val close = IconView(this, Icons.CLOSE, textColor)
        close.setPadding(dp(5), dp(5), dp(5), dp(5))
        close.setOnClickListener { onClose() }
        h.addView(close, LinearLayout.LayoutParams(dp(28), dp(28)))
        return Pair(h, tv)
    }

    private fun windowColumn(): LinearLayout {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        c.setPadding(dp(10), dp(10), dp(10), dp(10))
        return c
    }

    private fun openWindow(
        inner: View, header: View, w: Int, h: Int, focusable: Boolean, x: Int, y: Int
    ): View {
        val root = sharpFrame(inner)
        val flags = if (focusable) (fModal or fLimits) else (fNoFocus or fLimits)
        val p = lp(w, h, flags)
        p.gravity = Gravity.TOP or Gravity.START
        p.x = x
        p.y = y
        if (focusable) p.softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN
        makeDraggable(header, root, p)
        root.alpha = 0f
        root.scaleX = 0.92f
        root.scaleY = 0.92f
        wm.addView(root, p)
        root.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(220)
            .setInterpolator(DecelerateInterpolator()).start()
        return root
    }

    private fun makeDraggable(dragView: View, window: View, p: WindowManager.LayoutParams) {
        makeDraggableTap(dragView, window, p) { }
    }

    private fun makeDraggableTap(
        dragView: View, window: View, p: WindowManager.LayoutParams,
        onEnd: (() -> Unit)? = null, onTap: () -> Unit
    ) {
        var sx = 0f
        var sy = 0f
        var ox = 0
        var oy = 0
        var moved = false
        dragView.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ox = p.x; oy = p.y; moved = false }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - sx
                    val dy = e.rawY - sy
                    if (!moved && (Math.abs(dx) > dp(6) || Math.abs(dy) > dp(6))) moved = true
                    if (moved) {
                        p.x = ox + dx.toInt()
                        p.y = oy + dy.toInt()
                        try { wm.updateViewLayout(window, p) } catch (ex: Exception) { }
                    }
                }
                MotionEvent.ACTION_UP -> { if (!moved) onTap() else onEnd?.invoke() }
            }
            true
        }
    }

    private fun seekRow(title: String, lo: Int, hi: Int, value: Int, onChange: (Int) -> Unit): View {
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        val tv = TextView(this)
        tv.text = title
        tv.textSize = 11f
        tv.setTextColor(gray)
        tv.setPadding(dp(4), dp(8), 0, 0)
        col.addView(tv)
        val sb = SeekBar(this)
        sb.max = hi - lo
        sb.progress = (value - lo).coerceIn(0, hi - lo)
        sb.progressTintList = ColorStateList.valueOf(accent)
        sb.thumbTintList = ColorStateList.valueOf(accent2)
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                if (fromUser) onChange(p + lo)
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        col.addView(sb)
        return col
    }

    // ================= info sistem =================

    private fun battery(): Pair<Int, Int> {
        val i = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val lvl = i?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = i?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        val temp = (i?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0) / 10
        return Pair(if (lvl < 0) 0 else lvl * 100 / scale, temp)
    }

    private fun memInfo(): ActivityManager.MemoryInfo {
        val mi = ActivityManager.MemoryInfo()
        getSystemService(ActivityManager::class.java).getMemoryInfo(mi)
        return mi
    }

    private fun ramPct(): Int {
        val mi = memInfo()
        return (100 - mi.availMem * 100 / mi.totalMem).toInt()
    }

    private fun hasDump() =
        checkSelfPermission("android.permission.DUMP") == PackageManager.PERMISSION_GRANTED

    // ================= logo (tombol gestur) =================

    private fun handleSize() = dp(prefs.getInt("hsize", 48))
    private fun handleRight() = prefs.getBoolean("hright", true)

    private fun addHandle() {
        val size = handleSize()
        val v = FrameLayout(this)
        v.background = ChamferDrawable(0xFF1B1F2E.toInt(), 0xFF0E1018.toInt(), accent, dp(10).toFloat(), dens(), true)
        val mg = (size * 0.24f).toInt()
        val llp = FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT)
        llp.setMargins(mg, mg, mg, mg)
        v.addView(LogoView(this, textColor, accent), llp)
        v.alpha = prefs.getInt("halpha", 90) / 100f

        val p = lp(size, size, fNoFocus or fLimits)
        p.gravity = Gravity.TOP or Gravity.START
        p.x = if (handleRight()) screenW() - size else 0
        p.y = (prefs.getFloat("hy", 0.45f) * screenH()).toInt().coerceIn(0, screenH() - size)

        var sx = 0f
        var sy = 0f
        var ox = 0
        var oy = 0
        var dragging = false
        v.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    sx = e.rawX; sy = e.rawY; ox = p.x; oy = p.y; dragging = false
                    v.animate().alpha(1f).setDuration(120).start()
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - sx
                    val dy = e.rawY - sy
                    if (!dragging && (Math.abs(dx) > dp(8) || Math.abs(dy) > dp(8))) dragging = true
                    if (dragging) {
                        p.x = (ox + dx).toInt().coerceIn(0, screenW() - size)
                        p.y = (oy + dy).toInt().coerceIn(0, screenH() - size)
                        try { wm.updateViewLayout(v, p) } catch (ex: Exception) { }
                    }
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    v.animate().alpha(prefs.getInt("halpha", 90) / 100f).setDuration(300).start()
                    if (dragging) {
                        snapHandle(v, p, size)
                    } else if (e.actionMasked == MotionEvent.ACTION_UP) {
                        if (panel != null) {
                            closePanel()
                        } else if (SystemClock.uptimeMillis() - panelClosedAt > 350L) {
                            showPanel()
                        }
                    }
                }
            }
            true
        }
        wm.addView(v, p)
        handle = v
    }

    private fun snapHandle(v: View, p: WindowManager.LayoutParams, size: Int) {
        val right = p.x + size / 2 > screenW() / 2
        val target = if (right) screenW() - size else 0
        prefs.edit().putBoolean("hright", right)
            .putFloat("hy", p.y.toFloat() / screenH()).apply()
        ValueAnimator.ofInt(p.x, target).apply {
            duration = 180
            addUpdateListener {
                p.x = it.animatedValue as Int
                try { wm.updateViewLayout(v, p) } catch (e: Exception) { }
            }
            start()
        }
    }

    private fun rebuildHandle() {
        handleAnims.forEach { it.cancel() }
        handleAnims.clear()
        safeRemove(handle)
        handle = null
        addHandle()
    }

    // ================= panel utama (tab) =================

    private fun tile(
        icon: Int, label: String, active: Boolean,
        onLong: (() -> Unit)? = null, onClick: () -> Unit
    ): LinearLayout {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.gravity = Gravity.CENTER
        box.minimumHeight = dp(76)
        box.setPadding(dp(4), dp(10), dp(4), dp(8))
        box.background = if (active)
            ChamferDrawable(accent, accent2, 0xFFFFFFFF.toInt(), dp(9).toFloat(), dens(), true)
        else
            ChamferDrawable(0xFF262B3D.toInt(), 0xFF171A26.toInt(), 0xFF3A4057.toInt(), dp(9).toFloat(), dens(), false)
        val ic = IconView(this, icon, if (active) 0xFFFFFFFF.toInt() else accent2)
        box.addView(ic, LinearLayout.LayoutParams(dp(24), dp(24)))
        val tv = TextView(this)
        tv.text = label
        tv.textSize = 10f
        tv.typeface = Typeface.DEFAULT_BOLD
        tv.gravity = Gravity.CENTER
        tv.maxLines = 2
        tv.setTextColor(textColor)
        tv.setPadding(0, dp(5), 0, 0)
        box.addView(tv)
        box.setOnTouchListener { v, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN ->
                    v.animate().scaleX(0.93f).scaleY(0.93f).setDuration(80).start()
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL ->
                    v.animate().scaleX(1f).scaleY(1f).setDuration(120).start()
            }
            false
        }
        box.setOnClickListener { onClick() }
        if (onLong != null) box.setOnLongClickListener { onLong(); true }
        return box
    }

    private fun cell() = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        .apply { setMargins(dp(4), dp(4), dp(4), dp(4)) }

    private fun grid(vararg tiles: View): LinearLayout {
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        var i = 0
        while (i < tiles.size) {
            val r = LinearLayout(this)
            r.orientation = LinearLayout.HORIZONTAL
            for (k in 0 until 3) {
                val v: View = if (i + k < tiles.size) tiles[i + k] else Space(this)
                r.addView(v, cell())
            }
            col.addView(r)
            i += 3
        }
        return col
    }

    private fun note(text: String): TextView {
        val t = TextView(this)
        t.text = text
        t.textSize = 10f
        t.setTextColor(gray)
        t.setPadding(dp(6), dp(8), dp(6), dp(2))
        return t
    }

    private fun refreshPanel() {
        val holder = panelHolder ?: return
        holder.removeAllViews()
        holder.addView(buildPanelBody())
        fitPanel()
    }

    private fun measurePanelHeight(body: View): Int {
        val w = dp(318) - dp(8)
        body.measure(
            View.MeasureSpec.makeMeasureSpec(w, View.MeasureSpec.EXACTLY),
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
        )
        return minOf(body.measuredHeight + dp(8), screenH() - dp(24))
    }

    private fun fitPanel() {
        val root = panel ?: return
        val p = panelParams ?: return
        val body = panelHolder?.getChildAt(0) ?: return
        val h = measurePanelHeight(body)
        if (p.height != h) {
            p.height = h
            try { wm.updateViewLayout(root, p) } catch (e: Exception) { }
        }
    }

    private val tabNames = arrayOf("GAME", "PERFORMA", "NOTIF", "REKAM", "JARINGAN", "SENTUH", "ALAT")

    private fun fillTab(content: LinearLayout) {
        content.removeAllViews()
        when (selectedTab) {
            0 -> {
                content.addView(grid(
                    tile(Icons.GAME, "Game Launcher", launcherWin != null) { closePanel(); toggleLauncher() },
                    tile(Icons.ROBOT, "Asisten AI", robotWin != null) { closePanel(); toggleRobot() },
                    tile(Icons.CLOCK, "Jam Digital", clockWin != null) { closePanel(); toggleClock() },
                    tile(Icons.CROSSHAIR, "Crosshair", crosshair != null, onLong = { closePanel(); toggleCrossSettings() }) {
                        closePanel(); toggleCrosshair()
                    },
                    tile(Icons.GEAR, "Atur Crosshair", crossWin != null) { closePanel(); toggleCrossSettings() },
                    tile(Icons.CHART, "FPS HUD", hud != null) { closePanel(); toggleHud() }
                ))
                content.addView(note("Ketuk robot untuk bertanya atau minta tolong. Tahan Crosshair untuk mengaturnya."))
            }
            1 -> content.addView(grid(
                tile(Icons.ROCKET, "Boost", boostOn) { closePanel(); toggleBoost() },
                tile(Icons.CHART, "FPS HUD", hud != null) { closePanel(); toggleHud() },
                tile(Icons.CPU, "Monitor", hud != null && hudDetail) { closePanel(); toggleMonitor() },
                tile(Icons.MEM, "Bersihkan RAM", false) { closePanel(); cleanRam() },
                tile(Icons.SUN, "Layar Aktif", awakeView != null) { closePanel(); toggleAwake() },
                tile(Icons.CROSSHAIR, "Crosshair", crosshair != null, onLong = { closePanel(); toggleCrossSettings() }) {
                    closePanel(); toggleCrosshair()
                }
            ))
            2 -> {
                content.addView(grid(
                    tile(Icons.DND, "Jangan Ganggu", dndOn()) { closePanel(); toggleDnd() },
                    tile(Icons.BELLOFF, "Blokir Pop-up", headsUpOff()) { closePanel(); togglePopup() },
                    tile(Icons.PHONEOFF, "Tolak Panggilan", callBlock) { closePanel(); toggleCallBlock() },
                    tile(Icons.HEADSET, "Headset Only", headsetOnly) { closePanel(); toggleHeadset() },
                    tile(Icons.LOCK, "Kunci Sentuh", lockView != null) { closePanel(); toggleLock() }
                ))
                content.addView(note("Tolak Panggilan menolak semua panggilan masuk (belum ada daftar VIP)."))
            }
            3 -> {
                content.addView(grid(
                    tile(Icons.REC, "Rekam ${recLabel()}", recording, onLong = { cycleBitrate() }) {
                        closePanel(); toggleRecord()
                    },
                    tile(Icons.SHOT, "Screenshot", false) { closePanel(); takeShot() },
                    tile(Icons.SPEAKER, "Soundboard", sbWin != null) { closePanel(); toggleSoundboard() }
                ))
                val am = getSystemService(AudioManager::class.java)
                content.addView(seekRow(
                    "Volume media", 0, am.getStreamMaxVolume(AudioManager.STREAM_MUSIC),
                    am.getStreamVolume(AudioManager.STREAM_MUSIC)
                ) { am.setStreamVolume(AudioManager.STREAM_MUSIC, it, 0) })
                content.addView(note("Tahan Rekam untuk ganti bitrate. Rekaman tanpa suara."))
            }
            4 -> {
                content.addView(grid(
                    tile(Icons.CHART, "Monitor Jaringan", hud != null && hudDetail) { closePanel(); toggleMonitor() },
                    tile(Icons.SHIELD, "DNS Cepat", dnsFast()) { closePanel(); toggleDns() },
                    tile(Icons.WIFI, "Wi-Fi", wifiOn()) { closePanel(); toggleWifi() },
                    tile(Icons.DATA, "Data Seluler", dataOn()) { closePanel(); toggleData() },
                    tile(Icons.BOLT, "Low Latency", lowLat?.isHeld == true) { closePanel(); toggleLowLat() }
                ))
                content.addView(note("DNS Cepat memakai Cloudflare (1.1.1.1). Ping asli game tidak bisa dipercepat."))
            }
            5 -> {
                val names = arrayOf("Normal", "Cepat", "Maks")
                content.addView(grid(
                    tile(Icons.TOUCH, "Respons ${names[prefs.getInt("touch", 0).coerceIn(0, 2)]}", prefs.getInt("touch", 0) > 0) {
                        cycleTouch(); refreshPanel()
                    },
                    tile(Icons.ANIM, "Animasi Cepat", animFast()) { toggleAnim(); refreshPanel() },
                    tile(Icons.SAT, "Warna ${satLabel()}", prefs.getInt("sat", 0) > 0) { cycleSat(); refreshPanel() }
                ))
                content.addView(note("Polling rate sentuh tidak bisa diubah tanpa root. Respons mengatur jeda tekan-tahan."))
            }
            else -> content.addView(grid(
                tile(Icons.NOTE, "Catatan", notesWin != null) { closePanel(); toggleNotes() },
                tile(Icons.CALC, "Kalkulator", calc != null) { closePanel(); toggleCalc() },
                tile(Icons.TIMER, "Stopwatch", swWin != null) { closePanel(); toggleStopwatch() },
                tile(Icons.GLOBE, "Browser", browser != null) { closePanel(); toggleBrowser() },
                tile(Icons.FLASH, "Senter", torchOn) { closePanel(); toggleTorch() },
                tile(Icons.GEAR, "Pengaturan", settingsWin != null) { closePanel(); toggleSettings() }
            ))
        }
    }

    private fun buildPanelBody(): LinearLayout {
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(8), dp(8), dp(8), dp(6))

        val head = LinearLayout(this)
        head.orientation = LinearLayout.HORIZONTAL
        head.gravity = Gravity.CENTER_VERTICAL
        head.setPadding(dp(4), 0, dp(4), 0)
        head.addView(LogoView(this, textColor, accent), LinearLayout.LayoutParams(dp(30), dp(30)))
        val titles = LinearLayout(this)
        titles.orientation = LinearLayout.VERTICAL
        val title = TextView(this)
        title.text = "VEXED"
        title.textSize = 16f
        title.typeface = Typeface.DEFAULT_BOLD
        title.letterSpacing = 0.2f
        title.setTextColor(textColor)
        titles.addView(title)
        val bt = battery()
        val sys = TextView(this)
        sys.text = "RAM ${ramPct()}%  ·  ${bt.second}°C  ·  ${bt.first}%"
        sys.textSize = 10f
        sys.setTextColor(gray)
        titles.addView(sys)
        val tlp = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        tlp.leftMargin = dp(10)
        head.addView(titles, tlp)
        col.addView(head)

        val tabIcons = intArrayOf(
            Icons.GAME, Icons.ROCKET, Icons.BELLOFF, Icons.REC, Icons.WIFI, Icons.TOUCH, Icons.GEAR
        )
        val bar = LinearLayout(this)
        bar.orientation = LinearLayout.HORIZONTAL
        bar.setPadding(0, dp(10), 0, dp(2))
        for (i in tabIcons.indices) {
            val cellV = LinearLayout(this)
            cellV.orientation = LinearLayout.VERTICAL
            cellV.gravity = Gravity.CENTER_HORIZONTAL
            cellV.addView(
                IconView(this, tabIcons[i], if (i == selectedTab) accent2 else gray),
                LinearLayout.LayoutParams(dp(24), dp(24))
            )
            val ul = View(this)
            ul.setBackgroundColor(if (i == selectedTab) accent else 0x00000000)
            val ulp = LinearLayout.LayoutParams(dp(20), dp(2))
            ulp.topMargin = dp(4)
            cellV.addView(ul, ulp)
            cellV.setOnClickListener {
                if (selectedTab != i) {
                    selectedTab = i
                    refreshPanel()
                }
            }
            bar.addView(cellV, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        }
        col.addView(bar)

        val tabTitle = TextView(this)
        tabTitle.text = tabNames[selectedTab.coerceIn(0, tabNames.size - 1)]
        tabTitle.textSize = 10f
        tabTitle.letterSpacing = 0.2f
        tabTitle.typeface = Typeface.DEFAULT_BOLD
        tabTitle.setTextColor(accent)
        tabTitle.setPadding(dp(6), dp(6), 0, dp(4))
        col.addView(tabTitle)

        val content = LinearLayout(this)
        content.orientation = LinearLayout.VERTICAL
        fillTab(content)
        col.addView(content)

        val exit = TextView(this)
        exit.text = "KELUAR"
        exit.textSize = 11f
        exit.letterSpacing = 0.2f
        exit.typeface = Typeface.DEFAULT_BOLD
        exit.gravity = Gravity.CENTER
        exit.setTextColor(cRed)
        exit.setPadding(0, dp(10), 0, dp(6))
        exit.setOnClickListener { stopSelf() }
        col.addView(exit)
        return col
    }

    private fun showPanel(animate: Boolean = true) {
        if (panel != null) return
        // buang sisa panel yang masih animasi tutup supaya tidak numpuk
        closingPanel?.let { it.animate().cancel(); safeRemove(it); closingPanel = null }
        val right = handleRight()

        val sv = ScrollView(this)
        sv.isVerticalScrollBarEnabled = false
        val body = buildPanelBody()
        sv.addView(body)
        panelHolder = sv
        val root = sharpFrame(sv, 16)

        val p = lp(dp(318), measurePanelHeight(body), fNoFocus or fModal or fOutside)
        p.gravity = (if (right) Gravity.END else Gravity.START) or Gravity.CENTER_VERTICAL
        p.x = dp(6)
        root.setOnTouchListener { _, e ->
            if (e.action == MotionEvent.ACTION_OUTSIDE) { closePanel(); true } else false
        }
        wm.addView(root, p)
        panel = root
        panelParams = p

        if (animate) {
            root.alpha = 0f
            root.translationX = dp(40).toFloat() * (if (right) 1 else -1)
            root.animate().alpha(1f).translationX(0f).setDuration(200)
                .setInterpolator(DecelerateInterpolator()).start()
            val tiles = ArrayList<View>()
            collectTiles(body, tiles)
            tiles.forEachIndexed { i, v ->
                v.alpha = 0f
                v.translationY = dp(10).toFloat()
                v.animate().alpha(1f).translationY(0f)
                    .setStartDelay(40L + i * 25L).setDuration(180)
                    .setInterpolator(DecelerateInterpolator()).start()
            }
        }
    }

    private fun collectTiles(v: View, out: ArrayList<View>) {
        if (v is LinearLayout && v.isClickable) { out.add(v); return }
        if (v is android.view.ViewGroup) {
            for (i in 0 until v.childCount) collectTiles(v.getChildAt(i), out)
        }
    }

    private fun closePanel(animated: Boolean = true) {
        val v = panel ?: return
        panel = null
        panelHolder = null
        panelParams = null
        panelClosedAt = SystemClock.uptimeMillis()
        v.animate().cancel()
        if (!animated) { safeRemove(v); return }
        closingPanel = v
        val dir = if (handleRight()) 1 else -1
        v.animate().alpha(0f).translationX(dp(30).toFloat() * dir).setDuration(140)
            .withEndAction {
                safeRemove(v)
                if (closingPanel === v) closingPanel = null
            }.start()
    }

    // ================= pengaturan =================

    private fun toggleSettings() {
        if (settingsWin != null) { closeView(settingsWin); settingsWin = null; return }
        val hd = windowHeader("PENGATURAN") { closeView(settingsWin); settingsWin = null }
        val header = hd.first
        val inner = windowColumn()
        inner.addView(header)

        val tt = TextView(this)
        tt.text = "Tema warna"
        tt.textSize = 11f
        tt.setTextColor(gray)
        tt.setPadding(dp(4), dp(4), 0, 0)
        inner.addView(tt)
        val themeRow = LinearLayout(this)
        themeRow.orientation = LinearLayout.HORIZONTAL
        val cur = prefs.getInt("theme", 0)
        themes.forEachIndexed { i, th ->
            val dot = LogoView(this, th.first, th.second)
            dot.background = ChamferDrawable(
                0xFF1B1F2E.toInt(), 0xFF0E1018.toInt(),
                if (cur == i) 0xFFFFFFFF.toInt() else th.first, dp(6).toFloat(), dens(), false
            )
            dot.setPadding(dp(6), dp(6), dp(6), dp(6))
            dot.setOnClickListener {
                prefs.edit().putInt("theme", i).apply()
                accent = th.first
                accent2 = th.second
                rebuildHandle()
                closeView(settingsWin)
                settingsWin = null
                toast("Tema diganti. Buka ulang jendela agar warnanya berubah.")
            }
            val lpd = LinearLayout.LayoutParams(dp(40), dp(40))
            lpd.setMargins(dp(4), dp(6), dp(4), dp(6))
            themeRow.addView(dot, lpd)
        }
        inner.addView(themeRow)

        inner.addView(seekRow("Ukuran logo", 36, 72, prefs.getInt("hsize", 48)) {
            prefs.edit().putInt("hsize", it).apply()
            rebuildHandle()
        })
        inner.addView(seekRow("Transparansi logo", 20, 100, prefs.getInt("halpha", 90)) {
            prefs.edit().putInt("halpha", it).apply()
            handle?.alpha = it / 100f
        })

        val hc = pill(if (prefs.getBoolean("hud_clock", true)) "Jam di HUD: aktif" else "Jam di HUD: mati") { }
        hc.setOnClickListener {
            val on = !prefs.getBoolean("hud_clock", true)
            prefs.edit().putBoolean("hud_clock", on).apply()
            hc.text = if (on) "Jam di HUD: aktif" else "Jam di HUD: mati"
            hudText?.text = hudSpan()
        }
        val hlp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        hlp.setMargins(0, dp(12), 0, 0)
        inner.addView(hc, hlp)

        val reset = pill("Reset posisi logo") {
            prefs.edit().putBoolean("hright", true).putFloat("hy", 0.45f).apply()
            rebuildHandle()
            toast("Posisi logo direset")
        }
        val rlp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        rlp.setMargins(0, dp(12), 0, dp(4))
        inner.addView(reset, rlp)

        settingsWin = openWindow(inner, header, dp(290), wrap, false, dp(30), dp(110))
    }

    // ================= crosshair =================

    private inner class CrossView : View(this@OverlayService) {
        var shape = 1
        var color = 0xFF00FF88.toInt()
        var len = 11
        var thick = 2
        var gap = 4
        var dot = 3
        var outline = true
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG)

        override fun onDraw(canvas: Canvas) {
            val cx = width / 2f
            val cy = height / 2f
            if (outline) pass(canvas, cx, cy, 0xFF000000.toInt(), dens() * 1.6f)
            pass(canvas, cx, cy, color, 0f)
        }

        private fun pass(c: Canvas, cx: Float, cy: Float, col: Int, extra: Float) {
            paint.color = col
            paint.strokeCap = Paint.Cap.BUTT
            val th = dp(thick).toFloat() + extra
            val g = dp(gap).toFloat()
            val l = dp(len).toFloat()
            val ex = extra / 2f
            paint.strokeWidth = th
            paint.style = Paint.Style.STROKE
            when (shape) {
                0, 1 -> {
                    c.drawLine(cx - g - l - ex, cy, cx - g + ex, cy, paint)
                    c.drawLine(cx + g - ex, cy, cx + g + l + ex, cy, paint)
                    c.drawLine(cx, cy - g - l - ex, cx, cy - g + ex, paint)
                    c.drawLine(cx, cy + g - ex, cx, cy + g + l + ex, paint)
                }
                3, 4 -> c.drawCircle(cx, cy, g + l / 2f, paint)
                5 -> {
                    val k = 0.7071f
                    val a = g * k
                    val b = (g + l) * k
                    c.drawLine(cx - b, cy - b, cx - a, cy - a, paint)
                    c.drawLine(cx + a, cy + a, cx + b, cy + b, paint)
                    c.drawLine(cx + a, cy - a, cx + b, cy - b, paint)
                    c.drawLine(cx - a, cy + a, cx - b, cy + b, paint)
                }
            }
            if (shape == 1 || shape == 2 || shape == 4) {
                paint.style = Paint.Style.FILL
                c.drawCircle(cx, cy, dp(dot) / 2f + ex, paint)
            }
        }
    }

    private fun applyXh(v: CrossView) {
        v.shape = prefs.getInt("xh_shape", 1)
        v.color = prefs.getInt("xh_col", 0xFF00FF88.toInt())
        v.len = prefs.getInt("xh_len", 11)
        v.thick = prefs.getInt("xh_th", 2)
        v.gap = prefs.getInt("xh_gap", 4)
        v.dot = prefs.getInt("xh_dot", 3)
        v.outline = prefs.getBoolean("xh_out", true)
        v.alpha = prefs.getInt("xh_alpha", 100) / 100f
        v.invalidate()
    }

    private fun crossBox() =
        dp(prefs.getInt("xh_gap", 4) + prefs.getInt("xh_len", 11) + prefs.getInt("xh_th", 2) + 8) * 2

    private fun refreshCross() {
        crosshair?.let { v ->
            applyXh(v)
            val p = crossParams
            if (p != null) {
                val s = crossBox()
                p.width = s
                p.height = s
                p.x = dp(prefs.getInt("xh_ox", 0))
                p.y = dp(prefs.getInt("xh_oy", 0))
                try { wm.updateViewLayout(v, p) } catch (e: Exception) { }
            }
        }
        crossPreview?.let { applyXh(it) }
    }

    private fun toggleCrosshair() {
        if (crosshair != null) {
            safeRemove(crosshair)
            crosshair = null
            crossParams = null
            return
        }
        val v = CrossView()
        applyXh(v)
        val s = crossBox()
        val p = lp(s, s, fNoFocus or fNoTouch or fLimits)
        p.gravity = Gravity.CENTER
        p.x = dp(prefs.getInt("xh_ox", 0))
        p.y = dp(prefs.getInt("xh_oy", 0))
        wm.addView(v, p)
        crosshair = v
        crossParams = p
    }

    private fun closeCross() {
        closeView(crossWin)
        crossWin = null
        crossPreview = null
    }

    private fun chipRow(labels: List<String>, selected: Int, onPick: (Int) -> Unit): LinearLayout {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        val chips = ArrayList<TextView>()
        fun style(t: TextView, on: Boolean) {
            t.background = if (on)
                ChamferDrawable(accent, accent2, 0xFFFFFFFF.toInt(), dp(6).toFloat(), dens(), false)
            else
                ChamferDrawable(0xFF262B3D.toInt(), 0xFF171A26.toInt(), 0xFF3A4057.toInt(), dp(6).toFloat(), dens(), false)
        }
        labels.forEachIndexed { i, s ->
            val t = TextView(this)
            t.text = s
            t.textSize = 14f
            t.typeface = Typeface.DEFAULT_BOLD
            t.setTextColor(textColor)
            t.gravity = Gravity.CENTER
            t.setPadding(dp(4), dp(8), dp(4), dp(8))
            style(t, i == selected)
            t.setOnClickListener {
                chips.forEachIndexed { k, c -> style(c, k == i) }
                onPick(i)
            }
            chips.add(t)
            row.addView(t, cell())
        }
        return row
    }

    private fun switchChip(label: String, key: String, def: Boolean): TextView {
        val t = TextView(this)
        t.textSize = 11f
        t.typeface = Typeface.DEFAULT_BOLD
        t.setTextColor(textColor)
        t.gravity = Gravity.CENTER
        t.setPadding(dp(4), dp(8), dp(4), dp(8))
        fun paintIt() {
            val on = prefs.getBoolean(key, def)
            t.text = if (on) "$label ✓" else label
            t.background = if (on)
                ChamferDrawable(accent, accent2, 0xFFFFFFFF.toInt(), dp(6).toFloat(), dens(), false)
            else
                ChamferDrawable(0xFF262B3D.toInt(), 0xFF171A26.toInt(), 0xFF3A4057.toInt(), dp(6).toFloat(), dens(), false)
        }
        paintIt()
        t.setOnClickListener {
            prefs.edit().putBoolean(key, !prefs.getBoolean(key, def)).apply()
            paintIt()
        }
        return t
    }

    private fun xhSeek(title: String, key: String, lo: Int, hi: Int, def: Int): View {
        var tv: TextView? = null
        val cur = prefs.getInt(key, def)
        val col = seekRow("$title: $cur", lo, hi, cur) { v ->
            prefs.edit().putInt(key, v).apply()
            tv?.text = "$title: $v"
            refreshCross()
        }
        tv = (col as LinearLayout).getChildAt(0) as TextView
        return col
    }

    private fun label(text: String): TextView {
        val t = TextView(this)
        t.text = text
        t.textSize = 11f
        t.setTextColor(gray)
        t.setPadding(dp(4), dp(10), 0, dp(2))
        return t
    }

    private fun toggleCrossSettings() {
        if (crossWin != null) { closeCross(); return }
        val hd = windowHeader("CROSSHAIR") { closeCross() }
        val header = hd.first
        val inner = windowColumn()
        inner.addView(header)

        val prev = CrossView()
        crossPreview = prev
        applyXh(prev)
        val pb = FrameLayout(this)
        pb.background = ChamferDrawable(0xFF2B3347.toInt(), 0xFF171C28.toInt(), 0xFF3A4057.toInt(), dp(8).toFloat(), dens(), false)
        pb.addView(prev, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))
        inner.addView(pb, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(96)))

        val body = LinearLayout(this)
        body.orientation = LinearLayout.VERTICAL
        val sv = ScrollView(this)
        sv.isVerticalScrollBarEnabled = false
        sv.addView(body)
        inner.addView(sv, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))

        body.addView(label("Bentuk"))
        body.addView(chipRow(listOf("+", "+•", "•", "○", "○•", "×"), prefs.getInt("xh_shape", 1)) {
            prefs.edit().putInt("xh_shape", it).apply()
            refreshCross()
        })

        body.addView(label("Warna"))
        val swatches = intArrayOf(
            0xFF00FF88.toInt(), 0xFFFF3B5C.toInt(), 0xFF00E5FF.toInt(), 0xFFFFE600.toInt(),
            0xFFFFFFFF.toInt(), 0xFFFF7A18.toInt(), 0xFFB26BFF.toInt(), 0xFFFF4FD8.toInt()
        )
        val sw = LinearLayout(this)
        sw.orientation = LinearLayout.HORIZONTAL
        for (c in swatches) {
            val v = View(this)
            v.background = ChamferDrawable(c, c, 0xFFFFFFFF.toInt(), dp(4).toFloat(), dens(), false)
            v.setOnClickListener {
                prefs.edit().putInt("xh_col", c).apply()
                refreshCross()
            }
            val l = LinearLayout.LayoutParams(0, dp(28), 1f)
            l.setMargins(dp(2), dp(2), dp(2), dp(2))
            sw.addView(v, l)
        }
        body.addView(sw)
        val hsv = FloatArray(3)
        Color.colorToHSV(prefs.getInt("xh_col", 0xFF00FF88.toInt()), hsv)
        body.addView(seekRow("Warna bebas (geser)", 0, 360, hsv[0].toInt()) { h ->
            prefs.edit().putInt("xh_col", Color.HSVToColor(floatArrayOf(h.toFloat(), 1f, 1f))).apply()
            refreshCross()
        })

        body.addView(xhSeek("Panjang", "xh_len", 2, 40, 11))
        body.addView(xhSeek("Ketebalan", "xh_th", 1, 8, 2))
        body.addView(xhSeek("Celah tengah", "xh_gap", 0, 24, 4))
        body.addView(xhSeek("Ukuran titik", "xh_dot", 2, 10, 3))
        body.addView(xhSeek("Transparansi", "xh_alpha", 20, 100, 100))
        body.addView(xhSeek("Geser horizontal", "xh_ox", -120, 120, 0))
        body.addView(xhSeek("Geser vertikal", "xh_oy", -120, 120, 0))

        val opts = LinearLayout(this)
        opts.orientation = LinearLayout.HORIZONTAL
        val outlineChip = switchChip("Garis tepi", "xh_out", true)
        outlineChip.setOnClickListener {
            prefs.edit().putBoolean("xh_out", !prefs.getBoolean("xh_out", true)).apply()
            val on = prefs.getBoolean("xh_out", true)
            outlineChip.text = if (on) "Garis tepi ✓" else "Garis tepi"
            outlineChip.background = if (on)
                ChamferDrawable(accent, accent2, 0xFFFFFFFF.toInt(), dp(6).toFloat(), dens(), false)
            else
                ChamferDrawable(0xFF262B3D.toInt(), 0xFF171A26.toInt(), 0xFF3A4057.toInt(), dp(6).toFloat(), dens(), false)
            refreshCross()
        }
        opts.addView(outlineChip, cell())
        opts.addView(pill("Tampilkan di layar", crosshair == null) {
            toggleCrosshair()
        }, cell())
        body.addView(opts)

        val reset = pill("Reset crosshair") {
            val e = prefs.edit()
            for (k in listOf("xh_shape", "xh_col", "xh_len", "xh_th", "xh_gap", "xh_dot", "xh_alpha", "xh_ox", "xh_oy", "xh_out")) e.remove(k)
            e.apply()
            refreshCross()
            closeCross()
            toggleCrossSettings()
        }
        val rlp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        rlp.setMargins(0, dp(10), 0, dp(4))
        body.addView(reset, rlp)

        val h = minOf(dp(480), screenH() - dp(40))
        crossWin = openWindow(inner, header, dp(300), h, false, dp(24), dp(30))
    }

    // ================= notifikasi & panggilan =================

    private fun dndOn(): Boolean {
        val nm = getSystemService(NotificationManager::class.java)
        return nm.isNotificationPolicyAccessGranted &&
            nm.currentInterruptionFilter == NotificationManager.INTERRUPTION_FILTER_ALARMS
    }

    private fun toggleDnd() {
        val nm = getSystemService(NotificationManager::class.java)
        if (!nm.isNotificationPolicyAccessGranted) {
            toast("Beri izin Jangan Ganggu dulu")
            startActivity(
                Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
            return
        }
        val on = nm.currentInterruptionFilter == NotificationManager.INTERRUPTION_FILTER_ALARMS
        nm.setInterruptionFilter(
            if (on) NotificationManager.INTERRUPTION_FILTER_ALL
            else NotificationManager.INTERRUPTION_FILTER_ALARMS
        )
        toast(if (on) "Jangan Ganggu mati" else "Jangan Ganggu nyala")
    }

    private fun headsUpOff() =
        Settings.Global.getString(contentResolver, "heads_up_notifications_enabled") == "0"

    private fun togglePopup() {
        val off = headsUpOff()
        val ok = putSetting("global", "heads_up_notifications_enabled", if (off) "1" else "0")
        toast(
            if (!ok) "Butuh Shizuku aktif"
            else if (off) "Pop-up notifikasi nyala kembali"
            else "Pop-up notifikasi diblokir"
        )
    }

    private val callReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            val st = intent?.getStringExtra(TelephonyManager.EXTRA_STATE)
            if (callBlock && st == TelephonyManager.EXTRA_STATE_RINGING) {
                try {
                    val tm = getSystemService(TelecomManager::class.java)
                    tm.endCall()
                    toast("Panggilan ditolak otomatis")
                } catch (e: Exception) {
                    toast("Izin telepon belum aktif")
                }
            }
        }
    }

    private fun phonePerm() =
        checkSelfPermission("android.permission.READ_PHONE_STATE") == PackageManager.PERMISSION_GRANTED &&
            checkSelfPermission("android.permission.ANSWER_PHONE_CALLS") == PackageManager.PERMISSION_GRANTED

    private fun toggleCallBlock() {
        if (callBlock) {
            callBlock = false
            toast("Tolak panggilan mati")
            return
        }
        if (!phonePerm() && Sh.ready()) {
            Sh.run(
                "pm grant $packageName android.permission.READ_PHONE_STATE; " +
                    "pm grant $packageName android.permission.ANSWER_PHONE_CALLS"
            )
        }
        if (!phonePerm()) {
            toast("Beri izin Telepon lewat aplikasi VeXed")
            return
        }
        if (!callRegistered) {
            registerReceiver(callReceiver, IntentFilter(TelephonyManager.ACTION_PHONE_STATE_CHANGED))
            callRegistered = true
        }
        callBlock = true
        toast("Panggilan masuk akan ditolak")
    }

    private fun headsetConnected(am: AudioManager): Boolean =
        am.getDevices(AudioManager.GET_DEVICES_OUTPUTS).any {
            it.type == AudioDeviceInfo.TYPE_WIRED_HEADSET ||
                it.type == AudioDeviceInfo.TYPE_WIRED_HEADPHONES ||
                it.type == AudioDeviceInfo.TYPE_BLUETOOTH_A2DP ||
                it.type == AudioDeviceInfo.TYPE_BLUETOOTH_SCO ||
                it.type == AudioDeviceInfo.TYPE_USB_HEADSET
        }

    private fun applyHeadset() {
        val am = getSystemService(AudioManager::class.java)
        try {
            if (headsetOnly && !headsetConnected(am)) {
                if (savedRing < 0) {
                    savedRing = am.getStreamVolume(AudioManager.STREAM_RING)
                    savedNotif = am.getStreamVolume(AudioManager.STREAM_NOTIFICATION)
                }
                am.setStreamVolume(AudioManager.STREAM_RING, 0, 0)
                am.setStreamVolume(AudioManager.STREAM_NOTIFICATION, 0, 0)
            } else if (savedRing >= 0) {
                am.setStreamVolume(AudioManager.STREAM_RING, savedRing, 0)
                am.setStreamVolume(AudioManager.STREAM_NOTIFICATION, savedNotif, 0)
                savedRing = -1
                savedNotif = -1
            }
        } catch (e: Exception) {
            toast("Butuh izin Jangan Ganggu agar volume bisa diatur")
        }
    }

    private fun toggleHeadset() {
        val am = getSystemService(AudioManager::class.java)
        headsetOnly = !headsetOnly
        if (headsetOnly) {
            val cb = object : AudioDeviceCallback() {
                override fun onAudioDevicesAdded(addedDevices: Array<out AudioDeviceInfo>?) { applyHeadset() }
                override fun onAudioDevicesRemoved(removedDevices: Array<out AudioDeviceInfo>?) { applyHeadset() }
            }
            devCb = cb
            am.registerAudioDeviceCallback(cb, main)
        } else {
            val cb = devCb
            if (cb != null) am.unregisterAudioDeviceCallback(cb)
            devCb = null
        }
        applyHeadset()
        toast(if (headsetOnly) "Dering dan notifikasi hanya lewat headset" else "Headset Only mati")
    }

    // ================= senter, layar aktif, kunci sentuh =================

    private fun toggleTorch() {
        try {
            val cm = getSystemService(CameraManager::class.java)
            val id = cm.cameraIdList.firstOrNull {
                cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            }
            if (id == null) {
                toast("Perangkat tidak punya senter")
                return
            }
            torchOn = !torchOn
            cm.setTorchMode(id, torchOn)
            toast(if (torchOn) "Senter nyala" else "Senter mati")
        } catch (e: Exception) {
            torchOn = false
            toast("Senter gagal dinyalakan")
        }
    }

    private fun toggleAwake() {
        if (awakeView != null) {
            safeRemove(awakeView)
            awakeView = null
            toast("Layar kembali normal")
            return
        }
        val v = View(this)
        val p = lp(1, 1, fNoFocus or fNoTouch or fKeepOn)
        p.gravity = Gravity.TOP or Gravity.START
        wm.addView(v, p)
        awakeView = v
        toast("Layar tetap menyala")
    }

    private fun toggleLock() {
        if (lockView != null) {
            safeRemove(lockView)
            lockView = null
            return
        }
        val root = FrameLayout(this)
        root.setBackgroundColor(0x01000000)
        root.setOnTouchListener { _, _ -> true }
        val hint = LinearLayout(this)
        hint.orientation = LinearLayout.HORIZONTAL
        hint.gravity = Gravity.CENTER_VERTICAL
        hint.setPadding(dp(16), dp(10), dp(18), dp(10))
        hint.background = ChamferDrawable(0xE6181B28.toInt(), 0xE60D0F17.toInt(), accent, dp(10).toFloat(), dens(), true)
        hint.addView(IconView(this, Icons.LOCK, accent2), LinearLayout.LayoutParams(dp(20), dp(20)))
        val tv = TextView(this)
        tv.text = "Tahan untuk membuka"
        tv.textSize = 12f
        tv.typeface = Typeface.DEFAULT_BOLD
        tv.setTextColor(textColor)
        tv.setPadding(dp(8), 0, 0, 0)
        hint.addView(tv)
        hint.setOnClickListener { }
        hint.setOnLongClickListener { toggleLock(); true }
        val hl = FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT,
            Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
        )
        hl.bottomMargin = dp(70)
        root.addView(hint, hl)
        val p = lp(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT, fNoFocus or fLimits)
        wm.addView(root, p)
        lockView = root
        toast("Sentuhan dikunci")
    }

    // ================= performa: boost & RAM =================

    private fun cleanRam() {
        val am = getSystemService(ActivityManager::class.java)
        val before = memInfo().availMem / 1048576
        var n = 0
        for (ai in packageManager.getInstalledApplications(0)) {
            if (ai.packageName == packageName) continue
            if ((ai.flags and ApplicationInfo.FLAG_SYSTEM) != 0) continue
            try { am.killBackgroundProcesses(ai.packageName); n++ } catch (e: Exception) { }
        }
        main.postDelayed({
            val after = memInfo().availMem / 1048576
            toast("$n app ditutup · RAM bebas $before → $after MB")
        }, 900)
    }

    private fun toggleBoost() {
        if (!Sh.ready()) {
            toast("Boost butuh Shizuku aktif")
            return
        }
        boostOn = !boostOn
        val on = boostOn
        toast(if (on) "Boost aktif" else "Boost mati")
        Thread {
            if (on) {
                val pkg = foregroundPkg()
                val sb = StringBuilder()
                sb.append("cmd power set-fixed-performance-mode-enabled true 2>&1; ")
                sb.append("cmd power set-adaptive-power-saver-enabled false 2>&1; ")
                sb.append("settings put global low_power 0 2>&1; ")
                if (pkg != null && pkg != packageName) {
                    sb.append("cmd game mode performance $pkg 2>&1; ")
                    sb.append("cmd game set --mode performance $pkg 2>&1; ")
                }
                Sh.run(sb.toString())
                main.post { cleanRam() }
            } else {
                Sh.run(
                    "cmd power set-fixed-performance-mode-enabled false 2>&1; " +
                        "cmd power set-adaptive-power-saver-enabled true 2>&1"
                )
            }
        }.start()
    }

    // ================= rekam layar & screenshot =================

    private fun recLabel() = arrayOf("4M", "8M", "12M")[prefs.getInt("recbr", 1).coerceIn(0, 2)]

    private fun cycleBitrate() {
        val n = (prefs.getInt("recbr", 1) + 1) % 3
        prefs.edit().putInt("recbr", n).apply()
        toast("Bitrate rekam ${recLabel()}bps")
    }

    private fun toggleRecord() {
        if (!Sh.ready()) {
            toast("Rekam layar butuh Shizuku aktif")
            return
        }
        if (recording) {
            recording = false
            Thread { Sh.run("pkill -2 screenrecord 2>&1 || killall -2 screenrecord 2>&1") }.start()
            toast("Rekaman dihentikan. Cek Movies/VeXed")
            return
        }
        recording = true
        val br = intArrayOf(4, 8, 12)[prefs.getInt("recbr", 1).coerceIn(0, 2)] * 1_000_000
        toast("Merekam layar (tanpa suara)")
        Thread {
            while (recording) {
                val f = "/sdcard/Movies/VeXed/VeXed_${stamp()}.mp4"
                Sh.run("mkdir -p /sdcard/Movies/VeXed")
                val t0 = SystemClock.elapsedRealtime()
                val p = Sh.start("screenrecord --bit-rate $br '$f' 2>&1")
                try { p?.waitFor() } catch (e: Exception) { }
                if (p == null || SystemClock.elapsedRealtime() - t0 < 2000) {
                    recording = false
                    main.post { toast("Rekam layar gagal") }
                }
            }
        }.start()
    }

    private fun takeShot() {
        if (!Sh.ready()) {
            toast("Screenshot butuh Shizuku aktif")
            return
        }
        val file = "/sdcard/Pictures/VeXed/VeXed_${stamp()}.png"
        handle?.visibility = View.INVISIBLE
        hud?.visibility = View.INVISIBLE
        Thread {
            try { Thread.sleep(450) } catch (e: InterruptedException) { }
            Sh.run(
                "mkdir -p /sdcard/Pictures/VeXed; screencap -p '$file' 2>&1; " +
                    "am broadcast -a android.intent.action.MEDIA_SCANNER_SCAN_FILE -d file://$file >/dev/null 2>&1"
            )
            main.post {
                handle?.visibility = View.VISIBLE
                hud?.visibility = View.VISIBLE
                toast("Tersimpan di Pictures/VeXed")
            }
        }.start()
    }

    // ================= soundboard =================

    private fun gen(sec: Double, f: (Double, Double) -> Double): ShortArray {
        val sr = 22050
        val n = (sr * sec).toInt()
        val out = ShortArray(n)
        for (i in 0 until n) {
            val t = i / sr.toDouble()
            val env = minOf(1.0, i / 200.0) * minOf(1.0, (n - i) / 400.0)
            val v = (f(t, sec) * env * 12000).toInt().coerceIn(-32000, 32000)
            out[i] = v.toShort()
        }
        return out
    }

    private fun synth(kind: Int): ShortArray = when (kind) {
        0 -> gen(0.7) { t, _ ->
            if (Math.sin(2 * Math.PI * 440 * t) + 0.6 * Math.sin(2 * Math.PI * 554 * t) > 0) 0.7 else -0.7
        }
        1 -> gen(0.35) { t, d -> Math.sin(2 * Math.PI * (1800 * t - 1500 * t * t / (2 * d))) }
        2 -> gen(0.3) { t, _ ->
            Math.sin(2 * Math.PI * (if (t < 0.1) 988.0 else 1319.0) * t) * Math.exp(-3 * t)
        }
        3 -> gen(0.45) { t, _ ->
            Math.sin(2 * Math.PI * (45 * t + 20 * (1 - Math.exp(-6 * t)))) * Math.exp(-5 * t)
        }
        4 -> gen(0.9) { t, _ ->
            Math.sin(2 * Math.PI * (if (((t * 4).toInt() % 2) == 0) 800.0 else 600.0) * t)
        }
        5 -> gen(0.9) { t, d -> (Math.random() * 2 - 1) * Math.sin(Math.PI * t / d) }
        6 -> gen(1.0) { t, _ ->
            val f = if (t < 0.25) 392.0 else if (t < 0.5) 370.0 else if (t < 0.75) 349.0 else 330.0
            Math.sin(2 * Math.PI * f * t)
        }
        else -> gen(0.6) { t, _ -> Math.sin(2 * Math.PI * 880 * t) * Math.exp(-5 * t) }
    }

    private fun playSound(kind: Int) {
        Thread {
            try {
                val data = synth(kind)
                val track = AudioTrack.Builder()
                    .setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_GAME)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                            .build()
                    )
                    .setAudioFormat(
                        AudioFormat.Builder()
                            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                            .setSampleRate(22050)
                            .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                            .build()
                    )
                    .setBufferSizeInBytes(data.size * 2)
                    .setTransferMode(AudioTrack.MODE_STATIC)
                    .build()
                track.write(data, 0, data.size)
                track.play()
                Thread.sleep(data.size * 1000L / 22050 + 150)
                track.release()
            } catch (e: Exception) {
            }
        }.start()
    }

    private fun toggleSoundboard() {
        if (sbWin != null) { closeView(sbWin); sbWin = null; return }
        val hd = windowHeader("SOUNDBOARD") { closeView(sbWin); sbWin = null }
        val header = hd.first
        val inner = windowColumn()
        inner.addView(header)
        val names = arrayOf("Klakson", "Laser", "Koin", "Drum", "Alarm", "Sorak", "Sedih", "Ding")
        for (r in 0 until 2) {
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            for (k in 0 until 4) {
                val idx = r * 4 + k
                val b = pill(names[idx]) { playSound(idx) }
                b.textSize = 11f
                b.setPadding(dp(6), dp(12), dp(6), dp(12))
                row.addView(b, cell())
            }
            inner.addView(row)
        }
        inner.addView(note("Suara keluar lewat speaker. Rekan hanya mendengar bila mikrofon menangkapnya."))
        sbWin = openWindow(inner, header, dp(300), wrap, false, dp(30), dp(200))
    }

    // ================= jaringan =================

    private fun dnsFast() =
        Settings.Global.getString(contentResolver, "private_dns_mode") == "hostname"

    private fun toggleDns() {
        val on = dnsFast()
        val ok = if (on) putSetting("global", "private_dns_mode", "opportunistic")
        else (putSetting("global", "private_dns_specifier", "one.one.one.one") &&
            putSetting("global", "private_dns_mode", "hostname"))
        toast(if (!ok) "Butuh Shizuku aktif" else if (on) "DNS kembali otomatis" else "DNS Cepat aktif")
    }

    private fun wifiMgr() = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager

    private fun wifiOn() = try { wifiMgr().isWifiEnabled } catch (e: Exception) { false }

    private fun dataOn() = Settings.Global.getString(contentResolver, "mobile_data") == "1"

    private fun toggleWifi() {
        if (!Sh.ready()) { toast("Butuh Shizuku aktif"); return }
        val on = wifiOn()
        Thread { Sh.run("svc wifi ${if (on) "disable" else "enable"}") }.start()
        toast(if (on) "Wi-Fi dimatikan" else "Wi-Fi dinyalakan")
    }

    private fun toggleData() {
        if (!Sh.ready()) { toast("Butuh Shizuku aktif"); return }
        val on = dataOn()
        Thread { Sh.run("svc data ${if (on) "disable" else "enable"}") }.start()
        toast(if (on) "Data seluler dimatikan" else "Data seluler dinyalakan")
    }

    private fun toggleLowLat() {
        val cur = lowLat
        if (cur != null && cur.isHeld) {
            cur.release()
            lowLat = null
            toast("Low latency mati")
            return
        }
        try {
            val mode = if (Build.VERSION.SDK_INT >= 29) WifiManager.WIFI_MODE_FULL_LOW_LATENCY
            else WifiManager.WIFI_MODE_FULL_HIGH_PERF
            val lock = wifiMgr().createWifiLock(mode, "vexed")
            lock.acquire()
            lowLat = lock
            toast("Wi-Fi low latency aktif")
        } catch (e: Exception) {
            toast("Low latency gagal diaktifkan")
        }
    }

    // ================= sentuh & visual =================

    private fun cycleTouch() {
        val n = (prefs.getInt("touch", 0) + 1) % 3
        val lpt = intArrayOf(400, 300, 220)[n]
        val mpt = intArrayOf(300, 250, 200)[n]
        val ok = putSetting("secure", "long_press_timeout", lpt.toString()) &&
            putSetting("secure", "multi_press_timeout", mpt.toString())
        if (ok) {
            prefs.edit().putInt("touch", n).apply()
            toast("Respons sentuh: ${arrayOf("Normal", "Cepat", "Maks")[n]}")
        } else {
            toast("Butuh Shizuku aktif")
        }
    }

    private fun animFast() =
        Settings.Global.getString(contentResolver, "window_animation_scale") == "0.5"

    private fun toggleAnim() {
        val v = if (animFast()) "1.0" else "0.5"
        val ok = putSetting("global", "window_animation_scale", v) &&
            putSetting("global", "transition_animation_scale", v) &&
            putSetting("global", "animator_duration_scale", v)
        toast(if (!ok) "Butuh Shizuku aktif" else if (v == "0.5") "Animasi dipercepat" else "Animasi normal")
    }

    private fun satLabel() = arrayOf("1.0x", "1.3x", "1.6x", "2.0x")[prefs.getInt("sat", 0).coerceIn(0, 3)]

    private fun cycleSat() {
        if (!Sh.ready()) { toast("Butuh Shizuku aktif"); return }
        val n = (prefs.getInt("sat", 0) + 1) % 4
        val v = floatArrayOf(1.0f, 1.3f, 1.6f, 2.0f)[n]
        prefs.edit().putInt("sat", n).apply()
        Thread { Sh.run("service call SurfaceFlinger 1022 f $v") }.start()
        toast("Saturasi warna ${satLabel()} (bergantung perangkat)")
    }

    // ================= HUD =================

    private inner class GraphView : View(this@OverlayService) {
        private val n = 40
        private val f = IntArray(n)
        private val m = IntArray(n)
        private var idx = 0
        private val pf = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = dp(1).toFloat() * 1.6f
            color = cGreen
        }
        private val pm = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = dp(1).toFloat()
            color = accent2
        }

        fun push(fv: Int, pv: Int) {
            f[idx] = fv
            m[idx] = pv
            idx = (idx + 1) % n
            invalidate()
        }

        override fun onDraw(canvas: Canvas) {
            val w = width.toFloat()
            val h = height.toFloat()
            line(canvas, f, 120, pf, w, h)
            line(canvas, m, 200, pm, w, h)
        }

        private fun line(canvas: Canvas, d: IntArray, max: Int, paint: Paint, w: Float, h: Float) {
            val path = Path()
            for (k in 0 until n) {
                val i = (idx + k) % n
                val x = k * w / (n - 1)
                val y = h - (d[i].coerceIn(0, max) / max.toFloat()) * h
                if (k == 0) path.moveTo(x, y) else path.lineTo(x, y)
            }
            canvas.drawPath(path, paint)
        }
    }

    private val frameCb = object : Choreographer.FrameCallback {
        override fun doFrame(frameTimeNanos: Long) {
            frames++
            if (running && useChoreo) Choreographer.getInstance().postFrameCallback(this)
            else choreoActive = false
        }
    }

    private fun hudSpan(): SpannableStringBuilder {
        val real = realFps
        val fps = if (real >= 0) real else if (useChoreo) uiFps else -1
        val fpsColor = if (fps < 0) gray else if (fps >= 50) cGreen else if (fps >= 30) cYellow else cRed
        val pg = ping
        val msColor = if (pg < 0) gray else if (pg < 60) cGreen else if (pg < 120) cYellow else cRed
        val sb = SpannableStringBuilder()
        sb.addSpan(if (fps < 0) "--" else "$fps", fpsColor)
        sb.addSpan(if (real >= 0 || fps < 0) " FPS" else " FPS*", gray, 0.85f)
        sb.addSpan("  ·  ", gray, 0.85f)
        sb.addSpan(if (pg < 0) "--" else "$pg", msColor)
        sb.addSpan(" ms", gray, 0.85f)
        if (prefs.getBoolean("hud_clock", true)) {
            sb.addSpan("  ·  ", gray, 0.85f)
            sb.addSpan(hudFmt.format(Date()), textColor, 0.85f)
        }
        if (hudDetail) {
            val cpu = if (cpuPct >= 0) "$cpuPct%" else "--"
            val gpu = if (gpuPct >= 0) "$gpuPct%" else "--"
            val t = if (tempC > 0) tempC else battery().second
            sb.addSpan("\nCPU $cpu   GPU $gpu   RAM ${ramPct()}%", gray, 0.85f)
            sb.addSpan("\n$t°C   ↓${rxKb}K/s  ↑${txKb}K/s", gray, 0.85f)
            sb.addSpan("\nloss $loss%   jitter ${jitter}ms", gray, 0.85f)
            if (fpsNote.isNotEmpty()) sb.addSpan("\n$fpsNote", gray, 0.75f)
        }
        return sb
    }

    private val tick = object : Runnable {
        override fun run() {
            if (!running) return
            val s = hudText ?: return
            val now = SystemClock.elapsedRealtime()
            val dt = if (lastTickMs == 0L) 500L else (now - lastTickMs).coerceAtLeast(1L)
            lastTickMs = now
            if (useChoreo) { uiFps = (frames * 1000L / dt).toInt(); frames = 0 }
            val rx = TrafficStats.getTotalRxBytes()
            val tx = TrafficStats.getTotalTxBytes()
            if (rxPrev >= 0 && rx >= 0) {
                rxKb = (rx - rxPrev) * 1000L / dt / 1024L
                txKb = (tx - txPrev) * 1000L / dt / 1024L
            }
            rxPrev = rx
            txPrev = tx
            s.text = hudSpan()
            val fps = if (realFps >= 0) realFps else uiFps
            val pg = ping
            hudGraph?.push(fps, if (pg < 0) 0 else pg.toInt())
            main.postDelayed(this, 500)
        }
    }

    private fun applyHudMode() {
        hudGraph?.visibility = if (hudDetail) View.VISIBLE else View.GONE
        hudText?.text = hudSpan()
    }

    private fun toggleMonitor() {
        if (hud == null) {
            hudDetail = true
            toggleHud()
        } else {
            hudDetail = !hudDetail
            applyHudMode()
        }
    }

    private fun toggleHud() {
        if (hud != null) {
            running = false
            stopStream()
            main.removeCallbacks(tick)
            safeRemove(hud)
            hud = null
            hudText = null
            hudGraph = null
            return
        }
        val txt = TextView(this)
        txt.text = "--"
        txt.textSize = 10f
        txt.typeface = Typeface.DEFAULT_BOLD
        txt.setTextColor(textColor)
        val g = GraphView()
        g.visibility = if (hudDetail) View.VISIBLE else View.GONE
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(9), dp(5), dp(10), dp(5))
        box.background = ChamferDrawable(0xE6181B28.toInt(), 0xE60D0F17.toInt(), accent, dp(6).toFloat(), dens(), false)
        box.addView(txt)
        val glp = LinearLayout.LayoutParams(dp(110), dp(18))
        glp.topMargin = dp(3)
        box.addView(g, glp)

        val p = lp(wrap, wrap, fNoFocus or fLimits)
        p.gravity = Gravity.TOP or Gravity.START
        p.x = dp(10)
        p.y = dp(36)
        makeDraggableTap(box, box, p) {
            hudDetail = !hudDetail
            applyHudMode()
        }
        box.alpha = 0f
        wm.addView(box, p)
        box.animate().alpha(1f).setDuration(250).start()
        hud = box
        hudText = txt
        hudGraph = g

        running = true
        frames = 0
        lastTickMs = 0L
        realFps = -1
        fpsNote = ""
        rxPrev = -1L
        useChoreo = !(Sh.ready() || hasDump())
        if (useChoreo && !choreoActive) {
            choreoActive = true
            Choreographer.getInstance().postFrameCallback(frameCb)
        }
        main.removeCallbacks(tick)
        main.postDelayed(tick, 400)
        startPing()
        startSampler()
    }

    private fun startPing() {
        if (pingThread?.isAlive == true) return
        pingThread = Thread {
            val hist = ArrayList<Long>()
            while (running) {
                val t0 = System.nanoTime()
                val r = try {
                    Socket().use { it.connect(InetSocketAddress("1.1.1.1", 443), 1500) }
                    (System.nanoTime() - t0) / 1_000_000
                } catch (e: Exception) {
                    -1L
                }
                ping = r
                hist.add(r)
                if (hist.size > 10) hist.removeAt(0)
                loss = hist.count { it < 0 } * 100 / hist.size
                val ok = hist.filter { it >= 0 }
                var sum = 0L
                for (i in 1 until ok.size) sum += Math.abs(ok[i] - ok[i - 1])
                jitter = if (ok.size > 1) (sum / (ok.size - 1)).toInt() else 0
                try { Thread.sleep(1500) } catch (e: InterruptedException) { return@Thread }
            }
        }.also { it.start() }
    }

    // ---- pembacaan FPS asli: satu shell panjang yang terus menerus membaca timestamp frame ----

    private fun stopStream() {
        val pr = fpsProc
        fpsProc = null
        streamLayer = null
        try { pr?.destroy() } catch (e: Throwable) { }
        fpsReader?.interrupt()
        fpsReader = null
    }

    private fun startStream(layer: String) {
        stopStream()
        val q = layer.replace("'", "'\\''")
        val cmd = "while true; do dumpsys SurfaceFlinger --latency '$q' 2>/dev/null; " +
            "echo __END__ || break; sleep 0.4; done"
        val pr = Sh.startSys(cmd) ?: return
        fpsProc = pr
        streamLayer = layer
        zeroRuns = 0
        fpsReader = Thread {
            try {
                val br = pr.inputStream.bufferedReader()
                val buf = ArrayList<String>()
                while (running) {
                    val line = br.readLine() ?: break
                    if (line.trim() == "__END__") {
                        val f = parseFps(buf)
                        buf.clear()
                        if (f == null) {
                            realFps = -1
                            zeroRuns = 3
                        } else {
                            realFps = f
                            zeroRuns = if (f == 0) zeroRuns + 1 else 0
                        }
                    } else {
                        buf.add(line)
                    }
                }
            } catch (e: Throwable) {
            }
            if (fpsProc === pr) streamLayer = null
        }.also { it.start() }
    }

    /** Hitung FPS dari keluaran `dumpsys SurfaceFlinger --latency`. null = tidak ada data valid. */
    private fun parseFps(lines: List<String>): Int? {
        if (lines.size < 2) return null
        val ts = ArrayList<Long>()
        var latest = 0L
        var oldest = Long.MAX_VALUE
        for (i in 1 until lines.size) {
            val parts = lines[i].trim().split(Regex("\\s+"))
            if (parts.size < 3) continue
            val t = parts[1].toLongOrNull() ?: continue
            if (t <= 0L || t == Long.MAX_VALUE) continue
            ts.add(t)
            if (t > latest) latest = t
            if (t < oldest) oldest = t
        }
        if (ts.isEmpty()) return null
        if (System.nanoTime() - latest > 1_500_000_000L) return 0
        val span = latest - oldest
        if (span in 1 until 1_000_000_000L) {
            // buffer kurang dari 1 detik (FPS tinggi): skala ke 1 detik
            return ((ts.size - 1) * 1_000_000_000.0 / span).toInt()
        }
        var c = 0
        for (t in ts) if (t > latest - 1_000_000_000L) c++
        return c
    }

    private fun startSampler() {
        if (samplerThread?.isAlive == true) return
        samplerThread = Thread {
            var n = 0
            var lastScan = 0L
            while (running) {
                if (Sh.ready() || hasDump()) {
                    val now = SystemClock.elapsedRealtime()
                    val due = now - lastScan >= 3000L || (streamLayer == null && now - lastScan >= 1500L)
                    if (due) {
                        lastScan = now
                        var fg = foregroundPkg() ?: gamePkg
                        if (fg == null || fg == packageName) fg = fpsPkg
                        if (fg == null) {
                            fpsNote = "FPS: buka game dulu"
                        } else {
                            val changed = fg != fpsPkg
                            fpsPkg = fg
                            if (changed || streamLayer == null || zeroRuns >= 3) {
                                val l = pickLayer(fg)
                                if (l == null) {
                                    stopStream()
                                    realFps = -1
                                    fpsNote = "FPS: layer $fg tidak terbaca"
                                } else {
                                    if (l != streamLayer) startStream(l)
                                    zeroRuns = 0
                                    fpsNote = "FPS: $fg"
                                }
                            }
                        }
                    }
                } else {
                    stopStream()
                    realFps = -1
                    fpsNote = "FPS asli butuh Shizuku atau izin DUMP"
                }
                if (hudDetail && Sh.ready() && n % 2 == 0) readHw()
                n++
                try { Thread.sleep(1000) } catch (e: InterruptedException) { return@Thread }
            }
            stopStream()
        }.also { it.start() }
    }

    private fun foregroundPkg(): String? {
        val rx = Regex("""\bu\d+ ([\w.]+)/""")
        val a = Sh.sys("dumpsys activity activities 2>/dev/null | grep -E 'topResumedActivity|ResumedActivity' | head -n 4")
        rx.find(a)?.let { return it.groupValues[1] }
        val b = Sh.sys("dumpsys window 2>/dev/null | grep -E 'mCurrentFocus|mFocusedApp' | head -n 4")
        return rx.find(b)?.groupValues?.get(1)
    }

    /** Pilih layer game yang benar-benar sedang menggambar (FPS tertinggi di antara kandidat). */
    private fun pickLayer(pkg: String): String? {
        val layers = Sh.sys("dumpsys SurfaceFlinger --list 2>/dev/null").lines().map { it.trim() }
        val c = layers.filter { it.contains(pkg) }.sortedBy {
            when {
                it.contains("SurfaceView") && it.contains("BLAST") -> 0
                it.contains("SurfaceView") -> 1
                it.contains("BLAST") -> 2
                else -> 3
            }
        }.take(6)
        if (c.isEmpty()) return null
        var best: String? = null
        var bestFps = -1
        for (l in c) {
            val q = l.replace("'", "'\\''")
            val f = parseFps(Sh.sys("dumpsys SurfaceFlinger --latency '$q' 2>/dev/null").lines()) ?: continue
            if (f > bestFps) { best = l; bestFps = f }
        }
        return best ?: c.first()
    }

    private fun readHw() {
        val script = "head -n1 /proc/stat; echo '--'; " +
            "cat /sys/class/kgsl/kgsl-3d0/gpubusy 2>/dev/null; echo '--'; " +
            "cat /sys/kernel/gpu/gpu_busy 2>/dev/null; echo '--'; " +
            "cat /sys/kernel/ged/hal/gpu_utilization 2>/dev/null; echo '--'; " +
            "for z in /sys/class/thermal/thermal_zone*; do " +
            "echo \"\$(cat \$z/type 2>/dev/null) \$(cat \$z/temp 2>/dev/null)\"; done"
        val out = Sh.run(script)
        if (out.isEmpty()) return
        val secs = ArrayList<List<String>>()
        var cur = ArrayList<String>()
        for (line in out.lines()) {
            if (line.trim() == "--") {
                secs.add(cur)
                cur = ArrayList()
            } else {
                cur.add(line)
            }
        }
        secs.add(cur)

        // CPU
        val cpuLine = secs.getOrNull(0)?.firstOrNull()
        if (cpuLine != null) {
            val v = cpuLine.trim().split(Regex("\\s+")).drop(1).mapNotNull { it.toLongOrNull() }
            if (v.size >= 5) {
                val idle = v[3] + v[4]
                val total = v.sum()
                if (prevTotal > 0) {
                    val dt = total - prevTotal
                    val di = idle - prevIdle
                    if (dt > 0) cpuPct = ((dt - di) * 100 / dt).toInt().coerceIn(0, 100)
                }
                prevTotal = total
                prevIdle = idle
            }
        }

        // GPU (bergantung SoC)
        var g = -1
        val num = Regex("\\d+")
        val k = secs.getOrNull(1)?.firstOrNull()
        if (k != null) {
            val nums = num.findAll(k).map { it.value.toLong() }.toList()
            if (nums.size >= 2 && nums[1] > 0) g = (nums[0] * 100 / nums[1]).toInt()
        }
        if (g < 0) {
            val l = secs.getOrNull(2)?.firstOrNull()
            val x = if (l != null) num.find(l)?.value?.toIntOrNull() else null
            if (x != null) g = x
        }
        if (g < 0) {
            val l = secs.getOrNull(3)?.firstOrNull()
            val x = if (l != null) num.find(l)?.value?.toIntOrNull() else null
            if (x != null) g = x
        }
        gpuPct = if (g in 0..100) g else -1

        // suhu
        val temps = ArrayList<Pair<String, Int>>()
        for (ln in secs.last()) {
            val tk = ln.trim().split(Regex("\\s+"))
            val raw = tk.lastOrNull()?.toIntOrNull() ?: continue
            val tc = if (raw > 1000) raw / 1000 else raw
            if (tc in 10..120) temps.add(Pair(tk.dropLast(1).joinToString(" "), tc))
        }
        val pick = temps.firstOrNull {
            val n = it.first.lowercase()
            n.contains("cpu") || n.contains("soc") || n.contains("tsens") || n.contains("ap")
        } ?: temps.maxByOrNull { it.second }
        tempC = pick?.second ?: -1
    }

    // ================= catatan =================

    private fun loadNotes(): JSONArray = try {
        JSONArray(prefs.getString("notes", "[]"))
    } catch (e: Exception) {
        JSONArray()
    }

    private fun saveNotes(a: JSONArray) {
        prefs.edit().putString("notes", a.toString()).apply()
    }

    private fun toggleNotes() {
        if (notesWin != null) { closeNotes(); return }
        val hd = windowHeader("CATATAN") { closeNotes() }
        val header = hd.first
        notesTitle = hd.second
        val body = LinearLayout(this)
        body.orientation = LinearLayout.VERTICAL
        notesBody = body
        val inner = windowColumn()
        inner.addView(header)
        inner.addView(body)
        notesWin = openWindow(inner, header, dp(300), wrap, true, dp(24), dp(90))
        notesShowList()
    }

    private fun closeNotes() {
        closeView(notesWin)
        notesWin = null
        notesBody = null
        notesTitle = null
    }

    private fun notesShowList() {
        val body = notesBody ?: return
        body.removeAllViews()
        notesTitle?.text = "CATATAN"
        body.addView(pill("+  Catatan baru", true) {
            val old = loadNotes()
            val na = JSONArray()
            na.put(JSONObject().put("t", "").put("ts", System.currentTimeMillis()))
            for (i in 0 until old.length()) na.put(old.get(i))
            saveNotes(na)
            notesShowEditor(0)
        })
        val arr = loadNotes()
        val list = LinearLayout(this)
        list.orientation = LinearLayout.VERTICAL
        if (arr.length() == 0) list.addView(note("Belum ada catatan."))
        val fmt = SimpleDateFormat("d MMM HH:mm", Locale.getDefault())
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            val raw = o.optString("t", "").trim()
            val preview = if (raw.isEmpty()) "(kosong)" else raw.lines().first().take(42)
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER_VERTICAL
            row.setPadding(dp(12), dp(10), dp(6), dp(10))
            row.background = ChamferDrawable(0xFF262B3D.toInt(), 0xFF171A26.toInt(), 0xFF3A4057.toInt(), dp(8).toFloat(), dens(), false)
            row.setOnClickListener { notesShowEditor(i) }
            val col = LinearLayout(this)
            col.orientation = LinearLayout.VERTICAL
            val pv = TextView(this)
            pv.text = preview
            pv.setTextColor(textColor)
            pv.textSize = 13f
            pv.maxLines = 1
            col.addView(pv)
            val dt = TextView(this)
            dt.text = fmt.format(Date(o.optLong("ts", 0L)))
            dt.setTextColor(gray)
            dt.textSize = 10f
            col.addView(dt)
            row.addView(col, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            val del = IconView(this, Icons.TRASH, cRed)
            del.setPadding(dp(5), dp(5), dp(5), dp(5))
            del.setOnClickListener {
                val a2 = loadNotes()
                a2.remove(i)
                saveNotes(a2)
                notesShowList()
            }
            row.addView(del, LinearLayout.LayoutParams(dp(30), dp(30)))
            val rlp = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
            )
            rlp.setMargins(0, dp(4), 0, dp(4))
            list.addView(row, rlp)
        }
        val sv = ScrollView(this)
        sv.addView(list)
        body.addView(sv, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(240)))
    }

    private fun notesShowEditor(idx: Int) {
        val body = notesBody ?: return
        body.removeAllViews()
        notesTitle?.text = "EDIT CATATAN"
        val arr = loadNotes()
        val o = arr.optJSONObject(idx)
        if (o == null) { notesShowList(); return }
        val et = EditText(this)
        et.setText(o.optString("t", ""))
        et.hint = "Tulis di sini..."
        et.setHintTextColor(0xFF7A8099.toInt())
        et.setTextColor(textColor)
        et.textSize = 14f
        et.gravity = Gravity.TOP or Gravity.START
        et.minLines = 8
        et.maxLines = 12
        et.setPadding(dp(12), dp(10), dp(12), dp(10))
        et.background = ChamferDrawable(0xFF1E2233.toInt(), 0xFF171A26.toInt(), 0xFF3A4057.toInt(), dp(8).toFloat(), dens(), false)
        et.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) {
                o.put("t", s?.toString() ?: "")
                o.put("ts", System.currentTimeMillis())
                saveNotes(arr)
            }
        })
        body.addView(et, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
        ))
        val actions = LinearLayout(this)
        actions.orientation = LinearLayout.HORIZONTAL
        actions.addView(pill("Kembali") { notesShowList() }, cell())
        actions.addView(pill("Salin") {
            copyText("catatan", et.text.toString())
            toast("Catatan disalin")
        }, cell())
        body.addView(actions)
        et.requestFocus()
    }

    // ================= stopwatch =================

    private fun swElapsed(): Long =
        swAcc + (if (swRunning) SystemClock.elapsedRealtime() - swBase else 0L)

    private fun swFmt(ms: Long): String =
        String.format(Locale.US, "%02d:%02d.%02d", ms / 60000, (ms / 1000) % 60, (ms / 10) % 100)

    private val swTick = object : Runnable {
        override fun run() {
            val t = swText ?: return
            t.text = swFmt(swElapsed())
            if (swRunning) main.postDelayed(this, 50)
        }
    }

    private fun toggleStopwatch() {
        if (swWin != null) {
            swRunning = false
            main.removeCallbacks(swTick)
            closeView(swWin)
            swWin = null
            swText = null
            return
        }
        swAcc = 0L
        swRunning = false
        val hd = windowHeader("STOPWATCH") { toggleStopwatch() }
        val header = hd.first
        val time = TextView(this)
        time.text = "00:00.00"
        time.textSize = 34f
        time.typeface = Typeface.DEFAULT_BOLD
        time.setTextColor(textColor)
        time.gravity = Gravity.CENTER
        time.setPadding(0, dp(8), 0, dp(10))
        swText = time

        val startBtn = pill("Mulai", true) { }
        startBtn.setOnClickListener {
            if (swRunning) {
                swAcc = swElapsed()
                swRunning = false
                startBtn.text = "Lanjut"
            } else {
                swBase = SystemClock.elapsedRealtime()
                swRunning = true
                startBtn.text = "Jeda"
                main.post(swTick)
            }
        }
        val resetBtn = pill("Reset") {
            swAcc = 0L
            swBase = SystemClock.elapsedRealtime()
            time.text = swFmt(0L)
        }
        val actions = LinearLayout(this)
        actions.orientation = LinearLayout.HORIZONTAL
        actions.addView(startBtn, cell())
        actions.addView(resetBtn, cell())

        val inner = windowColumn()
        inner.addView(header)
        inner.addView(time)
        inner.addView(actions)
        swWin = openWindow(inner, header, dp(240), wrap, false, dp(40), dp(150))
    }

    // ================= kalkulator =================

    private fun toggleCalc() {
        if (calc != null) {
            closeView(calc)
            calc = null
            return
        }
        var acc = 0.0
        var op = ' '
        var cur = "0"
        var fresh = true

        val display = TextView(this)
        display.text = "0"
        display.textSize = 28f
        display.typeface = Typeface.DEFAULT_BOLD
        display.setTextColor(textColor)
        display.gravity = Gravity.END
        display.maxLines = 1
        display.setPadding(dp(8), dp(6), dp(12), dp(10))

        fun fmt(d: Double): String {
            if (d.isNaN()) return "NaN"
            val s = d.toString()
            return if (s.endsWith(".0")) s.dropLast(2) else s
        }

        fun calcResult(): Double {
            val b = cur.toDoubleOrNull() ?: 0.0
            return when (op) {
                '+' -> acc + b
                '-' -> acc - b
                '×' -> acc * b
                '÷' -> if (b == 0.0) Double.NaN else acc / b
                else -> b
            }
        }

        fun press(k: String) {
            val c = k[0]
            if (c.isDigit()) {
                if (fresh || cur == "NaN") { cur = k; fresh = false }
                else cur = if (cur == "0") k else cur + k
            } else when (k) {
                "." -> {
                    if (fresh || cur == "NaN") { cur = "0."; fresh = false }
                    else if (!cur.contains(".")) cur += "."
                }
                "C" -> { acc = 0.0; op = ' '; cur = "0"; fresh = true }
                "⌫" -> {
                    cur = if (cur.length > 1 && cur != "NaN") cur.dropLast(1) else "0"
                    if (cur == "-") cur = "0"
                }
                "%" -> cur = fmt((cur.toDoubleOrNull() ?: 0.0) / 100)
                "=" -> if (op != ' ') {
                    acc = calcResult()
                    cur = fmt(acc)
                    op = ' '
                    fresh = true
                }
                else -> {
                    if (!fresh) { acc = calcResult(); cur = fmt(acc) }
                    op = c
                    fresh = true
                }
            }
            display.text = if (cur == "NaN") "Error" else cur
        }

        fun key(label: String, isOp: Boolean): TextView {
            val kv = TextView(this)
            kv.text = label
            kv.textSize = 18f
            kv.typeface = Typeface.DEFAULT_BOLD
            kv.gravity = Gravity.CENTER
            kv.setTextColor(textColor)
            kv.setPadding(0, dp(12), 0, dp(12))
            kv.background = if (isOp)
                ChamferDrawable(accent, accent2, 0xFFFFFFFF.toInt(), dp(7).toFloat(), dens(), false)
            else
                ChamferDrawable(0xFF262B3D.toInt(), 0xFF171A26.toInt(), 0xFF3A4057.toInt(), dp(7).toFloat(), dens(), false)
            kv.setOnTouchListener { v, e ->
                when (e.actionMasked) {
                    MotionEvent.ACTION_DOWN ->
                        v.animate().scaleX(0.92f).scaleY(0.92f).setDuration(60).start()
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL ->
                        v.animate().scaleX(1f).scaleY(1f).setDuration(100).start()
                }
                false
            }
            kv.setOnClickListener { press(label) }
            return kv
        }

        val hd = windowHeader("KALKULATOR") { closeView(calc); calc = null }
        val header = hd.first
        val inner = windowColumn()
        inner.addView(header)
        inner.addView(display)

        val rows = listOf(
            listOf("C" to 1f, "⌫" to 1f, "%" to 1f, "÷" to 1f),
            listOf("7" to 1f, "8" to 1f, "9" to 1f, "×" to 1f),
            listOf("4" to 1f, "5" to 1f, "6" to 1f, "-" to 1f),
            listOf("1" to 1f, "2" to 1f, "3" to 1f, "+" to 1f),
            listOf("0" to 2f, "." to 1f, "=" to 1f)
        )
        val ops = listOf("÷", "×", "-", "+", "=")
        for (r in rows) {
            val rowView = LinearLayout(this)
            rowView.orientation = LinearLayout.HORIZONTAL
            for ((label, w) in r) {
                val lpk = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, w)
                lpk.setMargins(dp(3), dp(3), dp(3), dp(3))
                rowView.addView(key(label, label in ops), lpk)
            }
            inner.addView(rowView)
        }
        calc = openWindow(inner, header, dp(250), wrap, false, dp(30), dp(120))
    }

    // ================= browser =================

    private fun toggleBrowser() {
        if (browser != null) {
            closeBrowser()
            return
        }
        val hd = windowHeader("BROWSER") { closeBrowser() }
        val header = hd.first
        val inner = windowColumn()

        val urlBox = EditText(this)
        urlBox.hint = "Cari atau ketik alamat"
        urlBox.setHintTextColor(0xFF7A8099.toInt())
        urlBox.setTextColor(textColor)
        urlBox.textSize = 13f
        urlBox.isSingleLine = true
        urlBox.imeOptions = EditorInfo.IME_ACTION_GO

        val wv = WebView(this)
        wv.settings.javaScriptEnabled = true
        wv.webViewClient = WebViewClient()
        wv.loadUrl("https://www.google.com")
        web = wv

        urlBox.setOnEditorActionListener { v, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_GO) {
                var u = v.text.toString().trim()
                if (!u.startsWith("http")) {
                    u = if (u.contains(".") && !u.contains(" ")) "https://$u"
                    else "https://www.google.com/search?q=" + Uri.encode(u)
                }
                wv.loadUrl(u)
                true
            } else false
        }

        inner.addView(header)
        inner.addView(urlBox)
        inner.addView(wv, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))
        browser = openWindow(inner, header, dp(300), dp(400), true, dp(20), dp(80))
    }

    private fun closeBrowser() {
        web?.destroy()
        web = null
        closeView(browser)
        browser = null
    }

    // ================= game launcher =================

    private class AppItem(val pkg: String, val label: String, val icon: Drawable?, val game: Boolean)

    private var appCache: List<AppItem>? = null
    private var launcherList: LinearLayout? = null
    private var launchFilter = 0
    private var launchQuery = ""

    private val gameHints = listOf(
        "pubg", "tencent", "mobilelegends", "moonton", "freefire", "garena", "supercell", "activision",
        "mihoyo", "hoyoverse", "roblox", "mojang", "epicgames", "netease", "riotgames", "lilithgames",
        "proximabeta", "levelinfinite", "gameloft", "konami", "ubisoft", "miniclip", "playrix", "habby",
        "krafton", "valve", "nintendo", "bandainamco", "kiloo", "rovio", "zynga", "scopely", "voodoo",
        "ketchapp", "innersloth", "devsisters", "nexon", "com.ea.", "unity3d", ".game", ".games"
    )

    @Suppress("DEPRECATION")
    private fun isGameApp(ai: ApplicationInfo): Boolean {
        if (ai.category == ApplicationInfo.CATEGORY_GAME) return true
        if ((ai.flags and ApplicationInfo.FLAG_IS_GAME) != 0) return true
        val p = ai.packageName.lowercase()
        return gameHints.any { p.contains(it) }
    }

    private fun favs(): MutableSet<String> = try {
        val a = JSONArray(prefs.getString("favs", "[]"))
        val s = LinkedHashSet<String>()
        for (i in 0 until a.length()) s.add(a.getString(i))
        s
    } catch (e: Exception) {
        LinkedHashSet()
    }

    private fun saveFavs(s: Set<String>) {
        prefs.edit().putString("favs", JSONArray(s.toList()).toString()).apply()
    }

    private fun loadApps(done: () -> Unit) {
        Thread {
            val pm = packageManager
            val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            val list = ArrayList<AppItem>()
            val seen = HashSet<String>()
            for (ri in pm.queryIntentActivities(intent, 0)) {
                val ai = ri.activityInfo.applicationInfo
                val pkg = ai.packageName
                if (pkg == packageName || !seen.add(pkg)) continue
                val label = try { ri.loadLabel(pm).toString() } catch (e: Exception) { pkg }
                val icon = try { ri.loadIcon(pm) } catch (e: Exception) { null }
                list.add(AppItem(pkg, label, icon, isGameApp(ai)))
            }
            list.sortBy { it.label.lowercase() }
            appCache = list
            main.post { done() }
        }.start()
    }

    private fun closeLauncher() {
        closeView(launcherWin)
        launcherWin = null
        launcherList = null
    }

    private fun toggleLauncher() {
        if (launcherWin != null) { closeLauncher(); return }
        val hd = windowHeader("GAME LAUNCHER") { closeLauncher() }
        val header = hd.first
        val inner = windowColumn()
        inner.addView(header)

        val search = EditText(this)
        search.hint = "Cari game atau aplikasi"
        search.setHintTextColor(0xFF7A8099.toInt())
        search.setTextColor(textColor)
        search.textSize = 13f
        search.isSingleLine = true
        search.setText(launchQuery)
        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) {
                launchQuery = s?.toString() ?: ""
                renderLauncher()
            }
        })
        inner.addView(search)
        inner.addView(chipRow(listOf("Game", "Semua", "Favorit"), launchFilter) {
            launchFilter = it
            renderLauncher()
        })

        val list = LinearLayout(this)
        list.orientation = LinearLayout.VERTICAL
        launcherList = list
        val sv = ScrollView(this)
        sv.isVerticalScrollBarEnabled = false
        sv.addView(list)
        val slp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f)
        slp.topMargin = dp(6)
        inner.addView(sv, slp)

        inner.addView(label("Otomatis aktif saat game dibuka"))
        val r1 = LinearLayout(this)
        r1.orientation = LinearLayout.HORIZONTAL
        r1.addView(switchChip("HUD", "la_hud", true), cell())
        r1.addView(switchChip("Crosshair", "la_xh", false), cell())
        r1.addView(switchChip("Robot", "la_ai", false), cell())
        inner.addView(r1)
        val r2 = LinearLayout(this)
        r2.orientation = LinearLayout.HORIZONTAL
        r2.addView(switchChip("Boost", "la_boost", false), cell())
        r2.addView(switchChip("Jam", "la_clock", false), cell())
        r2.addView(Space(this), cell())
        inner.addView(r2)

        val h = minOf(dp(520), screenH() - dp(40))
        launcherWin = openWindow(inner, header, dp(310), h, true, dp(20), dp(24))

        if (appCache == null) {
            renderLauncher()
            loadApps { renderLauncher() }
        } else {
            renderLauncher()
        }
    }

    private fun renderLauncher() {
        val list = launcherList ?: return
        list.removeAllViews()
        val all = appCache
        if (all == null) { list.addView(note("Memuat daftar aplikasi...")); return }
        val fv = favs()
        val q = launchQuery.trim().lowercase()
        var items = when (launchFilter) {
            0 -> all.filter { it.game || it.pkg in fv }
            2 -> all.filter { it.pkg in fv }
            else -> all
        }
        if (q.isNotEmpty()) items = items.filter { it.label.lowercase().contains(q) || it.pkg.contains(q) }
        items = items.sortedWith(compareByDescending<AppItem> { it.pkg in fv }.thenBy { it.label.lowercase() })
        if (items.isEmpty()) {
            list.addView(note(
                when {
                    launchFilter == 2 -> "Belum ada favorit. Ketuk bintang di samping aplikasi."
                    launchFilter == 0 -> "Game tidak terdeteksi otomatis. Pilih \"Semua\" lalu beri bintang."
                    else -> "Tidak ada hasil."
                }
            ))
            return
        }
        for (a in items.take(150)) {
            val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
            lp.setMargins(0, 0, 0, dp(5))
            list.addView(appRow(a, a.pkg in fv), lp)
        }
    }

    private fun appRow(a: AppItem, fav: Boolean): View {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.setPadding(dp(8), dp(6), dp(4), dp(6))
        row.background = ChamferDrawable(0xFF1F2333.toInt(), 0xFF141722.toInt(), 0xFF2E3448.toInt(), dp(8).toFloat(), dens(), false)
        val iv = ImageView(this)
        iv.setImageDrawable(a.icon)
        row.addView(iv, LinearLayout.LayoutParams(dp(36), dp(36)))
        val tv = TextView(this)
        tv.text = a.label
        tv.textSize = 13f
        tv.setTextColor(textColor)
        tv.maxLines = 1
        tv.ellipsize = TextUtils.TruncateAt.END
        tv.setPadding(dp(10), 0, dp(6), 0)
        row.addView(tv, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        val star = IconView(this, Icons.STAR, if (fav) cYellow else gray)
        star.setPadding(dp(6), dp(6), dp(6), dp(6))
        star.setOnClickListener {
            val s = favs()
            if (!s.add(a.pkg)) s.remove(a.pkg)
            saveFavs(s)
            renderLauncher()
        }
        row.addView(star, LinearLayout.LayoutParams(dp(34), dp(34)))
        row.setOnClickListener { launchApp(a) }
        return row
    }

    private fun launchApp(a: AppItem) {
        val li = packageManager.getLaunchIntentForPackage(a.pkg)
        if (li == null) { toast("Tidak bisa membuka ${a.label}"); return }
        li.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        closeLauncher()
        gamePkg = a.pkg
        try { startActivity(li) } catch (e: Exception) { toast("Gagal membuka ${a.label}"); return }
        toast("Membuka ${a.label}")
        main.postDelayed({
            if (prefs.getBoolean("la_hud", true) && hud == null) { hudDetail = false; toggleHud() }
            if (prefs.getBoolean("la_xh", false) && crosshair == null) toggleCrosshair()
            if (prefs.getBoolean("la_clock", false) && clockWin == null) toggleClock()
            if (prefs.getBoolean("la_ai", false) && robotWin == null) toggleRobot()
            if (prefs.getBoolean("la_boost", false) && !boostOn) toggleBoost()
        }, 2500)
    }

    private fun openByName(raw: String): String {
        var name = raw.trim().lowercase()
        name = name.removePrefix("game ").removePrefix("aplikasi ").removePrefix("app ").trim()
        if (name.isEmpty()) return "Mau buka game apa?"
        val alias = mapOf("ml" to "mobile legends", "ff" to "free fire", "pubgm" to "pubg", "coc" to "clash of clans")
        name = alias[name] ?: name
        val c = appCache
        if (c == null) {
            loadApps { botReply(openByName(name)) }
            return "Sebentar, aku cek daftar aplikasimu..."
        }
        val hit = c.firstOrNull { it.label.lowercase() == name }
            ?: c.firstOrNull { it.label.lowercase().startsWith(name) }
            ?: c.firstOrNull { it.label.lowercase().contains(name) }
            ?: return "Aku tidak menemukan \"$name\" di HP-mu."
        launchApp(hit)
        return "Membuka ${hit.label}. Semoga menang!"
    }

    // ================= jam digital =================

    private var clockText: TextView? = null

    private fun clockSpan(): SpannableStringBuilder {
        val d = Date()
        val pat = if (prefs.getBoolean("clk24", true)) "HH:mm:ss" else "hh:mm:ss a"
        val sb = SpannableStringBuilder()
        sb.addSpan(SimpleDateFormat(pat, Locale.getDefault()).format(d), textColor)
        sb.addSpan("\n" + SimpleDateFormat("EEEE, d MMM yyyy", Locale("id", "ID")).format(d), gray, 0.42f)
        return sb
    }

    private val clockTick = object : Runnable {
        override fun run() {
            val t = clockText ?: return
            t.text = clockSpan()
            main.postDelayed(this, 1005L - System.currentTimeMillis() % 1000L)
        }
    }

    private fun toggleClock() {
        if (clockWin != null) {
            main.removeCallbacks(clockTick)
            closeView(clockWin)
            clockWin = null
            clockText = null
            return
        }
        val t = TextView(this)
        t.textSize = 26f
        t.typeface = Typeface.DEFAULT_BOLD
        t.gravity = Gravity.CENTER
        t.setTextColor(textColor)
        t.letterSpacing = 0.05f
        t.setPadding(dp(14), dp(6), dp(14), dp(8))
        t.text = clockSpan()
        val box = FrameLayout(this)
        box.background = ChamferDrawable(0xE6181B28.toInt(), 0xE60D0F17.toInt(), accent, dp(8).toFloat(), dens(), false)
        box.addView(t)
        val p = lp(wrap, wrap, fNoFocus or fLimits)
        p.gravity = Gravity.TOP or Gravity.START
        p.x = prefs.getInt("clk_x", dp(10))
        p.y = prefs.getInt("clk_y", dp(90))
        makeDraggableTap(box, box, p, onEnd = {
            prefs.edit().putInt("clk_x", p.x).putInt("clk_y", p.y).apply()
        }) {
            prefs.edit().putBoolean("clk24", !prefs.getBoolean("clk24", true)).apply()
            t.text = clockSpan()
        }
        box.alpha = 0f
        wm.addView(box, p)
        box.animate().alpha(1f).setDuration(220).start()
        clockWin = box
        clockText = t
        main.removeCallbacks(clockTick)
        main.postDelayed(clockTick, 1005L - System.currentTimeMillis() % 1000L)
    }

    // ================= asisten AI (robot pendamping) =================

    private val chatHistory = ArrayList<Pair<String, String>>()
    private var lastTip = 0L
    private val bubbleHide = Runnable {
        safeRemove(bubbleWin)
        bubbleWin = null
        if (chatWin == null) robotView?.mood = 0
    }

    private fun toggleRobot() {
        if (robotWin != null) { closeRobot(); return }
        val size = dp(60)
        val rv = RobotView(this, accent, accent2)
        val p = lp(size, size, fNoFocus or fLimits)
        p.gravity = Gravity.TOP or Gravity.START
        p.x = prefs.getInt("rb_x", dp(14)).coerceIn(0, screenW() - size)
        p.y = prefs.getInt("rb_y", screenH() / 2).coerceIn(0, screenH() - size)
        makeDraggableTap(rv, rv, p, onEnd = {
            prefs.edit().putInt("rb_x", p.x).putInt("rb_y", p.y).apply()
        }) { toggleChat() }
        rv.alpha = 0f
        wm.addView(rv, p)
        rv.animate().alpha(1f).setDuration(250).start()
        robotWin = rv
        robotView = rv
        robotParams = p
        val hasKey = !prefs.getString("ai_key", "").isNullOrBlank()
        say(if (hasKey) "Halo! Aku VeXed Bot. Ketuk aku kalau butuh bantuan." else "Halo! Ketuk aku. Pasang kunci API di aplikasi VeXed biar aku bisa ngobrol penuh.", 5000)
        main.removeCallbacks(companionTick)
        main.postDelayed(companionTick, 25000)
    }

    private fun closeRobot() {
        main.removeCallbacks(companionTick)
        main.removeCallbacks(bubbleHide)
        closeChat()
        safeRemove(bubbleWin)
        bubbleWin = null
        closeView(robotWin)
        robotWin = null
        robotView = null
        robotParams = null
    }

    private fun say(text: String, ms: Long = 4500L) {
        val p0 = robotParams ?: return
        if (robotWin == null) return
        main.removeCallbacks(bubbleHide)
        safeRemove(bubbleWin)
        val tv = TextView(this)
        tv.text = text
        tv.textSize = 12f
        tv.setTextColor(textColor)
        tv.maxWidth = dp(220)
        tv.setPadding(dp(12), dp(8), dp(12), dp(8))
        tv.background = ChamferDrawable(0xF2181B28.toInt(), 0xF20D0F17.toInt(), accent, dp(8).toFloat(), dens(), false)
        tv.measure(
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED),
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
        )
        val w = tv.measuredWidth
        val rightSide = p0.x + dp(30) < screenW() / 2
        val bp = lp(wrap, wrap, fNoFocus or fNoTouch or fLimits)
        bp.gravity = Gravity.TOP or Gravity.START
        bp.x = (if (rightSide) p0.x + dp(64) else p0.x - w - dp(4)).coerceIn(0, maxOf(0, screenW() - w))
        bp.y = (p0.y + dp(8)).coerceIn(0, maxOf(0, screenH() - dp(60)))
        try { wm.addView(tv, bp) } catch (e: Exception) { return }
        bubbleWin = tv
        robotView?.mood = 2
        main.postDelayed(bubbleHide, ms)
    }

    private val companionTick = object : Runnable {
        override fun run() {
            if (robotWin == null) return
            val now = SystemClock.elapsedRealtime()
            if (chatWin == null && now - lastTip > 60000L) {
                val bt = battery()
                val tip = when {
                    hud != null && realFps in 1..27 -> "FPS-nya turun ($realFps). Coba turunkan grafis atau nyalakan Boost."
                    hud != null && ping > 150 -> "Ping tinggi ($ping ms). Coba DNS Cepat atau pindah jaringan."
                    bt.second >= 43 -> "HP mulai panas (${bt.second}°C). Istirahat sebentar atau lepas casing."
                    ramPct() >= 92 -> "RAM hampir penuh. Ketuk aku lalu bilang \"bersihkan ram\"."
                    else -> null
                }
                if (tip != null) {
                    say(tip, 6000L)
                    lastTip = now
                }
            }
            main.postDelayed(this, 20000L)
        }
    }

    private fun closeChat() {
        closeView(chatWin)
        chatWin = null
        chatList = null
        chatScroll = null
    }

    private fun addMsg(text: String, mine: Boolean): TextView {
        val t = TextView(this)
        t.text = text
        t.textSize = 12.5f
        t.setTextColor(textColor)
        t.setPadding(dp(10), dp(7), dp(10), dp(7))
        t.maxWidth = dp(220)
        t.background = if (mine)
            ChamferDrawable(accent, accent2, 0x00FFFFFF, dp(8).toFloat(), dens(), false)
        else
            ChamferDrawable(0xFF262B3D.toInt(), 0xFF171A26.toInt(), 0xFF3A4057.toInt(), dp(8).toFloat(), dens(), false)
        val list = chatList ?: return t
        val lp = LinearLayout.LayoutParams(wrap, wrap)
        lp.gravity = if (mine) Gravity.END else Gravity.START
        lp.setMargins(0, dp(4), 0, dp(4))
        list.addView(t, lp)
        chatScroll?.post { chatScroll?.fullScroll(View.FOCUS_DOWN) }
        return t
    }

    private fun toggleChat() {
        if (chatWin != null) { closeChat(); return }
        val hd = windowHeader("VEXED BOT") { closeChat() }
        val header = hd.first
        val inner = windowColumn()
        inner.addView(header)

        val list = LinearLayout(this)
        list.orientation = LinearLayout.VERTICAL
        val sv = ScrollView(this)
        sv.isVerticalScrollBarEnabled = false
        sv.addView(list)
        inner.addView(sv, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))
        chatList = list
        chatScroll = sv

        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        val et = EditText(this)
        et.hint = "Tanya atau minta tolong..."
        et.setHintTextColor(0xFF7A8099.toInt())
        et.setTextColor(textColor)
        et.textSize = 13f
        et.isSingleLine = true
        et.imeOptions = EditorInfo.IME_ACTION_SEND
        val send = IconView(this, Icons.SEND, accent2)
        send.setPadding(dp(8), dp(8), dp(8), dp(8))
        row.addView(et, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        row.addView(send, LinearLayout.LayoutParams(dp(40), dp(40)))
        inner.addView(row)
        fun go() {
            val t = et.text.toString()
            et.setText("")
            sendChat(t)
        }
        et.setOnEditorActionListener { _, a, _ ->
            if (a == EditorInfo.IME_ACTION_SEND) { go(); true } else false
        }
        send.setOnClickListener { go() }

        val h = minOf(dp(400), screenH() - dp(80))
        chatWin = openWindow(inner, header, dp(300), h, true, dp(20), dp(50))

        if (chatHistory.isEmpty()) {
            addMsg("Hai! Aku VeXed Bot. Tanya apa saja soal game, atau suruh aku, misalnya: \"nyalakan hud\", \"pasang crosshair\", \"buka free fire\".", false)
        } else {
            for (m in chatHistory) addMsg(m.second, m.first == "user")
        }
    }

    private fun botReply(text: String) {
        chatHistory.add("assistant" to text)
        while (chatHistory.size > 30) chatHistory.removeAt(0)
        if (chatWin != null) addMsg(text, false) else say(text.take(200), 6000L)
    }

    private fun sendChat(text: String) {
        val q = text.trim()
        if (q.isEmpty()) return
        addMsg(q, true)
        chatHistory.add("user" to q)
        val local = localCommand(q)
        if (local != null) { botReply(local); return }
        val key = prefs.getString("ai_key", "") ?: ""
        if (key.isBlank()) {
            botReply("Aku belum punya kunci API, jadi baru bisa perintah dasar: hud, crosshair, boost, jam, ram, screenshot, buka <nama game>. Pasang kunci di aplikasi VeXed (tombol Atur AI).")
            return
        }
        val model = prefs.getString("ai_model", "claude-haiku-5-5") ?: "claude-haiku-5-5"
        val msgs = ArrayList(chatHistory.takeLast(12))
        while (msgs.isNotEmpty() && msgs[0].first != "user") msgs.removeAt(0)
        val sys = aiSystem()
        val typing = addMsg("...", false)
        robotView?.mood = 1
        Thread {
            var reply = ""
            var err: String? = null
            try {
                reply = Ai.ask(key, model, sys, msgs)
            } catch (e: Exception) {
                err = e.message ?: "tidak bisa terhubung"
            }
            main.post {
                robotView?.mood = 0
                chatList?.removeView(typing)
                if (err != null) {
                    botReply("Gagal: $err")
                } else {
                    val acts = Regex("""\[\[ACT:(\w+)]]""").findAll(reply).map { it.groupValues[1] }.toList()
                    val clean = reply.replace(Regex("""\s*\[\[ACT:\w+]]"""), "").trim()
                    botReply(if (clean.isEmpty()) "Siap!" else clean)
                    for (a in acts) runAction(a)
                }
            }
        }.start()
    }

    private fun aiSystem(): String {
        val bt = battery()
        return "Kamu VeXed Bot, asisten gaming mungil berbentuk robot yang melayang di atas layar HP pemain. " +
            "Jawab singkat (maksimal 3 kalimat), santai, bahasa Indonesia, tanpa markdown. " +
            "Bantu soal game, FPS/lag, pengaturan, strategi umum, dan kontrol HP. " +
            "Kamu bisa menjalankan aksi di HP dengan menulis tag di akhir jawaban: " +
            "[[ACT:hud]] (FPS HUD), [[ACT:crosshair]], [[ACT:boost]], [[ACT:clock]], [[ACT:ram]] (bersihkan RAM), " +
            "[[ACT:shot]] (screenshot), [[ACT:launcher]], [[ACT:dnd]] (jangan ganggu), [[ACT:notes]]. " +
            "Pakai tag hanya jika pemain memintanya, dan jangan tulis tag lain. " +
            "Kondisi sekarang: game=${gamePkg ?: fpsPkg ?: "-"}, " +
            "FPS=${if (realFps >= 0) realFps.toString() else "tidak terbaca"}, " +
            "ping=${if (ping >= 0) "$ping ms" else "-"}, RAM ${ramPct()}%, " +
            "suhu baterai ${bt.second}C, baterai ${bt.first}%."
    }

    private fun runAction(name: String) {
        when (name) {
            "hud" -> toggleHud()
            "crosshair" -> toggleCrosshair()
            "boost" -> toggleBoost()
            "clock" -> toggleClock()
            "ram" -> cleanRam()
            "shot" -> takeShot()
            "launcher" -> toggleLauncher()
            "dnd" -> toggleDnd()
            "notes" -> toggleNotes()
        }
    }

    /** Perintah offline. Hanya cocok bila pesan berbentuk perintah (ada kata kerja), supaya pertanyaan biasa tetap ke AI. */
    private fun localCommand(q: String): String? {
        val s = q.lowercase().trim()
        fun has(vararg w: String) = w.any { s.contains(it) }
        if (has("jam berapa", "pukul berapa")) {
            return "Sekarang jam " + SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date()) + "."
        }
        if (s.length > 60) return null
        fun word(w: String) = Regex("\\b$w\\b").containsMatchIn(s)
        val off = has("matikan", "tutup", "nonaktif", "hentikan", "sembunyi")
        val cmd = off || has("nyala", "hidup", "aktif", "tampil", "buka", "pasang", "munculkan", "jalankan", "ambil", "bersihkan", "bersihin", "atur", "mainkan")
        if (!cmd) return null

        if (has("sembunyi", "pergi dulu", "tutup bot", "tutup robot")) {
            main.post { closeRobot() }
            return "Oke, aku pergi dulu. Panggil lagi lewat tab GAME."
        }
        val feature = word("launcher") || has("crosshair", "bidik") || word("hud") || word("fps") ||
            word("monitor") || word("jam") || word("clock") || word("boost") || word("ram") ||
            has("catatan", "stopwatch", "kalkulator", "senter", "screenshot", "jangan ganggu", "performa", "daftar game", "list game")
        val app = Regex("""^(?:tolong )?(?:buka|jalankan|mainkan)\s+(.+)$""").find(s)
        if (app != null && !feature) return openByName(app.groupValues[1])

        if (word("launcher") || has("daftar game", "list game")) { toggleLauncher(); return "Membuka launcher game." }
        if (has("crosshair", "bidik")) {
            if (has("atur", "ubah", "custom", "setelan", "pengaturan")) {
                toggleCrossSettings()
                return "Membuka pengaturan crosshair."
            }
            val want = !off
            if ((crosshair != null) != want) toggleCrosshair()
            return if (want) "Crosshair dipasang." else "Crosshair dimatikan."
        }
        if (word("hud") || word("fps") || word("monitor")) {
            val want = !off
            if ((hud != null) != want) toggleHud()
            return if (want) "FPS HUD aktif." else "FPS HUD dimatikan."
        }
        if (word("jam") || word("clock")) {
            val want = !off
            if ((clockWin != null) != want) toggleClock()
            return if (want) "Jam digital dimunculkan." else "Jam digital ditutup."
        }
        if (word("boost") || has("performa")) { toggleBoost(); return "Boost diubah (butuh Shizuku aktif)." }
        if (word("ram")) { cleanRam(); return "Membersihkan RAM..." }
        if (has("screenshot", "tangkap layar")) { takeShot(); return "Mengambil screenshot." }
        if (has("jangan ganggu")) { toggleDnd(); return "Mode Jangan Ganggu diubah." }
        if (has("catatan")) { toggleNotes(); return "Membuka catatan." }
        if (has("stopwatch")) { toggleStopwatch(); return "Stopwatch diubah." }
        if (has("kalkulator")) { toggleCalc(); return "Membuka kalkulator." }
        if (has("senter")) { toggleTorch(); return "Senter diubah." }
        return null
    }
}
