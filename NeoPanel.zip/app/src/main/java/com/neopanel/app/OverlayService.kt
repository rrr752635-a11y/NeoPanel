package com.neopanel.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.view.Choreographer
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.net.InetSocketAddress
import java.net.Socket

class OverlayService : Service() {

    private lateinit var wm: WindowManager
    private val main = Handler(Looper.getMainLooper())

    private var handle: View? = null
    private var panel: View? = null
    private var crosshair: View? = null
    private var stats: TextView? = null
    private var browser: View? = null
    private var web: WebView? = null

    @Volatile private var running = false
    private var frames = 0
    @Volatile private var ping = -1L
    private var pingThread: Thread? = null

    private val bgTop = 0xFF2A3045.toInt()
    private val bgBottom = 0xFF171A24.toInt()
    private val accent = 0xFF7C5CFF.toInt()
    private val textColor = 0xFFE8EAF6.toInt()

    private val fNoFocus = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
    private val fNoTouch = WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
    private val fLimits = WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
    private val fModal = WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
    private val fOutside = WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        startForeground(1, buildNotification())
        addHandle()
    }

    override fun onDestroy() {
        running = false
        closePanel()
        closeBrowser()
        safeRemove(crosshair); crosshair = null
        safeRemove(stats); stats = null
        safeRemove(handle); handle = null
        super.onDestroy()
    }

    // ---------- util ----------

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun lp(w: Int, h: Int, flags: Int) = WindowManager.LayoutParams(
        w, h, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY, flags, PixelFormat.TRANSLUCENT
    )

    private fun safeRemove(v: View?) {
        if (v == null) return
        try { wm.removeView(v) } catch (e: Exception) { }
    }

    private fun buildNotification(): Notification {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("neo", "NeoPanel", NotificationManager.IMPORTANCE_MIN)
        )
        return Notification.Builder(this, "neo")
            .setContentTitle("NeoPanel aktif")
            .setSmallIcon(android.R.drawable.ic_menu_manage)
            .build()
    }

    private fun neoBg(radius: Int) =
        GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(bgTop, bgBottom)).apply {
            cornerRadius = dp(radius).toFloat()
            setStroke(dp(1), 0x33FFFFFF)
        }

    private fun makeDraggable(dragHandle: View, window: View, p: WindowManager.LayoutParams) {
        var sx = 0f
        var sy = 0f
        var ox = 0
        var oy = 0
        dragHandle.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ox = p.x; oy = p.y }
                MotionEvent.ACTION_MOVE -> {
                    p.x = ox + (e.rawX - sx).toInt()
                    p.y = oy + (e.rawY - sy).toInt()
                    try { wm.updateViewLayout(window, p) } catch (ex: Exception) { }
                }
            }
            true
        }
    }

    // ---------- handle tepi layar ----------

    private fun addHandle() {
        val v = View(this).apply {
            background = GradientDrawable().apply {
                setColor(0x88FFFFFF.toInt())
                cornerRadius = dp(5).toFloat()
            }
        }
        val p = lp(dp(14), dp(120), fNoFocus or fLimits)
        p.gravity = Gravity.END or Gravity.CENTER_VERTICAL

        var start = 0f
        var opened = false
        v.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { start = e.rawX; opened = false }
                MotionEvent.ACTION_MOVE -> {
                    if (!opened && start - e.rawX > dp(30)) { opened = true; showPanel() }
                }
                MotionEvent.ACTION_UP -> {
                    if (!opened && Math.abs(start - e.rawX) < dp(8)) showPanel()
                }
            }
            true
        }
        wm.addView(v, p)
        handle = v
    }

    // ---------- panel ----------

    private fun tile(label: String, active: Boolean, onClick: () -> Unit): TextView =
        TextView(this).apply {
            text = label
            setTextColor(textColor)
            textSize = 13f
            gravity = Gravity.CENTER
            setPadding(dp(8), dp(16), dp(8), dp(16))
            val colors = if (active) intArrayOf(accent, 0xFF5B3FD6.toInt())
            else intArrayOf(0xFF2F354C.toInt(), 0xFF1E2233.toInt())
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR, colors).apply {
                cornerRadius = dp(18).toFloat()
                setStroke(dp(1), 0x22FFFFFF)
            }
            setOnClickListener { onClick() }
        }

    private fun cell() = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        .apply { setMargins(dp(5), dp(5), dp(5), dp(5)) }

    private fun row(a: View, b: View) = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        addView(a, cell())
        addView(b, cell())
    }

    private fun dndOn(): Boolean {
        val nm = getSystemService(NotificationManager::class.java)
        return nm.isNotificationPolicyAccessGranted &&
            nm.currentInterruptionFilter == NotificationManager.INTERRUPTION_FILTER_ALARMS
    }

    private fun showPanel() {
        if (panel != null) return
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(10), dp(10), dp(10), dp(10))
            background = neoBg(28)
        }
        root.addView(TextView(this).apply {
            text = "NeoPanel"
            textSize = 15f
            setTextColor(textColor)
            setPadding(dp(8), dp(4), dp(8), dp(6))
        })
        root.addView(row(
            tile("Crosshair", crosshair != null) { closePanel(); toggleCrosshair() },
            tile("Jangan Ganggu", dndOn()) { closePanel(); toggleDnd() }
        ))
        root.addView(row(
            tile("Browser", browser != null) { closePanel(); toggleBrowser() },
            tile("FPS · Ping", stats != null) { closePanel(); toggleStats() }
        ))
        root.addView(
            tile("Keluar", false) { stopSelf() },
            LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { setMargins(dp(5), dp(5), dp(5), dp(5)) }
        )

        val p = lp(dp(230), WindowManager.LayoutParams.WRAP_CONTENT, fNoFocus or fModal or fOutside)
        p.gravity = Gravity.END or Gravity.CENTER_VERTICAL
        p.x = dp(8)
        root.setOnTouchListener { _, e ->
            if (e.action == MotionEvent.ACTION_OUTSIDE) { closePanel(); true } else false
        }
        wm.addView(root, p)
        panel = root
    }

    private fun closePanel() {
        safeRemove(panel)
        panel = null
    }

    // ---------- crosshair ----------

    private fun toggleCrosshair() {
        if (crosshair != null) {
            safeRemove(crosshair)
            crosshair = null
            return
        }
        val v = object : View(this) {
            val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = 0xFF00FF88.toInt()
                strokeWidth = dp(2).toFloat()
                style = Paint.Style.STROKE
            }

            override fun onDraw(canvas: Canvas) {
                val cx = width / 2f
                val cy = height / 2f
                val gap = dp(4).toFloat()
                val len = dp(12).toFloat()
                canvas.drawLine(cx - gap - len, cy, cx - gap, cy, paint)
                canvas.drawLine(cx + gap, cy, cx + gap + len, cy, paint)
                canvas.drawLine(cx, cy - gap - len, cx, cy - gap, paint)
                canvas.drawLine(cx, cy + gap, cx, cy + gap + len, paint)
            }
        }
        val p = lp(dp(48), dp(48), fNoFocus or fNoTouch or fLimits)
        p.gravity = Gravity.CENTER
        wm.addView(v, p)
        crosshair = v
    }

    // ---------- jangan ganggu ----------

    private fun toggleDnd() {
        val nm = getSystemService(NotificationManager::class.java)
        if (!nm.isNotificationPolicyAccessGranted) {
            Toast.makeText(this, "Beri izin Jangan Ganggu dulu", Toast.LENGTH_LONG).show()
            startActivity(
                Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
            return
        }
        val on = nm.currentInterruptionFilter == NotificationManager.INTERRUPTION_FILTER_ALARMS
        nm.setInterruptionFilter(
            if (on) NotificationManager.INTERRUPTION_FILTER_ALL
            else NotificationManager.INTERRUPTION_FILTER_ALARMS
        )
        Toast.makeText(this, if (on) "Jangan Ganggu mati" else "Jangan Ganggu nyala", Toast.LENGTH_SHORT).show()
    }

    // ---------- FPS / ping / ms ----------

    private val frameCb = object : Choreographer.FrameCallback {
        override fun doFrame(frameTimeNanos: Long) {
            frames++
            if (running) Choreographer.getInstance().postFrameCallback(this)
        }
    }

    private val tick = object : Runnable {
        override fun run() {
            if (!running) return
            val ms = if (ping < 0) "--" else ping.toString()
            stats?.text = "FPS $frames | $ms ms"
            frames = 0
            main.postDelayed(this, 1000)
        }
    }

    private fun toggleStats() {
        if (stats != null) {
            running = false
            safeRemove(stats)
            stats = null
            return
        }
        val t = TextView(this).apply {
            text = "FPS -- | -- ms"
            textSize = 12f
            setTextColor(textColor)
            setPadding(dp(12), dp(6), dp(12), dp(6))
            background = GradientDrawable().apply {
                setColor(0xCC171A24.toInt())
                cornerRadius = dp(14).toFloat()
                setStroke(dp(1), 0x33FFFFFF)
            }
        }
        val p = lp(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT, fNoFocus or fLimits)
        p.gravity = Gravity.TOP or Gravity.START
        p.x = dp(12)
        p.y = dp(40)
        makeDraggable(t, t, p)
        wm.addView(t, p)
        stats = t

        running = true
        frames = 0
        Choreographer.getInstance().postFrameCallback(frameCb)
        main.postDelayed(tick, 1000)
        startPing()
    }

    private fun startPing() {
        if (pingThread?.isAlive == true) return
        pingThread = Thread {
            while (running) {
                val t0 = System.nanoTime()
                ping = try {
                    Socket().use { it.connect(InetSocketAddress("1.1.1.1", 443), 1500) }
                    (System.nanoTime() - t0) / 1_000_000
                } catch (e: Exception) {
                    -1L
                }
                try { Thread.sleep(2000) } catch (e: InterruptedException) { return@Thread }
            }
        }.also { it.start() }
    }

    // ---------- browser ----------

    private fun toggleBrowser() {
        if (browser != null) {
            closeBrowser()
            return
        }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(8), dp(8), dp(8), dp(8))
            background = neoBg(22)
        }

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(6), dp(4), dp(6), dp(6))
        }
        val title = TextView(this).apply {
            text = "Browser  (tahan untuk geser)"
            textSize = 12f
            setTextColor(textColor)
        }
        val close = TextView(this).apply {
            text = "✕"
            textSize = 16f
            setTextColor(textColor)
            setPadding(dp(12), 0, dp(4), 0)
            setOnClickListener { closeBrowser() }
        }
        header.addView(title, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        header.addView(close)

        val urlBox = EditText(this).apply {
            hint = "Cari atau ketik alamat"
            setHintTextColor(0xFF7A8099.toInt())
            setTextColor(textColor)
            textSize = 13f
            isSingleLine = true
            imeOptions = EditorInfo.IME_ACTION_GO
        }

        val wv = WebView(this).apply {
            settings.javaScriptEnabled = true
            webViewClient = WebViewClient()
            loadUrl("https://www.google.com")
        }
        web = wv

        urlBox.setOnEditorActionListener { v, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_GO) {
                var u = v.text.toString().trim()
                if (!u.startsWith("http")) {
                    u = if (u.contains(".") && !u.contains(" ")) "https://$u"
                    else "https://www.google.com/search?q=" + Uri.encode(u)
                }
                wv.loadUrl(u)
                true
            } else false
        }

        root.addView(header)
        root.addView(urlBox)
        root.addView(wv, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))

        val p = lp(dp(300), dp(380), fModal or fLimits)
        p.gravity = Gravity.TOP or Gravity.START
        p.x = dp(20)
        p.y = dp(80)
        p.softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN
        makeDraggable(header, root, p)
        wm.addView(root, p)
        browser = root
    }

    private fun closeBrowser() {
        web?.destroy()
        web = null
        safeRemove(browser)
        browser = null
    }
}
