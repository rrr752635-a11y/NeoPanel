package com.neopanel.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.view.MotionEvent
import android.view.View

/** Canvas gambar bebas yang simpel: satu warna aktif, satu ketebalan, tanpa riwayat undo. */
class DoodleView(ctx: Context) : View(ctx) {
    var color = Color.WHITE
    var strokeWidth = 8f
    private var bmp: Bitmap? = null
    private var canvas: Canvas? = null
    private val path = Path()
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    private var lastX = 0f
    private var lastY = 0f

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        if (w <= 0 || h <= 0) return
        val old = bmp
        val fresh = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(fresh)
        c.drawColor(0xFF14161F.toInt())
        if (old != null) c.drawBitmap(old, 0f, 0f, null)
        bmp = fresh
        canvas = c
    }

    fun clear() {
        canvas?.drawColor(0xFF14161F.toInt())
        invalidate()
    }

    fun snapshot(): Bitmap? = bmp?.copy(Bitmap.Config.ARGB_8888, false)

    override fun onTouchEvent(e: MotionEvent): Boolean {
        val x = e.x
        val y = e.y
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                path.reset()
                path.moveTo(x, y)
                lastX = x
                lastY = y
            }
            MotionEvent.ACTION_MOVE -> {
                path.quadTo(lastX, lastY, (x + lastX) / 2f, (y + lastY) / 2f)
                lastX = x
                lastY = y
            }
            MotionEvent.ACTION_UP -> {
                path.lineTo(x, y)
                paint.color = color
                paint.strokeWidth = strokeWidth
                canvas?.drawPath(path, paint)
                path.reset()
            }
        }
        invalidate()
        return true
    }

    override fun onDraw(c: Canvas) {
        val b = bmp ?: return
        c.drawBitmap(b, 0f, 0f, null)
        if (!path.isEmpty) {
            paint.color = color
            paint.strokeWidth = strokeWidth
            c.drawPath(path, paint)
        }
    }
}
