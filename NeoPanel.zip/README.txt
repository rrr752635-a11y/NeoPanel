VeXed - game overlay toolkit
1. Unggah NeoPanel.zip ini ke repo GitHub (nama file tetap), build otomatis jalan.
2. Unduh APK dari Artifacts, pasang di atas versi lama (package sama).
3. Buka VeXed: beri izin overlay, tekan "Hubungkan Shizuku" (Shizuku harus aktif), lalu "Mulai VeXed".
