VeXed - game overlay toolkit
1. Unggah NeoPanel.zip ini ke repo GitHub (nama file tetap), build otomatis jalan.
2. Unduh APK dari Artifacts, pasang di atas versi lama (package sama).
3. Buka VeXed: beri izin overlay, tekan "Hubungkan Shizuku" (Shizuku harus aktif), lalu "Mulai VeXed".

v5: crosshair kustom (bentuk, warna, ukuran, geser), Game Launcher, jam digital, robot asisten AI,
FPS real-time (500 ms), perbaikan glitch buka-tutup panel.
Asisten AI: buka aplikasi VeXed > "Atur kunci API & model robot" lalu isi kunci API.
Tanpa kunci, robot tetap bisa perintah dasar (hud, crosshair, jam, boost, buka <game>).

v5.1: dukungan API OpenAI-compatible (preset BangunWeb Router), voice changer, animasi panel/launcher.
Voice changer: beri izin mikrofon lewat tombol di aplikasi VeXed. Suara hanya diputar di HP (pakai headset).

v5.2: robot lebih aktif (putar, lompat, joget, melambai), dialog robot ikut saat digeser,
robot bisa melihat layar (screenshot via Shizuku) + cari info Wikipedia, penerjemah (teks & layar),
booster tambahan (Mode Game, Refresh Maks, Terang Maks, Bersihkan Cache), soundboard 16 suara,
voice changer 12 efek + meter + putar ulang, animasi launcher baru.
Melihat layar & terjemah layar butuh Shizuku aktif dan model AI yang mendukung gambar.

v5.3: Gemini (AI Studio) jadi default, resize jendela (tarik sudut kanan-bawah), ukuran robot bisa diatur,
musik YouTube (Data API v3 + pemutar IFrame), tombol Salin di chat bot.
Isi kunci Gemini dan kunci YouTube lewat aplikasi VeXed > Atur kunci API.

v6.0 FINAL: robot kini karakter anime (Vex), tema Flame, header panel baru dengan avatar dan chip status,
menu radial (tahan robot), profil per game (tahan game di launcher), suara Vex (TTS) dan input suara,
potret karakter di animasi launcher, avatar di chat, gaya bicara & tampilan robot bisa diganti di Pengaturan.

v6.1: tata letak aplikasi baru (Beranda, Launcher, Pandu, Pengaturan), launcher grid dengan riwayat dan favorit,
YouTube melayang tanpa API (menggantikan musik berbasis API), game bisa diluncurkan dari layar utama.
Rencana berikutnya: Kunci Aplikasi dan AI VeXed.

v7.0: Kunci Aplikasi (PIN + sidik jari, semua aplikasi dikunci kecuali yang dibebaskan, lewat layanan aksesibilitas),
VeXed AI bawaan (asisten lokal tanpa kunci API, jadi default bila kunci kosong), waktu layar harian.
Aktifkan layanan: Pengaturan sistem > Aksesibilitas > Kunci Aplikasi VeXed.

v7.1: tombol "Izinkan pengaturan terbatas" di tab Kunci untuk mengatasi toggle Aksesibilitas yang
tidak bisa ditekan pada APK sideload (pembatasan Android, dijelaskan juga di Pandu).
VeXed AI bawaan diupgrade: pencocokan kata lebih akurat, lebih banyak topik, variasi jawaban,
dan mengingat topik terakhir supaya balasan singkat seperti "iya"/"lanjut" tetap nyambung.

v7.2: gambar karakter anime dihapus total (file gambar dan kode pemuatnya). Robot kembali ke
tampilan klasik sebagai default di semua tempat (header, chat, splash launcher, layar kunci).
Pilihan "Anime" di Pengaturan tetap ada tapi sekarang tanpa foto, hanya bentuk geometris bawaan.
