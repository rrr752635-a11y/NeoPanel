NeoPanel - panel jendela mengambang ringan

Cara build tanpa komputer:
1. Buat repo baru di GitHub, upload semua isi folder ini (termasuk folder .github).
2. Buka tab Actions > Build APK > tunggu selesai.
3. Unduh artifact "NeoPanel-APK", ekstrak, pasang app-debug.apk.
4. Buka NeoPanel, beri izin overlay (atau lewat rish: appops set com.neopanel.app SYSTEM_ALERT_WINDOW allow).
5. Tekan "Mulai panel", lalu geser dari tepi kanan layar.
