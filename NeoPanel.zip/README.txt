VeXed - game overlay toolkit
1. Unggah NeoPanel.zip ini ke repo GitHub (nama file tetap), build otomatis jalan.
2. Unduh APK dari Artifacts, pasang di atas versi lama (package sama).
3. Buka VeXed: beri izin overlay, tekan "Hubungkan Shizuku" (Shizuku harus aktif), lalu "Mulai VeXed".

v5: crosshair kustom (bentuk, warna, ukuran, geser), Game Launcher, jam digital, robot asisten AI,
FPS real-time (500 ms), perbaikan glitch buka-tutup panel.
Asisten AI: buka aplikasi VeXed > "Atur kunci API & model robot" lalu isi kunci API.
Tanpa kunci, robot tetap bisa perintah dasar (hud, crosshair, jam, boost, buka <game>).

v5.1: dukungan API OpenAI-compatible (preset BangunWeb Router), voice changer, animasi panel/launcher.
Voice changer: beri izin mikrofon lewat tombol di aplikasi VeXed. Suara hanya diputar di HP (pakai headset).

v5.2: robot lebih aktif (putar, lompat, joget, melambai), dialog robot ikut saat digeser,
robot bisa melihat layar (screenshot via Shizuku) + cari info Wikipedia, penerjemah (teks & layar),
booster tambahan (Mode Game, Refresh Maks, Terang Maks, Bersihkan Cache), soundboard 16 suara,
voice changer 12 efek + meter + putar ulang, animasi launcher baru.
Melihat layar & terjemah layar butuh Shizuku aktif dan model AI yang mendukung gambar.

v5.3: Gemini (AI Studio) jadi default, resize jendela (tarik sudut kanan-bawah), ukuran robot bisa diatur,
musik YouTube (Data API v3 + pemutar IFrame), tombol Salin di chat bot.
Isi kunci Gemini dan kunci YouTube lewat aplikasi VeXed > Atur kunci API.

v6.0 FINAL: robot kini karakter anime (Vex), tema Flame, header panel baru dengan avatar dan chip status,
menu radial (tahan robot), profil per game (tahan game di launcher), suara Vex (TTS) dan input suara,
potret karakter di animasi launcher, avatar di chat, gaya bicara & tampilan robot bisa diganti di Pengaturan.

v6.1: tata letak aplikasi baru (Beranda, Launcher, Pandu, Pengaturan), launcher grid dengan riwayat dan favorit,
YouTube melayang tanpa API (menggantikan musik berbasis API), game bisa diluncurkan dari layar utama.
Rencana berikutnya: Kunci Aplikasi dan AI VeXed.

v7.0: Kunci Aplikasi (PIN + sidik jari, semua aplikasi dikunci kecuali yang dibebaskan, lewat layanan aksesibilitas),
VeXed AI bawaan (asisten lokal tanpa kunci API, jadi default bila kunci kosong), waktu layar harian.
Aktifkan layanan: Pengaturan sistem > Aksesibilitas > Kunci Aplikasi VeXed.

v7.1: tombol "Izinkan pengaturan terbatas" di tab Kunci untuk mengatasi toggle Aksesibilitas yang
tidak bisa ditekan pada APK sideload (pembatasan Android, dijelaskan juga di Pandu).
VeXed AI bawaan diupgrade: pencocokan kata lebih akurat, lebih banyak topik, variasi jawaban,
dan mengingat topik terakhir supaya balasan singkat seperti "iya"/"lanjut" tetap nyambung.

v7.2: gambar karakter anime dihapus total (file gambar dan kode pemuatnya). Robot kembali ke
tampilan klasik sebagai default di semua tempat (header, chat, splash launcher, layar kunci).
Pilihan "Anime" di Pengaturan tetap ada tapi sekarang tanpa foto, hanya bentuk geometris bawaan.

v8.0: tahap 1 dari rencana GUI baru — tema "Liquid Glass". Semua jendela melayang (panel, chat,
launcher, pengaturan, voice changer, dll) dan kartu/tombol/header di aplikasi VeXed sekarang
berbentuk kaca buram dengan kilau tipis, bukan kotak solid. Di Android 12 ke atas, latar di
BELAKANG jendela ikut diburamkan sungguhan (FLAG_BLUR_BEHIND); bisa dimatikan di Pengaturan
("Kaca buram") kalau terasa berat. HUD, robot, jam, dan crosshair sengaja TIDAK ikut diburamkan
supaya tetap tajam dan cepat dibaca saat main. Tahap berikutnya: Launcher Home, lalu Game Turbo.

v8.1: perbaikan BUG kunci aplikasi -- setelah PIN/sidik jari benar, kadang diminta ulang.
Penyebabnya event sistem ganda yang membuat layar kunci reset input; sekarang ada debounce dan
layar kunci tidak lagi menghapus PIN yang sedang diketik kalau targetnya aplikasi yang sama.
Layar kunci dirombak: diposisikan di tengah layar, tombol angka bergaya kaca (Liquid Glass),
tombol sidik jari terpisah dan jelas, ada efek tekan di tiap tombol, animasi badge centang hijau
dan getar singkat saat berhasil. Logo VeXed diperhalus dengan gradien dan kilau tipis.

v8.2: fitur Dynamic Island -- pil kaca kecil di atas layar (gaya iPhone), melebar sebentar
menampilkan ikon + teks saat ada kejadian (Boost, Mode Game, mulai/selesai rekam, screenshot,
bersihkan RAM, peringatan FPS/suhu/RAM dari Vex), lalu ciut lagi. Kalau sedang merekam, Boost,
atau Mode Game aktif, pil kecil menampilkan titik status permanen; ketuk untuk melihat detailnya,
atau ketuk saat tidak ada status untuk membuka chat Vex. Bisa digeser posisinya, dan diatur lewat
Pengaturan (aktif/mati, posisi dari atas). Peringatan Vex sekarang muncul di Island walau robot
belum dipanggil.

v8.3: perbaikan -- Dynamic Island sekarang langsung muncul begitu VeXed dijalankan (sebelumnya baru
muncul setelah kejadian pertama seperti Boost dinyalakan, jadi terlihat seperti tidak aktif).

v8.4:
- Perbaikan MENDASAR bug Kunci Aplikasi minta PIN/sidik jari dua kali. Model lama (penanda "0 = di
  dalam" + debounce 700ms) diganti model "berlaku sampai jam berapa" yang jauh lebih tahan terhadap
  event sistem ganda, plus pengecekan dua lapis di layar PIN sendiri sebelum menampilkan apa pun.
- Dynamic Island dipoles: getar halus dan animasi ikon "pop" tiap kali status berganti, timer rekam
  yang jalan terus (bukan sekadar cuplikan) selama ditekan, dan sapaan singkat "VeXed aktif" begitu
  layanan pertama kali dijalankan.

v9.0: Era GUI baru -- "Flat Minimal" (datar, bersih, tipografi besar) hadir sebagai pilihan gaya
tampilan baru, berdampingan dengan Liquid Glass (tidak dihapus). Default untuk pemasangan baru
sekarang Flat Minimal. Ganti kapan saja lewat Pengaturan (panel melayang) atau tab Setelan di
aplikasi VeXed, bagian "GAYA TAMPILAN". Mencakup semua jendela melayang, panel utama, Dynamic
Island, serta kartu/tombol/header di aplikasi VeXed. Jendela yang sudah terbuka perlu dibuka ulang
untuk ikut berubah gaya.

v9.1: unduh TikTok tanpa watermark lewat chat Vex (tempel link-nya), generate gambar AI (Gemini,
"buatkan gambar ..."), kirim foto/video terbaru dari galeri ("kirim foto"/"kirim video"), Canvas
gambar bebas di chat, ringkasan notifikasi WhatsApp + draft balasan yang HARUS kamu tekan Kirim
sendiri (tidak pernah otomatis terkirim), dan perintah "izinkan floating window untuk <aplikasi>"
lewat Shizuku. Izin baru (galeri, notifikasi) diatur di tab Setelan aplikasi VeXed.
