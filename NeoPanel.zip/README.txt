VeXed - game overlay toolkit
1. Unggah NeoPanel.zip ini ke repo GitHub (nama file tetap), build otomatis jalan.
2. Unduh APK dari Artifacts, pasang di atas versi lama (package sama).
3. Buka VeXed: beri izin overlay, tekan "Hubungkan Shizuku" (Shizuku harus aktif), lalu "Mulai VeXed".

v5: crosshair kustom (bentuk, warna, ukuran, geser), Game Launcher, jam digital, robot asisten AI,
FPS real-time (500 ms), perbaikan glitch buka-tutup panel.
Asisten AI: buka aplikasi VeXed > "Atur kunci API & model robot" lalu isi kunci API.
Tanpa kunci, robot tetap bisa perintah dasar (hud, crosshair, jam, boost, buka <game>).

v5.1: dukungan API OpenAI-compatible (preset BangunWeb Router), voice changer, animasi panel/launcher.
Voice changer: beri izin mikrofon lewat tombol di aplikasi VeXed. Suara hanya diputar di HP (pakai headset).
